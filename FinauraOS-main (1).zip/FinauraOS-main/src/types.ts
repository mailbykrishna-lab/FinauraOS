export type UserPersona = 'freelancer' | 'startup' | 'msme' | 'agency';

export type AuthProvider = 'google' | 'apple' | 'email';

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  provider: AuthProvider;
  isEmailVerified: boolean;
  connectedAccounts: {
    google?: { email: string; connectedAt: string };
    apple?: { email: string; connectedAt: string };
    email?: { email: string; connectedAt: string };
  };
}

export type BusinessType = 'proprietorship' | 'partnership' | 'llp' | 'pvt_ltd' | 'other';

export type GSTStatus = 'registered' | 'unregistered' | 'composition';

export interface BankDetails {
  bankName?: string;
  accountHolderName?: string;
  accountNumber?: string;
  ifscCode?: string;
  branchName?: string;
  accountType?: 'Current' | 'Savings';
  upiId?: string;
}

export interface BusinessProfile {
  businessName: string;
  name?: string;
  businessType: BusinessType;
  industry: string;
  state: string;
  gstStatus: GSTStatus;
  gstin?: string;
  pan?: string;
  persona: UserPersona;
  turnoverRange: string;
  incorporationYear: string;
  contactName: string;
  bankDetails?: BankDetails;
}

export type NavTab = 
  | 'home'
  | 'dashboard'
  | 'finance'
  | 'accounting'
  | 'expenses'
  | 'invoices'
  | 'receivables'
  | 'payables'
  | 'cashflow'
  | 'tax'
  | 'compliance'
  | 'documents'
  | 'ai'
  | 'ask_ai'
  | 'professionals'
  | 'ca_services'
  | 'calendar'
  | 'customers'
  | 'vendors'
  | 'payroll'
  | 'inventory'
  | 'reports'
  | 'integrations'
  | 'settings'
  | 'billing'
  | 'notifications'
  | 'help';

export * from './types/subscription';

export interface CalendarEventItem {
  id: string;
  title: string;
  category: 'tax' | 'compliance' | 'finance' | 'task';
  date: string;
  daysLeft: number;
  status: 'pending' | 'completed' | 'urgent';
  authority?: string;
  amount?: number;
  description: string;
  actionLabel?: string;
}

export interface CustomerItem {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  gstin?: string;
  totalBilled: number;
  outstanding: number;
  status: 'active' | 'overdue' | 'clear';
}

export interface VendorItem {
  id: string;
  name: string;
  category: string;
  isMsme: boolean;
  msmeCategory?: 'Micro' | 'Small' | 'Medium';
  udyamNo?: string;
  pendingAmount: number;
  dueDate: string;
  daysRemaining: number;
  section43BStatus: 'safe' | 'warning' | 'critical_disallowed';
}

export interface PayrollItem {
  id: string;
  employeeName: string;
  designation: string;
  pan: string;
  grossSalary: number;
  tdsDeducted: number;
  epfDeducted: number;
  netPayable: number;
  status: 'processed' | 'pending';
}

export interface InventoryItem {
  id: string;
  sku: string;
  name: string;
  category: string;
  quantity: number;
  reorderLevel: number;
  unitPrice: number;
  totalValue: number;
  status: 'in_stock' | 'low_stock' | 'out_of_stock';
}

export type ViewPeriod = 'daily' | 'weekly' | 'monthly';

export interface Transaction {
  id: string;
  date: string;
  vendor: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
  suggestedCategory: string;
  userCategory?: string;
  confidence: number;
  status: 'approved' | 'needs_review' | 'skipped';
  whyNeedsReview?: string;
  whatHappensNext?: string;
  taxDeductible?: boolean;
  gstEligible?: boolean;
  sourceFileName?: string;
  sourceDocumentId?: string;
  bankName?: string;
  accountNumberMasked?: string;
  statementPeriod?: string;
  fileChecksum?: string;
  fileBufferId?: string;
}

export interface InvoiceItem {
  description: string;
  quantity: number;
  rate: number;
  gstRate: number;
  amount: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  clientName: string;
  clientGstin?: string;
  clientEmail: string;
  date: string;
  dueDate: string;
  items: InvoiceItem[];
  subtotal: number;
  gstAmount: number;
  total: number;
  status: 'draft' | 'sent' | 'paid' | 'overdue';
}

export interface ExpenseCategorySummary {
  category: string;
  amount: number;
  percentage: number;
  previousMonthAmount: number;
  changePercentage: number;
  color: string;
}

export interface ComplianceAction {
  id: string;
  title: string;
  category: 'GST' | 'TDS' | 'Income Tax' | 'MCA' | 'FEMA';
  authority: string;
  dueDate: string;
  daysLeft: number;
  status: 'pending' | 'in_progress' | 'completed';
  priority: 'urgent' | 'important' | 'upcoming';
  description: string;
  whatChanged: string;
  doesItAffectMe: string;
  whatShouldIDo: string[];
  source: string;
  circularNo: string;
  penaltyRisk?: string;
}

export interface GovernmentUpdate {
  id: string;
  title: string;
  authority: 'CBIC - GST' | 'CBDT - Income Tax' | 'MCA' | 'RBI Guidelines';
  date: string;
  circularNo: string;
  relevance: 'high' | 'medium' | 'low';
  impactTarget: string;
  summary: string;
  whatChangedOld: string;
  whatChangedNew: string;
  doesItAffectExplanation: string;
  actionSteps: {
    step: number;
    title: string;
    description: string;
  }[];
  officialSourceUrl: string;
}

export interface DocumentItem {
  id: string;
  name: string;
  category: 'Bank Statement' | 'GST Returns' | 'Expense Bills' | 'PAN/KYC' | 'Board Resolution';
  period: string;
  status: 'verified' | 'pending' | 'missing' | 'error';
  whyNeeded?: string;
  whatHappensNext?: string;
  fileSize?: string;
  size?: string;
  uploadedAt?: string;
  errorReason?: string;
  extractedItemsCount?: number;
}

export type UploadedDoc = DocumentItem;

export interface CAProfessional {
  id: string;
  name: string;
  photoUrl: string;
  membershipNo: string;
  firmName: string;
  experienceYears: number;
  rating: number;
  reviewsCount: number;
  specialties: string[];
  city: string;
  whyFit: string;
  turnaroundTime: string;
  feeEstimate: string;
}

export type CAServiceStep = 
  | 'requested'
  | 'assigned'
  | 'documents'
  | 'review'
  | 'in_progress'
  | 'client_review'
  | 'completed';

export interface CAServiceRequest {
  id: string;
  serviceName: string;
  caName: string;
  caPhoto: string;
  currentStep: CAServiceStep;
  progressPercent: number;
  whereAmI: string;
  whatsNext: string;
  whoIsResponsible: 'You (Client)' | 'CA Krishna Singhania' | 'Government Portal';
  requestedAt: string;
  estimatedCompletion: string;
  unreadMessagesCount: number;
}

export interface NextBestActionItem {
  page: NavTab;
  title: string;
  subtitle: string;
  urgency: 'high' | 'medium' | 'normal';
  whyAmISeeingThis: string;
  whatShouldIDo: string;
  whatHappensNext: string;
  actionLabel: string;
  onClickAction: () => void;
}

export interface FeatureIntro {
  id: string;
  title: string;
  badge: string;
  headline: string;
  description: string;
  whatChanged: string;
  doesItAffectMe: string;
  whatShouldIDo: string;
  source: string;
}
