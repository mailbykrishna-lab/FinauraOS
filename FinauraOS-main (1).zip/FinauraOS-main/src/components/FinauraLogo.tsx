import React from 'react';

interface FinauraLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | number;
  showWordmark?: boolean;
  wordmarkClassName?: string;
  subtitle?: string;
  className?: string;
  variant?: 'color' | 'monochrome' | 'white';
  theme?: 'light' | 'dark';
}

export const FinauraLogoMark: React.FC<{ size?: number; className?: string; variant?: 'color' | 'monochrome' | 'white' }> = ({
  size = 32,
  className = '',
  variant = 'color',
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`shrink-0 ${className}`}
      aria-label="Finaura Logo"
    >
      <defs>
        {/* Main vibrant blue gradient */}
        <linearGradient id="finaura-blue-primary" x1="12" y1="14" x2="88" y2="86" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#60A5FA" />
          <stop offset="35%" stopColor="#3B82F6" />
          <stop offset="70%" stopColor="#2563EB" />
          <stop offset="100%" stopColor="#1D4ED8" />
        </linearGradient>

        {/* Top wing accent gradient with electric cyan highlight */}
        <linearGradient id="finaura-top-wing" x1="20" y1="12" x2="90" y2="38" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#93C5FD" />
          <stop offset="45%" stopColor="#3B82F6" />
          <stop offset="100%" stopColor="#1E40AF" />
        </linearGradient>

        {/* Inner shadow / depth gradient */}
        <linearGradient id="finaura-stem-depth" x1="18" y1="20" x2="42" y2="88" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#38BDF8" />
          <stop offset="50%" stopColor="#2563EB" />
          <stop offset="100%" stopColor="#1E3A8A" />
        </linearGradient>

        {/* Glow filter for high fidelity look */}
        <filter id="finaura-glow" x="-10%" y="-10%" width="120%" height="120%" filterUnits="userSpaceOnUse">
          <feDropShadow dx="0" dy="2" stdDeviation="2.5" floodColor="#1D4ED8" floodOpacity="0.25" />
        </filter>
      </defs>

      {variant === 'color' ? (
        <g filter="url(#finaura-glow)">
          {/* Vertical Stem - Dynamic forward angled curve */}
          <path
            d="M 22 18 
               C 22 15, 25 13, 31 13
               L 42 13
               C 44.5 13, 46 14.8, 45.5 17.5
               L 33.5 81
               C 33 84.5, 30.5 87, 26 87
               L 20.5 87
               C 17.5 87, 16 85, 16.5 82
               Z"
            fill="url(#finaura-stem-depth)"
          />

          {/* Top Aerodynamic Wing Ribbon of 'F' */}
          <path
            d="M 26 14
               L 76 14
               C 83.5 14, 88.5 19, 87.5 25.5
               C 86.5 32, 80.5 36.5, 73 36.5
               L 38 36.5
               C 34.5 36.5, 33 34.5, 33.5 31
               L 35.5 20
               C 36 16.5, 33 14, 26 14
               Z"
            fill="url(#finaura-top-wing)"
          />

          {/* Top highlight glint */}
          <path
            d="M 36 16
               L 74 16
               C 79 16, 83 19, 82.5 23
               C 82 25, 79 26.5, 74 26.5
               L 37 26.5
               C 34.5 26.5, 34 24.5, 34.5 22
               Z"
            fill="#FFFFFF"
            fillOpacity="0.35"
          />

          {/* Middle Crossbar Ribbon */}
          <path
            d="M 33 46
               L 63 46
               C 68.5 46, 72 49.5, 71 54.5
               C 70 59.5, 65.5 62.5, 60 62.5
               L 29.5 62.5
               C 27.5 62.5, 26.5 60.5, 27 58
               L 28.5 50
               C 29 47.5, 31 46, 33 46
               Z"
            fill="url(#finaura-blue-primary)"
          />
        </g>
      ) : variant === 'white' ? (
        <g fill="#FFFFFF">
          <path d="M 22 18 C 22 15, 25 13, 31 13 L 42 13 C 44.5 13, 46 14.8, 45.5 17.5 L 33.5 81 C 33 84.5, 30.5 87, 26 87 L 20.5 87 C 17.5 87, 16 85, 16.5 82 Z" />
          <path d="M 26 14 L 76 14 C 83.5 14, 88.5 19, 87.5 25.5 C 86.5 32, 80.5 36.5, 73 36.5 L 38 36.5 C 34.5 36.5, 33 34.5, 33.5 31 L 35.5 20 C 36 16.5, 33 14, 26 14 Z" opacity="0.95" />
          <path d="M 33 46 L 63 46 C 68.5 46, 72 49.5, 71 54.5 C 70 59.5, 65.5 62.5, 60 62.5 L 29.5 62.5 C 27.5 62.5, 26.5 60.5, 27 58 L 28.5 50 C 29 47.5, 31 46, 33 46 Z" opacity="0.9" />
        </g>
      ) : (
        <g fill="currentColor">
          <path d="M 22 18 C 22 15, 25 13, 31 13 L 42 13 C 44.5 13, 46 14.8, 45.5 17.5 L 33.5 81 C 33 84.5, 30.5 87, 26 87 L 20.5 87 C 17.5 87, 16 85, 16.5 82 Z" />
          <path d="M 26 14 L 76 14 C 83.5 14, 88.5 19, 87.5 25.5 C 86.5 32, 80.5 36.5, 73 36.5 L 38 36.5 C 34.5 36.5, 33 34.5, 33.5 31 L 35.5 20 C 36 16.5, 33 14, 26 14 Z" />
          <path d="M 33 46 L 63 46 C 68.5 46, 72 49.5, 71 54.5 C 70 59.5, 65.5 62.5, 60 62.5 L 29.5 62.5 C 27.5 62.5, 26.5 60.5, 27 58 L 28.5 50 C 29 47.5, 31 46, 33 46 Z" />
        </g>
      )}
    </svg>
  );
};

export const FinauraLogo: React.FC<FinauraLogoProps> = ({
  size = 'md',
  showWordmark = true,
  wordmarkClassName = '',
  subtitle,
  className = '',
  variant = 'color',
  theme = 'light',
}) => {
  const pixelSizes = {
    xs: 20,
    sm: 26,
    md: 32,
    lg: 40,
    xl: 48,
  };

  const pixelSize = typeof size === 'number' ? size : pixelSizes[size] || 32;
  const isDark = theme === 'dark' || variant === 'white';

  return (
    <div className={`inline-flex items-center gap-2.5 ${className}`}>
      <FinauraLogoMark size={pixelSize} variant={variant === 'white' || isDark ? (variant === 'white' ? 'white' : 'color') : variant} />
      
      {showWordmark && (
        <div className="flex flex-col justify-center leading-none">
          <div className="flex items-center gap-1.5">
            <span
              className={`font-geist font-black tracking-tight ${
                isDark ? 'text-white' : 'text-slate-900'
              } ${
                pixelSize <= 24
                  ? 'text-sm'
                  : pixelSize <= 32
                  ? 'text-base'
                  : pixelSize <= 40
                  ? 'text-lg'
                  : 'text-xl'
              } ${wordmarkClassName}`}
            >
              FINAURA
            </span>
          </div>
          {subtitle && (
            <span
              className={`text-xs font-semibold tracking-wide uppercase mt-0.5 ${
                isDark ? 'text-slate-300' : 'text-slate-600'
              }`}
            >
              {subtitle}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
