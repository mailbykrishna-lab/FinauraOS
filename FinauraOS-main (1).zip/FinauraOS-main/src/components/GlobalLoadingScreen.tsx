import React, { useEffect, useState } from 'react';
import { Sparkles, Shield, Database, CheckCircle2, Landmark, RefreshCw } from 'lucide-react';
import { FinauraLogo } from './FinauraLogo';

interface GlobalLoadingScreenProps {
  onComplete?: () => void;
  message?: string;
}

export const GlobalLoadingScreen: React.FC<GlobalLoadingScreenProps> = ({
  onComplete,
  message = 'Initializing Financial OS & Ledger...',
}) => {
  const [stepIndex, setStepIndex] = useState(0);

  const steps = [
    'Connecting to GSTN & Bank Data Pipelines...',
    'Synchronizing Section 31 Invoicing Engine...',
    'Verifying Input Tax Credit (ITC) Offsets...',
    'Generating Daily Briefing & Financial Pulse...',
    'Ready',
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setStepIndex((prev) => {
        if (prev < steps.length - 1) {
          return prev + 1;
        }
        clearInterval(interval);
        return prev;
      });
    }, 280);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900 text-white flex flex-col items-center justify-center p-4">
      {/* Background ambient radial glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(16,185,129,0.15),rgba(255,255,255,0))] pointer-events-none" />

      {/* Main Card */}
      <div className="relative max-w-md w-full bg-slate-950/80 border border-slate-800 rounded-3xl p-8 shadow-2xl backdrop-blur-xl text-center space-y-6 animate-in fade-in zoom-in-95 duration-300">
        
        {/* Animated Brand Header */}
        <div className="flex flex-col items-center space-y-3">
          <div className="relative">
            {/* Spinning Outer Ring */}
            <div className="w-16 h-16 rounded-2xl border-2 border-emerald-500/20 border-t-emerald-500 animate-spin" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center shadow-inner">
                <Sparkles className="w-5 h-5 text-emerald-400 animate-pulse" />
              </div>
            </div>
          </div>

          <div className="pt-2">
            <FinauraLogo size="lg" subtitle="Financial Operating System" />
          </div>
        </div>

        {/* Dynamic Status Display */}
        <div className="space-y-2">
          <div className="text-sm font-semibold text-slate-200 font-sans tracking-wide">
            {message}
          </div>
          <div className="text-xs text-emerald-400 font-mono flex items-center justify-center gap-1.5 min-h-[20px]">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            <span>{steps[stepIndex]}</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-800/80 rounded-full h-1.5 overflow-hidden">
          <div
            className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full transition-all duration-300 ease-out"
            style={{ width: `${((stepIndex + 1) / steps.length) * 100}%` }}
          />
        </div>

        {/* Skeleton Screen Mock Preview Blocks */}
        <div className="pt-2 grid grid-cols-3 gap-2 opacity-35">
          <div className="h-10 bg-slate-800 rounded-xl animate-pulse" />
          <div className="h-10 bg-slate-800 rounded-xl animate-pulse delay-75" />
          <div className="h-10 bg-slate-800 rounded-xl animate-pulse delay-150" />
        </div>

        {/* Footer Security Badge */}
        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-center gap-2 text-[11px] text-slate-500 font-mono">
          <Shield className="w-3.5 h-3.5 text-emerald-500/70" />
          <span>256-Bit Encrypted Indian Financial Cloud</span>
        </div>

      </div>
    </div>
  );
};
