import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  Plus,
  Filter,
  CheckCircle2,
  Clock,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  ShieldAlert,
  Building2,
  FileText,
  IndianRupee,
  Sparkles,
} from 'lucide-react';
import { CalendarEventItem, NavTab } from '../../types';

interface CalendarWorkspaceViewProps {
  events: CalendarEventItem[];
  onOpenAddTask: () => void;
  onNavigate: (tab: NavTab) => void;
  onOpenAI: (prompt?: string) => void;
}

export const CalendarWorkspaceView: React.FC<CalendarWorkspaceViewProps> = ({
  events,
  onOpenAddTask,
  onNavigate,
  onOpenAI,
}) => {
  const [filterCategory, setFilterCategory] = useState<'all' | 'tax' | 'compliance' | 'finance' | 'task'>('all');
  const [currentMonth, setCurrentMonth] = useState('September 2026');

  const filteredEvents = events.filter((e) => {
    if (filterCategory === 'all') return true;
    return e.category === filterCategory;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Top Header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 md:p-6 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                STATUTORY & BUSINESS CALENDAR
              </span>
              <span className="text-xs text-slate-500 font-mono">FY 2026-27</span>
            </div>
            <h1 className="text-xl md:text-2xl font-bold text-slate-900 mt-1">
              Statutory Deadlines & Financial Calendar
            </h1>
            <p className="text-xs text-slate-600 mt-0.5">
              Live tracking of GST, TDS, Section 43B(h) MSME cutoffs, advance tax schedules, and custom business milestones.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onOpenAddTask}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-2xs cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Schedule Milestone</span>
            </button>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 border-t border-slate-200/80 mt-6 pt-3 overflow-x-auto">
          {[
            { id: 'all', label: 'All Statutory & Tasks' },
            { id: 'tax', label: 'Tax & GST/TDS' },
            { id: 'compliance', label: 'MCA & MSME 43B(h)' },
            { id: 'finance', label: 'Advance Tax & Cash' },
            { id: 'task', label: 'Custom Tasks' },
          ].map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setFilterCategory(cat.id as any)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                filterCategory === cat.id
                  ? 'bg-slate-900 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Calendar Grid & Events Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Visual Monthly Calendar Overview */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <CalendarIcon className="w-4 h-4 text-emerald-600" />
              <span>{currentMonth}</span>
            </h3>
            <div className="flex items-center gap-1 text-slate-400">
              <button className="p-1 hover:text-slate-800 rounded">
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button className="p-1 hover:text-slate-800 rounded">
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Mini Calendar Matrix */}
          <div className="grid grid-cols-7 gap-1 text-center text-xs">
            {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
              <span key={i} className="text-slate-400 font-bold py-1">
                {d}
              </span>
            ))}
            {/* Days 1 to 30 with key indicator dots */}
            {Array.from({ length: 30 }).map((_, i) => {
              const day = i + 1;
              const hasUrgent = day === 7 || day === 11 || day === 15;
              const isToday = day === 1;

              return (
                <div
                  key={day}
                  className={`h-9 rounded-lg flex flex-col items-center justify-center relative font-medium transition-all ${
                    isToday
                      ? 'bg-slate-900 text-white font-bold'
                      : hasUrgent
                      ? 'bg-rose-50 text-rose-900 font-bold border border-rose-200'
                      : 'hover:bg-slate-100 text-slate-700'
                  }`}
                >
                  <span>{day}</span>
                  {hasUrgent && !isToday && (
                    <span className="w-1.5 h-1.5 bg-rose-600 rounded-full absolute bottom-1" />
                  )}
                </div>
              );
            })}
          </div>

          <div className="pt-3 border-t border-slate-100 space-y-2 text-xs">
            <div className="flex items-center justify-between text-slate-600">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                <span>Statutory Tax Due Date</span>
              </div>
              <span className="font-bold text-slate-900">3 Upcoming</span>
            </div>
            <div className="flex items-center justify-between text-slate-600">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <span>Working Capital Action</span>
              </div>
              <span className="font-bold text-slate-900">2 Actions</span>
            </div>
          </div>
        </div>

        {/* Detailed Event Cards List */}
        <div className="lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">
              Upcoming Deadlines ({filteredEvents.length})
            </h3>
            <button
              type="button"
              onClick={() => onOpenAI('Give me a 3-point checklist for this week statutory deadlines.')}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" /> AI Deadline Strategy
            </button>
          </div>

          <div className="space-y-3">
            {filteredEvents.length === 0 ? (
              <div className="p-8 bg-white border border-slate-200 rounded-xl text-center">
                <CalendarIcon className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <div className="text-sm font-bold text-slate-800">NO DEADLINES SCHEDULED</div>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-4">
                  You have no pending tax or statutory compliance deadlines for this filter. Add your own custom task or reminder.
                </p>
                <button
                  type="button"
                  onClick={onOpenAddTask}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg cursor-pointer inline-flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Task
                </button>
              </div>
            ) : (
              filteredEvents.map((ev) => (
              <div
                key={ev.id}
                className="p-4 bg-white border border-slate-200 rounded-xl shadow-2xs hover:border-slate-300 transition-all space-y-2"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                        ev.category === 'tax' ? 'bg-blue-100 text-blue-800' :
                        ev.category === 'compliance' ? 'bg-rose-100 text-rose-800' :
                        ev.category === 'finance' ? 'bg-emerald-100 text-emerald-800' :
                        'bg-slate-100 text-slate-800'
                      }`}>
                        {ev.category}
                      </span>
                      {ev.authority && (
                        <span className="text-[11px] text-slate-500 font-medium">
                          {ev.authority}
                        </span>
                      )}
                    </div>
                    <h4 className="text-sm font-bold text-slate-900 mt-1">{ev.title}</h4>
                  </div>

                  <div className="text-right shrink-0">
                    <span className={`text-xs font-extrabold px-2.5 py-1 rounded-full ${
                      ev.daysLeft <= 5 ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {ev.daysLeft <= 0 ? 'Due Today' : `In ${ev.daysLeft} Days`}
                    </span>
                    <div className="text-[10px] text-slate-400 mt-1 font-mono">{ev.date}</div>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">{ev.description}</p>

                {ev.amount && (
                  <div className="text-xs font-bold text-slate-800">
                    Estimated Outflow / Liability: <span className="text-emerald-700">₹{ev.amount.toLocaleString('en-IN')}</span>
                  </div>
                )}

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500">Status: <strong className="text-slate-800 capitalize">{ev.status}</strong></span>
                  {ev.actionLabel && (
                    <button
                      type="button"
                      onClick={() => {
                        if (ev.category === 'tax') onNavigate('tax');
                        else if (ev.category === 'compliance') onNavigate('compliance');
                        else onNavigate('finance');
                      }}
                      className="text-xs font-bold text-emerald-700 hover:text-emerald-800 cursor-pointer"
                    >
                      {ev.actionLabel} →
                    </button>
                  )}
                </div>
              </div>
            )))}
          </div>
        </div>
      </div>
    </div>
  );
};
