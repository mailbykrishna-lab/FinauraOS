import React, { useState } from 'react';
import {
  Sparkles,
  TrendingUp,
  AlertTriangle,
  ArrowRight,
  HelpCircle,
  CreditCard,
  PieChart,
  Layers,
  Building2,
  ChevronRight,
  Info,
} from 'lucide-react';
import { ExpenseCategorySummary, NavTab, Transaction } from '../../types';
import { NextBestAction } from '../NextBestAction';
import { ExplainWhyCard } from '../ExplainWhyCard';
import { ContextTooltip } from '../ContextTooltip';

interface ExpensesViewProps {
  expenses?: ExpenseCategorySummary[];
  expensesSummary?: ExpenseCategorySummary[];
  transactions?: Transaction[];
  onNavigate?: (tab: NavTab) => void;
  onOpenAI?: (prompt?: string) => void;
}

export const ExpensesView: React.FC<ExpensesViewProps> = ({
  expenses: propExpenses,
  expensesSummary,
  transactions = [],
  onNavigate,
  onOpenAI,
}) => {
  // Compute real expense summaries from transactions if not explicitly passed
  const computedExpenses: ExpenseCategorySummary[] = React.useMemo(() => {
    if (propExpenses && propExpenses.length > 0) return propExpenses;
    if (expensesSummary && expensesSummary.length > 0) return expensesSummary;

    const debitTxs = (transactions || []).filter((t) => t.type === 'debit');
    if (debitTxs.length === 0) return [];

    const totalDebit = debitTxs.reduce((sum, t) => sum + (t.amount || 0), 0);
    const categoryMap = new Map<string, number>();

    debitTxs.forEach((t) => {
      const cat = t.userCategory || t.suggestedCategory || 'General Expense';
      categoryMap.set(cat, (categoryMap.get(cat) || 0) + (t.amount || 0));
    });

    const palette = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4'];
    let idx = 0;

    const result: ExpenseCategorySummary[] = [];
    categoryMap.forEach((amount, category) => {
      result.push({
        category,
        amount,
        percentage: totalDebit > 0 ? Math.round((amount / totalDebit) * 100) : 0,
        changePercentage: 0,
        previousMonthAmount: amount,
        color: palette[idx % palette.length],
      });
      idx++;
    });

    return result.sort((a, b) => b.amount - a.amount);
  }, [propExpenses, expensesSummary, transactions]);

  const expenses = computedExpenses;
  const totalExpense = expenses.reduce((sum, item) => sum + (item.amount || 0), 0);

  const [selectedCategory, setSelectedCategory] = useState<string | null>(
    expenses.length > 0 ? expenses[0].category : null
  );

  const activeCategoryTxs = (transactions || []).filter((t) => {
    if (!selectedCategory) return false;
    const cat = t.userCategory || t.suggestedCategory || 'General Expense';
    return t.type === 'debit' && cat === selectedCategory;
  });

  const activeCategoryVendors = Array.from(
    new Set(activeCategoryTxs.map((t) => t.vendor).filter(Boolean))
  );

  const selectedCategorySummary = expenses.find((e) => e.category === selectedCategory);
  const selectedAmount = selectedCategorySummary?.amount || 0;
  const estimatedITC = Math.round(selectedAmount * 0.18);

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Header */}
      <div>
        <span className="text-xs font-bold text-slate-600 uppercase tracking-wider font-geist">
          SPEND CLARITY &amp; RUNWAY
        </span>
        <h1 className="text-2xl md:text-3xl font-black text-slate-900 font-geist tracking-tight mt-0.5">
          WHERE IS YOUR MONEY GOING?
        </h1>
        <p className="text-sm text-slate-600 mt-0.5">
          Track cash outflow by category, identify subscription drift, and maximize tax-deductible claims.
        </p>
      </div>

      {/* If No Expenses Exist */}
      {expenses.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 md:p-12 text-center border border-slate-200 shadow-sm space-y-4">
          <div className="w-14 h-14 bg-slate-100 text-slate-700 rounded-full flex items-center justify-center mx-auto border border-slate-200">
            <PieChart className="w-7 h-7" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 font-geist">
            NO EXPENSES RECORDED YET
          </h3>
          <p className="text-xs md:text-sm text-slate-600 max-w-md mx-auto">
            Once you import bank statements or record business transactions, Finaura will automatically group expenses by statutory category, identify subscription anomalies, and calculate Section 37(1) tax deductions.
          </p>
          <div className="pt-2">
            <button
              onClick={() => onNavigate && onNavigate('accounting')}
              className="bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold py-3 px-6 rounded-xl inline-flex items-center gap-2 shadow-sm transition-all cursor-pointer"
            >
              <span>GO TO TRANSACTIONS LEDGER</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* Top Spend Insight */}
          <div className="bg-white border-l-4 border-l-slate-900 border border-slate-200 rounded-2xl p-5 md:p-6 shadow-sm relative overflow-hidden space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-slate-700" />
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider font-geist">
                    SPEND INTELLIGENCE
                  </span>
                </div>
                <h2 className="text-lg md:text-xl font-bold text-slate-900 font-geist">
                  Top spend category: {expenses[0]?.category} (₹{expenses[0]?.amount.toLocaleString('en-IN')})
                </h2>
                <p className="text-xs text-slate-600 max-w-2xl leading-relaxed">
                  Accounts for {expenses[0]?.percentage}% of total operating expenditures across {activeCategoryVendors.length || 1} vendor(s).
                </p>
              </div>

              <button
                onClick={() => onOpenAI && onOpenAI(`Review our expense distribution and suggest tax-saving optimizations`)}
                className="bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold py-2.5 px-5 rounded-xl flex items-center justify-center gap-1.5 shadow-sm transition-all whitespace-nowrap self-start md:self-auto cursor-pointer"
              >
                <span>AI OPTIMIZE SPEND</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Spend Breakdown Cards & Summary */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
            {/* Left Column: Category Bars */}
            <div className="md:col-span-7 bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 font-geist">Expense Category Breakdown</h3>
                  <p className="text-xs text-slate-500 mt-0.5">Total Outflow: ₹{totalExpense.toLocaleString('en-IN')}</p>
                </div>
                <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-md border border-slate-200">
                  Real Ledger
                </span>
              </div>

              <div className="space-y-3.5 pt-1">
                {expenses.map((exp) => (
                  <div
                    key={exp.category}
                    onClick={() => setSelectedCategory(exp.category)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      selectedCategory === exp.category
                        ? 'border-slate-900 bg-slate-50 shadow-sm'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: exp.color }}></div>
                        <span className="font-bold text-slate-900">{exp.category}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold font-geist text-slate-900">
                          ₹{exp.amount.toLocaleString('en-IN')}
                        </span>
                        <span className="text-[11px] text-slate-500">({exp.percentage}%)</span>
                      </div>
                    </div>

                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{ width: `${exp.percentage}%`, backgroundColor: exp.color }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Column: Selected Category Deep Dive */}
            <div className="md:col-span-5 bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold text-slate-600 uppercase font-geist">Category Deep Dive</span>
                  <span className="text-xs font-bold text-slate-700 bg-slate-100 border border-slate-200 px-2.5 py-0.5 rounded-full">
                    Tax-Deductible
                  </span>
                </div>

                <h4 className="text-lg font-bold text-slate-900 font-geist mb-1">
                  {selectedCategory || 'Selected Category'}
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed mb-4">
                  All legitimate business expenses in this category qualify for 100% tax deduction under Section 37(1) of the Income Tax Act.
                </p>

                <div className="space-y-2.5 text-xs">
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 flex justify-between items-center">
                    <span className="text-slate-600">Recorded Incurred Amount</span>
                    <span className="font-bold text-slate-900">₹{selectedAmount.toLocaleString('en-IN')}</span>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 flex justify-between items-center">
                    <span className="text-slate-600">Eligible Input Tax Credit (18% GST)</span>
                    <span className="font-bold text-slate-900">₹{estimatedITC.toLocaleString('en-IN')}</span>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 flex justify-between items-center">
                    <span className="text-slate-600">Vendors in Category</span>
                    <span className="font-bold text-slate-900">
                      {activeCategoryVendors.length > 0 ? activeCategoryVendors.join(', ') : 'None specified'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <button
                  onClick={() => onNavigate && onNavigate('accounting')}
                  className="text-xs font-semibold text-slate-900 hover:text-slate-600 flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <span>View all transactions in this category</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
