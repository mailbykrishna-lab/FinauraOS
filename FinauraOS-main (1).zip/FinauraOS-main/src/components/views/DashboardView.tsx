import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  Upload,
  Plus,
  Search,
  Bell,
  SlidersHorizontal,
  Layers,
  CreditCard,
  FileText,
  Building2,
  UserCheck,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { BusinessProfile, NavTab, ViewPeriod, Transaction, Invoice } from '../../types';
import { OperatingCapitalWhiteCard } from '../dashboard/OperatingCapitalWhiteCard';
import { CashFlowLineChart } from '../dashboard/CashFlowLineChart';
import { ExpenseDonutChart } from '../dashboard/ExpenseDonutChart';
import { RadialGaugeCard } from '../dashboard/RadialGaugeCard';
import { DualRadialRingCard } from '../dashboard/DualRadialRingCard';
import { HorizontalProgressBarList } from '../dashboard/HorizontalProgressBarList';
import { NextBestAction } from '../NextBestAction';

interface DashboardViewProps {
  profile: BusinessProfile;
  transactions?: Transaction[];
  invoices?: Invoice[];
  onNavigate: (tab: NavTab) => void;
  onOpenAI: (initialPrompt?: string) => void;
  onOpenAddTransaction?: () => void;
  onOpenCreateInvoice?: () => void;
  onOpenUploadStatement?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  profile,
  transactions = [],
  invoices = [],
  onNavigate,
  onOpenAI,
  onOpenAddTransaction,
  onOpenCreateInvoice,
  onOpenUploadStatement,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'cashflow' | 'ledger' | 'documents' | 'tax' | 'invoices'>('overview');
  const [showTriageBanner, setShowTriageBanner] = useState<boolean>(true);
  const [themeMode, setThemeMode] = useState<'cyber_mint' | 'classic_light'>('cyber_mint');

  // Dynamic calculations from real user data
  const hasData = (transactions?.length || 0) > 0 || (invoices?.length || 0) > 0;

  const totalRevenue = (transactions || [])
    .filter((t) => t.type === 'credit' && t.status === 'approved')
    .reduce((sum, t) => sum + (t.amount || 0), 0) +
    (invoices || [])
    .filter((inv) => inv.status === 'paid')
    .reduce((sum, inv) => sum + (inv.total || 0), 0);

  const totalExpenses = (transactions || [])
    .filter((t) => t.type === 'debit' && t.status === 'approved')
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const pendingInvoices = (invoices || []).filter((inv) => inv.status !== 'paid' && inv.status !== 'cancelled');
  const totalOutstanding = pendingInvoices.reduce((sum, inv) => sum + (inv.total || 0), 0);

  const pendingReviewTransactions = (transactions || []).filter(
    (t) => t.status === 'pending_review' || t.status === 'needs_review'
  );

  const reconciliationScore = transactions.length > 0
    ? Math.round(((transactions.length - pendingReviewTransactions.length) / transactions.length) * 100)
    : 94;

  const handleSubTabClick = (tab: typeof activeSubTab) => {
    setActiveSubTab(tab);
    if (tab === 'ledger') onNavigate('accounting');
    else if (tab === 'cashflow') onNavigate('finance');
    else if (tab === 'documents') onNavigate('documents');
    else if (tab === 'tax') onNavigate('compliance');
    else if (tab === 'invoices') onNavigate('invoices');
  };

  return (
    <div className={`-m-4 md:-m-8 p-4 md:p-8 min-h-screen transition-colors duration-300 ${
      themeMode === 'cyber_mint' ? 'bg-[#090e1a] text-slate-100' : 'bg-slate-50 text-slate-900'
    }`}>
      <div className="max-w-[1440px] mx-auto space-y-6">

        {/* 1. TOP HEADER & NAVIGATION BAR (Matches screenshot header structure) */}
        <header className={`rounded-2xl p-4 border transition-all ${
          themeMode === 'cyber_mint'
            ? 'bg-[#11192a]/95 border-[#1e2f47] text-white shadow-2xl backdrop-blur-md'
            : 'bg-white border-slate-200 text-slate-900 shadow-sm'
        }`}>
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            
            {/* Left: Brand Emblem & Workspace Indicator */}
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-slate-950 shadow-lg shadow-emerald-500/25">
                {/* Geometric hexagonal brand icon matching EIRK / FINAURA */}
                <svg className="w-6 h-6 stroke-slate-950" viewBox="0 0 24 24" fill="none" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="12 2 2 7 12 12 22 7 12 2" />
                  <polyline points="2 17 12 22 22 17" />
                  <polyline points="2 12 12 17 22 12" />
                </svg>
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <span className={`text-base font-extrabold tracking-wider font-geist uppercase ${
                    themeMode === 'cyber_mint' ? 'text-white' : 'text-slate-900'
                  }`}>
                    {profile?.businessName ? profile.businessName.toUpperCase().slice(0, 16) : 'FINAURA'}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border flex items-center gap-1 ${
                    themeMode === 'cyber_mint'
                      ? 'text-emerald-400 bg-emerald-950/80 border-emerald-800/60'
                      : 'text-emerald-700 bg-emerald-50 border-emerald-200'
                  }`}>
                    <span className={`w-1.5 h-1.5 rounded-full animate-pulse ${themeMode === 'cyber_mint' ? 'bg-emerald-400' : 'bg-emerald-600'}`} />
                    LIVE OS
                  </span>
                </div>
                <p className={`text-[11px] ${themeMode === 'cyber_mint' ? 'text-slate-400' : 'text-slate-600'}`}>
                  {profile?.businessName || 'Financial Intelligence & Statutory OS'}
                </p>
              </div>
            </div>

            {/* Center: Horizontal Navigation Links (Matching Screenshot Tabs) */}
            <nav className={`flex items-center gap-1 overflow-x-auto hide-scrollbar p-1 rounded-xl border ${
              themeMode === 'cyber_mint'
                ? 'bg-[#0a111e] border-[#1a293f]'
                : 'bg-slate-100 border-slate-200'
            }`}>
              {[
                { id: 'overview', label: 'Overview' },
                { id: 'cashflow', label: 'Cash Flow' },
                { id: 'ledger', label: 'Ledger' },
                { id: 'documents', label: 'Vault' },
                { id: 'tax', label: 'GST & Tax' },
                { id: 'invoices', label: 'Invoices' },
              ].map((tab) => {
                const isActive = activeSubTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => handleSubTabClick(tab.id as any)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                      isActive
                        ? themeMode === 'cyber_mint'
                          ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                          : 'bg-slate-900 text-white font-bold shadow-xs'
                        : themeMode === 'cyber_mint'
                        ? 'text-slate-400 hover:text-white hover:bg-white/5'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                    }`}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </nav>

            {/* Right: Quick Action Controls & Theme Toggle */}
            <div className="flex items-center gap-2 self-end lg:self-auto">
              {/* Import Bank Statement Quick Trigger */}
              {onOpenUploadStatement && (
                <button
                  type="button"
                  onClick={onOpenUploadStatement}
                  className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-md shadow-emerald-500/20 transition-all cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>Import Statement</span>
                </button>
              )}

              {/* Add Entry Quick Trigger */}
              {onOpenAddTransaction && (
                <button
                  type="button"
                  onClick={onOpenAddTransaction}
                  className={`text-xs font-semibold px-3 py-1.5 rounded-xl flex items-center gap-1.5 border transition-all cursor-pointer ${
                    themeMode === 'cyber_mint'
                      ? 'bg-[#1e2f47] hover:bg-[#283f5e] text-white border-[#2b3f5c]'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-900 border-slate-300'
                  }`}
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Entry</span>
                </button>
              )}

              {/* Ask AI Pill */}
              <button
                type="button"
                onClick={() => onOpenAI('Give me an executive summary of my financial health and upcoming statutory deadlines')}
                className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                  themeMode === 'cyber_mint'
                    ? 'bg-[#131d30] border-[#1e2f47] text-slate-300 hover:text-emerald-400 hover:border-emerald-500/40'
                    : 'bg-slate-100 border-slate-300 text-slate-700 hover:text-slate-900 hover:bg-slate-200'
                }`}
                title="Ask Finaura AI"
              >
                <Sparkles className={`w-4 h-4 ${themeMode === 'cyber_mint' ? 'text-emerald-400' : 'text-emerald-600'}`} />
              </button>

              {/* Aesthetic Theme Switcher Pill */}
              <button
                type="button"
                onClick={() => setThemeMode(themeMode === 'cyber_mint' ? 'classic_light' : 'cyber_mint')}
                className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                  themeMode === 'cyber_mint'
                    ? 'bg-[#131d30] border-[#1e2f47] text-slate-300 hover:text-white'
                    : 'bg-slate-100 border-slate-300 text-slate-800 hover:text-black hover:bg-slate-200'
                }`}
                title="Toggle Dashboard Visual Theme"
              >
                <SlidersHorizontal className={`w-3.5 h-3.5 ${themeMode === 'cyber_mint' ? 'text-emerald-400' : 'text-emerald-600'}`} />
                <span className="hidden sm:inline">
                  {themeMode === 'cyber_mint' ? 'Mint Dark' : 'Light'}
                </span>
              </button>
            </div>

          </div>
        </header>

        {/* 2. THE 6-CARD BENTO GRID (Pixel-accurate aesthetic matching reference screenshot) */}
        <div className="space-y-6">
          
          {/* ROW 1: 3 Bento Columns */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-12 gap-5 items-stretch">
            
            {/* Card 1: Operating Capital High-Contrast White Card (Col 1: 3/12) */}
            <div className="xl:col-span-3 h-full">
              <OperatingCapitalWhiteCard
                totalRevenue={totalRevenue}
                totalExpenses={totalExpenses}
                totalOutstanding={totalOutstanding}
                onOpenAddTransaction={onOpenAddTransaction}
                onNavigate={onNavigate}
              />
            </div>

            {/* Card 2: Cash Dynamics Curve Line Chart (Col 2: 6/12) */}
            <div className="xl:col-span-6 md:col-span-2 xl:col-auto h-full">
              <CashFlowLineChart
                totalRevenue={totalRevenue}
                totalExpenses={totalExpenses}
                themeMode={themeMode}
              />
            </div>

            {/* Card 3: Expense Donut Chart (Col 3: 3/12) */}
            <div className="xl:col-span-3 h-full">
              <ExpenseDonutChart
                totalExpenses={totalExpenses}
                themeMode={themeMode}
              />
            </div>
          </div>

          {/* ROW 2: 3 Bento Columns */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-12 gap-5 items-stretch">
            
            {/* Card 4: Radial Gauge AI Audit (Col 1: 3/12) */}
            <div className="xl:col-span-3 h-full">
              <RadialGaugeCard
                accuracyRate={reconciliationScore}
                onAction={onOpenUploadStatement || (() => onNavigate('accounting'))}
                themeMode={themeMode}
              />
            </div>

            {/* Card 5: Dual Radial Rings (Col 2: 6/12) */}
            <div className="xl:col-span-6 md:col-span-2 xl:col-auto h-full">
              <DualRadialRingCard
                runwayMonths={21}
                collectionDays={11}
                themeMode={themeMode}
              />
            </div>

            {/* Card 6: Horizontal Progress Bars (Col 3: 3/12) */}
            <div className="xl:col-span-3 h-full">
              <HorizontalProgressBarList themeMode={themeMode} />
            </div>
          </div>

        </div>

        {/* 3. OPTIONAL GUIDANCE & ACTION CENTER (Preserves all business capabilities) */}
        {showTriageBanner && (
          <div className={`rounded-2xl p-5 border shadow-xl space-y-4 transition-colors ${
            themeMode === 'cyber_mint'
              ? 'bg-[#11192a] border-[#1e2f47] text-white'
              : 'bg-white border-slate-200 text-slate-900 shadow-sm'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Zap className={`w-4 h-4 ${themeMode === 'cyber_mint' ? 'text-emerald-400' : 'text-emerald-600'}`} />
                <h3 className={`text-sm font-bold font-geist tracking-tight ${
                  themeMode === 'cyber_mint' ? 'text-slate-100' : 'text-slate-900'
                }`}>
                  Intelligent Guidance &amp; Priority Triage
                </h3>
              </div>
              <div className="flex items-center gap-3">
                <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded border ${
                  themeMode === 'cyber_mint'
                    ? 'text-emerald-400 bg-emerald-950/80 border-emerald-800/60'
                    : 'text-emerald-700 bg-emerald-50 border-emerald-200'
                }`}>
                  {pendingReviewTransactions.length > 0
                    ? `${pendingReviewTransactions.length} Pending Review`
                    : 'System Fully Synchronized'}
                </span>
                <button
                  type="button"
                  onClick={() => setShowTriageBanner(false)}
                  className={`text-xs cursor-pointer ${
                    themeMode === 'cyber_mint' ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  Dismiss
                </button>
              </div>
            </div>

            {/* Action Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {[
                {
                  title: 'Review Transactions',
                  sub: pendingReviewTransactions.length > 0 ? `${pendingReviewTransactions.length} uncategorized entries` : 'All entries reconciled',
                  icon: CreditCard,
                  onClick: () => onNavigate('accounting'),
                },
                {
                  title: 'Client Invoicing',
                  sub: pendingInvoices.length > 0 ? `₹${totalOutstanding.toLocaleString('en-IN')} pending collection` : 'UPI QR & GST auto-invoicing',
                  icon: FileText,
                  onClick: onOpenCreateInvoice || (() => onNavigate('invoices')),
                },
                {
                  title: 'Document Vault',
                  sub: 'Bank statements & GST returns',
                  icon: Building2,
                  onClick: onOpenUploadStatement || (() => onNavigate('documents')),
                },
                {
                  title: 'CA Network',
                  sub: 'Direct audit & tax filing support',
                  icon: UserCheck,
                  onClick: () => onNavigate('ca_services'),
                },
              ].map((act, i) => {
                const Icon = act.icon;
                return (
                  <button
                    key={i}
                    type="button"
                    onClick={act.onClick}
                    className={`p-3.5 rounded-xl border text-left transition-all group cursor-pointer ${
                      themeMode === 'cyber_mint'
                        ? 'bg-[#0b1322] hover:bg-[#121c2e] border-[#1e2f47] hover:border-emerald-500/40'
                        : 'bg-slate-50 hover:bg-slate-100 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <Icon className={`w-4 h-4 ${themeMode === 'cyber_mint' ? 'text-emerald-400' : 'text-emerald-600'}`} />
                      <ArrowRight className={`w-3.5 h-3.5 group-hover:translate-x-0.5 transition-all ${
                        themeMode === 'cyber_mint' ? 'text-slate-500 group-hover:text-emerald-400' : 'text-slate-400 group-hover:text-slate-900'
                      }`} />
                    </div>
                    <div className={`text-xs font-bold ${themeMode === 'cyber_mint' ? 'text-slate-100' : 'text-slate-900'}`}>
                      {act.title}
                    </div>
                    <div className={`text-[10px] mt-0.5 ${themeMode === 'cyber_mint' ? 'text-slate-400' : 'text-slate-600'}`}>
                      {act.sub}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
