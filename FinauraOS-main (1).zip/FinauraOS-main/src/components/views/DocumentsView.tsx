import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  FileText,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Clock,
  UserCheck,
  X,
  FileCheck,
  Table,
  Download,
  Mail,
  FileSpreadsheet,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { UploadedDoc, NavTab, Transaction } from '../../types';
import { ExplainWhyCard } from '../ExplainWhyCard';
import { NextBestAction } from '../NextBestAction';
import { downloadFinauraCsvTemplate, FINAURA_CSV_COLUMNS } from '../../utils/csvTemplate';
import { GmailSyncModal } from '../modals/GmailSyncModal';

interface DocumentsViewProps {
  documents: UploadedDoc[];
  onUploadDoc: (doc: UploadedDoc) => void;
  onNavigate: (tab: NavTab) => void;
  onImportTransactions?: (transactions: Transaction[], metadata?: any) => void | Promise<void | boolean>;
  onOpenStatementModal?: () => void;
}

export const DocumentsView: React.FC<DocumentsViewProps> = ({
  documents,
  onUploadDoc,
  onNavigate,
  onImportTransactions,
  onOpenStatementModal,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccessMessage, setUploadSuccessMessage] = useState<string | null>(null);
  const [showErrorState, setShowErrorState] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 'verified' | 'pending'>('all');
  const [isGmailModalOpen, setIsGmailModalOpen] = useState(false);
  const [showSchemaGuide, setShowSchemaGuide] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImportFromGmail = (doc: UploadedDoc, extractedTx?: Transaction[]) => {
    onUploadDoc(doc);
    if (extractedTx && extractedTx.length > 0 && onImportTransactions) {
      onImportTransactions(extractedTx, {
        fileName: doc.name,
        category: doc.category,
        accuracyScore: 99,
        source: 'Gmail Ingestion',
      });
    }
    setUploadSuccessMessage(
      `Successfully imported "${doc.name}" directly from Gmail into the Document Vault!`
    );
  };

  const processUploadedFile = (file: { name: string; size?: string | number }) => {
    setIsUploading(true);
    setShowErrorState(false);
    setUploadSuccessMessage(null);

    setTimeout(() => {
      setIsUploading(false);
      const sizeStr = typeof file.size === 'number'
        ? `${(file.size / (1024 * 1024)).toFixed(2)} MB`
        : file.size || '1.4 MB';

      const isStatement = file.name.toLowerCase().includes('statement') || file.name.toLowerCase().includes('bank');

      const newDoc: UploadedDoc = {
        id: `doc-${Date.now()}`,
        name: file.name || 'Bank_Statement_Aug2026.pdf',
        category: isStatement ? 'Bank Statement' : 'Expense Bills',
        period: 'Current Financial Period',
        size: sizeStr,
        uploadedAt: 'Just now',
        status: 'verified',
        extractedItemsCount: 42,
      };

      onUploadDoc(newDoc);

      if (isStatement && onImportTransactions) {
        const extracted: Transaction[] = [
          {
            id: `tx-doc-${Date.now()}-1`,
            date: new Date().toISOString().slice(0, 10),
            vendor: 'Amazon Web Services',
            description: 'Cloud hosting and compute instances',
            amount: 8250,
            type: 'debit',
            suggestedCategory: 'Software & Cloud',
            userCategory: 'Software & Cloud',
            confidence: 0.98,
            status: 'approved',
            taxDeductible: true,
            gstEligible: true,
          },
          {
            id: `tx-doc-${Date.now()}-2`,
            date: new Date(Date.now() - 86400000 * 2).toISOString().slice(0, 10),
            vendor: 'Client Inflow NEFT',
            description: 'Customer project payment received',
            amount: 145000,
            type: 'credit',
            suggestedCategory: 'Client Retainer / Revenue',
            userCategory: 'Client Retainer / Revenue',
            confidence: 0.99,
            status: 'approved',
            taxDeductible: false,
            gstEligible: true,
          },
          {
            id: `tx-doc-${Date.now()}-3`,
            date: new Date(Date.now() - 86400000 * 5).toISOString().slice(0, 10),
            vendor: 'Google Cloud Platform',
            description: 'Workspace and API intelligence tier',
            amount: 2800,
            type: 'debit',
            suggestedCategory: 'Software & Cloud',
            userCategory: 'Software & Cloud',
            confidence: 0.97,
            status: 'approved',
            taxDeductible: true,
            gstEligible: true,
          },
        ];
        onImportTransactions(extracted, {
          fileName: file.name,
          fileSize: typeof file.size === 'number' ? `${(file.size / (1024 * 1024)).toFixed(2)} MB` : String(file.size || '1.2 MB'),
          category: 'Bank Statement',
          bankName: 'Verified Bank Account',
          accuracyScore: 100,
        });
      }

      setUploadSuccessMessage(
        `Successfully processed "${file.name}". Extracted 42 transactions mapped to your tax categories!`
      );
    }, 1200);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processUploadedFile(file);
    }
  };

  const handleSimulateError = () => {
    setIsUploading(true);
    setShowErrorState(false);
    setTimeout(() => {
      setIsUploading(false);
      setShowErrorState(true);
    }, 800);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-slate-600 uppercase tracking-wider font-geist">
            SECURE VAULT &amp; AI PARSER
          </span>
          <h1 className="text-2xl md:text-3xl font-black text-slate-900 font-geist tracking-tight mt-0.5">
            DOCUMENTS &amp; STATEMENTS
          </h1>
          <p className="text-sm text-slate-600 mt-0.5">
            Upload PDF bank statements, vendor bills, and GST returns for encrypted OCR extraction.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => downloadFinauraCsvTemplate()}
            className="bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-bold text-xs py-2.5 px-4 rounded-xl flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
            title="Download standard 6-column CSV template"
          >
            <Download className="w-3.5 h-3.5 text-emerald-600" />
            <span>Download CSV Template</span>
          </button>

          <button
            type="button"
            onClick={() => setIsGmailModalOpen(true)}
            className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs py-2.5 px-4 rounded-xl flex items-center gap-2 shadow-sm transition-colors cursor-pointer"
            title="Scan your authorized Gmail for invoices & statements"
          >
            <Mail className="w-3.5 h-3.5 text-white" />
            <span>Scan Gmail Inbox</span>
          </button>
        </div>
      </div>

      {/* GMAIL INGESTION PROMO CARD */}
      <div className="bg-gradient-to-r from-red-50/70 via-slate-50 to-white border border-red-200/80 rounded-2xl p-5 md:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center shrink-0 shadow-sm mt-0.5">
            <Mail className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider bg-red-100 text-red-800 px-2 py-0.5 rounded-full font-geist">
                GOOGLE WORKSPACE INTEGRATION
              </span>
              <span className="text-xs text-slate-500">• OAuth Verified</span>
            </div>
            <h3 className="text-base font-bold text-slate-900 font-geist mt-1">
              Direct Financial Document Ingestion from Gmail
            </h3>
            <p className="text-xs text-slate-600 mt-1 max-w-xl leading-relaxed">
              Eliminate manual downloading. Finaura scans your authorized inbox for vendor invoices, payment receipts, and monthly bank statements to automatically import into your books.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsGmailModalOpen(true)}
          className="bg-slate-900 hover:bg-black text-white font-bold text-xs py-2.5 px-5 rounded-xl flex items-center gap-2 shrink-0 shadow-sm transition-all cursor-pointer self-start sm:self-center"
        >
          <Mail className="w-3.5 h-3.5 text-red-400" />
          <span>Connect &amp; Sync Gmail</span>
          <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
        </button>
      </div>

      {/* 17. CONTEXTUAL DOCUMENT GUIDANCE CARD */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 md:p-6 space-y-4 relative overflow-hidden">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-slate-900 text-white flex items-center justify-center shrink-0 mt-0.5">
            <FileText className="w-5 h-5 text-slate-100" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-600 uppercase tracking-wider font-geist">
              CURRENT DOCUMENT REQUEST
            </span>
            <h2 className="text-lg md:text-xl font-bold text-slate-900 font-geist mt-0.5">
              WE NEED YOUR CURRENT QUARTER BANK STATEMENT
            </h2>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs pt-1">
          <div className="bg-white p-3.5 rounded-xl border border-slate-200">
            <span className="font-bold text-slate-900 block mb-1">Why do you need this?</span>
            <p className="text-slate-600 leading-relaxed">
              To auto-categorize your revenue and expenses and unlock ₹18,400 GST input credits.
            </p>
          </div>

          <div className="bg-white p-3.5 rounded-xl border border-slate-200">
            <span className="font-bold text-slate-900 block mb-1">What period?</span>
            <p className="text-slate-600 leading-relaxed">
              <strong>July 1, 2026 to August 31, 2026</strong> (Current Q2 FY24-25).
            </p>
          </div>

          <div className="bg-white p-3.5 rounded-xl border border-slate-200">
            <span className="font-bold text-slate-900 block mb-1">What happens next?</span>
            <p className="text-slate-700 font-medium leading-relaxed">
              Finaura extracts and parses all debits/credits in under 2 minutes with 99.4% precision.
            </p>
          </div>
        </div>
      </div>

      {/* Upload Success Banner */}
      {uploadSuccessMessage && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center justify-between text-xs text-emerald-800 animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-medium">{uploadSuccessMessage}</span>
          </div>
          <button
            onClick={() => setUploadSuccessMessage(null)}
            className="text-emerald-700 hover:text-emerald-900 p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 25. ERROR RECOVERY BANNER (IF TRIGGERED) */}
      {showErrorState && (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-5 md:p-6 space-y-4 animate-in fade-in">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-6 h-6 text-red-600 shrink-0 mt-0.5" />
            <div>
              <h3 className="text-base font-bold text-red-900 font-geist">
                WE COULDN’T READ THIS DOCUMENT
              </h3>
              <p className="text-xs text-red-700 mt-1">
                The file could not be parsed automatically. Here are the likely reasons:
              </p>
              <ul className="list-disc list-inside text-xs text-slate-700 mt-1.5 space-y-0.5">
                <li><strong>Password Protection:</strong> The PDF might have a bank password.</li>
                <li><strong>File Format:</strong> Only PDF, CSV, PNG, and JPG are supported.</li>
                <li><strong>Image Clarity:</strong> Resolution is too low for OCR table extraction.</li>
              </ul>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => processUploadedFile({ name: 'HDFC_Statement_Fixed.pdf', size: '1.2 MB' })}
              className="bg-red-600 text-white hover:bg-red-700 text-xs font-semibold py-2.5 px-5 rounded-xl flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>TRY AGAIN (CLEAN FILE)</span>
            </button>

            <button
              onClick={() => onNavigate('ca_services')}
              className="bg-white border border-slate-300 text-slate-900 hover:bg-slate-50 text-xs font-semibold py-2.5 px-5 rounded-xl flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
            >
              <UserCheck className="w-3.5 h-3.5 text-slate-700" />
              <span>ASK MY CA TO MANUALLY PARSE</span>
            </button>

            <button
              onClick={() => setShowErrorState(false)}
              className="text-xs text-slate-500 hover:text-slate-900 px-2 cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* DRAG & DROP UPLOAD BOX */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragging(false);
          if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            processUploadedFile(e.dataTransfer.files[0]);
          } else {
            processUploadedFile({ name: 'Bank_Statement_Q2.pdf', size: '1.4 MB' });
          }
        }}
        className={`bg-white rounded-2xl border-2 border-dashed p-8 md:p-10 text-center transition-all ${
          isDragging ? 'border-slate-900 bg-slate-50' : 'border-slate-300 hover:border-slate-400'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          onChange={handleFileInputChange}
          accept=".pdf,.csv,.xlsx,.xls,.png,.jpg"
          className="hidden"
        />

        <div className="max-w-md mx-auto space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 text-slate-700 flex items-center justify-center mx-auto">
            {isUploading ? (
              <RefreshCw className="w-7 h-7 text-slate-900 animate-spin" />
            ) : (
              <UploadCloud className="w-7 h-7 text-slate-900" />
            )}
          </div>

          <div>
            <h3 className="text-base font-bold text-slate-900 font-geist">
              {isUploading ? 'Extracting transactions...' : 'Drag & drop your files here'}
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Supports PDF bank statements, Excel, CSV or scanned receipts up to 25MB each.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold py-2.5 px-6 rounded-xl flex items-center gap-2 shadow-sm transition-all disabled:opacity-50 cursor-pointer"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Browse Computer</span>
            </button>

            {onOpenStatementModal && (
              <button
                type="button"
                onClick={onOpenStatementModal}
                disabled={isUploading}
                className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold py-2.5 px-5 rounded-xl flex items-center gap-2 shadow-sm transition-all cursor-pointer disabled:opacity-50"
              >
                <Table className="w-4 h-4" />
                <span>Import Bank CSV</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* DOCUMENT VAULT LIST */}
      <div className="bg-white rounded-2xl p-5 md:p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 font-geist">Uploaded Document Vault</h3>
            <p className="text-xs text-slate-500 mt-0.5">{documents.length} verified statutory files</p>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs">
            <button
              type="button"
              onClick={() => setShowSchemaGuide(!showSchemaGuide)}
              className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Inspect required CSV column structure"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-slate-600" />
              <span>{showSchemaGuide ? 'Hide CSV Schema' : 'View CSV Schema'}</span>
              {showSchemaGuide ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>

            <button
              type="button"
              onClick={() => downloadFinauraCsvTemplate()}
              className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
              title="Download pre-formatted CSV template to ensure transaction imports match Finaura's schema"
            >
              <Download className="w-3.5 h-3.5 text-emerald-700" />
              <span>Download CSV Template</span>
            </button>

            <div className="flex items-center gap-1 border-l border-slate-200 pl-2">
              <button
                onClick={() => setActiveTab('all')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  activeTab === 'all' ? 'bg-slate-900 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                All Files
              </button>
              <button
                onClick={() => setActiveTab('verified')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  activeTab === 'verified' ? 'bg-slate-900 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Verified
              </button>
            </div>
          </div>
        </div>

        {/* EXPANDABLE CSV SCHEMA FORMAT GUIDE */}
        {showSchemaGuide && (
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs space-y-3 animate-in fade-in duration-150">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900">Standard Finaura 6-Column Banking Schema</span>
                <p className="text-slate-500 text-[11px] mt-0.5">
                  Prepare your transaction exports or bank statements using this exact layout for 100% automated parsing:
                </p>
              </div>
              <button
                onClick={() => downloadFinauraCsvTemplate()}
                className="text-emerald-700 hover:text-emerald-800 font-bold text-xs underline flex items-center gap-1 cursor-pointer"
              >
                <Download className="w-3 h-3" />
                <span>Save Sample .CSV</span>
              </button>
            </div>

            <div className="overflow-x-auto rounded-lg border border-slate-200 bg-white">
              <table className="w-full text-left border-collapse text-[11px]">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                    <th className="p-2">Column Header</th>
                    <th className="p-2">Description</th>
                    <th className="p-2">Format / Type</th>
                    <th className="p-2">Required?</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {FINAURA_CSV_COLUMNS.map((col) => (
                    <tr key={col.name} className="hover:bg-slate-50">
                      <td className="p-2 font-mono font-bold text-slate-900">{col.name}</td>
                      <td className="p-2 text-slate-600">{col.description}</td>
                      <td className="p-2 font-mono text-slate-700">{col.format}</td>
                      <td className="p-2">
                        {col.required ? (
                          <span className="text-red-700 bg-red-50 border border-red-200 px-1.5 py-0.5 rounded-sm font-bold text-[10px]">
                            Required
                          </span>
                        ) : (
                          <span className="text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded-sm text-[10px]">
                            Optional
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {documents
            .filter((d) => (activeTab === 'all' ? true : d.status === activeTab))
            .map((doc) => (
              <div
                key={doc.id}
                className="p-4 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-800 flex items-center justify-center shrink-0 border border-slate-200">
                    <FileCheck className="w-5 h-5 text-slate-800" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-bold text-slate-900">{doc.name}</h4>
                      <span className="text-[10px] bg-slate-100 border border-slate-200 text-slate-800 font-bold px-2 py-0.5 rounded-full uppercase">
                        {doc.status}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Period: {doc.period} • {doc.size} • {doc.uploadedAt}
                    </p>
                  </div>
                </div>

                <div className="flex sm:flex-col sm:items-end justify-between items-center gap-2 text-xs">
                  <span className="text-slate-800 font-semibold">
                    {doc.extractedItemsCount} entries parsed
                  </span>
                  <button
                    onClick={() => onNavigate('accounting')}
                    className="text-slate-900 hover:underline font-semibold flex items-center gap-1"
                  >
                    <span>View in Books</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* GMAIL SYNC MODAL */}
      <GmailSyncModal
        isOpen={isGmailModalOpen}
        onClose={() => setIsGmailModalOpen(false)}
        onImportDocument={handleImportFromGmail}
      />
    </div>
  );
};
