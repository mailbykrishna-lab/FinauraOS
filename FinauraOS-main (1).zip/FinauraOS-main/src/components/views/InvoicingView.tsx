import React, { useState, useEffect, useMemo } from 'react';
import QRCode from 'qrcode';
import {
  FileText,
  Plus,
  ArrowRight,
  ArrowLeft,
  Check,
  Send,
  User,
  Package,
  IndianRupee,
  Eye,
  Trash2,
  Download,
  Edit3,
  Building,
  CheckCircle2,
  Landmark,
  QrCode,
  Copy,
  Sparkles,
  Save,
  CreditCard,
  ShieldCheck,
  ExternalLink,
  BarChart3,
  FileSpreadsheet,
  Layers,
  Mail,
  Share2,
  Paperclip,
  AlertCircle,
} from 'lucide-react';
import { Invoice, InvoiceItem, NavTab, BusinessProfile, UserAccount, BankDetails } from '../../types';
import { NextBestAction } from '../NextBestAction';
import { generateInvoicePdf, SupplierDetails } from '../../utils/generateInvoicePdf';
import { MonthlySalesGstReport } from '../MonthlySalesGstReport';
import { SendInvoiceEmailModal } from '../SendInvoiceEmailModal';

interface InvoicingViewProps {
  invoices?: Invoice[];
  profile?: BusinessProfile;
  currentUser?: UserAccount | null;
  onAddInvoice?: (invoice: Invoice) => void;
  onUpdateBankDetails?: (bankDetails: BankDetails) => void;
  onNavigate?: (tab: NavTab) => void;
  onOpenAI?: (prompt?: string) => void;
}

export const InvoicingView: React.FC<InvoicingViewProps> = ({
  invoices = [],
  profile,
  currentUser,
  onAddInvoice,
  onUpdateBankDetails,
  onNavigate,
  onOpenAI: _onOpenAI,
}) => {
  const handleSafeAddInvoice = (inv: Invoice) => {
    if (typeof onAddInvoice === 'function') {
      onAddInvoice(inv);
    }
  };
  const [isCreating, setIsCreating] = useState(false);
  const [editingInvoiceId, setEditingInvoiceId] = useState<string | null>(null);
  const [mainViewMode, setMainViewMode] = useState<'gst_reports' | 'invoices_list'>('gst_reports');
  // 5-step wizard: 1 | 2 | 3 | 4 | 5
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4 | 5>(1);

  // Dynamic Billed By (Supplier) details derived from logged-in user and business profile
  const supplierBusinessName = profile?.businessName || currentUser?.name || 'Business Name';
  const supplierContactName = currentUser?.name || profile?.contactName || 'Authorized Signatory';
  const supplierEmail = currentUser?.email || profile?.email || '';
  const supplierGstin = profile?.gstin || (profile?.gstStatus === 'registered' ? '' : 'Unregistered / Composition');
  const supplierState = profile?.state ? `${profile.state}` : 'State';

  // Bank & UPI Details Management with LocalStorage persistence
  const initialBank: BankDetails = useMemo(() => {
    return profile?.bankDetails || {
      bankName: '',
      accountHolderName: supplierBusinessName,
      accountNumber: '',
      ifscCode: '',
      branchName: '',
      accountType: 'Current',
      upiId: '',
    };
  }, [profile?.bankDetails, supplierBusinessName]);

  const [bankDetails, setBankDetails] = useState<BankDetails>(() => {
    try {
      const saved = localStorage.getItem('finaura_user_bank_details');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // fallback
    }
    return initialBank;
  });

  // Bank update modal state
  const [showBankModal, setShowBankModal] = useState(false);
  const [bankForm, setBankForm] = useState<BankDetails>(bankDetails);
  const [bankSavedToast, setBankSavedToast] = useState(false);
  const [copiedUpi, setCopiedUpi] = useState(false);

  // Preview Modal state for any invoice
  const [previewInvoice, setPreviewInvoice] = useState<Invoice | null>(null);
  const [isPdfGenerating, setIsPdfGenerating] = useState(false);

  // Email Modal state
  const [emailModalInvoice, setEmailModalInvoice] = useState<Invoice | null>(null);
  const [emailHistory, setEmailHistory] = useState<Record<string, { to: string; sentAt: string; method: string }>>(() => {
    try {
      const saved = localStorage.getItem('finaura_invoice_email_history');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const handleRecordEmailSent = (invoiceId: string, emailDetails: { to: string; sentAt: string; method: string }) => {
    const updated = {
      ...emailHistory,
      [invoiceId]: emailDetails,
    };
    setEmailHistory(updated);
    try {
      localStorage.setItem('finaura_invoice_email_history', JSON.stringify(updated));
    } catch {
      // ignore
    }
    // If invoice is in draft status, advance it to sent
    const found = invoices.find((i) => i.id === invoiceId);
    if (found && found.status === 'draft') {
      handleSafeAddInvoice({ ...found, status: 'sent' });
    }
  };

  // QR Code Data URLs
  const [activeQrDataUrl, setActiveQrDataUrl] = useState<string>('');
  const [previewQrDataUrl, setPreviewQrDataUrl] = useState<string>('');
  const [modalQrDataUrl, setModalQrDataUrl] = useState<string>('');

  // Invoice Form State
  const defaultDueDate = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + 15);
    return d.toISOString().split('T')[0];
  }, []);

  const [invoiceNumber, setInvoiceNumber] = useState(`INV-${new Date().getFullYear()}-${String((invoices?.length || 0) + 1).padStart(3, '0')}`);
  const [clientName, setClientName] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [clientGstin, setClientGstin] = useState('');
  const [items, setItems] = useState<InvoiceItem[]>([
    { description: '', quantity: 1, rate: '' as unknown as number, gstRate: 18, amount: 0 },
  ]);
  const [dueDate, setDueDate] = useState(defaultDueDate);
  const [step3Error, setStep3Error] = useState<string | null>(null);

  const subtotal = (items || []).reduce((acc, item) => acc + (Number(item?.quantity) || 0) * (Number(item?.rate) || 0), 0);
  const gstTotal = (items || []).reduce((acc, item) => acc + ((Number(item?.quantity) || 0) * (Number(item?.rate) || 0) * (item?.gstRate || 0)) / 100, 0);
  const totalAmount = subtotal + gstTotal;

  // Construct current working invoice object
  const currentWorkingInvoice: Invoice = useMemo(() => ({
    id: editingInvoiceId || `inv-${Date.now()}`,
    invoiceNumber: invoiceNumber || `INV-${new Date().getFullYear()}-${String(invoices.length + 1).padStart(3, '0')}`,
    clientName: clientName || 'Client Name',
    clientEmail: clientEmail || '',
    clientGstin: clientGstin || '',
    date: new Date().toISOString().split('T')[0],
    dueDate: dueDate || defaultDueDate,
    items,
    subtotal,
    gstAmount: gstTotal,
    total: totalAmount,
    status: 'sent',
  }), [editingInvoiceId, invoiceNumber, invoices.length, clientName, clientEmail, clientGstin, dueDate, defaultDueDate, items, subtotal, gstTotal, totalAmount]);

  // Combined Supplier & Bank Details
  const supplierDetails: SupplierDetails = useMemo(() => ({
    businessName: supplierBusinessName,
    contactName: supplierContactName,
    email: supplierEmail,
    gstin: supplierGstin,
    state: supplierState,
    bankDetails,
  }), [supplierBusinessName, supplierContactName, supplierEmail, supplierGstin, supplierState, bankDetails]);

  // Generate QR Code for Current Invoice
  useEffect(() => {
    const upiIdClean = (bankDetails.upiId || '').trim();
    if (!upiIdClean) {
      setActiveQrDataUrl('');
      return;
    }
    const upiUrl = `upi://pay?pa=${encodeURIComponent(upiIdClean)}&pn=${encodeURIComponent(supplierBusinessName)}&am=${totalAmount}&cu=INR&tn=${encodeURIComponent('Invoice ' + (invoiceNumber || 'Payment'))}`;

    QRCode.toDataURL(upiUrl, {
      margin: 1,
      width: 240,
      errorCorrectionLevel: 'M',
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
    })
      .then((url) => setActiveQrDataUrl(url))
      .catch((err) => console.error('Error generating QR code:', err));
  }, [bankDetails.upiId, supplierBusinessName, totalAmount, invoiceNumber]);

  // Generate QR Code for Preview Modal Invoice
  useEffect(() => {
    if (previewInvoice) {
      const upiIdClean = (bankDetails.upiId || '').trim();
      if (!upiIdClean) {
        setPreviewQrDataUrl('');
        return;
      }
      const upiUrl = `upi://pay?pa=${encodeURIComponent(upiIdClean)}&pn=${encodeURIComponent(supplierBusinessName)}&am=${previewInvoice.total}&cu=INR&tn=${encodeURIComponent('Invoice ' + (previewInvoice.invoiceNumber || 'Payment'))}`;

      QRCode.toDataURL(upiUrl, {
        margin: 1,
        width: 240,
        errorCorrectionLevel: 'M',
        color: {
          dark: '#0f172a',
          light: '#ffffff',
        },
      })
        .then((url) => setPreviewQrDataUrl(url))
        .catch((err) => console.error('Error generating preview QR code:', err));
    }
  }, [previewInvoice, bankDetails.upiId, supplierBusinessName]);

  // Generate Live Dynamic QR Code inside the Modal based on VPA / UPI ID
  useEffect(() => {
    if (showBankModal) {
      const upiIdClean = (bankForm.upiId || '').trim();
      const payeeName = bankForm.accountHolderName?.trim() || supplierBusinessName || 'Payee';
      const sampleAmt = totalAmount > 0 ? totalAmount : 1000;
      const upiUrl = `upi://pay?pa=${encodeURIComponent(upiIdClean)}&pn=${encodeURIComponent(payeeName)}&am=${sampleAmt}&cu=INR&tn=${encodeURIComponent('Invoice Payment')}`;

      QRCode.toDataURL(upiUrl, {
        margin: 1,
        width: 220,
        errorCorrectionLevel: 'M',
        color: {
          dark: '#0f172a',
          light: '#ffffff',
        },
      })
        .then((url) => setModalQrDataUrl(url))
        .catch((err) => console.error('Error generating modal dynamic QR:', err));
    }
  }, [showBankModal, bankForm.upiId, bankForm.accountHolderName, supplierBusinessName, totalAmount]);

  const handleStartNew = () => {
    setEditingInvoiceId(null);
    setInvoiceNumber(`INV-${new Date().getFullYear()}-${String(invoices.length + 1).padStart(3, '0')}`);
    setClientName('');
    setClientEmail('');
    setClientGstin('');
    setItems([{ description: '', quantity: 1, rate: '' as unknown as number, gstRate: 18, amount: 0 }]);
    setDueDate(defaultDueDate);
    setStep3Error(null);
    setCurrentStep(1);
    setIsCreating(true);
  };

  const handleEditExisting = (inv: Invoice) => {
    setEditingInvoiceId(inv.id);
    setInvoiceNumber(inv.invoiceNumber);
    setClientName(inv.clientName);
    setClientEmail(inv.clientEmail);
    setClientGstin(inv.clientGstin || '');
    setItems(inv.items && inv.items.length > 0 ? inv.items : [
      { description: 'Consulting Support', quantity: 1, rate: inv.subtotal, gstRate: 18, amount: inv.subtotal },
    ]);
    setDueDate(inv.dueDate);
    setCurrentStep(1);
    setIsCreating(true);
  };

  const handleAddItem = () => {
    setItems([...items, { description: 'Additional Deliverable', quantity: 1, rate: 25000, gstRate: 18, amount: 25000 }]);
  };

  const handleRemoveItem = (index: number) => {
    if (items.length > 1) {
      setItems(items.filter((_, idx) => idx !== index));
    }
  };

  const handleDownloadPdf = async (targetInvoice?: Invoice) => {
    setIsPdfGenerating(true);
    try {
      const invToPrint = targetInvoice || currentWorkingInvoice;
      await generateInvoicePdf(invToPrint, supplierDetails);
    } catch (err) {
      console.error('Error generating PDF:', err);
    } finally {
      setIsPdfGenerating(false);
    }
  };

  const handleCompleteInvoice = () => {
    handleSafeAddInvoice(currentWorkingInvoice);
    setIsCreating(false);
    setCurrentStep(1);
  };

  // Open Bank Details editor
  const handleOpenBankModal = () => {
    setBankForm(bankDetails);
    setShowBankModal(true);
  };

  // Save updated bank details
  const handleSaveBankDetails = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedDetails: BankDetails = {
      ...bankForm,
      upiId: (bankForm.upiId || 'finaura@upi').trim(),
      accountHolderName: bankForm.accountHolderName?.trim() || supplierBusinessName,
    };
    setBankDetails(updatedDetails);
    try {
      localStorage.setItem('finaura_user_bank_details', JSON.stringify(updatedDetails));
    } catch {
      // ignore
    }
    if (onUpdateBankDetails) {
      onUpdateBankDetails(updatedDetails);
    }
    setShowBankModal(false);
    setBankSavedToast(true);
    setTimeout(() => setBankSavedToast(false), 4000);
  };

  const handleCopyUpi = () => {
    if (bankDetails.upiId) {
      navigator.clipboard?.writeText(bankDetails.upiId);
      setCopiedUpi(true);
      setTimeout(() => setCopiedUpi(false), 2500);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Toast notification for bank update */}
      {bankSavedToast && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl border border-emerald-500/50 flex items-center gap-3 animate-in fade-in slide-in-from-top-3">
          <div className="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-bold text-white">Payment Details &amp; Dynamic UPI QR Updated</div>
            <div className="text-[11px] text-slate-300">
              Dynamic QR code calibrated for VPA <span className="font-mono text-emerald-400">{bankDetails.upiId}</span>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider font-geist">
            CASH FLOW ENGINE
          </span>
          <h1 className="text-2xl md:text-3xl font-black text-slate-900 font-geist tracking-tight mt-0.5">
            {isCreating ? (editingInvoiceId ? 'EDIT & MODIFY INVOICE' : 'CREATE AN INVOICE') : 'INVOICES & RECEIVABLES'}
          </h1>
          <p className="text-sm text-slate-600 mt-0.5">
            {isCreating
              ? 'Modify details across any step, configure bank payout details, and generate GST invoices with UPI QR codes.'
              : 'Track client receivables, customize bank payout accounts, and download GST-compliant PDF invoices.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Bank Details Config Button */}
          <button
            type="button"
            onClick={handleOpenBankModal}
            className="bg-white border border-slate-300 hover:border-slate-400 hover:bg-slate-50 text-slate-800 text-xs font-semibold py-2.5 px-3.5 rounded-xl inline-flex items-center gap-2 shadow-xs transition-all cursor-pointer"
            title="Configure Bank & UPI Payout details"
          >
            <QrCode className="w-4 h-4 text-emerald-600" />
            <span>Bank &amp; UPI Details</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
          </button>

          {!isCreating && (
            <button
              onClick={handleStartNew}
              className="bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Invoice</span>
            </button>
          )}
        </div>
      </div>

      {/* Bank & Payment Snapshot Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 text-white rounded-2xl p-4 sm:p-5 border border-slate-800 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center shrink-0 text-emerald-400 mt-0.5">
            <QrCode className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">PAYMENT &amp; PAYOUT DESTINATION</span>
              <span className="px-2 py-0.5 rounded-md bg-emerald-950 text-emerald-300 border border-emerald-800/80 text-[10px] font-semibold">
                Dynamic QR Active
              </span>
            </div>
            <div className="text-sm font-bold text-white mt-0.5">
              {bankDetails.accountNumber ? (
                <span>{bankDetails.bankName || 'Bank Account'} • A/C: {bankDetails.accountNumber} ({bankDetails.accountType || 'Current'})</span>
              ) : (
                <span className="text-emerald-300">Instant Dynamic UPI QR Enabled</span>
              )}
            </div>
            <div className="text-xs text-slate-300 flex flex-wrap items-center gap-x-3 gap-y-1 mt-1">
              {bankDetails.ifscCode && (
                <>
                  <span>IFSC: <strong className="font-mono text-slate-100">{bankDetails.ifscCode}</strong></span>
                  <span>•</span>
                </>
              )}
              <span className="flex items-center gap-1">
                UPI ID / VPA: <strong className="font-mono text-emerald-300 font-bold">{bankDetails.upiId || 'finaura@upi'}</strong>
              </span>
              <span>•</span>
              <span>Beneficiary: {bankDetails.accountHolderName || supplierBusinessName}</span>
              {!bankDetails.accountNumber && (
                <>
                  <span>•</span>
                  <span className="text-[10px] text-slate-400 bg-white/10 px-1.5 py-0.5 rounded">Bank Transfer: Optional</span>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
          <button
            type="button"
            onClick={handleOpenBankModal}
            className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white border border-white/20 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Update Payment / VPA</span>
          </button>
        </div>
      </div>

      {/* 09. NEXT BEST ACTION (Only for real overdue invoice or first invoice guidance) */}
      {!isCreating && (() => {
        const overdue = (invoices || []).find(
          (i) => i.status === 'overdue' || (i.status === 'sent' && new Date(i.dueDate) < new Date())
        );
        if (overdue) {
          return (
            <NextBestAction
              category="RECEIVABLES MANAGEMENT"
              title={`Send Reminder for ₹${overdue.total.toLocaleString('en-IN')} Overdue Balance`}
              subtitle={`${overdue.clientName} (Invoice #${overdue.invoiceNumber}) is overdue.`}
              urgency="urgent"
              whyAmISeeingThis={`Payment was due on ${overdue.dueDate}. Follow-up pending.`}
              whatShouldIDo="Click 'Open Invoice' to review invoice statement and share dynamic UPI QR payment link."
              whatHappensNext="Client will receive invoice statement with direct QR code settlement."
              actionLabel="OPEN INVOICE"
              onAction={() => setPreviewInvoice(overdue)}
            />
          );
        }
        if (invoices.length === 0) {
          return (
            <NextBestAction
              category="INVOICE READINESS"
              title="Issue Your First GST-Compliant Invoice"
              subtitle="Generate a professional tax invoice with automated GST breakdown and instant dynamic UPI QR."
              urgency="important"
              whyAmISeeingThis="No sales invoices recorded yet in your business ledger."
              whatShouldIDo="Click 'Create Invoice' to draft your first invoice and share with your client via PDF or Email."
              whatHappensNext="Invoiced amount will automatically populate your GSTR-1 sales ledger and cash forecast."
              actionLabel="CREATE INVOICE"
              onAction={handleStartNew}
            />
          );
        }
        return null;
      })()}

      {/* Main View Switcher between GST Monthly Report & All Invoices */}
      {!isCreating && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-2 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center gap-1.5 p-1 bg-slate-100/80 rounded-xl text-xs font-bold">
            <button
              type="button"
              onClick={() => setMainViewMode('gst_reports')}
              className={`px-4 py-2 rounded-lg flex items-center gap-2 transition-all cursor-pointer ${
                mainViewMode === 'gst_reports'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <BarChart3 className="w-4 h-4 text-emerald-400" />
              <span>Monthly Sales GST Report (GSTR-1 / 3B)</span>
              <span className="px-1.5 py-0.2 rounded text-[10px] bg-emerald-500/20 text-emerald-300 font-extrabold">
                GOVT READY
              </span>
            </button>

            <button
              type="button"
              onClick={() => setMainViewMode('invoices_list')}
              className={`px-4 py-2 rounded-lg flex items-center gap-2 transition-all cursor-pointer ${
                mainViewMode === 'invoices_list'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <FileText className="w-4 h-4 text-slate-400" />
              <span>All Client Invoices ({invoices.length})</span>
            </button>
          </div>

          <div className="flex items-center gap-2 px-2">
            <button
              type="button"
              onClick={handleStartNew}
              className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-3.5 py-2 rounded-xl flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Invoice</span>
            </button>
          </div>
        </div>
      )}

      {/* 13. GUIDED 5-STEP INVOICE CREATOR & EDITOR */}
      {isCreating ? (
        <div className="bg-white rounded-2xl shadow-[0px_8px_30px_rgba(10,15,30,0.06)] border border-slate-200 p-6 md:p-8 space-y-6">
          {/* Interactive Step Progress & Navigation Bar */}
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-semibold">
              <div className="flex items-center gap-2">
                <span className="bg-slate-900 text-white px-2.5 py-0.5 rounded-md font-bold text-[11px]">
                  Step {currentStep} of 5
                </span>
                <span className="text-slate-900 font-bold hidden sm:inline">
                  {currentStep === 1 && '1. Customer Details'}
                  {currentStep === 2 && '2. Services & Line Items'}
                  {currentStep === 3 && '3. Rates, GST & Bank Info'}
                  {currentStep === 4 && '4. Review Draft & UPI QR Code'}
                  {currentStep === 5 && '5. Finalize, Send & Download'}
                </span>
              </div>

              {/* Quick Actions Header: Download Draft PDF & Cancel */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleDownloadPdf()}
                  disabled={isPdfGenerating}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
                  title="Download current invoice draft as PDF"
                >
                  <Download className="w-3.5 h-3.5 text-slate-700" />
                  <span>{isPdfGenerating ? 'Generating PDF...' : 'Download PDF Draft'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className="text-xs text-slate-500 hover:text-slate-900 font-semibold px-2 py-1"
                >
                  Close
                </button>
              </div>
            </div>

            {/* Clickable Step Pills */}
            <div className="grid grid-cols-5 gap-1.5 sm:gap-2">
              {[
                { step: 1, label: 'Customer' },
                { step: 2, label: 'Items' },
                { step: 3, label: 'Rates & Bank' },
                { step: 4, label: 'Review & QR' },
                { step: 5, label: 'Send & PDF' },
              ].map((s) => {
                const isCurrent = currentStep === s.step;
                const isPassed = currentStep > s.step;
                return (
                  <button
                    key={s.step}
                    type="button"
                    onClick={() => setCurrentStep(s.step as 1 | 2 | 3 | 4 | 5)}
                    className={`py-2 px-1 sm:px-2 rounded-xl text-center transition-all cursor-pointer border ${
                      isCurrent
                        ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                        : isPassed
                        ? 'bg-slate-100 text-slate-800 border-slate-200 hover:bg-slate-200'
                        : 'bg-slate-50 text-slate-400 border-slate-200/60 hover:text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <div className="text-[10px] font-bold uppercase tracking-wider">
                      {isPassed ? `✓ Step ${s.step}` : `Step ${s.step}`}
                    </div>
                    <div className="text-xs font-semibold truncate mt-0.5">{s.label}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* STEP 1: CHOOSE / EDIT CUSTOMER */}
          {currentStep === 1 && (
            <div className="space-y-4 animate-in fade-in">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <User className="w-5 h-5 text-slate-700" />
                  <h3 className="text-lg font-bold text-slate-900 font-geist">Step 1 — Customer &amp; Billing Details</h3>
                </div>
                <span className="text-xs text-slate-500 font-medium">Click any step at top to jump</span>
              </div>

              {/* Billed By (Supplier / Current Authenticated Business) Badge */}
              <div className="bg-slate-900 text-white rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center shrink-0 mt-0.5">
                    <Building className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div>
                    <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">BILLED BY (SUPPLIER - YOUR BUSINESS)</div>
                    <div className="text-sm font-bold text-white flex items-center gap-2">
                      <span>{supplierBusinessName}</span>
                      <span className="text-[10px] font-normal px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-800/80 rounded-md">
                        Active Account
                      </span>
                    </div>
                    <div className="text-xs text-slate-300 flex flex-wrap items-center gap-x-3 gap-y-0.5 mt-1">
                      <span>Contact: <strong>{supplierContactName}</strong></span>
                      <span>•</span>
                      <span>Email: {supplierEmail}</span>
                      <span>•</span>
                      <span className="font-mono text-[11px]">GSTIN: {supplierGstin}</span>
                    </div>
                  </div>
                </div>
                <div className="text-xs text-slate-400 sm:text-right shrink-0">
                  <div className="text-[11px] text-slate-400">Place of Supply</div>
                  <div className="text-xs font-semibold text-slate-200">{supplierState}</div>
                </div>
              </div>

              <div className="space-y-3.5 bg-slate-50/50 p-4 rounded-xl border border-slate-200">
                <div className="text-xs font-bold text-slate-900 uppercase tracking-wider">BILLED TO (RECIPIENT / CLIENT)</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="text-xs font-bold text-slate-900 block mb-1">Invoice Number</label>
                    <input
                      type="text"
                      value={invoiceNumber}
                      onChange={(e) => setInvoiceNumber(e.target.value)}
                      placeholder="INV-2024-001"
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm font-semibold focus:outline-none focus:border-slate-500 font-geist"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-900 block mb-1">Customer / Company Name</label>
                    <input
                      type="text"
                      value={clientName}
                      onChange={(e) => setClientName(e.target.value)}
                      placeholder="e.g. Infosys Enterprise Labs"
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm focus:outline-none focus:border-slate-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="text-xs font-bold text-slate-900 block mb-1">Client Email (For Delivery &amp; Reminders)</label>
                    <input
                      type="email"
                      value={clientEmail}
                      onChange={(e) => setClientEmail(e.target.value)}
                      placeholder="e.g. billing@infosys.com"
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm focus:outline-none focus:border-slate-500"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-900 block mb-1">Client GSTIN (Optional for B2C)</label>
                    <input
                      type="text"
                      value={clientGstin}
                      onChange={(e) => setClientGstin(e.target.value)}
                      placeholder="29AAAAA0000A1Z5"
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm uppercase focus:outline-none focus:border-slate-500 font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-4 flex justify-between items-center">
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className="text-xs text-slate-500 hover:text-slate-900 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentStep(2)}
                  className="bg-slate-900 text-white hover:bg-slate-800 font-semibold text-xs py-2.5 px-6 rounded-xl flex items-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <span>Next: Line Items</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: ADD / MODIFY SERVICES & PRODUCTS */}
          {currentStep === 2 && (
            <div className="space-y-4 animate-in fade-in">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Package className="w-5 h-5 text-slate-700" />
                  <h3 className="text-lg font-bold text-slate-900 font-geist">Step 2 — Add or Edit Line Items</h3>
                </div>
                <button
                  type="button"
                  onClick={handleAddItem}
                  className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 bg-blue-50 px-3 py-1.5 rounded-lg border border-blue-200/60"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Line Item</span>
                </button>
              </div>

              <div className="space-y-3">
                {items.map((item, idx) => (
                  <div key={idx} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-700">Line Item #{idx + 1}</span>
                      {items.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(idx)}
                          className="text-xs text-red-600 hover:text-red-700 font-semibold flex items-center gap-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Remove</span>
                        </button>
                      )}
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-900 block mb-1">Description / SAC / HSN Code</label>
                      <input
                        type="text"
                        value={item.description}
                        onChange={(e) => {
                          const updated = [...items];
                          updated[idx].description = e.target.value;
                          setItems(updated);
                        }}
                        placeholder="e.g. UX Design & Engineering Consulting (SAC 998314)"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs focus:outline-none focus:border-slate-500"
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-4 flex justify-between items-center">
                <button
                  type="button"
                  onClick={() => setCurrentStep(1)}
                  className="inline-flex items-center gap-1 text-xs text-slate-600 hover:text-slate-900 font-semibold"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Customer</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentStep(3)}
                  className="bg-slate-900 text-white hover:bg-slate-800 font-semibold text-xs py-2.5 px-6 rounded-xl flex items-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <span>Next: Rates &amp; Bank Details</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: ADD / MODIFY AMOUNTS, TAXES & BANK DETAILS */}
          {currentStep === 3 && (
            <div className="space-y-4 animate-in fade-in">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <IndianRupee className="w-5 h-5 text-slate-700" />
                  <h3 className="text-lg font-bold text-slate-900 font-geist">Step 3 — Quantities, Unit Rates &amp; Payment Details</h3>
                </div>
              </div>

              <div className="space-y-3">
                {items.map((item, idx) => (
                  <div key={idx} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                    <div className="sm:col-span-1">
                      <label className="font-semibold text-slate-900 block mb-1">Item #{idx + 1}</label>
                      <div className="text-slate-600 truncate text-xs pt-1 font-medium">{item.description || 'Deliverable'}</div>
                    </div>
                    <div>
                      <label className="font-semibold text-slate-900 block mb-1">Quantity</label>
                      <input
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) => {
                          const updated = [...items];
                          updated[idx].quantity = Math.max(1, Number(e.target.value));
                          setItems(updated);
                        }}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                      />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="font-semibold text-slate-900 flex items-center gap-1">
                          <span>Rate (₹)</span>
                          <span className="text-rose-500 font-bold" title="Mandatory field">*</span>
                        </label>
                        <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
                          Mandatory
                        </span>
                      </div>
                      <input
                        type="number"
                        min="1"
                        step="any"
                        required
                        aria-required="true"
                        placeholder="Enter unit rate (mandatory)"
                        value={item.rate === 0 || !item.rate ? '' : item.rate}
                        onChange={(e) => {
                          const val = e.target.value;
                          const updated = [...items];
                          updated[idx].rate = val === '' ? ('' as unknown as number) : Math.max(0, Number(val));
                          setItems(updated);
                          if (step3Error && val && Number(val) > 0) {
                            setStep3Error(null);
                          }
                        }}
                        className={`w-full px-3 py-2 bg-white border rounded-lg font-geist font-bold text-xs transition-all outline-none ${
                          !item.rate || Number(item.rate) <= 0
                            ? 'border-rose-400 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 bg-rose-50/10 placeholder:text-slate-400 placeholder:font-normal'
                            : 'border-slate-300 focus:border-slate-900 focus:ring-2 focus:ring-slate-900/10'
                        }`}
                      />
                      {(!item.rate || Number(item.rate) <= 0) && (
                        <span className="text-[10px] text-rose-600 font-medium block mt-1">
                          Rate is mandatory to calculate invoice totals
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="font-semibold text-slate-900 block mb-1">GST Slab</label>
                      <select
                        value={item.gstRate}
                        onChange={(e) => {
                          const updated = [...items];
                          updated[idx].gstRate = Number(e.target.value);
                          setItems(updated);
                        }}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                      >
                        <option value={18}>18% (Standard Services)</option>
                        <option value={12}>12% (Specified Tech)</option>
                        <option value={5}>5% (Essential Goods)</option>
                        <option value={0}>0% (Export with LUT)</option>
                        <option value={28}>28% (Luxury / Specified)</option>
                      </select>
                    </div>
                  </div>
                ))}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  <div className="p-3.5 bg-white border border-slate-200 rounded-xl">
                    <label className="text-xs font-bold text-slate-900 block mb-1">Payment Due Date</label>
                    <input
                      type="date"
                      value={dueDate}
                      onChange={(e) => setDueDate(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium"
                    />
                    <p className="text-[11px] text-slate-500 mt-1">MSME rule: Payment term should be ≤ 45 days.</p>
                  </div>

                  {/* Bank / UPI Destination Card */}
                  <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                          <QrCode className="w-3.5 h-3.5 text-emerald-600" />
                          Payment &amp; Payout Destination
                        </span>
                        <button
                          type="button"
                          onClick={handleOpenBankModal}
                          className="text-[11px] text-blue-600 hover:underline font-semibold flex items-center gap-0.5 cursor-pointer"
                        >
                          <Edit3 className="w-3 h-3" /> Edit Payment / VPA
                        </button>
                      </div>
                      {bankDetails.accountNumber ? (
                        <>
                          <p className="text-xs text-slate-800 font-semibold">{bankDetails.bankName || 'Bank'} ({bankDetails.accountNumber})</p>
                          <p className="text-[11px] text-slate-500 font-mono">IFSC: {bankDetails.ifscCode} • UPI: {bankDetails.upiId}</p>
                        </>
                      ) : (
                        <>
                          <p className="text-xs text-slate-800 font-semibold flex items-center gap-1 text-emerald-800">
                            <Sparkles className="w-3 h-3 text-emerald-600" />
                            Dynamic UPI QR Active (VPA: {bankDetails.upiId})
                          </p>
                          <p className="text-[11px] text-slate-500">Payee: {bankDetails.accountHolderName || supplierBusinessName} • Bank account is optional</p>
                        </>
                      )}
                    </div>
                    <span className="text-[10px] text-emerald-700 font-semibold mt-1">✓ Dynamic UPI QR code generated from VPA &amp; total amount</span>
                  </div>
                </div>
              </div>

              {step3Error && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span className="font-semibold">{step3Error}</span>
                </div>
              )}

              <div className="pt-4 flex justify-between items-center">
                <button
                  type="button"
                  onClick={() => setCurrentStep(2)}
                  className="inline-flex items-center gap-1 text-xs text-slate-600 hover:text-slate-900 font-semibold"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Line Items</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const hasInvalidRate = items.some((item) => !item.rate || Number(item.rate) <= 0);
                    if (hasInvalidRate) {
                      setStep3Error('Please enter a valid rate for all line items before proceeding (mandatory).');
                      return;
                    }
                    setStep3Error(null);
                    setCurrentStep(4);
                  }}
                  className="bg-slate-900 text-white hover:bg-slate-800 font-semibold text-xs py-2.5 px-6 rounded-xl flex items-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <span>Next: Review &amp; UPI QR Code</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: REVIEW & LIVE EDIT WITH UPI QR CODE BESIDE INVOICE */}
          {currentStep === 4 && (
            <div className="space-y-4 animate-in fade-in">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Eye className="w-5 h-5 text-slate-700" />
                  <h3 className="text-lg font-bold text-slate-900 font-geist">Step 4 — Review Draft &amp; Payment QR Code</h3>
                </div>
                <button
                  type="button"
                  onClick={() => handleDownloadPdf()}
                  disabled={isPdfGenerating}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-black text-white rounded-lg text-xs font-semibold transition-all shadow-xs cursor-pointer disabled:opacity-50"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isPdfGenerating ? 'Generating...' : 'Download PDF Now'}</span>
                </button>
              </div>

              {/* Review Card with Live Bank Details and UPI QR Code */}
              <div className="border border-slate-200 rounded-xl p-5 bg-slate-50/70 space-y-4 text-xs">
                {/* Header info */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 border-b border-slate-200 pb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-slate-900">Billed By (Supplier):</span>
                    </div>
                    <span className="text-sm font-bold text-slate-900 block">{supplierBusinessName}</span>
                    <span className="text-slate-600 block">Contact: {supplierContactName}</span>
                    <span className="text-slate-600 block">{supplierEmail}</span>
                    <span className="text-slate-500 font-mono text-[11px] block mt-0.5">GSTIN: {supplierGstin}</span>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-slate-900">Billed To (Recipient):</span>
                      <button
                        type="button"
                        onClick={() => setCurrentStep(1)}
                        className="text-[11px] text-blue-600 hover:underline inline-flex items-center gap-0.5 font-semibold"
                      >
                        <Edit3 className="w-3 h-3" /> Edit
                      </button>
                    </div>
                    <span className="text-sm font-bold text-slate-900 block">{clientName || 'Acme Global Ventures'}</span>
                    <span className="text-slate-600 block">{clientEmail || 'billing@acme.com'}</span>
                    <span className="text-slate-500 font-mono text-[11px] block mt-0.5">GSTIN: {clientGstin || 'Unregistered / B2C'}</span>
                  </div>

                  <div className="sm:text-right">
                    <div className="flex sm:justify-end items-center gap-2 mb-1">
                      <span className="font-bold text-slate-900">Invoice Info:</span>
                      <button
                        type="button"
                        onClick={() => setCurrentStep(1)}
                        className="text-[11px] text-blue-600 hover:underline inline-flex items-center gap-0.5 font-semibold"
                      >
                        <Edit3 className="w-3 h-3" /> Edit
                      </button>
                    </div>
                    <span className="font-geist font-bold text-slate-900 block">{invoiceNumber}</span>
                    <span className="text-slate-600 block">Due Date: {dueDate}</span>
                    <span className="text-[11px] text-emerald-700 font-semibold mt-0.5 block">✓ GST Compliant Format</span>
                  </div>
                </div>

                {/* Line Items Table */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-900">Line Items &amp; Deliverables</span>
                    <button
                      type="button"
                      onClick={() => setCurrentStep(2)}
                      className="text-[11px] text-blue-600 hover:underline inline-flex items-center gap-0.5 font-semibold"
                    >
                      <Edit3 className="w-3 h-3" /> Edit Items &amp; Quantities
                    </button>
                  </div>

                  <div className="divide-y divide-slate-200 border border-slate-200 rounded-lg overflow-hidden bg-white">
                    {items.map((item, idx) => (
                      <div key={idx} className="p-2.5 flex justify-between items-center text-xs">
                        <div className="flex-1 pr-2">
                          <span className="font-medium text-slate-900 block">{item.description}</span>
                          <span className="text-[11px] text-slate-500">
                            Qty: {item.quantity} × ₹{Number(item.rate || 0).toLocaleString('en-IN')} (GST {item.gstRate}%)
                          </span>
                        </div>
                        <span className="font-geist font-bold text-slate-900 text-sm">
                          ₹{(item.quantity * (Number(item.rate) || 0)).toLocaleString('en-IN')}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Totals Breakdown */}
                <div className="pt-2 border-t border-slate-200 space-y-1.5">
                  <div className="flex justify-between text-slate-600">
                    <span>Taxable Subtotal:</span>
                    <span className="font-geist font-semibold">₹{subtotal.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Total GST:</span>
                    <span className="font-geist font-semibold">₹{gstTotal.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between text-base font-black text-slate-900 pt-2 border-t border-slate-300">
                    <span>Total Invoice Payable:</span>
                    <span className="font-geist text-lg text-slate-950 font-black">₹{totalAmount.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                {/* PAYMENT SECTION: BANK DETAILS + LIVE UPI QR CODE BESIDE INVOICE */}
                <div className="pt-3 border-t border-slate-200">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-slate-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                      <QrCode className="w-3.5 h-3.5 text-emerald-600" />
                      Dynamic UPI Payment QR Code &amp; Payout Details
                    </span>
                    <button
                      type="button"
                      onClick={handleOpenBankModal}
                      className="text-[11px] text-blue-600 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <Edit3 className="w-3 h-3" /> Edit VPA / Bank Info
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-3 bg-white p-4 rounded-xl border border-slate-200">
                    {/* Left: Payment Text Details */}
                    <div className="md:col-span-8 space-y-2 text-xs">
                      {bankDetails.accountNumber ? (
                        <>
                          <div className="font-semibold text-slate-900 text-sm">
                            {bankDetails.bankName} {bankDetails.branchName ? `(${bankDetails.branchName})` : ''}
                          </div>
                          <div className="text-slate-600">
                            Beneficiary: <strong className="text-slate-900">{bankDetails.accountHolderName || supplierBusinessName}</strong>
                          </div>
                          <div className="text-slate-600 font-mono text-[11px]">
                            Account Number: <strong className="text-slate-900">{bankDetails.accountNumber}</strong> ({bankDetails.accountType || 'Current'})
                          </div>
                          <div className="text-slate-600 font-mono text-[11px]">
                            IFSC Code: <strong className="text-slate-900">{bankDetails.ifscCode}</strong>
                          </div>
                        </>
                      ) : (
                        <div className="space-y-1.5">
                          <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 text-[10px] font-bold border border-emerald-200">
                            <Sparkles className="w-3 h-3 text-emerald-600" />
                            DYNAMIC UPI QR PAYMENT ACTIVATED
                          </div>
                          <div className="font-bold text-slate-900 text-sm">
                            Payee: {bankDetails.accountHolderName || supplierBusinessName}
                          </div>
                          <p className="text-slate-600 text-xs">
                            Clients scan the dynamic QR code beside this invoice using any UPI-enabled app (Google Pay, PhonePe, Paytm, BHIM, CRED). The payable amount of <strong className="text-slate-900 font-semibold">₹{totalAmount.toLocaleString('en-IN')}</strong> and reference <strong className="text-slate-900 font-semibold">{invoiceNumber}</strong> are auto-filled.
                          </p>
                          <div className="text-[11px] text-slate-500 italic">
                            (Bank account transfer details are optional and can be added anytime)
                          </div>
                        </div>
                      )}
                      <div className="flex items-center gap-2 pt-2">
                        <span className="text-slate-700 font-mono text-xs">
                          UPI ID / VPA: <strong className="text-slate-900 font-bold bg-slate-100 px-2 py-1 rounded border border-slate-200">{bankDetails.upiId}</strong>
                        </span>
                        <button
                          type="button"
                          onClick={handleCopyUpi}
                          className="text-[10px] text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-2.5 py-1 rounded-md flex items-center gap-1 cursor-pointer font-medium border border-slate-300"
                        >
                          {copiedUpi ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedUpi ? 'Copied' : 'Copy VPA'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Right: Live Dynamic UPI QR Code beside Invoice */}
                    <div className="md:col-span-4 flex flex-col items-center justify-center p-3.5 bg-gradient-to-b from-slate-50 to-white rounded-xl border border-slate-200 text-center shadow-2xs">
                      <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-1.5">Scan to Pay via UPI</div>
                      {activeQrDataUrl ? (
                        <img
                          src={activeQrDataUrl}
                          alt="Dynamic UPI Payment QR Code"
                          className="w-32 h-32 object-contain rounded-lg border border-slate-200 bg-white p-1.5 shadow-xs"
                        />
                      ) : (
                        <div className="w-32 h-32 bg-slate-100 animate-pulse rounded-lg flex items-center justify-center text-slate-400">
                          <QrCode className="w-8 h-8" />
                        </div>
                      )}
                      <div className="text-xs font-black text-slate-900 mt-2 font-mono">₹{totalAmount.toLocaleString('en-IN')}</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">Google Pay • PhonePe • Paytm • BHIM</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-4 flex flex-wrap justify-between items-center gap-3">
                <button
                  type="button"
                  onClick={() => setCurrentStep(3)}
                  className="inline-flex items-center gap-1 text-xs text-slate-600 hover:text-slate-900 font-semibold"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Step 3</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleDownloadPdf()}
                    disabled={isPdfGenerating}
                    className="bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 font-semibold text-xs py-2.5 px-4 rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer disabled:opacity-50"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{isPdfGenerating ? 'Generating PDF...' : 'Download PDF'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCurrentStep(5)}
                    className="bg-slate-900 text-white hover:bg-slate-800 font-semibold text-xs py-2.5 px-6 rounded-xl flex items-center gap-1.5 shadow-sm cursor-pointer"
                  >
                    <span>Proceed to Send</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* STEP 5: FINAL SEND & INSTANT PDF DOWNLOAD */}
          {currentStep === 5 && (
            <div className="space-y-5 animate-in fade-in text-center py-4">
              <div className="w-16 h-16 bg-slate-900 text-white rounded-2xl flex items-center justify-center mx-auto shadow-md">
                <CheckCircle2 className="w-8 h-8 text-emerald-400" />
              </div>

              <div className="space-y-1 max-w-lg mx-auto">
                <h3 className="text-xl font-black text-slate-900 font-geist">Invoice Ready with Bank Details &amp; UPI QR</h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  GST-compliant invoice <strong>{invoiceNumber}</strong> generated for <strong>{clientName || 'Client'}</strong> totaling{' '}
                  <strong>₹{totalAmount.toLocaleString('en-IN')}</strong>. Includes payout info for <strong>{bankDetails.bankName}</strong> and instant QR code.
                </p>
              </div>

              {/* Delivery / Download Options */}
              <div className="max-w-xl mx-auto grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    handleSafeAddInvoice(currentWorkingInvoice);
                    setEmailModalInvoice(currentWorkingInvoice);
                    setIsCreating(false);
                    setCurrentStep(1);
                  }}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all cursor-pointer group"
                >
                  <Mail className="w-4 h-4 text-emerald-100 group-hover:scale-110 transition-transform" />
                  <span>Email &amp; Attach PDF</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleDownloadPdf()}
                  disabled={isPdfGenerating}
                  className="bg-white border-2 border-slate-900 hover:bg-slate-50 text-slate-900 font-bold text-xs py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer disabled:opacity-50"
                >
                  <Download className="w-4 h-4 text-slate-900" />
                  <span>{isPdfGenerating ? 'Generating...' : 'Download PDF'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleCompleteInvoice}
                  className="bg-slate-900 hover:bg-black text-white font-bold text-xs py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
                >
                  <Send className="w-4 h-4 text-slate-400" />
                  <span>Save &amp; Track</span>
                </button>
              </div>

              <div className="pt-4 flex justify-center items-center gap-4 text-xs">
                <button
                  type="button"
                  onClick={() => setCurrentStep(4)}
                  className="text-slate-500 hover:text-slate-900 font-semibold inline-flex items-center gap-1"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Modify Draft</span>
                </button>
                <span className="text-slate-300">|</span>
                <button
                  type="button"
                  onClick={() => setCurrentStep(1)}
                  className="text-blue-600 hover:underline font-semibold"
                >
                  Edit from Step 1
                </button>
              </div>
            </div>
          )}
        </div>
      ) : mainViewMode === 'gst_reports' ? (
        /* MONTHLY SALES GST REPORT VIEW (GOVT COMPLIANCE GSTR-1, 2B, 3B) */
        <MonthlySalesGstReport
          invoices={invoices}
          profile={profile}
          onSelectInvoice={(inv) => setPreviewInvoice(inv)}
        />
      ) : (
        /* INVOICE LIST OR EMPTY STATE */
        <div className="space-y-4">
          {invoices.length === 0 ? (
            /* EMPTY STATE */
            <div className="bg-white rounded-2xl p-8 md:p-12 text-center border border-slate-200 shadow-sm space-y-4">
              <div className="w-12 h-12 bg-slate-100 text-slate-500 rounded-full flex items-center justify-center mx-auto">
                <FileText className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 font-geist">NO INVOICES YET</h3>
              <p className="text-xs text-slate-600 max-w-sm mx-auto leading-relaxed">
                Create your first invoice to start tracking customer payments, automate GST calculations, and generate downloadable PDF statements.
              </p>
              <button
                onClick={handleStartNew}
                className="bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold py-3 px-6 rounded-xl inline-flex items-center gap-2 shadow-sm transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>CREATE INVOICE</span>
              </button>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-4 md:p-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-base font-bold text-slate-900 font-geist">Recent Client Invoices</h3>
                  <p className="text-xs text-slate-500">View, edit, track, or download GST invoices in PDF format with dynamic QR code</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg">
                    {invoices.length} Total Invoices
                  </span>
                  <button
                    type="button"
                    onClick={handleStartNew}
                    className="inline-flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>New</span>
                  </button>
                </div>
              </div>

              <div className="space-y-3">
                {invoices.map((inv) => (
                  <div
                    key={inv.id}
                    className="p-4 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50/50 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900 font-geist tracking-wide">{inv.invoiceNumber}</span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                            inv.status === 'paid'
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : inv.status === 'overdue'
                              ? 'bg-red-50 text-red-700 border border-red-200'
                              : 'bg-slate-100 text-slate-700 border border-slate-200'
                          }`}
                        >
                          {inv.status}
                        </span>
                        <span className="text-[11px] text-slate-400 font-mono">Date: {inv.date}</span>
                      </div>
                      <div className="text-sm font-semibold text-slate-900">{inv.clientName}</div>
                      <div className="text-xs text-slate-500 flex flex-wrap items-center gap-2">
                        <span>Email: {inv.clientEmail}</span>
                        <span>•</span>
                        <span>Due: {inv.dueDate}</span>
                        {inv.clientGstin && (
                          <>
                            <span>•</span>
                            <span className="font-mono text-[11px]">GSTIN: {inv.clientGstin}</span>
                          </>
                        )}
                        {emailHistory[inv.id] && (
                          <>
                            <span>•</span>
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              Emailed ({emailHistory[inv.id].method})
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between md:justify-end gap-3 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
                      <div className="text-left md:text-right">
                        <div className="text-base font-black font-geist text-slate-900">
                          ₹{inv.total.toLocaleString('en-IN')}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          GST: ₹{inv.gstAmount.toLocaleString('en-IN')}
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setEmailModalInvoice(inv)}
                          className="px-2.5 py-1.5 text-xs font-semibold text-emerald-700 hover:text-emerald-900 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                          title="Send detailed tax invoice to customer via Email"
                        >
                          <Mail className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Email</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setPreviewInvoice(inv)}
                          className="px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                          title="Preview invoice document"
                        >
                          <Eye className="w-3.5 h-3.5 text-slate-500" />
                          <span>Preview</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDownloadPdf(inv)}
                          disabled={isPdfGenerating}
                          className="px-2.5 py-1.5 text-xs font-semibold text-slate-900 hover:text-black bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg flex items-center gap-1 transition-colors cursor-pointer disabled:opacity-50"
                          title="Download GST invoice as PDF"
                        >
                          <Download className="w-3.5 h-3.5 text-slate-700" />
                          <span>PDF</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleEditExisting(inv)}
                          className="px-2.5 py-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200/60 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                          title="Edit invoice details"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>

                        {inv.status === 'overdue' && (
                          <button
                            type="button"
                            onClick={() => setEmailModalInvoice(inv)}
                            className="text-xs bg-red-700 text-white hover:bg-red-800 px-3 py-1.5 rounded-lg font-semibold shadow-xs cursor-pointer flex items-center gap-1"
                            title="Send urgent overdue payment reminder to customer"
                          >
                            <Mail className="w-3.5 h-3.5" />
                            <span>Remind Client</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* FULL INVOICE PREVIEW & DOWNLOAD MODAL */}
      {previewInvoice && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 p-6 md:p-8 space-y-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div>
                <span className="text-xs font-bold text-slate-500 font-geist uppercase">TAX INVOICE PREVIEW</span>
                <h3 className="text-lg font-black text-slate-900 font-geist">{previewInvoice.invoiceNumber}</h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setEmailModalInvoice(previewInvoice);
                  }}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold px-3.5 py-2 rounded-xl flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
                  title="Send detailed invoice via Email with PDF attachment"
                >
                  <Mail className="w-4 h-4 text-emerald-100" />
                  <span>Email &amp; Attach PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleDownloadPdf(previewInvoice)}
                  disabled={isPdfGenerating}
                  className="bg-slate-900 hover:bg-black text-white text-xs font-semibold px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-sm transition-all cursor-pointer disabled:opacity-50"
                >
                  <Download className="w-4 h-4" />
                  <span>{isPdfGenerating ? 'Generating...' : 'Download PDF'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewInvoice(null)}
                  className="text-slate-400 hover:text-slate-700 text-sm font-bold p-2 cursor-pointer"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Rendered Invoice Paper View */}
            <div className="border border-slate-200 rounded-xl p-6 bg-slate-50/50 space-y-5 text-xs">
              <div className="flex justify-between items-start">
                <div>
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">BILLED BY (SUPPLIER)</div>
                  <h4 className="text-sm font-bold text-slate-900">{supplierBusinessName}</h4>
                  <p className="text-slate-600">Contact: {supplierContactName}</p>
                  <p className="text-slate-500 font-mono">GSTIN: {supplierGstin}</p>
                  <p className="text-slate-500">Email: {supplierEmail}</p>
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold text-slate-900">Date: {previewInvoice.date}</div>
                  <div className="text-slate-500">Due: {previewInvoice.dueDate}</div>
                  <span className="inline-block mt-1 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase bg-slate-100 text-slate-800 border border-slate-200">
                    Status: {previewInvoice.status}
                  </span>
                </div>
              </div>

              <div className="border-t border-slate-200 pt-4">
                <span className="font-bold text-slate-900 block mb-1">BILLED TO (RECIPIENT):</span>
                <p className="text-sm font-semibold text-slate-900">{previewInvoice.clientName}</p>
                <p className="text-slate-600">Email: {previewInvoice.clientEmail}</p>
                <p className="text-slate-500 font-mono text-[11px]">GSTIN: {previewInvoice.clientGstin || 'Unregistered'}</p>
              </div>

              {/* Items Table */}
              <div className="border border-slate-200 rounded-lg overflow-hidden bg-white">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                    <tr>
                      <th className="p-2.5">Item &amp; Description</th>
                      <th className="p-2.5 text-right">Qty</th>
                      <th className="p-2.5 text-right">Rate</th>
                      <th className="p-2.5 text-right">GST</th>
                      <th className="p-2.5 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {previewInvoice.items && previewInvoice.items.length > 0 ? (
                      previewInvoice.items.map((it, i) => (
                        <tr key={i}>
                          <td className="p-2.5 font-medium text-slate-900">{it.description}</td>
                          <td className="p-2.5 text-right font-mono">{it.quantity}</td>
                          <td className="p-2.5 text-right font-geist">₹{it.rate.toLocaleString('en-IN')}</td>
                          <td className="p-2.5 text-right">{it.gstRate}%</td>
                          <td className="p-2.5 text-right font-geist font-bold text-slate-900">
                            ₹{(it.quantity * it.rate).toLocaleString('en-IN')}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td className="p-2.5 font-medium text-slate-900">Consulting &amp; Engineering Support</td>
                        <td className="p-2.5 text-right font-mono">1</td>
                        <td className="p-2.5 text-right font-geist">₹{previewInvoice.subtotal.toLocaleString('en-IN')}</td>
                        <td className="p-2.5 text-right">18%</td>
                        <td className="p-2.5 text-right font-geist font-bold text-slate-900">
                          ₹{previewInvoice.subtotal.toLocaleString('en-IN')}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Summary */}
              <div className="flex justify-end pt-2">
                <div className="w-64 space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal:</span>
                    <span className="font-geist font-semibold">₹{previewInvoice.subtotal.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>GST (18%):</span>
                    <span className="font-geist font-semibold">₹{previewInvoice.gstAmount.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between text-sm font-black text-slate-900 pt-2 border-t border-slate-300">
                    <span>Total Amount:</span>
                    <span className="font-geist text-base text-slate-950 font-black">₹{previewInvoice.total.toLocaleString('en-IN')}</span>
                  </div>
                </div>
              </div>

              {/* Payment Info & UPI QR Code in Preview */}
              <div className="border-t border-slate-200 pt-4">
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">BANK &amp; PAYMENT DETAILS</div>
                <div className="grid grid-cols-1 md:grid-cols-12 gap-3 bg-white p-3.5 rounded-xl border border-slate-200">
                  <div className="md:col-span-8 space-y-1 text-xs">
                    {bankDetails.accountNumber ? (
                      <>
                        <p className="font-bold text-slate-900">{bankDetails.bankName} {bankDetails.branchName ? `(${bankDetails.branchName})` : ''}</p>
                        <p className="text-slate-600">Beneficiary: <strong className="text-slate-900">{bankDetails.accountHolderName || supplierBusinessName}</strong></p>
                        <p className="text-slate-600 font-mono text-[11px]">A/C No: <strong className="text-slate-900">{bankDetails.accountNumber}</strong> ({bankDetails.accountType || 'Current'})</p>
                        <p className="text-slate-600 font-mono text-[11px]">IFSC Code: <strong className="text-slate-900">{bankDetails.ifscCode}</strong></p>
                      </>
                    ) : (
                      <>
                        <p className="font-bold text-slate-900 flex items-center gap-1.5 text-emerald-800">
                          <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                          Dynamic UPI QR Payment Active
                        </p>
                        <p className="text-slate-600">Payee: <strong className="text-slate-900">{bankDetails.accountHolderName || supplierBusinessName}</strong></p>
                        <p className="text-[11px] text-slate-500">Instant scan to pay via GPay, PhonePe, Paytm, BHIM, CRED</p>
                      </>
                    )}
                    <p className="text-slate-600 font-mono text-[11px]">UPI ID / VPA: <strong className="text-slate-900">{bankDetails.upiId}</strong></p>
                  </div>

                  <div className="md:col-span-4 flex flex-col items-center justify-center p-2.5 bg-slate-50 rounded-lg border border-slate-200/80 text-center">
                    {previewQrDataUrl ? (
                      <img
                        src={previewQrDataUrl}
                        alt="Payment QR"
                        className="w-24 h-24 object-contain rounded bg-white p-1 border border-slate-200 shadow-2xs"
                      />
                    ) : (
                      <div className="w-24 h-24 bg-slate-200 animate-pulse rounded flex items-center justify-center">
                        <QrCode className="w-6 h-6 text-slate-400" />
                      </div>
                    )}
                    <span className="text-[10px] font-bold text-slate-900 mt-1">Scan to Pay via UPI</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center pt-2">
              <button
                type="button"
                onClick={() => {
                  const inv = previewInvoice;
                  setPreviewInvoice(null);
                  handleEditExisting(inv);
                }}
                className="text-xs font-semibold text-blue-600 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit this Invoice in Wizard</span>
              </button>

              <button
                type="button"
                onClick={() => handleDownloadPdf(previewInvoice)}
                disabled={isPdfGenerating}
                className="bg-slate-900 hover:bg-black text-white text-xs font-semibold px-5 py-2.5 rounded-xl flex items-center gap-2 shadow-sm transition-all cursor-pointer disabled:opacity-50"
              >
                <Download className="w-4 h-4" />
                <span>{isPdfGenerating ? 'Generating...' : 'Download Official PDF'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* BANK & DYNAMIC UPI QR CONFIGURATION MODAL */}
      {showBankModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200 p-6 space-y-5 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3.5">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center">
                  <QrCode className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 font-geist">Dynamic UPI QR &amp; Payment Setup</h3>
                  <p className="text-xs text-slate-500">Configure your VPA / UPI ID to generate dynamic scan-to-pay QR codes. Bank details are optional.</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowBankModal(false)}
                className="text-slate-400 hover:text-slate-700 text-sm font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Dynamic QR Info Banner */}
            <div className="p-3.5 bg-emerald-50/70 border border-emerald-200 rounded-xl flex items-start gap-3">
              <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div className="text-xs text-emerald-950">
                <strong className="font-semibold block text-emerald-900">Dynamic UPI QR Codes for Instant Collections</strong>
                Your UPI ID (VPA) is encoded with the exact invoice amount and invoice number. Clients can scan and pay seamlessly via Google Pay, PhonePe, Paytm, BHIM, or CRED. Full bank account details are optional.
              </div>
            </div>

            <form onSubmit={handleSaveBankDetails} className="space-y-4 text-xs">
              {/* Account Holder Name */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-bold text-slate-900">Beneficiary / Payee Business Name</label>
                  <span className="text-[11px] text-slate-400 font-normal">Optional (defaults to business name)</span>
                </div>
                <input
                  type="text"
                  value={bankForm.accountHolderName || ''}
                  onChange={(e) => setBankForm({ ...bankForm, accountHolderName: e.target.value })}
                  placeholder={supplierBusinessName || 'e.g. Krishna Tech Enterprises'}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold focus:outline-none focus:border-slate-500"
                />
              </div>

              {/* Bank Name & Preset helper */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-bold text-slate-900">Bank Name</label>
                  <span className="text-[11px] text-slate-400 font-normal">Optional (for NEFT / RTGS)</span>
                </div>
                <input
                  type="text"
                  value={bankForm.bankName || ''}
                  onChange={(e) => setBankForm({ ...bankForm, bankName: e.target.value })}
                  placeholder="Optional (e.g. HDFC Bank Ltd, ICICI Bank, State Bank of India)"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:outline-none focus:border-slate-500"
                />
                <div className="flex flex-wrap gap-1.5 mt-1.5">
                  {['HDFC Bank Ltd', 'ICICI Bank', 'State Bank of India', 'Axis Bank', 'Kotak Mahindra'].map((b) => (
                    <button
                      key={b}
                      type="button"
                      onClick={() => setBankForm({ ...bankForm, bankName: b })}
                      className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[10px] font-medium transition-colors cursor-pointer"
                    >
                      {b}
                    </button>
                  ))}
                </div>
              </div>

              {/* Account Number & Account Type */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-bold text-slate-900">Account Number</label>
                    <span className="text-[10px] text-slate-400 font-normal">Optional</span>
                  </div>
                  <input
                    type="text"
                    value={bankForm.accountNumber || ''}
                    onChange={(e) => setBankForm({ ...bankForm, accountNumber: e.target.value.replace(/\s+/g, '') })}
                    placeholder="Optional (e.g. 50200084920194)"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-semibold focus:outline-none focus:border-slate-500"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-900 block mb-1">Account Type</label>
                  <select
                    value={bankForm.accountType || 'Current'}
                    onChange={(e) => setBankForm({ ...bankForm, accountType: e.target.value as 'Current' | 'Savings' })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:outline-none focus:border-slate-500"
                  >
                    <option value="Current">Current Account (Business)</option>
                    <option value="Savings">Savings Account (Individual/Freelancer)</option>
                  </select>
                </div>
              </div>

              {/* IFSC & Branch */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-bold text-slate-900">IFSC Code (11 alphanumeric)</label>
                    <span className="text-[10px] text-slate-400 font-normal">Optional</span>
                  </div>
                  <input
                    type="text"
                    value={bankForm.ifscCode || ''}
                    onChange={(e) => setBankForm({ ...bankForm, ifscCode: e.target.value.toUpperCase().replace(/\s+/g, '') })}
                    placeholder="Optional (e.g. HDFC0000184)"
                    maxLength={11}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono uppercase font-semibold focus:outline-none focus:border-slate-500"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-bold text-slate-900">Branch / Location</label>
                    <span className="text-[10px] text-slate-400 font-normal">Optional</span>
                  </div>
                  <input
                    type="text"
                    value={bankForm.branchName || ''}
                    onChange={(e) => setBankForm({ ...bankForm, branchName: e.target.value })}
                    placeholder="Optional (e.g. Indiranagar, Bengaluru)"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:outline-none focus:border-slate-500"
                  />
                </div>
              </div>

              {/* UPI ID / VPA with Live Dynamic QR Code Preview */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
                    <QrCode className="w-4 h-4 text-emerald-600" />
                    UPI ID / VPA (Primary For Dynamic QR Code)
                  </label>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                    Recommended
                  </span>
                </div>

                <div className="relative">
                  <input
                    type="text"
                    value={bankForm.upiId || ''}
                    onChange={(e) => setBankForm({ ...bankForm, upiId: e.target.value.toLowerCase().replace(/\s+/g, '') })}
                    placeholder="e.g. mailbykrishna@okhdfcbank or business@upi"
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono font-semibold focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* Quick handle presets */}
                <div>
                  <span className="text-[10px] text-slate-500 block mb-1">Quick Handle Presets:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {['@okhdfcbank', '@okicici', '@oksbi', '@okaxis', '@paytm', '@ybl', '@upi'].map((handle) => {
                      const prefix = (bankForm.upiId || '').split('@')[0] || 'finaura';
                      return (
                        <button
                          key={handle}
                          type="button"
                          onClick={() => setBankForm({ ...bankForm, upiId: `${prefix}${handle}` })}
                          className="px-2 py-0.5 bg-white hover:bg-emerald-50 hover:border-emerald-300 border border-slate-200 rounded text-[10px] font-mono text-slate-700 transition-colors cursor-pointer"
                        >
                          {handle}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Live Dynamic QR Preview */}
                <div className="flex items-center gap-4 bg-white p-3 rounded-lg border border-slate-200">
                  {modalQrDataUrl ? (
                    <img
                      src={modalQrDataUrl}
                      alt="Live Dynamic QR Preview"
                      className="w-20 h-20 object-contain rounded border border-slate-200 p-1 bg-white shrink-0"
                    />
                  ) : (
                    <div className="w-20 h-20 bg-slate-100 rounded flex items-center justify-center text-slate-400 shrink-0">
                      <QrCode className="w-6 h-6" />
                    </div>
                  )}
                  <div className="space-y-1 text-xs">
                    <div className="font-bold text-slate-900 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                      Live Dynamic QR Code Preview
                    </div>
                    <div className="text-[11px] text-slate-600">
                      VPA: <strong className="font-mono text-slate-900">{bankForm.upiId || 'finaura@upi'}</strong>
                    </div>
                    <div className="text-[10px] text-slate-500">
                      Encodes Payee, Invoice Reference &amp; Amount into NPCI URI standard.
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-200 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setShowBankModal(false)}
                  className="text-xs text-slate-600 hover:text-slate-900 font-semibold px-3 py-2 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-slate-900 hover:bg-black text-white font-bold text-xs py-2.5 px-6 rounded-xl flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
                >
                  <Save className="w-4 h-4 text-emerald-400" />
                  <span>Save &amp; Update Payment Info</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REAL EMAIL DISPATCHER MODAL */}
      {emailModalInvoice && (
        <SendInvoiceEmailModal
          isOpen={!!emailModalInvoice}
          onClose={() => setEmailModalInvoice(null)}
          invoice={emailModalInvoice}
          businessProfile={profile}
          bankDetails={bankDetails}
          onMarkAsSent={handleRecordEmailSent}
        />
      )}
    </div>
  );
};
