import React, { useState } from 'react';
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
  FileText,
  Plus,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Send,
  Building2,
  Calendar,
  Sparkles,
  Download,
  IndianRupee,
  RefreshCw,
} from 'lucide-react';
import {
  BusinessProfile,
  Transaction,
  Invoice,
  ExpenseCategorySummary,
  NavTab,
  BankDetails,
  UserAccount,
} from '../../types';
import { AccountingView } from './AccountingView';
import { InvoicingView } from './InvoicingView';
import { ExpensesView } from './ExpensesView';

interface FinanceWorkspaceViewProps {
  profile: BusinessProfile;
  transactions: Transaction[];
  invoices: Invoice[];
  expensesSummary: ExpenseCategorySummary[];
  onUpdateTransaction: (id: string, updates: Partial<Transaction>) => void;
  onNavigate: (tab: NavTab) => void;
  onOpenAI: (prompt?: string) => void;
  onOpenAddTransaction: () => void;
  onOpenCreateInvoice: () => void;
  initialSubTab?: string;
  onAddInvoice?: (invoice: Invoice) => void;
  onUpdateBankDetails?: (bankDetails: BankDetails) => void;
  currentUser?: UserAccount | null;
}

export const FinanceWorkspaceView: React.FC<FinanceWorkspaceViewProps> = ({
  profile,
  transactions,
  invoices,
  expensesSummary,
  onUpdateTransaction,
  onNavigate,
  onOpenAI,
  onOpenAddTransaction,
  onOpenCreateInvoice,
  initialSubTab = 'overview',
  onAddInvoice,
  onUpdateBankDetails,
  currentUser,
}) => {
  const [subTab, setSubTab] = useState<
    'overview' | 'transactions' | 'invoices' | 'expenses' | 'receivables' | 'payables' | 'cashflow'
  >(initialSubTab as any);

  // Financial calculations from real user data
  const totalRevenue = (transactions || [])
    .filter((t) => t?.type === 'credit' && t?.status === 'approved')
    .reduce((sum, t) => sum + (t?.amount || 0), 0) +
    (invoices || [])
    .filter((inv) => inv?.status === 'paid')
    .reduce((sum, inv) => sum + (inv?.total || 0), 0);

  const totalExpenses = (transactions || [])
    .filter((t) => t?.type === 'debit' && t?.status === 'approved')
    .reduce((sum, t) => sum + (t?.amount || 0), 0);

  const netCashFlow = totalRevenue - totalExpenses;
  const cashBalance = netCashFlow;

  const pendingInvoices = (invoices || []).filter((inv) => inv?.status !== 'paid' && inv?.status !== 'cancelled');
  const pendingReceivables = pendingInvoices.reduce((sum, inv) => sum + (inv?.total || 0), 0);

  const pendingReviewTransactions = (transactions || []).filter(
    (t) => t?.status === 'pending_review' || t?.status === 'needs_review'
  );

  const deductibleExpensesCount = (transactions || []).filter(
    (t) => t?.type === 'debit' && t?.taxDeductible
  ).length;

  const hasData = (transactions?.length || 0) > 0 || (invoices?.length || 0) > 0;
  const runwayMonths = totalExpenses > 0 && cashBalance > 0 ? (cashBalance / totalExpenses).toFixed(1) : null;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Top Header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 md:p-6 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                FINANCE WORKSPACE
              </span>
              <span className="text-xs text-slate-500 font-mono">FY 2026-27 (Q2 Active)</span>
            </div>
            <h1 className="text-xl md:text-2xl font-bold text-slate-900 mt-1">Finance & Treasury Operations</h1>
            <p className="text-xs text-slate-600 mt-0.5">
              General ledger, double-entry bookkeeping, smart categorization, invoices, and working capital cashflow.
            </p>
          </div>

          {/* Quick Action CTAs */}
          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              type="button"
              onClick={onOpenAddTransaction}
              className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-2xs cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Transaction</span>
            </button>
            <button
              type="button"
              onClick={onOpenCreateInvoice}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-2xs cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Create Invoice</span>
            </button>
          </div>
        </div>

        {/* Top 4 Financial Metric Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mt-6">
          <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-xl">
            <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
              <span>Total Inflow (Revenue)</span>
              <ArrowUpRight className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-lg md:text-xl font-extrabold text-slate-900 mt-1">
              ₹{totalRevenue.toLocaleString('en-IN')}
            </div>
            <div className="text-[11px] text-emerald-700 font-bold mt-0.5">
              {totalRevenue > 0 ? `${(transactions || []).filter((t) => t.type === 'credit').length} credit entries` : 'No sales recorded yet'}
            </div>
          </div>

          <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-xl">
            <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
              <span>Total Outflow (Expenses)</span>
              <ArrowDownRight className="w-4 h-4 text-rose-600" />
            </div>
            <div className="text-lg md:text-xl font-extrabold text-slate-900 mt-1">
              ₹{totalExpenses.toLocaleString('en-IN')}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              {deductibleExpensesCount > 0 ? `${deductibleExpensesCount} Tax Deductible (Sec 37)` : 'No expenses logged'}
            </div>
          </div>

          <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-xl">
            <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
              <span>Receivables (Outstanding)</span>
              <Clock className="w-4 h-4 text-amber-600" />
            </div>
            <div className="text-lg md:text-xl font-extrabold text-slate-900 mt-1">
              ₹{pendingReceivables.toLocaleString('en-IN')}
            </div>
            <div className="text-[11px] text-amber-700 font-bold mt-0.5">
              {pendingInvoices.length > 0 ? `${pendingInvoices.length} Invoices Pending` : '0 Invoices Pending'}
            </div>
          </div>

          <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-xl">
            <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
              <span>Net Working Capital</span>
              <Wallet className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-lg md:text-xl font-extrabold text-slate-900 mt-1">
              ₹{cashBalance.toLocaleString('en-IN')}
            </div>
            <div className="text-[11px] text-emerald-700 font-bold mt-0.5">
              {runwayMonths ? `${runwayMonths} Months Runway` : hasData ? 'Operating Balance' : 'Awaiting Records'}
            </div>
          </div>
        </div>

        {/* Finance Sub-navigation Bar */}
        <div className="flex items-center gap-1 border-t border-slate-200/80 mt-6 pt-3 overflow-x-auto">
          {[
            { id: 'overview', label: 'Overview & Treasury' },
            { id: 'transactions', label: 'Transactions & Ledger' },
            { id: 'invoices', label: 'Invoices & Receivables' },
            { id: 'expenses', label: 'Expenses & Spend Analytics' },
            { id: 'receivables', label: 'Receivables Aging' },
            { id: 'payables', label: 'Payables & MSME 43B(h)' },
            { id: 'cashflow', label: 'Cash Flow Forecast' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSubTab(tab.id as any)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                subTab === tab.id
                  ? 'bg-slate-900 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Sub-tab Content Areas */}
      {subTab === 'overview' && (
        <div className="space-y-6">
          {/* Working Capital Snapshot */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-6 shadow-2xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Cash Inflow vs Outflow</h3>
                  <p className="text-xs text-slate-500">Real-time bank synchronization &amp; reconciliation</p>
                </div>
                <button
                  type="button"
                  onClick={() => onOpenAI('Analyze our monthly financial cashflow drift and give recommendations')}
                  className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" /> AI Treasury Brief
                </button>
              </div>

              {/* Visual Bars or Empty State */}
              {!hasData ? (
                <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200 text-slate-500 text-xs space-y-3">
                  <p className="font-semibold text-slate-700">No transactions recorded yet.</p>
                  <p className="text-slate-500 max-w-md mx-auto">
                    Record your first income or expense transaction or create a client invoice to activate real-time cash flow metrics.
                  </p>
                  <div className="flex justify-center gap-2 pt-2">
                    <button
                      type="button"
                      onClick={onOpenAddTransaction}
                      className="px-3 py-1.5 bg-slate-900 text-white text-xs font-bold rounded-lg cursor-pointer"
                    >
                      + Add Transaction
                    </button>
                    <button
                      type="button"
                      onClick={onOpenCreateInvoice}
                      className="px-3 py-1.5 bg-white border border-slate-300 text-slate-800 text-xs font-bold rounded-lg cursor-pointer hover:bg-slate-50"
                    >
                      + Create Invoice
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3 pt-2">
                  <div>
                    <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                      <span>Total Inflow (Credits &amp; Paid Invoices)</span>
                      <span className="text-emerald-700">₹{totalRevenue.toLocaleString('en-IN')}</span>
                    </div>
                    <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                      <div
                        className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${Math.min(100, Math.max(10, totalRevenue > 0 ? (totalRevenue / Math.max(totalRevenue, totalExpenses, 1)) * 100 : 0))}%`,
                        }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                      <span>Operating Outflows (Debits)</span>
                      <span className="text-rose-700">₹{totalExpenses.toLocaleString('en-IN')}</span>
                    </div>
                    <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                      <div
                        className="bg-rose-500 h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${Math.min(100, Math.max(10, totalExpenses > 0 ? (totalExpenses / Math.max(totalRevenue, totalExpenses, 1)) * 100 : 0))}%`,
                        }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                      <span>Net Operating Cash Margin</span>
                      <span className={netCashFlow >= 0 ? 'text-blue-700' : 'text-amber-700'}>
                        ₹{netCashFlow.toLocaleString('en-IN')}
                        {totalRevenue > 0 ? ` (${Math.round((netCashFlow / totalRevenue) * 100)}%)` : ''}
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${netCashFlow >= 0 ? 'bg-blue-600' : 'bg-amber-500'}`}
                        style={{
                          width: `${Math.min(100, Math.max(10, Math.abs(netCashFlow) > 0 ? (Math.abs(netCashFlow) / Math.max(totalRevenue, totalExpenses, 1)) * 100 : 0))}%`,
                        }}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* AI Financial Health Card */}
            <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-2xs flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center gap-2 text-emerald-400 text-xs font-mono font-bold">
                  <Sparkles className="w-4 h-4" />
                  <span>FINANCIAL OS HEALTH</span>
                </div>
                <h3 className="text-lg font-bold text-white mt-1">Audit-Ready Treasury</h3>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                  {!hasData
                    ? 'No records entered yet. All statements and balance sheets are ready to be populated from real transactions.'
                    : pendingReviewTransactions.length > 0
                    ? `${pendingReviewTransactions.length} recent transaction(s) need 1-click category confirmation to claim full GST Input Tax Credit.`
                    : 'Books are 100% categorized and ready for statutory reconciliation.'}
                </p>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Runway Duration:</span>
                  <span className="font-bold text-emerald-400">{runwayMonths ? `${runwayMonths} Months` : 'N/A'}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Total Recorded Entries:</span>
                  <span className="font-bold text-slate-200">{(transactions || []).length}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setSubTab('transactions')}
                  className="w-full mt-2 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl text-center cursor-pointer transition-colors"
                >
                  Review Ledger Transactions →
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {subTab === 'transactions' && (
        <AccountingView
          transactions={transactions}
          onUpdateTransaction={onUpdateTransaction}
          onNavigate={onNavigate}
          onOpenAI={onOpenAI}
        />
      )}

      {subTab === 'invoices' && (
        <InvoicingView
          invoices={invoices}
          profile={profile}
          currentUser={currentUser}
          onAddInvoice={onAddInvoice}
          onUpdateBankDetails={onUpdateBankDetails}
          onNavigate={onNavigate}
          onOpenAI={onOpenAI}
        />
      )}

      {subTab === 'expenses' && (
        <ExpensesView
          expenses={expensesSummary}
          expensesSummary={expensesSummary}
          transactions={transactions}
          onNavigate={onNavigate}
          onOpenAI={onOpenAI}
        />
      )}

      {subTab === 'receivables' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">Receivables Aging &amp; Recovery Tracker</h3>
              <p className="text-xs text-slate-500">Track outstanding payments from B2B clients and issue automated reminders</p>
            </div>
            <button
              type="button"
              onClick={onOpenCreateInvoice}
              className="px-3.5 py-1.5 bg-slate-900 text-white text-xs font-bold rounded-xl cursor-pointer hover:bg-slate-800"
            >
              + New Client Invoice
            </button>
          </div>

          {invoices.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200 text-slate-500 text-xs">
              <p className="font-semibold text-slate-700">No client invoices found.</p>
              <p className="mt-1 text-slate-500">Create your first invoice to track customer payment due dates and automate reminders.</p>
              <button
                type="button"
                onClick={onOpenCreateInvoice}
                className="mt-3 px-3.5 py-1.5 bg-slate-900 text-white text-xs font-bold rounded-xl cursor-pointer"
              >
                + Create Invoice
              </button>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 pt-2">
              {invoices.map((inv) => (
                <div key={inv.id} className="py-3 flex items-center justify-between flex-wrap gap-3">
                  <div>
                    <div className="text-xs font-bold text-slate-900">{inv.clientName}</div>
                    <div className="text-[11px] text-slate-500 font-mono">Invoice #{inv.invoiceNumber} • Due: {inv.dueDate}</div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-sm font-extrabold text-slate-900">₹{inv.total.toLocaleString('en-IN')}</div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        inv.status === 'paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {inv.status.toUpperCase()}
                      </span>
                    </div>
                    {inv.status !== 'paid' && (
                      <button
                        type="button"
                        onClick={() => alert(`Payment reminder sent to ${inv.clientEmail || inv.clientName}`)}
                        className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg cursor-pointer"
                      >
                        Send 1-Click Reminder
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {subTab === 'payables' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">Vendor Payables &amp; Section 43B(h) Guard</h3>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">MSME Statutory Rule</span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Payments to registered Micro &amp; Small enterprises must be cleared within 45 days to claim tax deductions.
              </p>
            </div>
            <button
              type="button"
              onClick={onOpenAddTransaction}
              className="px-3.5 py-1.5 bg-emerald-600 text-white text-xs font-bold rounded-xl cursor-pointer hover:bg-emerald-700"
            >
              + Record Vendor Payment
            </button>
          </div>

          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 space-y-2">
            <div className="font-semibold text-slate-800">43B(h) MSME Payment Safeguard Active</div>
            <p>
              When you record vendor bills, tag registered Micro and Small enterprises. Finaura automatically counts down the statutory 45-day cutoff to protect your income tax deductions under Section 43B(h).
            </p>
          </div>
        </div>
      )}

      {subTab === 'cashflow' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-2xs space-y-4">
          <h3 className="text-base font-bold text-slate-900">Working Capital &amp; Cash Forecast</h3>
          <p className="text-xs text-slate-500">Projected working capital based on confirmed receivables and average expense velocity.</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500 font-medium">Projected 30-Day Balance</div>
              <div className="text-lg font-bold text-slate-900 mt-1">
                ₹{(cashBalance + pendingReceivables).toLocaleString('en-IN')}
              </div>
              <div className="text-[11px] text-emerald-700 font-semibold">
                {pendingReceivables > 0 ? `+₹${pendingReceivables.toLocaleString('en-IN')} expected receivables` : 'Based on current cash'}
              </div>
            </div>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500 font-medium">Projected 60-Day Balance</div>
              <div className="text-lg font-bold text-slate-900 mt-1">
                ₹{Math.max(0, cashBalance + pendingReceivables - totalExpenses).toLocaleString('en-IN')}
              </div>
              <div className="text-[11px] text-slate-600">Post ongoing monthly operating expense buffer</div>
            </div>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500 font-medium">Projected 90-Day Balance</div>
              <div className="text-lg font-bold text-slate-900 mt-1">
                ₹{Math.max(0, cashBalance + (pendingReceivables * 1.5) - (totalExpenses * 2)).toLocaleString('en-IN')}
              </div>
              <div className="text-[11px] text-emerald-700 font-semibold">Working capital trajectory</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
