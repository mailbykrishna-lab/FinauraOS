import React, { useState } from 'react';
import {
  UserCheck,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldCheck,
  Star,
  MessageSquare,
  FileText,
  HelpCircle,
  Sparkles,
  Send,
  Building2,
  ChevronRight,
  Calendar,
} from 'lucide-react';
import { CAServiceRequest, NavTab } from '../../types';
import { NextBestAction } from '../NextBestAction';
import { ExplainWhyCard } from '../ExplainWhyCard';

interface CAMarketplaceViewProps {
  activeServices: CAServiceRequest[];
  onNavigate: (tab: NavTab) => void;
  onOpenAI: (prompt?: string) => void;
}

export const CAMarketplaceView: React.FC<CAMarketplaceViewProps> = ({
  activeServices,
  onNavigate,
  onOpenAI,
}) => {
  const [selectedServiceType, setSelectedServiceType] = useState<string | null>(null);
  const [requestDescription, setRequestDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState<'track' | 'browse'>('track');
  const [chatMessage, setChatMessage] = useState('');
  const [chatLog, setChatLog] = useState([
    { sender: 'CA Rajesh Sharma', time: '10:30 AM', message: 'Hello Krishna! I reviewed your GSTR-3B draft and uploaded bank statements. All 3 purchase invoices are accounted for.' },
  ]);

  const serviceCategories = [
    { id: 'gst', title: 'GST Filing & Reconciliation', desc: 'Monthly GSTR-1, 3B, and 2B ITC matching with zero mismatch' },
    { id: 'accounting', title: 'Accounting & Year-End Close', desc: 'Financial statement preparation, balance sheet & P&L sign-off' },
    { id: 'itr', title: 'Income Tax Return (ITR-6)', desc: 'Corporate tax computation, MAT calculation, and e-filing' },
    { id: 'tds', title: 'TDS Returns & 26Q/27Q', desc: 'Quarterly withholding returns, Form 16A generation & challan check' },
    { id: 'mca', title: 'MCA & ROC Annual Compliance', desc: 'Form AOC-4, MGT-7, and Director KYC filings with MCA21 portal' },
    { id: 'consult', title: '1-on-1 Strategic Tax Consultation', desc: 'Structure ESOPs, cross-border remittance, and transfer pricing' },
  ];

  const vettedCAs = [
    {
      name: 'CA Rajesh Sharma, FCA',
      firm: 'Sharma & Associates LLP',
      experience: '14+ Years',
      rating: 4.98,
      reviewsCount: 312,
      specialization: 'Pvt Ltd & Tech Startups (Bangalore)',
      whyFits: 'Expert in GST reconciliations & SaaS cross-border withholding tax.',
      status: 'Assigned to your workspace',
    },
    {
      name: 'CA Priya Venkatesh, ACA',
      firm: 'Venkatesh Advisory Co',
      experience: '9+ Years',
      rating: 4.95,
      reviewsCount: 184,
      specialization: 'D2C, Retail & Export (Ex-KPMG)',
      whyFits: 'Fast 24-hr turnaround for advance tax estimates & MCA filings.',
      status: 'Available for Consultation',
    },
  ];

  const handleSendMessage = () => {
    if (!chatMessage.trim()) return;
    setChatLog([...chatLog, { sender: 'You', time: 'Just now', message: chatMessage }]);
    setChatMessage('');
    setTimeout(() => {
      setChatLog((prev) => [
        ...prev,
        {
          sender: 'CA Rajesh Sharma',
          time: 'Just now',
          message: 'Got it! I will incorporate this before the final DSC signature this evening.',
        },
      ]);
    }, 1000);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-slate-600 uppercase tracking-wider font-geist">
            ICAI-CERTIFIED NETWORK
          </span>
          <h1 className="text-2xl md:text-3xl font-black text-slate-900 font-geist tracking-tight mt-0.5">
            CHARTERED ACCOUNTANT SERVICES
          </h1>
          <p className="text-sm text-slate-600 mt-0.5">
            On-demand statutory filing, audit assistance, and advisory from vetted Chartered Accountants.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('track')}
            className={`text-xs font-semibold px-4 py-2 rounded-xl transition-all ${
              activeTab === 'track'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
            }`}
          >
            Active Service Track ({activeServices.length})
          </button>
          <button
            onClick={() => setActiveTab('browse')}
            className={`text-xs font-semibold px-4 py-2 rounded-xl transition-all ${
              activeTab === 'browse'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
            }`}
          >
            Request New CA Service
          </button>
        </div>
      </div>

      {/* Professional Services Revenue Separation Notice & CA Pro Banner (Phase 5 & 12) */}
      <div className="bg-amber-50/80 border border-amber-200/90 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs text-amber-900">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <span className="font-bold block">Independent Professional Services Layer</span>
            <span className="text-amber-800/90">
              Statutory audit sign-offs and legal representations are provided directly by empanelled ICAI Chartered Accountants. These engagements are separate from your Finaura software license.
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={() => onNavigate('billing')}
          className="px-3 py-1.5 rounded-lg bg-amber-900 text-white hover:bg-amber-950 font-bold shrink-0 transition-colors cursor-pointer"
        >
          View Workspace Plan
        </button>
      </div>

      {/* 19. ACTIVE SERVICE TRACKING (Section 19 from user prompt) */}
      {activeTab === 'track' && activeServices.length > 0 && (
        <div className="space-y-6">
          {activeServices.map((service) => (
            <div
              key={service.id}
              className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 md:p-8 space-y-6"
            >
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-800 bg-slate-100 border border-slate-200 px-2.5 py-0.5 rounded-full uppercase font-geist">
                      ACTIVE ENGAGEMENT
                    </span>
                    <span className="text-xs text-slate-500">Target Date: {service.targetDate}</span>
                  </div>
                  <h2 className="text-xl font-bold text-slate-900 font-geist mt-1">{service.title}</h2>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-slate-100 text-slate-900 border border-slate-200 flex items-center justify-center font-bold font-geist">
                    RS
                  </div>
                  <div className="text-xs">
                    <div className="font-bold text-slate-900">{service.assignedCaName}</div>
                    <div className="text-slate-500">ICAI Reg: 084920</div>
                  </div>
                </div>
              </div>

              {/* 19. 7-STEP PROGRESS TRACKER */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-900 font-geist">
                  <span>ENGAGEMENT MILESTONES (Step {service.currentStep} of 7)</span>
                  <span className="text-slate-800 uppercase">In Progress</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-7 gap-2 pt-2">
                  {[
                    { step: 1, label: 'Requested' },
                    { step: 2, label: 'CA Assigned' },
                    { step: 3, label: 'Docs Synced' },
                    { step: 4, label: 'Review' },
                    { step: 5, label: 'In Progress' },
                    { step: 6, label: 'Client Sign-off' },
                    { step: 7, label: 'Filing Complete' },
                  ].map((st) => (
                    <div
                      key={st.step}
                      className={`p-2.5 rounded-lg text-center border text-[11px] font-semibold transition-all ${
                        st.step < service.currentStep
                          ? 'bg-slate-100 text-slate-800 border-slate-300'
                          : st.step === service.currentStep
                          ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                          : 'bg-slate-50 text-slate-400 border-slate-200'
                      }`}
                    >
                      <div className="text-[10px] opacity-80">STEP 0{st.step}</div>
                      <div className="truncate mt-0.5">{st.label}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 19. WHERE AM I? WHAT’S NEXT? WHO IS RESPONSIBLE? */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-500 font-semibold block mb-1">WHERE AM I?</span>
                  <p className="font-bold text-slate-900">{service.whereAmI}</p>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-500 font-semibold block mb-1">WHAT'S NEXT?</span>
                  <p className="font-bold text-slate-900">{service.whatsNext}</p>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-500 font-semibold block mb-1">WHO IS RESPONSIBLE?</span>
                  <p className="font-bold text-slate-900">{service.whoIsResponsible}</p>
                </div>
              </div>

              {/* Direct CA Chat Box */}
              <div className="border border-slate-200 rounded-xl p-4 space-y-3 bg-slate-50">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                  <MessageSquare className="w-4 h-4 text-slate-700" />
                  <span>Direct Encrypted Chat with {service.assignedCaName}</span>
                </div>

                <div className="space-y-2 max-h-40 overflow-y-auto bg-white p-3 rounded-lg border border-slate-200 text-xs">
                  {chatLog.map((c, i) => (
                    <div
                      key={i}
                      className={`p-2.5 rounded-lg max-w-[85%] ${
                        c.sender === 'You'
                          ? 'ml-auto bg-slate-900 text-white'
                          : 'bg-slate-100 text-slate-900'
                      }`}
                    >
                      <div className="flex justify-between text-[10px] opacity-70 mb-0.5">
                        <span>{c.sender}</span>
                        <span>{c.time}</span>
                      </div>
                      <p>{c.message}</p>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={chatMessage}
                    onChange={(e) => setChatMessage(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Type a message or question for your CA..."
                    className="flex-1 px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs focus:outline-none focus:border-slate-900"
                  />
                  <button
                    onClick={handleSendMessage}
                    className="bg-slate-900 text-white hover:bg-slate-800 px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 18. REQUEST NEW CA SERVICE WIZARD */}
      {(activeTab === 'browse' || activeServices.length === 0) && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-6 md:p-8 border border-slate-200 shadow-sm space-y-6">
            <div>
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider font-geist">
                SERVICE DIRECTORY
              </span>
              <h2 className="text-xl font-bold text-slate-900 font-geist mt-0.5">
                WHAT DO YOU NEED HELP WITH?
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Select an engagement category to match with certified Chartered Accountants.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {serviceCategories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedServiceType(cat.id)}
                  className={`p-4 rounded-xl border text-left transition-all ${
                    selectedServiceType === cat.id
                      ? 'border-slate-900 bg-slate-50 shadow-sm ring-1 ring-slate-900'
                      : 'border-slate-200 bg-white hover:bg-slate-50'
                  }`}
                >
                  <h3 className="font-bold text-xs text-slate-900 mb-1">{cat.title}</h3>
                  <p className="text-[11px] text-slate-500 leading-relaxed">{cat.desc}</p>
                </button>
              ))}
            </div>

            {/* Questionnaire container */}
            {selectedServiceType && (
              <div className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-4 animate-in fade-in">
                <h3 className="text-sm font-bold text-slate-900 font-geist">
                  TELL US A LITTLE MORE
                </h3>
                <div>
                  <label className="text-xs font-semibold text-slate-900 block mb-1">
                    Describe your requirements or specific questions
                  </label>
                  <textarea
                    rows={3}
                    value={requestDescription}
                    onChange={(e) => setRequestDescription(e.target.value)}
                    placeholder="e.g. Need assistance filing Q2 GSTR-3B and auditing ₹1.24L in software expenses..."
                    className="w-full p-3 bg-white border border-slate-300 rounded-xl text-xs focus:outline-none focus:border-slate-900"
                  />
                </div>

                <div className="flex justify-between items-center pt-2">
                  <span className="text-xs text-slate-500">Fixed-fee quotes delivered within 4 business hours</span>
                  <button
                    onClick={() => {
                      alert('Service request created! Matched with CA Rajesh Sharma.');
                      setActiveTab('track');
                    }}
                    className="bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold py-2.5 px-6 rounded-xl flex items-center gap-1.5 shadow-sm transition-all"
                  >
                    <span>Match with Vetted CA</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* VETTED CA PROFILES */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 font-geist">Vetted Chartered Accountants in Network</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {vettedCAs.map((ca, idx) => (
                <div key={idx} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{ca.name}</h4>
                      <p className="text-xs text-slate-500">{ca.firm} • {ca.experience}</p>
                    </div>
                    <div className="flex items-center gap-1 text-xs font-bold text-slate-900 bg-slate-100 px-2 py-1 rounded-md border border-slate-200">
                      <Star className="w-3.5 h-3.5 fill-slate-800 text-slate-800" />
                      <span>{ca.rating}</span>
                    </div>
                  </div>

                  <div className="text-xs bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <span className="text-slate-500 block text-[10px] uppercase font-semibold">
                      Why this professional fits:
                    </span>
                    <p className="text-slate-900 font-medium mt-0.5">{ca.whyFits}</p>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1">
                    <span className="text-slate-800 font-semibold">{ca.status}</span>
                    <button
                      onClick={() => {
                        setSelectedServiceType('consult');
                        setActiveTab('browse');
                      }}
                      className="text-slate-900 hover:underline font-semibold"
                    >
                      Book Intro Call
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
