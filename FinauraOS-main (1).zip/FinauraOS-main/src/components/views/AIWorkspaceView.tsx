import React, { useState } from 'react';
import {
  Sparkles,
  Bot,
  Send,
  ShieldCheck,
  Zap,
  Calculator,
  History,
  AlertTriangle,
  Lightbulb,
  FileText,
  Building2,
  CheckCircle2,
  RefreshCw,
  Clock,
  ArrowRight,
  TrendingUp,
  TrendingDown,
  Receipt,
} from 'lucide-react';
import { BusinessProfile, Transaction, Invoice } from '../../types';

interface AIWorkspaceViewProps {
  profile: BusinessProfile;
  transactions?: Transaction[];
  invoices?: Invoice[];
  onOpenAddTransaction?: () => void;
  onNavigate?: (tab: any) => void;
}

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  statutoryBasis?: string;
  actionRecommendation?: string;
}

export const AIWorkspaceView: React.FC<AIWorkspaceViewProps> = ({
  profile,
  transactions = [],
  invoices = [],
  onOpenAddTransaction,
  onNavigate,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'chat' | 'reasoner' | 'insights' | 'alerts' | 'history'>('chat');
  const [inputQuery, setInputQuery] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  // Active statement metrics
  const debits = transactions.filter((t) => t.type === 'debit');
  const credits = transactions.filter((t) => t.type === 'credit');
  const totalDebits = debits.reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
  const totalCredits = credits.reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
  const netCashFlow = totalCredits - totalDebits;
  const fmt = (n: number) => `₹${n.toLocaleString('en-IN')}`;

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg-1',
      sender: 'ai',
      text: `Hello ${profile.contactName || 'Founder'}! I am your Finaura Statutory & Financial AI Copilot. ${
        transactions.length > 0
          ? `I have connected your bank statement (${transactions.length} verified transactions loaded: Inflows ${fmt(totalCredits)}, Outflows ${fmt(totalDebits)}). I can analyze your spending, cash flow, calculate your tax under Income Tax Act 2025, or check Section 43B(h) MSME compliance.`
          : `I have calibrated your workspace for ${profile.businessName} (${profile.persona.toUpperCase()} • ${profile.state}) under the New Income Tax Act 2025, GST Rules, and Section 43B(h) MSME mandates. How can I assist your business today?`
      }`,
      timestamp: 'Today, 09:00 AM',
      statutoryBasis: 'Income Tax Act 2025, GST Act 2017 & MSMED Act 2006',
    },
  ]);

  // Reasoner Simulator State
  const [annualTurnover, setAnnualTurnover] = useState(2400000);
  const [optedTaxRegime, setOptedTaxRegime] = useState<'new_2025' | 'sec_44ada'>('sec_44ada');

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim()) return;

    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setIsTyping(true);

    try {
      const response = await fetch('/api/ask-finaura', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToSend,
          businessProfile: profile,
          transactions: transactions,
          invoices: invoices,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const aiMsg: Message = {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: data.answer || data.explanation || 'Processed successfully.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          statutoryBasis: data.statutoryRule || 'Income Tax Act 2025 / CBIC Circulars',
          actionRecommendation: data.recommendedAction,
        };
        setMessages((prev) => [...prev, aiMsg]);
      } else {
        throw new Error('API offline');
      }
    } catch (err) {
      // Dynamic local statement-aware fallback
      setTimeout(() => {
        const q = textToSend.toLowerCase();
        let replyText = '';
        let rule = 'Income Tax Act 2025 Forensic Banking Engine';
        let action = 'Check updated transactions in Finance Workspace.';

        if (q.includes('statement') || q.includes('transaction') || q.includes('uploaded') || q.includes('import')) {
          if (transactions.length > 0) {
            replyText = `I have analyzed your statement data: you currently have **${transactions.length} verified transactions** in your ledger. Total deposits stand at **${fmt(totalCredits)}** and total payments at **${fmt(totalDebits)}**, yielding a net cash balance of **${netCashFlow >= 0 ? '+' : ''}${fmt(netCashFlow)}**. All records are synchronized with 100% forensic precision.`;
            rule = 'General Ledger Audit & Bank Statement Extraction';
            action = 'View line items in Finance > Transactions.';
          } else {
            replyText = 'No statement is currently uploaded. Upload your bank statement in the Documents Vault to unlock instant automated tax categorization and OCR forensic reconciliation.';
            action = 'Upload statement in Documents tab.';
          }
        } else if (q.includes('spend') || q.includes('expense') || q.includes('cost') || q.includes('outgoing') || q.includes('debit')) {
          const topVendors = debits.slice(0, 3).map((d) => `${d.vendor || d.description} (${fmt(d.amount)})`).join(', ');
          replyText = `Your statement debits total **${fmt(totalDebits)}** across ${debits.length} payments${topVendors ? `, with major disbursements to ${topVendors}` : ''}. Under Section 37(1) of the Income Tax Act 2025, wholly and exclusively incurred business expenses are 100% tax deductible against your gross revenue.`;
          rule = 'Income Tax Act 2025 Section 37(1) - Deductible Business Outflows';
          action = 'Verify GST invoices in Finance > Expenses.';
        } else if (q.includes('income') || q.includes('revenue') || q.includes('turnover') || q.includes('credit') || q.includes('deposit')) {
          replyText = `Your bank statement captures **${fmt(totalCredits)}** in total customer deposits. If your gross receipts are up to ₹75 Lakhs with 95%+ digital payments, you qualify for Presumptive Taxation under Section 44ADA, declaring a flat 50% deemed profit with zero requirement for a CA audit.`;
          rule = 'Section 44ADA / Section 44AD Presumptive Taxation';
          action = 'Test scenarios in Tax Act 2025 Simulator.';
        } else if (q.includes('vendor') || q.includes('msme') || q.includes('43b')) {
          replyText = `Under Section 43B(h) and MSMED Act Section 15, payments to registered Micro and Small suppliers must be cleared within 45 days (or 15 days without contract). Overdue amounts are disallowed from your business deductions and added back to taxable income with 3x RBI bank rate penal interest (~19.5% p.a.).`;
          rule = 'Section 43B(h) & MSMED Act 2006 Mandate';
          action = 'Review vendor aging in Finance > Payables.';
        } else if (q.includes('tax') || q.includes('slab') || q.includes('2025')) {
          replyText = `Under the Income Tax Act 2025 new regime slabs: ₹0-4L (0%), ₹4-8L (5%), ₹8-12L (10%), ₹12-16L (15%), ₹16-20L (20%), ₹20-24L (25%), and >₹24L (30%). Incomes up to ₹12 Lakhs enjoy full Section 87A rebate. Standard deduction is ₹75,000.`;
          rule = 'Income Tax Act 2025 Modernized Direct Tax Slabs';
          action = 'Check Tax Center for quarterly advance tax installments.';
        } else {
          replyText = `I have evaluated your query for **${profile.businessName}** (${profile.persona.toUpperCase()} in ${profile.state}). ${transactions.length > 0 ? `Your ledger holds ${transactions.length} verified transactions (Inflows: ${fmt(totalCredits)}, Outflows: ${fmt(totalDebits)}). Feel free to ask me to analyze your bank statements, verify GST Input Tax Credits, or stress-test your cash runway.` : 'You can ask me to analyze your bank statements, calculate tax under 2025 slabs, or check compliance deadlines.'}`;
        }

        const fallbackMsg: Message = {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: replyText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          statutoryBasis: rule,
          actionRecommendation: action,
        };
        setMessages((prev) => [...prev, fallbackMsg]);
      }, 500);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 md:p-6 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-emerald-600" />
                ASK FINAURA AI INTELLIGENCE
              </span>
              <span className="text-xs text-slate-500 font-mono">Gemini 3.7 + Tax Act 2025 Engine</span>
            </div>
            <h1 className="text-xl md:text-2xl font-bold text-slate-900 mt-1">AI Copilot & Statutory Engine</h1>
            <p className="text-xs text-slate-600 mt-0.5">
              Ask any tax question, simulate Income Tax Act 2025 scenarios, and receive statutory citations in plain English.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs bg-slate-100 text-slate-700 px-3 py-1.5 rounded-xl font-bold border border-slate-200">
              Active Entity: {profile.businessName}
            </span>
          </div>
        </div>

        {/* Sub-tabs */}
        <div className="flex items-center gap-1 border-t border-slate-200/80 mt-6 pt-3 overflow-x-auto">
          {[
            { id: 'chat', label: 'AI Chat & Copilot', icon: Bot },
            { id: 'reasoner', label: 'Tax Act 2025 Simulator', icon: Calculator },
            { id: 'insights', label: 'Proactive AI Insights', icon: Lightbulb },
            { id: 'alerts', label: 'Statutory AI Alerts', icon: AlertTriangle },
            { id: 'history', label: 'Advisory Query History', icon: History },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveSubTab(tab.id as any)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
                  activeSubTab === tab.id
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Sub-tab 1: AI Chat */}
      {activeSubTab === 'chat' && (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-2xs overflow-hidden flex flex-col h-[600px]">
          {/* Statement Intelligence Connection Header */}
          <div className="px-4 py-2.5 bg-emerald-50/70 border-b border-emerald-100 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-bold text-emerald-900">
                {transactions.length > 0
                  ? `Active Statement Grounding: ${transactions.length} verified transactions loaded`
                  : 'Statement Grounding: Ready for bank statement upload'}
              </span>
            </div>
            {transactions.length > 0 && (
              <div className="hidden sm:flex items-center gap-3 text-[11px] font-medium text-emerald-800">
                <span>Inflows: {fmt(totalCredits)}</span>
                <span>Outflows: {fmt(totalDebits)}</span>
                <span className="font-bold">Net: {fmt(netCashFlow)}</span>
              </div>
            )}
          </div>

          {/* Preset query chips */}
          <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center gap-2 overflow-x-auto text-xs">
            <span className="text-slate-400 font-bold shrink-0">Quick Prompts:</span>
            {[
              'Summarize my bank statement transactions & cash flow',
              'What are my highest business expense categories?',
              'Who are my top vendors & payables?',
              'Calculate tax on ₹18L income under 2025 Act',
              'Explain Section 43B(h) MSME 45-day rule',
            ].map((chip, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSend(chip)}
                className="px-3 py-1 bg-white border border-slate-200 hover:border-emerald-500 hover:text-emerald-700 rounded-full text-slate-700 whitespace-nowrap text-xs font-medium cursor-pointer transition-colors shadow-2xs"
              >
                {chip}
              </button>
            ))}
          </div>

          {/* Messages list */}
          <div className="flex-1 p-6 overflow-y-auto space-y-4">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex gap-3 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {m.sender === 'ai' && (
                  <div className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center shrink-0">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                  </div>
                )}
                <div
                  className={`max-w-2xl rounded-2xl p-4 text-xs leading-relaxed space-y-2 ${
                    m.sender === 'user'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-50 border border-slate-200/90 text-slate-800'
                  }`}
                >
                  <p className="whitespace-pre-wrap leading-relaxed text-slate-800 text-[13px] font-normal">{m.text}</p>
                  {m.statutoryBasis && (
                    <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px] text-slate-500">
                      <span className="font-semibold text-emerald-800">Statutory Citation: {m.statutoryBasis}</span>
                      <span className="font-mono text-[10px]">{m.timestamp}</span>
                    </div>
                  )}
                  {m.actionRecommendation && (
                    <div className="p-2.5 bg-emerald-100/60 text-emerald-950 rounded-xl font-bold flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                      <span>Recommended: {m.actionRecommendation}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex items-center gap-2 text-xs text-slate-500 italic p-2">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600 animate-spin" />
                <span>Finaura AI is cross-referencing statutory rules...</span>
              </div>
            )}
          </div>

          {/* Input Box */}
          <div className="p-4 border-t border-slate-200 bg-slate-50/50">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={inputQuery}
                onChange={(e) => setInputQuery(e.target.value)}
                placeholder="Ask about GST, TDS, advance tax, deductions, or business compliance..."
                className="flex-1 px-4 py-3 bg-white border border-slate-300 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <button
                type="submit"
                disabled={!inputQuery.trim()}
                className="px-5 py-3 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-2xs transition-all"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Ask</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Sub-tab 2: Statutory Reasoner */}
      {activeSubTab === 'reasoner' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-2xs space-y-6">
          <div>
            <h3 className="text-base font-bold text-slate-900">Income Tax Act 2025 & Sec 44ADA Calculator</h3>
            <p className="text-xs text-slate-500">
              Interactive statutory simulator comparing New Direct Tax slabs vs Presumptive 44ADA Taxation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4 p-5 bg-slate-50 border border-slate-200 rounded-xl">
              <label className="text-xs font-bold text-slate-700 block">
                Estimated Annual Gross Receipts / Turnover (₹)
              </label>
              <input
                type="range"
                min="500000"
                max="10000000"
                step="100000"
                value={annualTurnover}
                onChange={(e) => setAnnualTurnover(parseInt(e.target.value, 10))}
                className="w-full accent-emerald-600"
              />
              <div className="text-2xl font-extrabold text-slate-900">
                ₹{annualTurnover.toLocaleString('en-IN')}
              </div>

              <div className="space-y-2 pt-2">
                <label className="text-xs font-bold text-slate-700 block">Tax Regime</label>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setOptedTaxRegime('sec_44ada')}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${
                      optedTaxRegime === 'sec_44ada'
                        ? 'bg-emerald-50 border-emerald-400 text-emerald-800'
                        : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    Presumptive Sec 44ADA (50% Profit)
                  </button>
                  <button
                    type="button"
                    onClick={() => setOptedTaxRegime('new_2025')}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${
                      optedTaxRegime === 'new_2025'
                        ? 'bg-emerald-50 border-emerald-400 text-emerald-800'
                        : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    Standard Books (Actual P&L)
                  </button>
                </div>
              </div>
            </div>

            {/* Computation Result */}
            <div className="p-5 bg-slate-900 text-white rounded-xl space-y-4 flex flex-col justify-between">
              <div>
                <div className="text-xs font-mono text-emerald-400 font-bold">STATUTORY SIMULATION RESULT</div>
                <div className="mt-2">
                  <span className="text-xs text-slate-400">Deemed Taxable Income:</span>
                  <div className="text-xl font-bold text-white">
                    ₹{(annualTurnover * 0.5).toLocaleString('en-IN')}
                  </div>
                </div>
                <div className="mt-2">
                  <span className="text-xs text-slate-400">Estimated Total Tax Liability:</span>
                  <div className="text-2xl font-extrabold text-emerald-400">
                    ₹{Math.max(0, Math.round(annualTurnover * 0.5 * 0.08)).toLocaleString('en-IN')}
                  </div>
                  <span className="text-[11px] text-slate-400">With Section 87A rebate & standard deductions</span>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 text-xs text-slate-300">
                <strong>Tax Saving Tip: </strong>
                Under Section 44ADA, you are exempt from maintaining burdensome 44AA books of account and Section 44AB tax audit.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sub-tab 3: Insights */}
      {activeSubTab === 'insights' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-5 bg-white border border-slate-200 rounded-2xl space-y-3">
            <div className="flex items-center gap-2 text-emerald-700 font-bold text-sm">
              <Lightbulb className="w-4 h-4" />
              <span>Input Tax Credit (ITC) Maximization</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              We identified ₹14,200 of GST on cloud software invoices from foreign suppliers. Ensure invoices contain your GSTIN to claim IGST credit on GSTR-3B table 4(A)(5).
            </p>
          </div>

          <div className="p-5 bg-white border border-slate-200 rounded-2xl space-y-3">
            <div className="flex items-center gap-2 text-blue-700 font-bold text-sm">
              <Zap className="w-4 h-4" />
              <span>Working Capital Optimization</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Zeta Innovations invoice (₹2,80,000) is pending for 18 days. Sending an automated payment link via UPI reduces collection lag by an average of 4.2 days.
            </p>
          </div>
        </div>
      )}

      {/* Sub-tab 4: Alerts */}
      {activeSubTab === 'alerts' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-2xs space-y-4">
          <h3 className="text-base font-bold text-slate-900">Active Statutory AI Alerts</h3>
          <div className="space-y-3">
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-rose-700 shrink-0 mt-0.5" />
              <div className="text-xs text-rose-900 space-y-1">
                <span className="font-bold block">Critical: Section 43B(h) MSME Cutoff in 6 Days</span>
                <span>Payment of ₹85,000 to Precision Printworks must be recorded by Sept 7 to avoid tax add-back.</span>
              </div>
            </div>
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-3">
              <Clock className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
              <div className="text-xs text-amber-900 space-y-1">
                <span className="font-bold block">Important: Q2 Advance Tax Installment Due Sept 15</span>
                <span>45% cumulative tax buffer of ₹1,85,000 should be deposited via Challan 280.</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sub-tab 5: History */}
      {activeSubTab === 'history' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-2xs space-y-4">
          <h3 className="text-base font-bold text-slate-900">Historical AI Consultations</h3>
          <div className="divide-y divide-slate-100 text-xs">
            <div className="py-3 space-y-1">
              <div className="font-bold text-slate-900">"What are the consequences of paying MSME vendor after 45 days?"</div>
              <div className="text-slate-500">Answered: Section 43B(h) disallows deduction in FY 2026-27 + compound interest @ 3x RBI bank rate under MSMED Act.</div>
            </div>
            <div className="py-3 space-y-1">
              <div className="font-bold text-slate-900">"How to generate e-Invoices for B2B export clients?"</div>
              <div className="text-slate-500">Answered: Use standard IRP schema with LUT reference to claim zero-rated GST export benefits.</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
