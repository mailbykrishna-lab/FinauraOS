import React, { useState } from 'react';
import {
  Sparkles,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  RotateCcw,
  Check,
  X,
  HelpCircle,
  Filter,
  Search,
  ChevronRight,
  ShieldCheck,
  Tag,
  CreditCard,
} from 'lucide-react';
import { Transaction, NavTab } from '../../types';
import { ExplainWhyCard } from '../ExplainWhyCard';
import { NextBestAction } from '../NextBestAction';

interface AccountingViewProps {
  transactions: Transaction[];
  onUpdateTransaction: (id: string, updates: Partial<Transaction>) => void;
  onNavigate?: (tab: NavTab) => void;
  onOpenAI?: (prompt?: string) => void;
}

export const AccountingView: React.FC<AccountingViewProps> = ({
  transactions,
  onUpdateTransaction,
  onNavigate,
  onOpenAI: _onOpenAI,
}) => {
  // Modes: 'guided_card' (1-by-1) or 'table'
  const [viewMode, setViewMode] = useState<'guided_card' | 'table'>('guided_card');
  
  // Pending review transactions
  const pendingTransactions = transactions.filter(
    (t) => t.status === 'needs_review' || t.status === 'pending_review'
  );
  const reviewedTransactions = transactions.filter((t) => t.status === 'approved');
  
  const [currentIndex, setCurrentIndex] = useState(0);
  const [lastApprovedItem, setLastApprovedItem] = useState<{ name: string; amount: number; category: string } | null>(null);
  const [showCategorySelector, setShowCategorySelector] = useState(false);
  const [searchFilter, setSearchFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'needs_review' | 'approved'>('all');

  const currentTx = pendingTransactions[currentIndex] || null;

  const categories = [
    'Software & Tools',
    'Marketing & Growth',
    'Revenue - Consulting',
    'Rent & Workspace',
    'Staff Welfare & Meals',
    'Capital Assets - Computers',
    'Professional & Legal Fees',
    'Export Revenue - Software Services',
    'Utilities & Internet',
    'Bank Charges',
  ];

  const handleApprove = (tx: Transaction) => {
    onUpdateTransaction(tx.id, {
      status: 'approved',
      userCategory: tx.suggestedCategory,
    });
    setLastApprovedItem({
      name: tx.vendor,
      amount: tx.amount,
      category: tx.suggestedCategory,
    });
    // Advance index
    if (currentIndex >= pendingTransactions.length - 1) {
      setCurrentIndex(0);
    }
  };

  const handleCustomCategory = (category: string) => {
    if (!currentTx) return;
    onUpdateTransaction(currentTx.id, {
      status: 'approved',
      userCategory: category,
      suggestedCategory: category,
    });
    setLastApprovedItem({
      name: currentTx.vendor,
      amount: currentTx.amount,
      category: category,
    });
    setShowCategorySelector(false);
    if (currentIndex >= pendingTransactions.length - 1) {
      setCurrentIndex(0);
    }
  };

  const handleSkip = () => {
    if (currentIndex < pendingTransactions.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setCurrentIndex(0);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Top Banner & Progress */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider font-geist">
            SMART BOOKKEEPING
          </span>
          <h1 className="text-2xl md:text-3xl font-black text-slate-900 font-geist tracking-tight mt-0.5">
            LET’S REVIEW YOUR BOOKS.
          </h1>
          <p className="text-sm text-slate-600 mt-0.5">
            Review transactions one by one without complex accounting double-entry spreadsheets.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setViewMode(viewMode === 'guided_card' ? 'table' : 'guided_card')}
            className="text-xs font-semibold text-slate-900 bg-white hover:bg-slate-50 border border-slate-300 px-3.5 py-2 rounded-xl transition-all shadow-sm"
          >
            {viewMode === 'guided_card' ? 'Switch to Table View' : 'Switch to 1-by-1 Guided Mode'}
          </button>
        </div>
      </div>

      {/* PROGRESS INDICATORS & STATS */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <span className="text-xs text-slate-500 font-medium block mb-1">Total Transactions Found</span>
          <div className="text-2xl font-black text-slate-900 font-geist">{transactions.length}</div>
          <span className="text-[11px] text-slate-500 mt-1 block">
            {transactions.length > 0 ? 'Recorded ledger entries' : 'No statements uploaded yet'}
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <span className="text-xs text-slate-700 font-medium block mb-1">Confidently Categorized</span>
          <div className="text-2xl font-black text-slate-900 font-geist">
            {reviewedTransactions.length} / {transactions.length}
          </div>
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden mt-1.5">
            <div
              className="bg-slate-900 h-full rounded-full transition-all duration-300"
              style={{
                width: `${transactions.length > 0 ? (reviewedTransactions.length / transactions.length) * 100 : 100}%`,
              }}
            ></div>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <span className="text-xs text-red-700 font-medium block mb-1">Needs Your Review</span>
          <div className="text-2xl font-black text-red-700 font-geist">
            {pendingTransactions.length} items
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">
            {transactions.length === 0
              ? 'No ledger items to review'
              : pendingTransactions.length === 0
              ? 'All caught up! 🎉'
              : 'Takes ~45 seconds'}
          </span>
        </div>
      </div>

      {/* 24. SUCCESS STATE THAT EXPLAINS WHAT HAPPENED */}
      {lastApprovedItem && pendingTransactions.length > 0 && (
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center shrink-0">
              <Check className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900 uppercase font-geist">
                TRANSACTION APPROVED
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                <strong>₹{lastApprovedItem.amount.toLocaleString('en-IN')}</strong> for{' '}
                <strong>{lastApprovedItem.name}</strong> has been categorized as{' '}
                <span className="text-slate-900 font-semibold">{lastApprovedItem.category}</span>.
              </p>
            </div>
          </div>
          <div className="text-xs text-slate-500 font-medium">
            <strong>Next:</strong> Review your remaining {pendingTransactions.length} items.
          </div>
        </div>
      )}

      {/* 11. GUIDED 1-BY-1 TRANSACTION REVIEW CARD */}
      {viewMode === 'guided_card' && (
        <>
          {pendingTransactions.length > 0 && currentTx ? (
            <div className="bg-white rounded-2xl shadow-[0px_8px_30px_rgba(10,15,30,0.06)] border border-slate-200 p-6 md:p-8 relative overflow-hidden space-y-6">
              {/* Step indicator */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-800 bg-slate-100 border border-slate-200 px-3 py-1 rounded-full uppercase font-geist">
                    ITEM {currentIndex + 1} OF {pendingTransactions.length}
                  </span>
                  <span className="text-xs text-slate-500">{currentTx.date}</span>
                </div>
                <div className="text-xs text-slate-500">
                  Confidence score: <strong>{Math.round(currentTx.confidence * 100)}%</strong>
                </div>
              </div>

              {/* Vendor & Amount Headline */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs text-slate-500 font-medium block mb-0.5">Vendor / Payee</span>
                  <h2 className="text-xl md:text-2xl font-bold text-slate-900 tracking-tight">
                    {currentTx.vendor}
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">{currentTx.description}</p>
                </div>

                <div className="sm:text-right">
                  <span className="text-xs text-slate-500 font-medium block mb-0.5">Transaction Amount</span>
                  <div className={`text-2xl md:text-3xl font-black font-geist ${currentTx.type === 'credit' ? 'text-slate-900' : 'text-slate-900'}`}>
                    {currentTx.type === 'credit' ? '+ ' : '- '}₹{currentTx.amount.toLocaleString('en-IN')}
                  </div>
                </div>
              </div>

              {/* Finaura Suggestion Box */}
              <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-slate-700" />
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider font-geist">
                      FINAURA SUGGESTS
                    </span>
                  </div>
                  <span className="text-xs bg-slate-200 text-slate-800 px-2.5 py-0.5 rounded-md font-semibold">
                    {Math.round(currentTx.confidence * 100)}% Confidence
                  </span>
                </div>

                <div className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Tag className="w-5 h-5 text-slate-700" />
                  <span>{currentTx.suggestedCategory}</span>
                </div>

                {/* 10. EVERY ACTION EXPLAINS WHY */}
                <div className="space-y-2 pt-2 border-t border-slate-200 text-xs">
                  <div>
                    <span className="font-semibold text-slate-900">Why am I seeing this?</span>
                    <p className="text-slate-600 mt-0.5 leading-relaxed">{currentTx.whyNeedsReview}</p>
                  </div>

                  <div>
                    <span className="font-semibold text-slate-900">What happens next?</span>
                    <p className="text-slate-700 font-medium mt-0.5 leading-relaxed">{currentTx.whatHappensNext}</p>
                  </div>
                </div>
              </div>

              {/* DOES THIS LOOK RIGHT? Action Buttons */}
              <div className="pt-2">
                <div className="text-xs font-bold text-slate-900 mb-3 uppercase tracking-wider font-geist">
                  DOES THIS LOOK RIGHT?
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => handleApprove(currentTx)}
                    className="flex-1 min-w-[140px] bg-slate-900 text-white hover:bg-slate-800 font-semibold text-sm py-3 px-6 rounded-xl flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.98]"
                  >
                    <Check className="w-4 h-4 text-slate-100" />
                    <span>Approve Category</span>
                  </button>

                  <button
                    onClick={() => setShowCategorySelector(true)}
                    className="flex-1 min-w-[140px] bg-white hover:bg-slate-50 text-slate-900 border border-slate-300 font-semibold text-sm py-3 px-6 rounded-xl flex items-center justify-center gap-2 transition-all shadow-sm"
                  >
                    <span>Change Category</span>
                  </button>

                  <button
                    onClick={handleSkip}
                    className="px-4 py-3 text-xs font-semibold text-slate-500 hover:text-slate-900 transition-colors"
                  >
                    Skip for now
                  </button>
                </div>
              </div>

              {/* Category selector dropdown/modal */}
              {showCategorySelector && (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900">Select Correct Category</span>
                    <button onClick={() => setShowCategorySelector(false)} className="text-slate-500 hover:text-slate-900">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                    {categories.map((cat) => (
                      <button
                        key={cat}
                        onClick={() => handleCustomCategory(cat)}
                        className="p-2.5 bg-white hover:bg-slate-900 hover:text-white border border-slate-300 rounded-lg text-left font-medium transition-colors"
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : transactions.length === 0 ? (
            /* ZERO TRANSACTIONS STATE */
            <div className="bg-white rounded-2xl p-8 md:p-12 text-center border border-slate-200 shadow-sm space-y-4">
              <div className="w-14 h-14 bg-slate-100 text-slate-700 rounded-full flex items-center justify-center mx-auto border border-slate-200">
                <CreditCard className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 font-geist">
                NO TRANSACTIONS IMPORTED YET
              </h3>
              <p className="text-xs md:text-sm text-slate-600 max-w-md mx-auto">
                Upload your bank statement (CSV/PDF) or record manual transactions to activate AI auto-categorization and guided ledger review.
              </p>
              <div className="pt-2">
                <button
                  onClick={() => onNavigate && onNavigate('dashboard')}
                  className="bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold py-3 px-6 rounded-xl inline-flex items-center gap-2 shadow-sm transition-all cursor-pointer"
                >
                  <span>RETURN TO DASHBOARD</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : (
            /* ALL CAUGHT UP STATE */
            <div className="bg-white rounded-2xl p-8 md:p-12 text-center border border-slate-200 shadow-sm space-y-4">
              <div className="w-14 h-14 bg-emerald-50 text-emerald-700 rounded-full flex items-center justify-center mx-auto border border-emerald-200">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 font-geist">
                ALL {transactions.length} TRANSACTIONS RECONCILED!
              </h3>
              <p className="text-xs md:text-sm text-slate-600 max-w-md mx-auto">
                Your general ledger is up to date and categorized for statutory tax and filing readiness.
              </p>
              <div className="pt-2">
                <button
                  onClick={() => onNavigate && onNavigate('compliance')}
                  className="bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold py-3 px-6 rounded-xl inline-flex items-center gap-2 shadow-sm transition-all cursor-pointer"
                >
                  <span>PROCEED TO COMPLIANCE HQ</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </>
      )}

      {/* TABLE VIEW */}
      {viewMode === 'table' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden space-y-4 p-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search vendor or category..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-slate-400"
              />
            </div>

            <div className="flex items-center gap-2 text-xs">
              <button
                onClick={() => setStatusFilter('all')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${statusFilter === 'all' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:text-slate-900'}`}
              >
                All ({transactions.length})
              </button>
              <button
                onClick={() => setStatusFilter('needs_review')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${statusFilter === 'needs_review' ? 'bg-red-700 text-white' : 'bg-slate-100 text-slate-600 hover:text-slate-900'}`}
              >
                Needs Review ({pendingTransactions.length})
              </button>
              <button
                onClick={() => setStatusFilter('approved')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${statusFilter === 'approved' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:text-slate-900'}`}
              >
                Approved ({reviewedTransactions.length})
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-geist uppercase text-[11px]">
                  <th className="py-3 px-3">Date</th>
                  <th className="py-3 px-3">Vendor / Payee</th>
                  <th className="py-3 px-3">Category</th>
                  <th className="py-3 px-3">Amount</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {transactions
                  .filter((t) => {
                    const matchSearch = t.vendor.toLowerCase().includes(searchFilter.toLowerCase()) || t.suggestedCategory.toLowerCase().includes(searchFilter.toLowerCase());
                    const matchStatus = statusFilter === 'all' ? true : t.status === statusFilter;
                    return matchSearch && matchStatus;
                  })
                  .map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-3 text-slate-500">{tx.date}</td>
                      <td className="py-3 px-3 font-semibold text-slate-900">
                        <div>{tx.vendor}</div>
                        <div className="text-[10px] text-slate-500">{tx.description}</div>
                      </td>
                      <td className="py-3 px-3 text-slate-900">
                        <span className="inline-flex items-center gap-1 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded text-[11px]">
                          {tx.userCategory || tx.suggestedCategory}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-bold font-geist text-slate-900">
                        {tx.type === 'credit' ? '+ ' : '- '}₹{tx.amount.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3 px-3">
                        {tx.status === 'needs_review' ? (
                          <span className="text-[10px] bg-red-50 text-red-700 border border-red-200 font-bold px-2 py-0.5 rounded-full uppercase">
                            Needs Review
                          </span>
                        ) : (
                          <span className="text-[10px] bg-slate-100 text-slate-800 border border-slate-200 font-bold px-2 py-0.5 rounded-full uppercase">
                            Approved
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-right">
                        {tx.status === 'needs_review' ? (
                          <button
                            onClick={() => handleApprove(tx)}
                            className="text-xs bg-slate-900 text-white hover:bg-slate-800 px-3 py-1 rounded-md font-semibold shadow-sm"
                          >
                            Approve
                          </button>
                        ) : (
                          <span className="text-slate-700 font-medium text-[11px] inline-flex items-center gap-0.5">
                            <Check className="w-3.5 h-3.5 text-slate-900" /> Reconciled
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
