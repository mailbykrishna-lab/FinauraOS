import React, { useState } from 'react';
import {
  Sparkles,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldCheck,
  Calculator,
  UserCheck,
  FileText,
  HelpCircle,
  TrendingDown,
} from 'lucide-react';
import { BusinessProfile, NavTab } from '../../types';
import { NextBestAction } from '../NextBestAction';
import { ExplainWhyCard } from '../ExplainWhyCard';
import { ContextTooltip } from '../ContextTooltip';

interface TaxViewProps {
  profile: BusinessProfile;
  transactions?: import('../../types').Transaction[];
  invoices?: import('../../types').Invoice[];
  onNavigate: (tab: NavTab) => void;
  onOpenAI: (prompt?: string) => void;
}

export const TaxView: React.FC<TaxViewProps> = ({ profile, transactions = [], invoices = [], onNavigate, onOpenAI }) => {
  const [activeStep, setActiveStep] = useState<number>(3);

  // Compute actual recorded numbers
  const recordedRevenue = (transactions || [])
    .filter((t) => t.type === 'credit' && t.status === 'approved')
    .reduce((sum, t) => sum + (t.amount || 0), 0) +
    (invoices || [])
    .filter((inv) => inv.status === 'paid')
    .reduce((sum, inv) => sum + (inv.total || 0), 0);

  const recordedExpense = (transactions || [])
    .filter((t) => t.type === 'debit' && t.status === 'approved')
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  // Default projection to annualized recorded or 0
  const [annualRevenue, setAnnualRevenue] = useState(
    recordedRevenue > 0 ? recordedRevenue * 12 : 0
  );
  const [estimatedExpense, setEstimatedExpense] = useState(
    recordedExpense > 0 ? recordedExpense * 12 : 0
  );

  const taxableProfit = Math.max(0, annualRevenue - estimatedExpense);
  // Corporate 22% or presumptive 44ADA (50% profit @ slab)
  const corporateTaxEstimate = Math.round(taxableProfit * 0.2517); // 22% + 10% surcharge + 4% cess = 25.17%
  const advanceTaxQ2Due = Math.round(corporateTaxEstimate * 0.45); // 45% cumulative due by Sep 15

  const steps = [
    { step: 1, title: 'Your Profile', desc: `${profile?.businessName || 'My Business'} (${(profile?.businessType || 'proprietorship').toUpperCase()})`, status: 'completed' },
    {
      step: 2,
      title: 'Financial Information',
      desc: recordedRevenue > 0 || recordedExpense > 0
        ? `Revenue: ₹${recordedRevenue.toLocaleString('en-IN')}, Expenses: ₹${recordedExpense.toLocaleString('en-IN')} recorded`
        : 'Connect bank statement or enter ledger transactions',
      status: recordedRevenue > 0 ? 'completed' : 'active',
    },
    { step: 3, title: 'Required Documents', desc: 'Bank statement & GSTR-3B filings audit', status: 'pending' },
    { step: 4, title: 'Review Tax Buffers', desc: 'Advance Tax Q2 instalment calculation', status: 'pending' },
    { step: 5, title: 'Professional CA Support', desc: 'Assign to CA for filing & DSC signing', status: 'pending' },
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Header */}
      <div>
        <span className="text-xs font-bold text-slate-600 uppercase tracking-wider font-geist">
          TAX WORKFLOW READY
        </span>
        <h1 className="text-2xl md:text-3xl font-black text-slate-900 font-geist tracking-tight mt-0.5">
          LET’S GET YOUR TAX WORKFLOW READY.
        </h1>
        <p className="text-sm text-slate-600 mt-0.5">
          Follow the 5 clear steps to calculate advance taxes, claim all allowable deductions, and avoid Section 234 interest.
        </p>
      </div>

      {/* 09. NEXT BEST ACTION */}
      <NextBestAction
        category="TAX PREPARATION"
        title="Verify Advance Tax Q2 Buffer (Due Sept 15)"
        subtitle="Businesses with estimated tax above ₹10,000 must deposit 45% cumulative tax by 15th September."
        urgency="important"
        whyAmISeeingThis={
          taxableProfit > 0
            ? `Based on your projected annual profit of ₹${taxableProfit.toLocaleString('en-IN')}, your estimated Q2 advance tax buffer is ₹${advanceTaxQ2Due.toLocaleString('en-IN')}.`
            : 'Estimate your annual turnover and operating expenses below to calculate exact advance tax requirements.'
        }
        whatShouldIDo="Review your business deductions to lower net tax before sharing computation with your CA."
        whatHappensNext="Avoids 1% per month statutory interest penalty under Section 234C."
        actionLabel="CALCULATE BUFFER"
        onAction={() => setActiveStep(4)}
        onAskCA={() => onNavigate('ca_services')}
      />

      {/* 16. STEP COMPLETION TRACKER (2 of 5 complete) */}
      <div className="bg-white rounded-2xl p-5 md:p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900 font-geist">
            Tax Readiness Progress
          </h2>
          <span className="text-xs font-bold text-slate-800 bg-slate-100 border border-slate-200 px-3 py-1 rounded-full uppercase font-geist">
            2 of 5 completed
          </span>
        </div>

        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
          <div className="bg-slate-900 h-full rounded-full transition-all duration-500" style={{ width: '40%' }}></div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2.5 pt-2">
          {steps.map((st) => (
            <div
              key={st.step}
              onClick={() => setActiveStep(st.step)}
              className={`p-3 rounded-xl border cursor-pointer transition-all text-xs ${
                activeStep === st.step
                  ? 'border-slate-900 bg-slate-50 shadow-sm ring-1 ring-slate-900'
                  : st.status === 'completed'
                  ? 'border-slate-200 bg-white text-slate-600'
                  : 'border-slate-200 bg-white opacity-60'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-bold text-[10px] text-slate-500 font-geist">STEP {st.step}</span>
                {st.status === 'completed' ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                )}
              </div>
              <div className="font-bold text-slate-900 line-clamp-1">{st.title}</div>
              <div className="text-[11px] text-slate-500 mt-1 line-clamp-2">{st.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Advance Tax Estimation Calculator */}
      <div className="bg-white rounded-2xl p-5 md:p-6 border border-slate-200 shadow-sm grid grid-cols-1 md:grid-cols-12 gap-6">
        <div className="md:col-span-7 space-y-4">
          <div className="flex items-center gap-2">
            <Calculator className="w-5 h-5 text-slate-700" />
            <h3 className="text-base font-bold text-slate-900 font-geist">
              Live Advance Tax Calculator (Income Tax Act 2025)
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="font-semibold text-slate-900 block mb-1">
                Projected Annual Revenue (₹)
              </label>
              <input
                type="number"
                value={annualRevenue}
                onChange={(e) => setAnnualRevenue(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-geist font-bold text-sm text-slate-900 focus:outline-none focus:border-slate-900 focus:ring-1 focus:ring-slate-900"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-900 block mb-1">
                Projected Allowable Business Expenses (₹)
              </label>
              <input
                type="number"
                value={estimatedExpense}
                onChange={(e) => setEstimatedExpense(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-geist font-bold text-sm text-slate-900 focus:outline-none focus:border-slate-900 focus:ring-1 focus:ring-slate-900"
              />
            </div>

            <div className="p-3 bg-slate-50 rounded-xl space-y-2 border border-slate-200">
              <div className="flex justify-between text-slate-600">
                <span>Taxable Net Profit:</span>
                <span className="font-bold font-geist text-slate-900">₹{taxableProfit.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Section 115BAA Rate (22% + Cess):</span>
                <span className="font-bold font-geist text-slate-900">25.17%</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-slate-900 pt-2 border-t border-slate-200">
                <span>Full Year Tax Liability:</span>
                <span className="font-geist text-slate-900">₹{corporateTaxEstimate.toLocaleString('en-IN')}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="md:col-span-5 bg-slate-50 p-5 rounded-xl border border-slate-200 flex flex-col justify-between space-y-4">
          <div>
            <span className="text-xs font-bold text-slate-600 uppercase font-geist">UPCOMING DEADLINE</span>
            <h4 className="text-base font-bold text-slate-900 mt-1">Q2 Advance Tax Instalment</h4>
            <p className="text-xs text-slate-500 mt-1">Due by September 15, 2026</p>

            <div className="mt-4 p-3 bg-white rounded-lg border border-slate-200">
              <span className="text-xs text-slate-500 block">Cumulative 45% Buffer Due</span>
              <span className="text-2xl font-black text-slate-900 font-geist">
                ₹{advanceTaxQ2Due.toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          <button
            onClick={() => onNavigate('invoices')}
            className="w-full bg-emerald-50 hover:bg-emerald-100 text-emerald-950 border border-emerald-300/80 text-xs font-bold py-2.5 rounded-xl flex items-center justify-center gap-2 shadow-2xs transition-all cursor-pointer"
          >
            <FileText className="w-4 h-4 text-emerald-700" />
            <span>VIEW MONTHLY GST SALES REPORTS (GSTR-1 / 3B)</span>
          </button>

          <button
            onClick={() => onNavigate('ca_services')}
            className="w-full bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold py-3 rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all"
          >
            <UserCheck className="w-4 h-4 text-slate-300" />
            <span>CONFIRM COMPUTATION WITH CA</span>
          </button>
        </div>
      </div>
    </div>
  );
};
