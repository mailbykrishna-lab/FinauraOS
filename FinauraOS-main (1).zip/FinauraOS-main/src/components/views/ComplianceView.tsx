import React, { useState } from 'react';
import {
  ShieldAlert,
  CheckCircle2,
  Calendar,
  AlertCircle,
  ArrowRight,
  ExternalLink,
  HelpCircle,
  Sparkles,
  Search,
  Building2,
  FileText,
  UserCheck,
  ChevronRight,
  Clock,
  Info,
  ShieldCheck,
  History,
  X,
} from 'lucide-react';
import { ComplianceAction, GovernmentUpdate, NavTab } from '../../types';
import { NextBestAction } from '../NextBestAction';
import { ExplainWhyCard } from '../ExplainWhyCard';

interface ComplianceViewProps {
  actions: ComplianceAction[];
  updates: GovernmentUpdate[];
  onNavigate: (tab: NavTab) => void;
  onOpenAI: (prompt?: string) => void;
}

export const ComplianceView: React.FC<ComplianceViewProps> = ({
  actions,
  updates,
  onNavigate,
  onOpenAI,
}) => {
  const [selectedAction, setSelectedAction] = useState<ComplianceAction | null>(null);
  const [selectedUpdate, setSelectedUpdate] = useState<GovernmentUpdate | null>(null);
  const [activeFilter, setActiveFilter] = useState<'All' | 'GST' | 'Income Tax' | 'TDS' | 'MCA'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [onlyRelevant, setOnlyRelevant] = useState(true);

  const filteredUpdates = updates.filter((up) => {
    const matchesFilter =
      activeFilter === 'All'
        ? true
        : activeFilter === 'GST'
        ? up.authority.includes('GST')
        : activeFilter === 'Income Tax'
        ? up.authority.includes('Income Tax')
        : activeFilter === 'TDS'
        ? up.title.includes('TDS')
        : up.authority.includes('MCA');

    const matchesSearch =
      up.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      up.summary.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRelevant = onlyRelevant ? up.relevance === 'high' || up.relevance === 'medium' : true;

    return matchesFilter && matchesSearch && matchesRelevant;
  });

  const urgentActions = (actions || []).filter((a) => a.urgency === 'urgent').length;
  const pendingActions = (actions || []).length;
  const complianceScore = actions.length === 0 ? 100 : Math.max(60, 100 - (urgentActions * 12) - (pendingActions * 4));

  const topAction = actions.length > 0 ? actions[0] : null;

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Header */}
      <div>
        <span className="text-xs font-bold text-slate-600 uppercase tracking-wider font-geist">
          STATUTORY RADAR
        </span>
        <h1 className="text-2xl md:text-3xl font-black text-slate-900 font-geist tracking-tight mt-0.5">
          WHAT DO YOU NEED TO KNOW?
        </h1>
        <p className="text-sm text-slate-600 mt-0.5">
          Real-time regulatory shifts and government updates filtered strictly for your business structure.
        </p>
      </div>

      {/* 09. NEXT BEST ACTION */}
      {topAction ? (
        <NextBestAction
          category="COMPLIANCE PRIORITY"
          title={topAction.title}
          subtitle={topAction.description}
          urgency={topAction.urgency || 'important'}
          whyAmISeeingThis={topAction.whyAmISeeingThis || 'Mandated statutory filing for registered Indian businesses.'}
          whatShouldIDo={topAction.whatShouldIDo || 'Review requirement and confirm filing execution with your CA.'}
          whatHappensNext={topAction.whatHappensNext || 'Finaura verifies proof of compliance to maintain 100% standing.'}
          actionLabel="EXECUTE ACTION"
          onAction={() => setSelectedAction(topAction)}
          onAskCA={() => onNavigate('ca_services')}
        />
      ) : (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center justify-between text-xs text-emerald-900">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <span className="font-semibold">All statutory filings and compliances are up to date!</span>
          </div>
          <button
            onClick={() => onNavigate('dashboard')}
            className="text-xs font-bold text-emerald-800 underline cursor-pointer"
          >
            Dashboard
          </button>
        </div>
      )}

      {/* Compliance Health Score & Deadlines Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-500 mb-2 font-geist">
              <span>Compliance Health</span>
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-black text-slate-900 font-geist">{complianceScore}</span>
              <span className="text-sm text-slate-500">/ 100</span>
            </div>
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mt-3">
              <div
                className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${complianceScore}%` }}
              ></div>
            </div>
          </div>
          <p className="text-xs text-emerald-700 font-medium mt-3 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            {actions.length === 0
              ? 'All statutory requirements clear.'
              : `${actions.length} action(s) require your attention.`}
          </p>
        </div>

        {/* Deadline Alert Card */}
        <div className="md:col-span-2 bg-red-50/60 border border-red-200 rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-red-600" />
              <span className="text-xs font-bold text-red-700 uppercase font-geist">
                DEADLINE SHIFT NOTIFICATION
              </span>
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Statutory Filing Calendar Synchronized
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              MCA, CBIC (GST), and CBDT (Income Tax) deadline tracking is live. Your compliance calendar automatically updates when notifications are gazetted.
            </p>
            <div className="text-[11px] text-slate-500 flex items-center gap-1 pt-1">
              <span>Source: Ministry of Corporate Affairs &amp; GSTN</span>
            </div>
          </div>

          <button
            onClick={() => onNavigate('ca_services')}
            className="bg-white hover:bg-slate-50 text-slate-900 border border-slate-300 text-xs font-semibold px-4 py-2 rounded-xl shrink-0 transition-colors shadow-sm cursor-pointer"
          >
            Consult CA
          </button>
        </div>
      </div>

      {/* REQUIRED ACTIONS SECTION */}
      <div className="bg-white rounded-2xl p-5 md:p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base md:text-lg font-black text-slate-900 font-geist">
              {actions.length === 0 ? 'NO PENDING ACTIONS' : `YOU HAVE ${actions.length} REQUIRED ACTION${actions.length > 1 ? 'S' : ''}`}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Filtered for your registered corporate structure and current financial year.
            </p>
          </div>
        </div>

        {actions.length === 0 ? (
          <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200 text-slate-500 text-xs">
            <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
            <p className="font-semibold text-slate-800">No overdue compliance actions.</p>
            <p className="mt-1 text-slate-500">All regular monthly filings are in order.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {actions.map((act) => (
              <div
                key={act.id}
                onClick={() => setSelectedAction(act)}
                className="p-4 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 transition-all cursor-pointer flex flex-col justify-between space-y-3 group"
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="font-bold text-[10px] bg-slate-200 text-slate-800 px-2 py-0.5 rounded-full uppercase">
                      {act.category}
                    </span>
                    <span className="font-semibold text-xs text-red-600">
                      {act.daysLeft} days left
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 group-hover:text-slate-600 transition-colors">
                    {act.title}
                  </h3>
                  <p className="text-xs text-slate-600 mt-1 line-clamp-2">{act.description}</p>
                </div>

                <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-xs text-slate-800 font-semibold">
                  <span>Inspect Details</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 15. GOVERNMENT-REFERENCED UPDATE GUIDANCE FEED */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base md:text-lg font-black text-slate-900 font-geist">
              Government Regulatory Watch
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Real-time circulars, notifications, and gazette amendments analyzed by Finaura AI.
            </p>
          </div>

          <label className="flex items-center gap-2 text-xs text-slate-800 font-semibold cursor-pointer bg-slate-100 px-3 py-1.5 rounded-full border border-slate-200">
            <input
              type="checkbox"
              checked={onlyRelevant}
              onChange={(e) => setOnlyRelevant(e.target.checked)}
              className="rounded text-slate-900 focus:ring-slate-900"
            />
            <Sparkles className="w-3.5 h-3.5 text-slate-700" />
            <span>Only Relevant to My Business</span>
          </label>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          {['All', 'GST', 'Income Tax', 'TDS', 'MCA'].map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveFilter(cat as any)}
              className={`px-3.5 py-1.5 rounded-full font-medium transition-all whitespace-nowrap ${
                activeFilter === cat
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Circular Cards */}
        <div className="space-y-3">
          {filteredUpdates.map((item) => (
            <article
              key={item.id}
              onClick={() => setSelectedUpdate(item)}
              className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm hover:shadow transition-shadow cursor-pointer space-y-3 group"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <span
                    className={`font-bold px-2 py-0.5 rounded text-[10px] uppercase border ${
                      item.relevance === 'high'
                        ? 'bg-red-50 text-red-700 border-red-200'
                        : item.relevance === 'medium'
                        ? 'bg-slate-100 text-slate-800 border-slate-200'
                        : 'bg-slate-50 text-slate-600 border-slate-200'
                    }`}
                  >
                    {item.relevance.toUpperCase()} RELEVANCE
                  </span>
                  <span className="text-slate-500">{item.date}</span>
                </div>

                <span className="bg-slate-100 text-slate-700 font-semibold px-2.5 py-0.5 rounded-md text-[11px] self-start sm:self-auto border border-slate-200">
                  {item.authority}
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-900 group-hover:text-slate-600 transition-colors">
                  {item.title}
                </h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed line-clamp-2">
                  {item.summary}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-700 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-slate-600" />
                  Impacts '{item.impactTarget}'
                </span>
                <span className="font-semibold text-slate-900 group-hover:underline flex items-center gap-1">
                  <span>Read Finaura Breakdown</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* Regulatory Disclaimer (Section 15) */}
      <div className="text-center p-4 bg-slate-100 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1">
        <p className="font-semibold text-slate-900">
          Finaura is interpreting and organizing the information. It is not the government authority.
        </p>
        <p className="text-[11px] text-slate-500">
          Always verify statutory computations with your certified Chartered Accountant before legal filings.
        </p>
      </div>

      {/* 15. GOVERNMENT UPDATE DETAIL MODAL (Matching Screenshot) */}
      {selectedUpdate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 md:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto space-y-6 relative">
            <button
              onClick={() => setSelectedUpdate(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1.5 rounded-full hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Breadcrumb / Meta */}
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs text-slate-500 uppercase tracking-wider font-geist">
                <span>{selectedUpdate.impactTarget}</span>
                <span>›</span>
                <span>UPDATES</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span className="bg-slate-100 px-2 py-0.5 rounded font-medium text-slate-800 border border-slate-200">{selectedUpdate.authority}</span>
                <span>•</span>
                <span>{selectedUpdate.date}</span>
                <span>•</span>
                <span>{selectedUpdate.circularNo}</span>
              </div>
            </div>

            <h2 className="text-xl md:text-2xl font-black text-slate-900 font-geist tracking-tight">
              {selectedUpdate.title}
            </h2>

            {/* Finaura Explains Section */}
            <div className="space-y-4 pt-2">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-slate-700" />
                <h3 className="text-base font-bold text-slate-900 font-geist">Finaura Explains</h3>
              </div>

              {/* 1. WHAT CHANGED (Before vs After) */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <h4 className="text-xs font-bold text-slate-900 uppercase">1. What Changed?</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="bg-white p-3 rounded-lg border border-slate-200">
                    <span className="text-slate-500 block text-[10px] uppercase font-semibold">Previous Rule</span>
                    <p className="text-red-700 line-through font-medium mt-0.5">{selectedUpdate.whatChangedOld}</p>
                  </div>
                  <div className="bg-white p-3 rounded-lg border-2 border-slate-900">
                    <span className="text-slate-900 block text-[10px] uppercase font-bold">New Mandate</span>
                    <p className="text-slate-900 font-bold mt-0.5">{selectedUpdate.whatChangedNew}</p>
                  </div>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">{selectedUpdate.summary}</p>
              </div>

              {/* 2. DOES THIS AFFECT ME? */}
              <div className="bg-slate-900 text-white p-4 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase text-slate-300">2. Does this affect me?</h4>
                  <span className="bg-slate-800 text-emerald-400 border border-slate-700 text-xs font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Likely Yes
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{selectedUpdate.doesItAffectExplanation}</p>
              </div>

              {/* 3. WHAT SHOULD I DO? */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <h4 className="text-xs font-bold text-slate-900 uppercase">3. What should I do?</h4>
                <div className="space-y-2">
                  {selectedUpdate.actionSteps.map((step) => (
                    <div key={step.step} className="p-3 bg-white rounded-lg border border-slate-200 flex gap-3 text-xs">
                      <span className="w-6 h-6 rounded-full bg-slate-100 text-slate-900 border border-slate-200 flex items-center justify-center font-bold shrink-0">
                        {step.step}
                      </span>
                      <div>
                        <span className="font-bold text-slate-900 block">{step.title}</span>
                        <span className="text-slate-600">{step.description}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 4. SOURCE REFERENCE */}
              <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-200">
                <span>Official Source: <strong className="text-slate-800">{selectedUpdate.authority}</strong></span>
                <a
                  href={selectedUpdate.officialSourceUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-slate-900 hover:underline flex items-center gap-1 font-semibold"
                >
                  <span>View Original Gazette</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            {/* Modal Bottom CTAs */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-200">
              <button
                onClick={() => {
                  setSelectedUpdate(null);
                  onNavigate('ca_services');
                }}
                className="w-full sm:w-auto bg-white hover:bg-slate-50 text-slate-900 border border-slate-300 font-semibold text-xs py-3 px-6 rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                <UserCheck className="w-4 h-4 text-slate-700" />
                <span>Ask My CA to Handle This</span>
              </button>

              <button
                onClick={() => setSelectedUpdate(null)}
                className="w-full sm:w-auto bg-slate-900 text-white hover:bg-slate-800 font-semibold text-xs py-3 px-6 rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                <span>Acknowledge &amp; Return</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ACTION DRILL DOWN MODAL */}
      {selectedAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 md:p-8 shadow-2xl border border-slate-200 space-y-5 relative">
            <button
              onClick={() => setSelectedAction(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1.5 rounded-full hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>

            <div>
              <span className="text-xs font-bold bg-slate-100 text-slate-800 border border-slate-200 px-2.5 py-0.5 rounded-full uppercase font-geist">
                {selectedAction.category} ACTION • DUE IN {selectedAction.daysLeft} DAYS
              </span>
              <h2 className="text-xl font-bold text-slate-900 font-geist mt-2">
                {selectedAction.title}
              </h2>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3 text-xs">
              <div>
                <span className="font-bold text-slate-900 block">What changed?</span>
                <p className="text-slate-600 mt-0.5">{selectedAction.whatChanged}</p>
              </div>

              <div>
                <span className="font-bold text-slate-900 block">Does it affect me?</span>
                <p className="text-slate-600 mt-0.5">{selectedAction.doesItAffectMe}</p>
              </div>

              <div>
                <span className="font-bold text-slate-900 block">Suggested action steps:</span>
                <ul className="list-disc list-inside space-y-1 text-slate-800 font-medium mt-0.5">
                  {selectedAction.whatShouldIDo.map((st, i) => (
                    <li key={i}>{st}</li>
                  ))}
                </ul>
              </div>

              {selectedAction.penaltyRisk && (
                <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-red-700">
                  <span className="font-bold block">Statutory Penalty Risk:</span>
                  <span>{selectedAction.penaltyRisk}</span>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => {
                  setSelectedAction(null);
                  onNavigate('ca_services');
                }}
                className="bg-white border border-slate-300 text-slate-900 hover:bg-slate-50 text-xs font-semibold px-4 py-2.5 rounded-xl shadow-sm transition-all"
              >
                Delegate to CA
              </button>
              <button
                onClick={() => {
                  setSelectedAction(null);
                  onNavigate('accounting');
                }}
                className="bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold px-5 py-2.5 rounded-xl flex items-center gap-1.5 shadow-sm transition-all"
              >
                <span>Start Review</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
