import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowRight,
  ShieldCheck,
  Zap,
  TrendingUp,
  Sparkles,
  Calculator,
  UserCheck,
  CheckCircle2,
  AlertTriangle,
  FileSpreadsheet,
  Building,
  Briefcase,
  Layers,
  ChevronRight,
  ChevronDown,
  ExternalLink,
  Laptop,
  Coins,
  Receipt,
  HelpCircle,
  Clock,
  Lock,
  Compass,
  Copy,
  Check,
} from 'lucide-react';
import { FinauraLogo } from '../FinauraLogo';
import { AuthModal } from '../AuthModal';
import { HlsBackgroundVideo } from '../HlsBackgroundVideo';
import { useTypewriter } from '../../hooks/useTypewriter';
import { UserPersona, UserAccount, PlanTier, BillingCycle } from '../../types';
import { PublicPricingSection } from '../pricing/PublicPricingSection';

interface PublicLandingProps {
  onEnterApp?: (persona?: UserPersona, businessName?: string) => void;
  onStartOnboarding?: () => void;
  onAuthenticate?: (user: UserAccount, persona?: UserPersona, businessName?: string) => void;
  onSelectPlan?: (planId: PlanTier, cycle: BillingCycle) => void;
  initialAuthModalOpen?: boolean;
  initialAuthMode?: 'login' | 'signup';
  currentUser?: UserAccount | null;
  onSignOut?: () => void;
}

export const PublicLandingView: React.FC<PublicLandingProps> = ({
  onEnterApp,
  onStartOnboarding,
  onAuthenticate,
  onSelectPlan,
  initialAuthModalOpen = false,
  initialAuthMode = 'login',
  currentUser,
  onSignOut,
}) => {
  const [selectedPersona, setSelectedPersona] = useState<UserPersona>('freelancer');
  const [showAuthModal, setShowAuthModal] = useState(initialAuthModalOpen);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup'>(initialAuthMode);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    setShowAuthModal(initialAuthModalOpen);
  }, [initialAuthModalOpen]);

  useEffect(() => {
    if (initialAuthMode) {
      setAuthModalMode(initialAuthMode);
    }
  }, [initialAuthMode]);
  const [pillsVisible, setPillsVisible] = useState(false);
  const [copied, setCopied] = useState(false);

  // Background video refs and state for mouse-scrubbing
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const prevXRef = useRef<number | null>(null);
  const targetTimeRef = useRef<number>(0);
  const isSeekingRef = useRef<boolean>(false);

  // Typewriter hook for hero message (short & punchy to avoid overlapping background character)
  const typewriterText = 'Autonomous financial OS for Bharat. 50% flat tax & zero tax notices.';
  const { displayed, done } = useTypewriter({
    text: typewriterText,
    speed: 36,
    startDelay: 450,
  });

  // Action pill buttons become visible 400ms after page load
  useEffect(() => {
    const timer = setTimeout(() => {
      setPillsVisible(true);
    }, 400);
    return () => clearTimeout(timer);
  }, []);

  // Video mouse-scrub control
  useEffect(() => {
    const SENSITIVITY = 0.8;

    const handleMouseMove = (e: MouseEvent) => {
      if (prevXRef.current === null) {
        prevXRef.current = e.clientX;
        return;
      }
      const delta = e.clientX - prevXRef.current;
      prevXRef.current = e.clientX;

      const video = videoRef.current;
      if (!video || !video.duration || Number.isNaN(video.duration)) return;

      const timeOffset = (delta / window.innerWidth) * SENSITIVITY * video.duration;
      const newTarget = Math.max(0, Math.min(video.duration, targetTimeRef.current + timeOffset));
      targetTimeRef.current = newTarget;

      if (!isSeekingRef.current) {
        isSeekingRef.current = true;
        video.currentTime = newTarget;
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  const handleSeeked = () => {
    const video = videoRef.current;
    if (!video || !video.duration) {
      isSeekingRef.current = false;
      return;
    }
    if (Math.abs(video.currentTime - targetTimeRef.current) > 0.02) {
      video.currentTime = targetTimeRef.current;
    } else {
      isSeekingRef.current = false;
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      targetTimeRef.current = videoRef.current.currentTime || 0;
    }
  };

  const handleCopyEmail = async () => {
    try {
      await navigator.clipboard.writeText('hello@finaura.co');
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Savings Estimator state
  const [annualTurnoverLakhs, setAnnualTurnoverLakhs] = useState<number>(36);
  const [businessType, setBusinessType] = useState<'service' | 'trading' | 'tech'>('service');

  // Dynamic calculations for Tax Savings Estimator
  const turnoverAmount = annualTurnoverLakhs * 100000;
  const standardEstimatedTax = Math.round(turnoverAmount * 0.22);
  const finauraOptimizedTax =
    businessType === 'service'
      ? Math.round(turnoverAmount * 0.5 * 0.125) // Section 44ADA 50% presumptive
      : Math.round(turnoverAmount * 0.08 * 0.15); // Section 44AD 8% presumptive

  const estimatedTaxSaved = Math.max(0, standardEstimatedTax - finauraOptimizedTax);
  const hoursSavedPerMonth = 18;

  // Persona Details
  const personaCards: Record<
    UserPersona,
    {
      title: string;
      tagline: string;
      painPoint: string;
      finauraSolution: string;
      keyFeatures: string[];
      stat: string;
      statLabel: string;
      demoBusinessName: string;
    }
  > = {
    freelancer: {
      title: 'Freelancers & Solo Creators',
      tagline: '50% Flat Presumptive Tax under Sec 44ADA with 0 Bookkeeping headache.',
      painPoint: 'Tired of tracking every coffee receipt and getting surprise 194J TDS notices?',
      finauraSolution: 'Finaura automatically syncs TDS credits from 26AS, reconciles international payments (Wise/Stripe), and computes advance tax in 1 click.',
      keyFeatures: [
        'Instant 44ADA Presumptive Tax Calculation (Declare 50% as taxable profit)',
        'Form 26AS & AIS automatic TDS credit matching (Never lose 10% TDS)',
        'Export Invoices with FIRC & LUT auto-tagging for foreign client remittances',
        'Direct CA e-filing for ITR-4 without manual spreadsheet preparation',
      ],
      stat: '₹1.85 Lakh',
      statLabel: 'Avg. annual tax legally saved via 44ADA',
      demoBusinessName: 'Aarav Studio (Freelance UX & Tech)',
    },
    startup: {
      title: 'Tech & SaaS Startups',
      tagline: 'Runway visibility, GST LUT export filing & investor-ready financials.',
      painPoint: 'Drowning in vendor TDS (194C/194J), SaaS subscriptions, and GST 2B vs 3B mismatches?',
      finauraSolution: 'Real-time cash runway burn rate, automated Input Tax Credit (ITC) reconciliation, and clean audit trails ready for angel/VC diligence.',
      keyFeatures: [
        'Real-time Cash Runway & Burn Rate forecasting with AI anomaly detection',
        'GST Export Invoices with Zero-Rated GST & LUT acknowledgement linking',
        'Automated 194J/194C Vendor TDS withholding and challan generation',
        'Virtual CA Boardroom with instant response on MCA & RoC filings',
      ],
      stat: '14.2 Days',
      statLabel: 'Runway saved through automated ITC claiming',
      demoBusinessName: 'ApexLabs Technologies Pvt Ltd',
    },
    msme: {
      title: 'MSMEs & Retail Traders',
      tagline: '45-Day MSME Payment Rule Guard & e-Way Bill compliance in plain English.',
      painPoint: 'Worried about Section 43B(h) 45-day payment disallowances and supplier disputes?',
      finauraSolution: 'Finaura flags unpaid MSME vendor invoices before the 45-day deadline, generates QRMP GST reports, and audits purchase registers.',
      keyFeatures: [
        'Automated Section 43B(h) MSME 45-Day Payment countdown & penalty alerts',
        'GSTR-2B vs Purchase Register 1-click matching to catch fake ITC invoices',
        'Bank-to-Book reconciliation for multi-branch Current Accounts',
        'One-click WhatsApp invoice reminders with instant UPI payment links',
      ],
      stat: '100%',
      statLabel: 'Protection against Section 43B(h) tax disallowance penalties',
      demoBusinessName: 'Bharat Traders & Engineering Co.',
    },
    agency: {
      title: 'Agencies & Service Studios',
      tagline: 'Multi-client invoicing, milestone retainers & GST reverse charge (RCM).',
      painPoint: 'Chasing unpaid client retainers while calculating GST on contractor payouts?',
      finauraSolution: 'Automated recurring retainers, dynamic RCM tax liability detection, and team expense debit cards with AI receipt OCR.',
      keyFeatures: [
        'Smart Invoicing with automatic 18% GST bifurcation & digital signature',
        'Reverse Charge Mechanism (RCM) automated journal entries for lawyer/freelancer fees',
        'Client-wise Profitability and resource margin tracking',
        'Chartered Accountant review queue with complete document audit history',
      ],
      stat: '22 Hrs',
      statLabel: 'Saved every month on client billing & GST filing',
      demoBusinessName: 'Mainframe Design & Digital Agency',
    },
  };

  const currentPersonaData = personaCards[selectedPersona];

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans selection:bg-blue-100 selection:text-blue-900 scroll-smooth">
      {/* 1. TOP HERO SECTION WITH MOUSE-SCRUB VIDEO (INTEGRATED DIRECTLY) */}
      <section
        id="hero"
        className="relative w-full h-screen min-h-[640px] max-h-[1080px] overflow-hidden select-none bg-black text-black"
        style={{ fontFamily: 'var(--font-body)' }}
      >
        {/* Background Video with Mouse-Scrubbing */}
        <video
          ref={videoRef}
          id="hero-bg-video"
          className="absolute inset-0 w-full h-full object-cover z-0 pointer-events-none"
          style={{
            objectPosition: 'right center',
          }}
          src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260530_042513_df96a13b-6155-4f6e-8b93-c9dee66fba08.mp4"
          muted
          playsInline
          preload="auto"
          aria-hidden="true"
          tabIndex={-1}
          title="Decorative ambient background video"
          onSeeked={handleSeeked}
          onLoadedMetadata={handleLoadedMetadata}
        >
          <track kind="captions" src="data:text/vtt,WEBVTT" label="No speech audio" default />
        </video>

        {/* Soft Vignette Gradient on Left to ensure contrast while preserving the person on the right */}
        <div className="absolute inset-0 bg-gradient-to-r from-white/95 via-white/75 sm:via-white/50 to-transparent pointer-events-none z-[5]" />

        {/* Hero Top Navbar (Fixed on hero, backdrop-blur) */}
        <header
          id="hero-navbar"
          className="absolute top-0 left-0 right-0 z-20 w-full px-5 sm:px-8 py-4 sm:py-5 flex justify-between items-center bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs"
        >
          {/* Left Brand Logo & Primary Navigation Links grouped together */}
          <div className="flex items-center gap-6 lg:gap-8">
            {/* Brand Logo */}
            <div
              id="hero-logo"
              className="flex items-center gap-3 cursor-pointer shrink-0"
              onClick={() => {
                if (onEnterApp) onEnterApp();
              }}
            >
              <FinauraLogo size="md" subtitle="FINANCIAL OS FOR BHARAT" />
            </div>

            {/* Desktop Nav Links (Left-aligned immediately adjacent to logo) */}
            <nav
              id="hero-desktop-nav"
              className="hidden md:flex items-center gap-5 lg:gap-6 text-sm lg:text-base text-slate-800 font-semibold"
            >
              <button
                type="button"
                onClick={() => scrollToSection('overview')}
                className="hover:text-blue-700 transition-colors bg-transparent border-0 p-0 cursor-pointer"
              >
                Overview
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('architecture')}
                className="hover:text-blue-700 transition-colors bg-transparent border-0 p-0 cursor-pointer"
              >
                Architecture
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('savings-estimator')}
                className="hover:text-blue-700 transition-colors bg-transparent border-0 p-0 cursor-pointer"
              >
                Tax Estimator
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('ca-network')}
                className="hover:text-blue-700 transition-colors bg-transparent border-0 p-0 cursor-pointer"
              >
                CA Network
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('pricing')}
                className="hover:text-blue-700 transition-colors bg-transparent border-0 p-0 cursor-pointer"
              >
                Pricing
              </button>
            </nav>
          </div>

          {/* Right Header CTAs */}
          <div className="hidden md:flex items-center gap-3">
            {currentUser ? (
              <div className="flex items-center gap-3">
                <span className="text-xs font-semibold text-slate-700 max-w-[180px] truncate">
                  {currentUser.name || currentUser.email}
                </span>
                <button
                  type="button"
                  id="hero-nav-workspace-btn"
                  onClick={() => {
                    if (onEnterApp) onEnterApp();
                  }}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-900 text-white rounded-full text-xs font-semibold hover:bg-black transition-all shadow-sm cursor-pointer active:scale-95"
                >
                  <span>Go to Workspace</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
                {onSignOut && (
                  <button
                    type="button"
                    onClick={onSignOut}
                    className="text-xs text-slate-500 hover:text-slate-800 font-medium px-2 py-1 cursor-pointer"
                  >
                    Sign Out
                  </button>
                )}
              </div>
            ) : (
              <>
                <button
                  type="button"
                  id="hero-nav-signin-btn"
                  onClick={() => {
                    setAuthModalMode('login');
                    setShowAuthModal(true);
                  }}
                  className="text-sm font-semibold text-slate-800 hover:text-black px-3.5 py-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  Sign In
                </button>
                <button
                  type="button"
                  id="hero-nav-signup-btn"
                  onClick={() => {
                    setAuthModalMode('signup');
                    setShowAuthModal(true);
                  }}
                  className="text-sm font-semibold text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-200/80 px-3.5 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  Sign Up
                </button>
              </>
            )}
          </div>

          {/* Mobile Hamburger */}
          <button
            id="hero-mobile-hamburger"
            type="button"
            aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden flex flex-col justify-center items-center gap-[5px] w-8 h-8 focus:outline-none z-30 cursor-pointer"
          >
            <span
              className={`w-6 h-[2px] bg-black transition-all duration-300 transform origin-center ${
                mobileMenuOpen ? 'rotate-45 translate-y-[7px]' : 'rotate-0 translate-y-0'
              }`}
            />
            <span
              className={`w-6 h-[2px] bg-black transition-all duration-300 ${
                mobileMenuOpen ? 'opacity-0' : 'opacity-100'
              }`}
            />
            <span
              className={`w-6 h-[2px] bg-black transition-all duration-300 transform origin-center ${
                mobileMenuOpen ? '-rotate-45 -translate-y-[7px]' : 'rotate-0 translate-y-0'
              }`}
            />
          </button>
        </header>

        {/* Mobile Navigation Overlay */}
        <div
          id="hero-mobile-overlay"
          className={`fixed inset-0 z-20 bg-white/95 backdrop-blur-md flex flex-col justify-center px-8 gap-6 transition-opacity duration-300 md:hidden ${
            mobileMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
          }`}
        >
          <button
            type="button"
            onClick={() => {
              setMobileMenuOpen(false);
              scrollToSection('overview');
            }}
            className="text-left text-2xl font-semibold text-slate-900 hover:text-blue-600 transition-colors bg-transparent border-0 p-0"
          >
            Overview
          </button>
          <button
            type="button"
            onClick={() => {
              setMobileMenuOpen(false);
              scrollToSection('architecture');
            }}
            className="text-left text-2xl font-semibold text-slate-900 hover:text-blue-600 transition-colors bg-transparent border-0 p-0"
          >
            Architecture
          </button>
          <button
            type="button"
            onClick={() => {
              setMobileMenuOpen(false);
              scrollToSection('savings-estimator');
            }}
            className="text-left text-2xl font-semibold text-slate-900 hover:text-blue-600 transition-colors bg-transparent border-0 p-0"
          >
            Savings Estimator
          </button>
          <button
            type="button"
            onClick={() => {
              setMobileMenuOpen(false);
              scrollToSection('ca-network');
            }}
            className="text-left text-2xl font-semibold text-slate-900 hover:text-blue-600 transition-colors bg-transparent border-0 p-0"
          >
            CA Network
          </button>
          <button
            type="button"
            onClick={() => {
              setMobileMenuOpen(false);
              scrollToSection('pricing');
            }}
            className="text-left text-2xl font-semibold text-slate-900 hover:text-blue-600 transition-colors bg-transparent border-0 p-0"
          >
            Pricing
          </button>
          {currentUser ? (
            <div className="pt-4 border-t border-slate-200 flex flex-col gap-3">
              <span className="text-xs text-slate-500">Signed in as {currentUser.email}</span>
              <button
                type="button"
                id="mobile-nav-workspace-btn"
                onClick={() => {
                  setMobileMenuOpen(false);
                  if (onEnterApp) onEnterApp();
                }}
                className="w-full py-3 bg-slate-900 text-white rounded-xl text-center font-semibold text-sm cursor-pointer"
              >
                Go to Workspace
              </button>
              {onSignOut && (
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onSignOut();
                  }}
                  className="text-left text-sm text-red-600 font-semibold py-1 cursor-pointer"
                >
                  Sign Out
                </button>
              )}
            </div>
          ) : (
            <>
              <button
                type="button"
                id="mobile-nav-signin-btn"
                onClick={() => {
                  setMobileMenuOpen(false);
                  setAuthModalMode('login');
                  setShowAuthModal(true);
                }}
                className="text-left text-2xl font-semibold text-blue-600 underline underline-offset-4 hover:opacity-80 transition-opacity bg-transparent border-0 p-0 pt-2 cursor-pointer"
              >
                Sign In
              </button>
              <button
                type="button"
                id="mobile-nav-signup-btn"
                onClick={() => {
                  setMobileMenuOpen(false);
                  setAuthModalMode('signup');
                  setShowAuthModal(true);
                }}
                className="text-left text-2xl font-semibold text-slate-800 hover:opacity-80 transition-opacity bg-transparent border-0 p-0 pt-2 cursor-pointer"
              >
                Sign Up
              </button>
            </>
          )}
        </div>

        {/* Hero Interactive Main Content (Cleanly Aligned to Left, Preserving Person on Right) */}
        <main
          id="hero-interactive-content"
          className="relative z-10 h-full flex flex-col justify-end pb-24 md:justify-center md:pb-0 px-6 sm:px-10 md:px-12 lg:px-16 overflow-hidden"
        >
          <div className="max-w-md sm:max-w-lg lg:max-w-xl relative z-10">
            {/* Intro Tag */}
            <div
              id="hero-aria-intro"
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/10 backdrop-blur-md border border-slate-900/15 text-xs font-semibold text-slate-900 tracking-wide mb-3.5"
            >
              <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" aria-hidden="true" />
              <span>A.R.I.A™ • Autonomous Tax &amp; Finance</span>
            </div>

            {/* Typewriter Hero Statement */}
            <p
              id="hero-typewriter-text"
              className="text-slate-950 font-semibold text-lg sm:text-2xl leading-snug tracking-tight mb-5 max-w-sm sm:max-w-md lg:max-w-lg min-h-[50px] sm:min-h-[58px]"
            >
              {displayed}
              {!done && (
                <span
                  className="inline-block w-[2.5px] h-[1.05em] bg-blue-600 align-middle ml-1 animate-blink"
                  aria-hidden="true"
                />
              )}
            </p>

            {/* Hero Direct CTAs */}
            <div
              className="flex flex-wrap items-center gap-3 pt-1 max-w-md sm:max-w-lg"
              style={{
                opacity: pillsVisible ? 1 : 0,
                transform: pillsVisible ? 'translateY(0)' : 'translateY(8px)',
                transition: 'opacity 0.4s ease, transform 0.4s ease',
              }}
            >
              <button
                type="button"
                onClick={() => scrollToSection('overview')}
                className="inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white rounded-full text-xs sm:text-sm font-semibold px-5 py-2.5 transition-all duration-200 cursor-pointer shadow-sm hover:shadow-md active:scale-95"
              >
                <span>Explore Platform</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => {
                  if (onEnterApp) onEnterApp('freelancer', 'Aarav Studio');
                }}
                className="inline-flex items-center justify-center gap-2 bg-white/95 backdrop-blur-md text-slate-900 border border-slate-300 rounded-full text-xs sm:text-sm font-semibold px-4 py-2.5 hover:bg-slate-900 hover:text-white hover:border-slate-900 transition-all duration-200 cursor-pointer shadow-sm hover:shadow-md active:scale-95"
              >
                <Laptop className="w-4 h-4 text-slate-600" />
                <span>Live Interactive Demo</span>
              </button>
            </div>
          </div>

          {/* Bottom Scroll Indicator Pill */}
          <div className="absolute bottom-5 left-1/2 -translate-x-1/2 z-10">
            <button
              type="button"
              onClick={() => scrollToSection('overview')}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-white/90 hover:bg-white text-slate-800 text-xs font-semibold rounded-full backdrop-blur-md border border-slate-200 shadow-sm transition-all hover:scale-105"
            >
              <span>Explore Platform</span>
              <ChevronDown className="w-3.5 h-3.5 animate-bounce text-blue-600" />
            </button>
          </div>
        </main>

        {/* Seamless Blend Gradient at bottom into Overview section */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent pointer-events-none z-[6]" />
      </section>

      {/* 2. OVERVIEW & VALUE PROPOSITION SECTION */}
      <section id="overview" className="relative min-h-[580px] pt-12 pb-20 md:pt-16 md:pb-28 px-4 sm:px-6 lg:px-8 overflow-hidden bg-slate-950 text-white">
        {/* Animated Background Video */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none select-none">
          <HlsBackgroundVideo
            src="https://stream.mux.com/T6oQJQ02cQ6N01TR6iHwZkKFkbepS34dkkIc9iukgy400g.m3u8"
            fallbackMp4="/videos/overview_bg.mp4"
            className="w-full h-full object-cover opacity-80 sm:opacity-90"
          />
          {/* Ambient overlays for readability and smooth section transitions */}
          <div className="absolute inset-0 bg-slate-950/40" />
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950/80 via-transparent to-slate-950/90" />
        </div>

        {/* Live Motion Status Indicator */}
        <div className="absolute bottom-3 right-4 z-10 hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900/70 border border-slate-700/60 backdrop-blur-md text-[11px] text-slate-400 font-medium pointer-events-none">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span>Active Motion Stream</span>
        </div>

        <div className="relative z-10 max-w-5xl mx-auto text-center flex flex-col items-center">
          {/* Target Audience Pill Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-500/20 text-blue-300 text-xs sm:text-sm font-medium mb-8 border border-blue-400/30 backdrop-blur-md shadow-sm">
            <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
            <span>Built for Indian Founders, Freelancers &amp; MSMEs</span>
          </div>

          {/* Main Headline */}
          <h1 className="text-3xl sm:text-5xl md:text-6xl font-bold tracking-tight text-white max-w-4xl leading-[1.14] mb-6">
            Business finance and compliance,{' '}
            <span className="text-blue-300 font-semibold block sm:inline">
              without the accounting chaos.
            </span>
          </h1>

          {/* Subheadline */}
          <p className="text-base sm:text-lg md:text-xl text-slate-300 max-w-3xl leading-relaxed mb-10">
            Finaura eliminates spreadsheets and surprise tax notices with plain-language decisions.
            Connect bank accounts, track GST &amp; TDS deadlines in real time, and collaborate
            directly with certified Chartered Accountants.
          </p>

          {/* Hero Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-3.5 w-full sm:w-auto justify-center mb-10">
            <button
              type="button"
              id="overview-get-started-btn"
              onClick={() => {
                if (onEnterApp) onEnterApp();
              }}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 bg-blue-600 hover:bg-blue-500 text-white text-base font-semibold px-7 py-3.5 rounded-full transition-all shadow-lg shadow-blue-500/30 active:scale-98 cursor-pointer"
            >
              <span>Get Started Free</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => {
                if (onEnterApp) onEnterApp('freelancer', 'Aarav Studio');
              }}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-slate-900/80 hover:bg-slate-800 text-slate-200 text-base font-medium px-6 py-3.5 rounded-full transition-colors border border-slate-700/80 backdrop-blur-md cursor-pointer"
            >
              <Laptop className="w-4 h-4 text-blue-400" />
              <span>Explore Live Workspace Demo</span>
            </button>
          </div>

          {/* Action Pills Container - Tool Specific Actions Placed below main headline and value prop */}
          <div className="w-full max-w-3xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-3">
              Explore specialized tools:
            </span>
            <div
              id="hero-action-pills"
              className="flex flex-wrap gap-2 justify-center"
            >
              <button
                type="button"
                onClick={() => scrollToSection('personas')}
                className="inline-flex items-center justify-center bg-slate-900/80 text-slate-200 border border-slate-700/80 rounded-full text-xs sm:text-sm font-semibold px-4 py-2 hover:bg-slate-800 hover:text-white hover:border-slate-500 transition-all duration-200 cursor-pointer shadow-sm hover:shadow-md active:scale-95 backdrop-blur-md"
              >
                Sec 44ADA (50% Flat Tax)
              </button>

              <button
                type="button"
                onClick={() => scrollToSection('savings-estimator')}
                className="inline-flex items-center justify-center bg-slate-900/80 text-slate-200 border border-slate-700/80 rounded-full text-xs sm:text-sm font-semibold px-4 py-2 hover:bg-slate-800 hover:text-white hover:border-slate-500 transition-all duration-200 cursor-pointer shadow-sm hover:shadow-md active:scale-95 backdrop-blur-md"
              >
                Calculate Tax Savings
              </button>

              <button
                type="button"
                onClick={() => scrollToSection('architecture')}
                className="inline-flex items-center justify-center bg-slate-900/80 text-slate-200 border border-slate-700/80 rounded-full text-xs sm:text-sm font-semibold px-4 py-2 hover:bg-slate-800 hover:text-white hover:border-slate-500 transition-all duration-200 cursor-pointer shadow-sm hover:shadow-md active:scale-95 backdrop-blur-md"
              >
                GST 2B vs 3B Reconciliation
              </button>

              <button
                type="button"
                onClick={() => scrollToSection('ca-network')}
                className="inline-flex items-center justify-center bg-slate-900/80 text-slate-200 border border-slate-700/80 rounded-full text-xs sm:text-sm font-semibold px-4 py-2 hover:bg-slate-800 hover:text-white hover:border-slate-500 transition-all duration-200 cursor-pointer shadow-sm hover:shadow-md active:scale-95 backdrop-blur-md"
              >
                Connect Verified CA
              </button>

              <button
                type="button"
                onClick={handleCopyEmail}
                title="Click to copy email"
                className="inline-flex items-center justify-center bg-blue-600/20 text-blue-300 border border-blue-500/40 rounded-full text-xs sm:text-sm font-semibold px-4 py-2 gap-2 hover:bg-blue-600/30 hover:border-blue-400 transition-all duration-200 cursor-pointer shadow-sm hover:shadow-md active:scale-95 backdrop-blur-md"
              >
                <span>
                  {copied ? 'Copied!' : (
                    <>
                      Direct: <span className="underline underline-offset-2">hello@finaura.co</span>
                    </>
                  )}
                </span>
                {copied ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                ) : (
                  <Copy className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                )}
              </button>
            </div>
          </div>

          {/* Trust Highlights */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6 pt-6 border-t border-slate-800/80 w-full max-w-3xl text-left">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="text-xs sm:text-sm font-semibold text-slate-300">100% Tax Compliant</span>
            </div>
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="text-xs sm:text-sm font-semibold text-slate-300">Sec 44ADA &amp; 44AD</span>
            </div>
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="text-xs sm:text-sm font-semibold text-slate-300">GST 2B vs 3B Auto-Match</span>
            </div>
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="text-xs sm:text-sm font-semibold text-slate-300">ICAI Certified CAs</span>
            </div>
          </div>
        </div>
      </section>

      {/* 3. PERSONAS SECTION */}
      <section
        id="personas"
        className="relative py-20 bg-slate-950 border-y border-slate-800/80 px-4 sm:px-6 lg:px-8 overflow-hidden"
      >
        {/* Animated Background Video */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none select-none">
          <video
            autoPlay
            loop
            muted
            playsInline
            preload="auto"
            aria-hidden="true"
            tabIndex={-1}
            className="w-full h-full object-cover opacity-60 sm:opacity-75"
            src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260629_021419_291eb2af-5ed4-45a0-a1d6-3ef58f4bca0b.mp4"
          >
            <source
              src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260629_021419_291eb2af-5ed4-45a0-a1d6-3ef58f4bca0b.mp4"
              type="video/mp4"
            />
            <track kind="captions" src="data:text/vtt,WEBVTT" label="No audio" default />
          </video>
          {/* Refined gradient overlay to preserve contrast while highlighting the luminous motion */}
          <div className="absolute inset-0 bg-slate-950/60" />
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-transparent to-slate-950" />
        </div>

        <div className="relative z-10 max-w-6xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30 text-xs font-semibold mb-3 backdrop-blur-xs">
              <Compass className="w-3.5 h-3.5" />
              <span>Tailored Operating Models</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-white mb-4">
              Designed specifically for your business structure.
            </h2>
            <p className="text-slate-300 text-base sm:text-lg">
              Whether you are an individual consultant declaring 50% presumptive income or an MSME navigating
              the 45-day payment rule, Finaura configures itself to your exact tax rules.
            </p>
          </div>

          {/* Persona Tab Switcher */}
          <div className="flex flex-wrap justify-center gap-2 mb-10">
            {(
              [
                { id: 'freelancer', label: 'Freelancers & Creators', icon: Laptop },
                { id: 'startup', label: 'Tech & SaaS Startups', icon: Zap },
                { id: 'msme', label: 'MSMEs & Retail Traders', icon: Building },
                { id: 'agency', label: 'Agencies & Studios', icon: Briefcase },
              ] as const
            ).map((tab) => {
              const Icon = tab.icon;
              const isSelected = selectedPersona === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setSelectedPersona(tab.id)}
                  className={`inline-flex items-center gap-2 px-5 py-3 rounded-2xl text-sm font-semibold transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30 scale-102'
                      : 'bg-slate-900/80 backdrop-blur-md text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700/80'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-slate-400'}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Selected Persona Showcase Card */}
          <div className="bg-white/95 backdrop-blur-md rounded-3xl border border-white/40 p-6 sm:p-10 shadow-2xl transition-all">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              {/* Left Column: Details & Key Features */}
              <div className="lg:col-span-7 space-y-6">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
                    Active Persona Profile
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
                    {currentPersonaData.title}
                  </h3>
                  <p className="text-slate-600 font-medium text-base mt-2">
                    {currentPersonaData.tagline}
                  </p>
                </div>

                <div className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-4 text-xs sm:text-sm text-amber-900">
                  <div className="font-semibold flex items-center gap-1.5 text-amber-800 mb-1">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>The Struggle Today</span>
                  </div>
                  <p>{currentPersonaData.painPoint}</p>
                </div>

                <div className="space-y-3">
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                    How Finaura automates it:
                  </h4>
                  <ul className="space-y-2.5">
                    {currentPersonaData.keyFeatures.map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-sm text-slate-700">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-2 flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      if (onEnterApp) {
                        onEnterApp(selectedPersona, currentPersonaData.demoBusinessName);
                      }
                    }}
                    className="inline-flex items-center gap-2 bg-slate-900 hover:bg-black text-white text-sm font-semibold px-5 py-2.5 rounded-full transition-all shadow-sm"
                  >
                    <span>Launch {currentPersonaData.title} Workspace</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (onStartOnboarding) onStartOnboarding();
                    }}
                    className="text-xs font-semibold text-blue-600 hover:text-blue-700 underline underline-offset-4"
                  >
                    Setup my custom profile &rarr;
                  </button>
                </div>
              </div>

              {/* Right Column: Live Metric Snapshot Card */}
              <div className="lg:col-span-5 bg-slate-900 bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-2xl p-6 sm:p-8 flex flex-col justify-between space-y-6 shadow-md">
                <div>
                  <div className="flex items-center justify-between text-slate-300 text-xs font-semibold mb-4">
                    <span>FINAURA INTELLIGENCE ENGINE</span>
                    <span className="inline-flex items-center gap-1 text-emerald-300">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      Live Reconciled
                    </span>
                  </div>

                  <div className="space-y-1 mb-6">
                    <span className="text-3xl sm:text-4xl font-extrabold text-white">
                      {currentPersonaData.stat}
                    </span>
                    <p className="text-xs sm:text-sm text-slate-300">
                      {currentPersonaData.statLabel}
                    </p>
                  </div>

                  <div className="space-y-3 pt-4 border-t border-slate-700/80 text-xs text-slate-300">
                    <div className="flex justify-between items-center gap-2">
                      <span className="text-slate-300 shrink-0">Demo Entity:</span>
                      <span
                        className="font-semibold text-white text-right"
                        title={currentPersonaData.demoBusinessName}
                      >
                        {currentPersonaData.demoBusinessName}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">Audit Status:</span>
                      <span className="text-emerald-300 font-semibold">100% Notice-Proof</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">CA Verified:</span>
                      <span className="text-blue-300 font-semibold">Priya Sharma &amp; Associates (FCA)</span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-800/80 rounded-xl p-3 border border-slate-700 text-xs text-slate-300 flex items-center justify-between">
                  <span>Try interactive demo directly</span>
                  <button
                    type="button"
                    onClick={() => {
                      if (onEnterApp) {
                        onEnterApp(selectedPersona, currentPersonaData.demoBusinessName);
                      }
                    }}
                    className="text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 px-3 py-1.5 rounded-lg transition-colors"
                  >
                    Open
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. THE PROBLEM SECTION */}
      <section id="the-problem" className="py-20 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold text-rose-600 uppercase tracking-wider">The Problem</span>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 mt-2 mb-4">
            Indian tax compliance is broken for modern builders.
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Spreadsheets break, traditional accounting software is built for 1995 desktop computers, and
            tax notices arrive 18 months late with crippling interest penalties.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold mb-4">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Unmatched GSTR-2B Losses</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              When your vendors fail to upload invoices on time, you lose Input Tax Credit (ITC). Most
              businesses forfeit ₹40,000+ each quarter without ever noticing.
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold mb-4">
              <Clock className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Section 234B &amp; 234C Interest</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Missing the 4 quarterly Advance Tax installments triggers mandatory 1% per month penal
              interest. Finaura forecasts your exact tax liability before each deadline.
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold mb-4">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Spreadsheet Blackbox</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Bank statements in PDF, bills in email attachments, and TDS certificates in TRACES. Reconciling
              them manually burns 20 hours every month.
            </p>
          </div>
        </div>
      </section>

      {/* 5. ARCHITECTURE SECTION */}
      <section id="architecture" className="py-20 bg-slate-900 text-white px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-bold text-blue-400 uppercase tracking-wider">Architecture</span>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mt-2 mb-4">
              The 4-Layer Financial OS Engine
            </h2>
            <p className="text-slate-400 text-base sm:text-lg">
              How Finaura bridges your real bank feeds with tax compliance and CA audit signoffs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-6">
              <span className="text-xs font-bold text-blue-400 block mb-3">01 / INGESTION</span>
              <h3 className="text-lg font-bold text-white mb-2">Account Aggregator Feeds</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Connect HDFC, ICICI, SBI, Razorpay &amp; Stripe. Encrypted, read-only transaction streaming.
              </p>
            </div>

            <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-6">
              <span className="text-xs font-bold text-blue-400 block mb-3">02 / TAX RULES</span>
              <h3 className="text-lg font-bold text-white mb-2">Deterministic Engine</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Hardcoded compliance rules for GST 1/3B, TDS Sections 194C/J/I/H, and 44ADA Presumptive thresholds.
              </p>
            </div>

            <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-6">
              <span className="text-xs font-bold text-blue-400 block mb-3">03 / AI EXPLAINER</span>
              <h3 className="text-lg font-bold text-white mb-2">Plain English Copilot</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Translates cryptic tax jargon into clear, actionable business choices with &ldquo;Explain Why&rdquo; context.
              </p>
            </div>

            <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-6">
              <span className="text-xs font-bold text-blue-400 block mb-3">04 / CA ESCROW</span>
              <h3 className="text-lg font-bold text-white mb-2">ICAI Audit Verification</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Direct handoff to certified Chartered Accountants with workpaper export to Tally &amp; ITD portal.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. SAVINGS ESTIMATOR SECTION */}
      <section id="savings-estimator" className="py-20 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <div className="bg-blue-50 bg-gradient-to-br from-blue-50 to-indigo-50/50 border border-blue-200/70 rounded-3xl p-6 sm:p-10">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold text-blue-800 uppercase tracking-wider">
              Interactive Estimator
            </span>
            <h2 className="text-3xl font-bold text-slate-900 mt-1 mb-2">
              Calculate your tax &amp; time savings.
            </h2>
            <p className="text-slate-600 text-sm">
              See what you could save by switching from standard accounting chaos to Finaura&apos;s guided rules.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            {/* Sliders and Controls */}
            <div className="space-y-6 bg-white p-6 rounded-2xl border border-blue-100 shadow-sm">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label htmlFor="turnover-slider" className="text-xs font-bold text-slate-700">
                    Annual Gross Turnover:
                  </label>
                  <span className="text-sm font-bold text-blue-600">₹{annualTurnoverLakhs} Lakhs</span>
                </div>
                <div className="py-2.5">
                  <input
                    id="turnover-slider"
                    type="range"
                    min="6"
                    max="120"
                    step="2"
                    value={annualTurnoverLakhs}
                    onChange={(e) => setAnnualTurnoverLakhs(Number(e.target.value))}
                    aria-label="Annual Gross Turnover in Lakhs"
                    aria-valuemin={6}
                    aria-valuemax={120}
                    aria-valuenow={annualTurnoverLakhs}
                    aria-valuetext={`₹${annualTurnoverLakhs} Lakhs`}
                    className="w-full h-3 sm:h-3.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600 touch-none"
                  />
                </div>
                <div className="flex justify-between text-xs text-slate-500 mt-1">
                  <span>₹6L (Freelancer)</span>
                  <span>₹50L (44ADA Cap)</span>
                  <span>₹1.2Cr+ (MSME)</span>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-2">Business Activity:</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'service', label: 'Services / UX / Tech' },
                    { id: 'tech', label: 'SaaS / Product' },
                    { id: 'trading', label: 'Trading / Retail' },
                  ].map((b) => (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => setBusinessType(b.id as any)}
                      className={`text-xs font-semibold p-2.5 rounded-xl border transition-all ${
                        businessType === b.id
                          ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {b.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Results Snapshot */}
            <div className="bg-slate-900 text-white p-6 sm:p-8 rounded-2xl flex flex-col justify-between space-y-6 shadow-md">
              <div>
                <span className="text-xs font-bold text-blue-300 uppercase tracking-wider">
                  Estimated Annual Benefit
                </span>
                <div className="mt-3">
                  <span className="text-4xl font-extrabold text-white">
                    ₹{estimatedTaxSaved.toLocaleString('en-IN')}
                  </span>
                  <p className="text-xs text-slate-300 mt-1">
                    Potential tax deduction savings under optimized Section 44ADA / 44AD presumptive rules.
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-slate-300 block">Hours Saved:</span>
                  <span className="text-base font-bold text-emerald-300">~{hoursSavedPerMonth} hrs/mo</span>
                </div>
                <div>
                  <span className="text-slate-300 block">Audit Penalty Risk:</span>
                  <span className="text-base font-bold text-emerald-300">0% Guarantee</span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  if (onEnterApp) onEnterApp();
                }}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs py-3 rounded-xl transition-all text-center"
              >
                Claim this Setup in Finaura &rarr;
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 7. CA NETWORK SECTION */}
      <section id="ca-network" className="py-20 bg-slate-50 border-t border-slate-200 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
              On-Demand CA Network
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 mt-2 mb-4">
              Collaborate directly with certified Chartered Accountants.
            </h2>
            <p className="text-slate-600 text-base sm:text-lg">
              Never get stuck on tricky tax laws. Book an instant 30-minute advisory video call or have
              a dedicated CA review your books before every GST deadline.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                name: 'Priya Sharma, FCA',
                firm: 'Sharma & Associates',
                experience: '12+ Yrs Experience',
                speciality: 'SaaS Cross-border Invoicing & GST LUT',
                rating: '4.9 ★ (140+ reviews)',
              },
              {
                name: 'Rajesh K. Mehta, CA',
                firm: 'Mehta Tax Advisory',
                experience: '8+ Yrs Experience',
                speciality: 'MSME Section 43B(h) & GSTR-9 Annual Filing',
                rating: '5.0 ★ (98 reviews)',
              },
              {
                name: 'Ananya Deshmukh, ACA',
                firm: 'VentureBooks Advisors',
                experience: '6+ Yrs Experience',
                speciality: 'Freelancers Sec 44ADA & 26AS Reconciliation',
                rating: '4.9 ★ (210+ reviews)',
              },
            ].map((ca, idx) => (
              <div key={idx} className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-11 h-11 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-sm">
                      {ca.name.slice(0, 2)}
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-sm">{ca.name}</h3>
                      <p className="text-xs text-slate-500">{ca.firm}</p>
                    </div>
                  </div>
                  <span className="inline-block text-xs font-semibold bg-emerald-50 text-emerald-700 px-2.5 py-0.5 rounded-full mb-3">
                    {ca.experience}
                  </span>
                  <p className="text-xs text-slate-600 mb-4">{ca.speciality}</p>
                </div>
                <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800">{ca.rating}</span>
                  <button
                    type="button"
                    onClick={() => {
                      if (onEnterApp) onEnterApp();
                    }}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                  >
                    <span>Consult Now</span>
                    <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 8. PUBLIC PRICING & SUBSCRIPTION SECTION */}
      <PublicPricingSection
        onSelectPlan={(planId, cycle) => {
          if (onSelectPlan) {
            onSelectPlan(planId, cycle);
          } else if (onEnterApp) {
            onEnterApp(selectedPersona, currentPersonaData.demoBusinessName);
          }
        }}
        onExploreCAPro={() => {
          scrollToSection('ca-network');
        }}
      />

      {/* 9. FOOTER */}
      <footer className="bg-white border-t border-slate-200 py-12 px-4 sm:px-6 lg:px-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <FinauraLogo size="sm" subtitle="FINANCIAL OS" />
            <span>&copy; 2026 Finaura Inc. All rights reserved.</span>
          </div>

          <div className="flex flex-wrap items-center gap-6">
            <a href="#overview" className="hover:text-slate-900 transition-colors">
              Overview
            </a>
            <a href="#the-problem" className="hover:text-slate-900 transition-colors">
              The Problem
            </a>
            <a href="#architecture" className="hover:text-slate-900 transition-colors">
              Architecture
            </a>
            <a href="#savings-estimator" className="hover:text-slate-900 transition-colors">
              Savings Estimator
            </a>
            <a href="#ca-network" className="hover:text-slate-900 transition-colors">
              CA Network
            </a>
            <a href="#pricing" className="hover:text-slate-900 transition-colors">
              Pricing
            </a>
          </div>
        </div>
      </footer>

      {/* Auth Modal for Sign In / Sign Up */}
      {showAuthModal && (
        <AuthModal
          isOpen={showAuthModal}
          initialMode={authModalMode}
          onClose={() => setShowAuthModal(false)}
          onSuccess={(user) => {
            setShowAuthModal(false);
            if (onAuthenticate) {
              onAuthenticate(user, selectedPersona, currentPersonaData.demoBusinessName);
            } else if (onEnterApp) {
              onEnterApp(selectedPersona, currentPersonaData.demoBusinessName);
            }
          }}
        />
      )}
    </div>
  );
};
