import React, { useState } from 'react';
import {
  CreditCard,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  ArrowUpRight,
  Download,
  Calendar,
  Clock,
  Layers,
  Users,
  HardDrive,
  FileText,
  HelpCircle,
  RefreshCw,
  QrCode,
  Building,
  Check,
  Zap,
} from 'lucide-react';
import {
  UserSubscription,
  BillingInvoice,
  UsageMetrics,
  PlanTier,
  BusinessProfile,
  Invoice,
  UploadedDoc,
} from '../../types';
import { PLANS, getPlan, isPlanAtLeast } from '../../lib/plans';
import { paymentService } from '../../lib/payment';
import { UpgradeModal } from '../pricing/UpgradeModal';
import { DowngradeModal } from '../pricing/DowngradeModal';
import { CancellationModal } from '../pricing/CancellationModal';
import { analytics } from '../../lib/analytics';

interface SubscriptionBillingViewProps {
  subscription: UserSubscription;
  onUpdateSubscription: (sub: UserSubscription) => void;
  billingInvoices: BillingInvoice[];
  onAddInvoice: (inv: BillingInvoice) => void;
  metrics: UsageMetrics;
  profile: BusinessProfile;
  invoices?: Invoice[];
  documents?: UploadedDoc[];
  onNavigateToCA?: () => void;
}

export const SubscriptionBillingView: React.FC<SubscriptionBillingViewProps> = ({
  subscription,
  onUpdateSubscription,
  billingInvoices,
  onAddInvoice,
  metrics,
  profile,
  invoices = [],
  documents = [],
  onNavigateToCA,
}) => {
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [showDowngradeModal, setShowDowngradeModal] = useState(false);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [selectedTargetPlan, setSelectedTargetPlan] = useState<PlanTier>('business');
  const [isResuming, setIsResuming] = useState(false);
  const [paymentMethodEdit, setPaymentMethodEdit] = useState(false);
  const [newVpa, setNewVpa] = useState(subscription.paymentMethod?.vpa || 'finance@okhdfcbank');

  const currentPlan = getPlan(subscription.planId);
  const isYearly = subscription.billingCycle === 'yearly';

  const renewalDateStr = new Date(subscription.currentPeriodEnd).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  const handleOpenUpgrade = (target: PlanTier = 'business') => {
    setSelectedTargetPlan(target);
    setShowUpgradeModal(true);
  };

  const handleResumeSubscription = async () => {
    setIsResuming(true);
    analytics.track('subscription_resumed', { planId: subscription.planId });
    try {
      const res = await paymentService.resumeSubscription(subscription);
      if (res.success) {
        onUpdateSubscription(res.updatedSubscription);
      }
    } finally {
      setIsResuming(false);
    }
  };

  const handleSavePaymentMethod = () => {
    onUpdateSubscription({
      ...subscription,
      paymentMethod: {
        type: 'upi',
        vpa: newVpa,
      },
    });
    setPaymentMethodEdit(false);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-200">
      {/* 1. PAGE HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider bg-emerald-50 px-2.5 py-0.5 rounded-md border border-emerald-200">
              Billing &amp; Subscription HQ
            </span>
            {subscription.isDemoMode && (
              <span className="text-[10px] font-bold text-slate-700 uppercase tracking-wider bg-slate-100 px-2 py-0.5 rounded-md border border-slate-300">
                Sandbox Simulator Mode
              </span>
            )}
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Workspace Plan &amp; Billing
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Manage your subscription, live operational quotas, team seats, and GST tax invoices.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {subscription.status === 'cancelled' ? (
            <button
              type="button"
              disabled={isResuming}
              onClick={handleResumeSubscription}
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-xs cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Resume Subscription</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => handleOpenUpgrade(subscription.planId === 'growth' ? 'business' : 'professional')}
              className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-black text-white font-bold text-xs flex items-center gap-2 shadow-xs cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>Upgrade Plan</span>
            </button>
          )}
        </div>
      </div>

      {/* 2. CURRENT PLAN CARD */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          {/* Left: Plan Info */}
          <div className="space-y-4 max-w-xl">
            <div className="flex items-center gap-3">
              <span className="text-2xl sm:text-3xl font-black text-white">
                FINAURA {currentPlan.name.toUpperCase()}
              </span>
              <span
                className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider flex items-center gap-1 ${
                  subscription.status === 'active'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    : subscription.status === 'cancelled'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
                <span>
                  {subscription.status === 'active'
                    ? 'Active Plan'
                    : subscription.status === 'cancelled'
                    ? 'Cancelling at Period End'
                    : 'Scheduled Downgrade'}
                </span>
              </span>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {currentPlan.purpose}
            </p>

            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-2 border-t border-slate-800">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>
                  {subscription.status === 'cancelled' ? 'Expires on:' : 'Renews on:'}{' '}
                  <strong className="text-white">{renewalDateStr}</strong>
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-slate-400" />
                <span>
                  Term:{' '}
                  <strong className="text-white">
                    {subscription.billingCycle === 'yearly' ? 'Annual (Billed Yearly)' : 'Monthly'}
                  </strong>
                </span>
              </div>
            </div>
          </div>

          {/* Right: Pricing & Quick Actions */}
          <div className="bg-slate-800/80 backdrop-blur-md rounded-2xl p-6 border border-slate-700/60 lg:min-w-[280px] space-y-4">
            <div>
              <span className="text-[11px] text-slate-400 block font-medium">Subscription Rate:</span>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-3xl font-extrabold text-white">
                  ₹
                  {(isYearly
                    ? currentPlan.monthlyEquivalentYearly
                    : currentPlan.priceMonthly
                  ).toLocaleString('en-IN')}
                </span>
                <span className="text-xs text-slate-400">/month</span>
              </div>
              {isYearly ? (
                <span className="text-[10px] text-emerald-400 font-semibold block mt-0.5">
                  Billed ₹{currentPlan.priceYearly.toLocaleString('en-IN')} annually (20% discount applied)
                </span>
              ) : (
                <span className="text-[10px] text-slate-400 block mt-0.5">
                  Billed monthly + 18% GST
                </span>
              )}
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-700">
              <button
                type="button"
                onClick={() => handleOpenUpgrade(subscription.planId === 'growth' ? 'business' : 'professional')}
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs"
              >
                <span>Upgrade to Higher Tier</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-between gap-2 pt-1 text-[11px]">
                <button
                  type="button"
                  onClick={() => setShowDowngradeModal(true)}
                  className="text-slate-400 hover:text-white underline cursor-pointer"
                >
                  Change / Downgrade
                </button>
                {subscription.status !== 'cancelled' && (
                  <button
                    type="button"
                    onClick={() => setShowCancelModal(true)}
                    className="text-slate-400 hover:text-rose-400 cursor-pointer"
                  >
                    Cancel Plan
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3. OPERATIONAL USAGE METERS SECTION (Phase 10 mandate) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Current Billing Period Usage</h2>
            <p className="text-xs text-slate-500">
              Real-time resource meters against your {currentPlan.name} plan quotas.
            </p>
          </div>
          <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
            Resets automatically on 1st of month
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Meter 1: AI Queries */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-700 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span>AI Copilot Queries</span>
              </span>
              <span className="font-bold text-slate-900">
                {metrics.aiQuestionsUsed} / {metrics.aiQuestionsLimit}
              </span>
            </div>
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
              <div
                className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                style={{
                  width: `${Math.min(
                    100,
                    (metrics.aiQuestionsUsed / metrics.aiQuestionsLimit) * 100
                  )}%`,
                }}
              />
            </div>
            <div className="flex justify-between text-[11px] text-slate-500">
              <span>{Math.round((metrics.aiQuestionsUsed / metrics.aiQuestionsLimit) * 100)}% consumed</span>
              <span>{metrics.aiQuestionsLimit - metrics.aiQuestionsUsed} remaining</span>
            </div>
          </div>

          {/* Meter 2: Invoices */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-700 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-blue-600" />
                <span>Invoices Generated</span>
              </span>
              <span className="font-bold text-slate-900">
                {metrics.invoicesCount} / {metrics.invoicesLimit}
              </span>
            </div>
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
              <div
                className="bg-blue-600 h-full rounded-full transition-all duration-500"
                style={{
                  width: `${Math.min(
                    100,
                    (metrics.invoicesCount / metrics.invoicesLimit) * 100
                  )}%`,
                }}
              />
            </div>
            <div className="flex justify-between text-[11px] text-slate-500">
              <span>Tax &amp; GST compliant</span>
              <span>{metrics.invoicesLimit - metrics.invoicesCount} remaining</span>
            </div>
          </div>

          {/* Meter 3: Vault Storage */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-700 flex items-center gap-1.5">
                <HardDrive className="w-3.5 h-3.5 text-indigo-600" />
                <span>Encrypted Vault Storage</span>
              </span>
              <span className="font-bold text-slate-900">
                {(metrics.storageUsedBytes / (1024 * 1024 * 1024)).toFixed(1)} GB /{' '}
                {currentPlan.limits.storageGB} GB
              </span>
            </div>
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
              <div
                className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                style={{
                  width: `${Math.min(
                    100,
                    (metrics.storageUsedBytes / metrics.storageLimitBytes) * 100
                  )}%`,
                }}
              />
            </div>
            <div className="flex justify-between text-[11px] text-slate-500">
              <span>Tamper-proof audit trail</span>
              <span>
                {(
                  currentPlan.limits.storageGB -
                  metrics.storageUsedBytes / (1024 * 1024 * 1024)
                ).toFixed(1)}{' '}
                GB free
              </span>
            </div>
          </div>

          {/* Meter 4: Team Members */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-700 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-purple-600" />
                <span>Team Member Seats</span>
              </span>
              <span className="font-bold text-slate-900">
                {metrics.teamMembersCount} / {metrics.teamMembersLimit} seats
              </span>
            </div>
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
              <div
                className="bg-purple-600 h-full rounded-full transition-all duration-500"
                style={{
                  width: `${Math.min(
                    100,
                    (metrics.teamMembersCount / metrics.teamMembersLimit) * 100
                  )}%`,
                }}
              />
            </div>
            <div className="flex justify-between text-[11px] text-slate-500">
              <span>Director &amp; Finance team</span>
              {currentPlan.limits.teamMembers <= 2 && (
                <button
                  type="button"
                  onClick={() => handleOpenUpgrade('business')}
                  className="text-purple-600 font-bold hover:underline cursor-pointer"
                >
                  + Add seats
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 4. PAYMENT METHOD & CA SERVICES SEPARATION */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Payment Method Card */}
        <div className="md:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-slate-100 text-slate-800 flex items-center justify-center">
                <CreditCard className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">Active Payment Method</h3>
                <span className="text-[11px] text-slate-500">Indian Autopay / Mandate</span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setPaymentMethodEdit(!paymentMethodEdit)}
              className="text-xs font-bold text-emerald-800 hover:text-emerald-900 cursor-pointer"
            >
              {paymentMethodEdit ? 'Cancel' : 'Update Method'}
            </button>
          </div>

          {!paymentMethodEdit ? (
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                  UPI
                </div>
                <div>
                  <span className="font-bold text-slate-900 block">
                    {subscription.paymentMethod?.vpa || 'director@okhdfcbank'}
                  </span>
                  <span className="text-[11px] text-slate-500">
                    Primary mandate for recurring subscriptions
                  </span>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                Verified Mandate
              </span>
            </div>
          ) : (
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3 text-xs">
              <label className="font-bold text-slate-700 block">Update UPI ID / VPA:</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newVpa}
                  onChange={(e) => setNewVpa(e.target.value)}
                  className="flex-1 px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold focus:outline-emerald-600"
                />
                <button
                  type="button"
                  onClick={handleSavePaymentMethod}
                  className="px-4 py-2 bg-slate-900 hover:bg-black text-white rounded-xl font-bold cursor-pointer"
                >
                  Save
                </button>
              </div>
            </div>
          )}

          <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              Transactions processed via RBI-compliant 256-bit tokenized gateway abstraction.
            </span>
          </div>
        </div>

        {/* Professional Services Box (Phase 5 mandate: Separate layer) */}
        <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-6 shadow-2xs flex flex-col justify-between space-y-4">
          <div>
            <span className="text-[10px] font-bold text-amber-900 uppercase tracking-wider bg-amber-100/70 px-2 py-0.5 rounded">
              Separate Revenue Layer
            </span>
            <h3 className="text-sm font-bold text-slate-900 mt-2">
              Need CA Review or ITR Representation?
            </h3>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
              Chartered Accountant audit sign-offs, formal representation before ITD, and customized tax advisory are separate professional services.
            </p>
          </div>

          <button
            type="button"
            onClick={onNavigateToCA}
            className="w-full py-2.5 px-3 rounded-xl bg-white border border-amber-300 hover:bg-amber-100 text-amber-950 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
          >
            <span>Browse CA Marketplace</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 5. BILLING HISTORY & TAX INVOICES TABLE (Phase 11 mandate) */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-2xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-lg font-bold text-slate-900">Billing History &amp; GST Invoices</h3>
            <p className="text-xs text-slate-500">
              Download GST-compliant tax invoices for your business tax deduction records.
            </p>
          </div>
          <span className="text-xs text-slate-500">
            GSTIN: 27AABCF1234F1Z8 (SAC: 998313)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-bold">
                <th className="pb-3 px-2">Invoice #</th>
                <th className="pb-3 px-2">Date</th>
                <th className="pb-3 px-2">Plan / Description</th>
                <th className="pb-3 px-2">Amount</th>
                <th className="pb-3 px-2">Status</th>
                <th className="pb-3 px-2">Payment Method</th>
                <th className="pb-3 px-2 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {billingInvoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3.5 px-2 font-mono font-bold text-slate-900">
                    {inv.invoiceNumber}
                  </td>
                  <td className="py-3.5 px-2">{inv.date}</td>
                  <td className="py-3.5 px-2 font-medium">
                    Finaura {inv.planName} ({inv.billingCycle})
                  </td>
                  <td className="py-3.5 px-2 font-bold text-slate-900">
                    ₹{inv.amount.toLocaleString('en-IN')}
                  </td>
                  <td className="py-3.5 px-2">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold text-[10px] border border-emerald-200">
                      <Check className="w-3 h-3" />
                      <span>{inv.status.toUpperCase()}</span>
                    </span>
                  </td>
                  <td className="py-3.5 px-2 text-slate-500">{inv.paymentMethod}</td>
                  <td className="py-3.5 px-2 text-right">
                    <button
                      type="button"
                      onClick={() => paymentService.downloadInvoice(inv, profile.businessName)}
                      className="inline-flex items-center gap-1 text-slate-700 hover:text-slate-900 font-bold hover:underline cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODALS */}
      {showUpgradeModal && (
        <UpgradeModal
          isOpen={showUpgradeModal}
          onClose={() => setShowUpgradeModal(false)}
          currentSubscription={subscription}
          initialTargetPlan={selectedTargetPlan}
          onSuccess={(updatedSub, newInvoice) => {
            onUpdateSubscription(updatedSub);
            onAddInvoice(newInvoice);
          }}
          businessName={profile.businessName}
        />
      )}

      {showDowngradeModal && (
        <DowngradeModal
          isOpen={showDowngradeModal}
          onClose={() => setShowDowngradeModal(false)}
          currentSubscription={subscription}
          metrics={metrics}
          onSuccess={(updatedSub) => {
            onUpdateSubscription(updatedSub);
          }}
        />
      )}

      {showCancelModal && (
        <CancellationModal
          isOpen={showCancelModal}
          onClose={() => setShowCancelModal(false)}
          currentSubscription={subscription}
          onSuccess={(updatedSub) => {
            onUpdateSubscription(updatedSub);
          }}
        />
      )}
    </div>
  );
};
