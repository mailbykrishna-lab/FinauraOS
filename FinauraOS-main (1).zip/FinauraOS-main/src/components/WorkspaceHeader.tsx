import React, { useState } from 'react';
import {
  LayoutDashboard,
  CreditCard,
  PieChart,
  FileText,
  ShieldAlert,
  Calculator,
  FolderLock,
  UserCheck,
  Sparkles,
  Search,
  Building2,
  ChevronDown,
  User,
  LogOut,
  Sliders,
  Globe,
  CheckCircle2,
  Calendar,
  Menu,
  X,
  Scale,
} from 'lucide-react';
import { NavTab, BusinessProfile, UserAccount, Invoice, ComplianceAction, Transaction } from '../types';
import { FinauraLogo } from './FinauraLogo';

interface WorkspaceHeaderProps {
  currentTab: NavTab;
  onNavigate: (tab: NavTab) => void;
  profile: BusinessProfile;
  currentUser?: UserAccount | null;
  onOpenAI: (prompt?: string) => void;
  onOpenAuthModal: () => void;
  onSignOut: () => void;
  onViewPublicLanding: () => void;
  onRestartOnboarding: () => void;
  invoices?: Invoice[];
  complianceActions?: ComplianceAction[];
  transactions?: Transaction[];
}

export const WorkspaceHeader: React.FC<WorkspaceHeaderProps> = ({
  currentTab,
  onNavigate,
  profile,
  currentUser,
  onOpenAI,
  onOpenAuthModal,
  onSignOut,
  onViewPublicLanding,
  onRestartOnboarding,
  invoices = [],
  complianceActions = [],
  transactions = [],
}) => {
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Compute live badges
  const pendingLedgerCount = transactions.filter((t) => !t.confirmed).length;
  const overdueInvoiceCount = invoices.filter((i) => i.status === 'overdue').length;
  const urgentComplianceCount = complianceActions.filter((c) => c.priority === 'urgent' && c.status !== 'completed').length;

  const NAV_ITEMS: Array<{
    id: NavTab;
    label: string;
    icon: React.FC<{ className?: string }>;
    badge?: number;
    badgeColor?: string;
  }> = [
    { id: 'dashboard', label: 'Daily Brief', icon: LayoutDashboard },
    {
      id: 'accounting',
      label: 'Smart Accounting',
      icon: CreditCard,
      badge: pendingLedgerCount > 0 ? pendingLedgerCount : undefined,
      badgeColor: 'bg-amber-100 text-amber-800 border-amber-300',
    },
    { id: 'expenses', label: 'Expenses', icon: PieChart },
    {
      id: 'invoices',
      label: 'Invoicing & GST',
      icon: FileText,
      badge: overdueInvoiceCount > 0 ? overdueInvoiceCount : undefined,
      badgeColor: 'bg-rose-100 text-rose-800 border-rose-300',
    },
    {
      id: 'compliance',
      label: 'Compliance HQ',
      icon: ShieldAlert,
      badge: urgentComplianceCount > 0 ? urgentComplianceCount : undefined,
      badgeColor: 'bg-rose-100 text-rose-800 border-rose-300',
    },
    { id: 'tax', label: 'Tax Workflow', icon: Calculator },
    { id: 'documents', label: 'Vault', icon: FolderLock },
    { id: 'ca_services', label: 'CA Services', icon: UserCheck },
  ];

  return (
    <header className="bg-white/95 backdrop-blur-md border-b border-slate-200/90 sticky top-0 z-40 transition-all shadow-xs">
      {/* TOP PRIMARY BAR */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-15 gap-3">
          
          {/* LEFT: LOGO & ENTITY PILL */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => onNavigate('dashboard')}
              className="flex items-center gap-2 focus:outline-none cursor-pointer"
            >
              <FinauraLogo size="sm" theme="light" subtitle="Financial OS" />
            </button>

            {/* Entity Badge */}
            <div className="hidden lg:flex items-center gap-2 px-2.5 py-1 bg-slate-100/90 rounded-lg border border-slate-200/80 text-xs font-semibold text-slate-700">
              <Building2 className="w-3.5 h-3.5 text-slate-500" />
              <span className="truncate max-w-[130px] font-bold text-slate-900">{profile.businessName || 'My Entity'}</span>
              <span className="text-[10px] font-mono text-emerald-700 bg-emerald-100/80 px-1.5 py-0.2 rounded border border-emerald-300/60 font-bold">
                {profile.persona === 'startup' ? 'Pvt Ltd' : profile.persona === 'agency' ? 'LLP' : 'Prop.'}
              </span>
            </div>
          </div>

          {/* CENTER: DESKTOP NAVIGATION TABS */}
          <nav className="hidden xl:flex items-center gap-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onNavigate(item.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer relative ${
                    isActive
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-400' : 'text-slate-500'}`} />
                  <span>{item.label}</span>
                  {item.badge !== undefined && (
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono border font-extrabold ${
                        isActive ? 'bg-emerald-400 text-slate-950 border-emerald-300' : item.badgeColor
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* RIGHT: ASK FINAURA AI & USER UTILITIES */}
          <div className="flex items-center gap-2">
            
            {/* Ask Finaura AI Button */}
            <button
              type="button"
              onClick={() => onOpenAI()}
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-3 sm:px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs hover:shadow-sm transition-all cursor-pointer group"
              title="Open Finaura AI Statutory Reasoner"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-200 group-hover:rotate-12 transition-transform" />
              <span className="hidden sm:inline">Ask Finaura AI</span>
              <span className="sm:hidden">AI</span>
              <kbd className="hidden md:inline-block text-[10px] font-mono bg-emerald-800/80 text-emerald-200 px-1.5 py-0.5 rounded border border-emerald-500/40">
                ⌘K
              </kbd>
            </button>

            {/* Statutory Act 2025 Pill */}
            <div className="hidden md:flex items-center gap-1 text-[11px] font-semibold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200/80">
              <Scale className="w-3 h-3 text-emerald-600" />
              <span>Tax Act 2025</span>
            </div>

            {/* User Account / Profile Menu */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center gap-1.5 p-1.5 rounded-xl border border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50 transition-all cursor-pointer text-slate-700"
              >
                <div className="w-6 h-6 rounded-lg bg-slate-900 text-white flex items-center justify-center text-[11px] font-bold">
                  {currentUser?.name ? currentUser.name.charAt(0).toUpperCase() : 'K'}
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
              </button>

              {userMenuOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 animate-in fade-in slide-in-from-top-2">
                  <div className="px-3.5 py-2 border-b border-slate-100">
                    <p className="text-xs font-bold text-slate-900 truncate">
                      {currentUser?.name || profile.businessName || 'Business Owner'}
                    </p>
                    <p className="text-[11px] text-slate-500 truncate">
                      {currentUser?.email || profile.contactEmail || 'user@example.com'}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setUserMenuOpen(false);
                      onRestartOnboarding();
                    }}
                    className="w-full text-left px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2 font-medium"
                  >
                    <Sliders className="w-3.5 h-3.5 text-slate-500" />
                    <span>Change Business Persona</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setUserMenuOpen(false);
                      onViewPublicLanding();
                    }}
                    className="w-full text-left px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2 font-medium"
                  >
                    <Globe className="w-3.5 h-3.5 text-slate-500" />
                    <span>View Public Landing Page</span>
                  </button>

                  {currentUser ? (
                    <button
                      type="button"
                      onClick={() => {
                        setUserMenuOpen(false);
                        onSignOut();
                      }}
                      className="w-full text-left px-3.5 py-2 text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2 font-bold border-t border-slate-100 mt-1"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Sign Out</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setUserMenuOpen(false);
                        onOpenAuthModal();
                      }}
                      className="w-full text-left px-3.5 py-2 text-xs text-emerald-700 hover:bg-emerald-50 flex items-center gap-2 font-bold border-t border-slate-100 mt-1"
                    >
                      <User className="w-3.5 h-3.5" />
                      <span>Sign In / Register Account</span>
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Mobile Hamburger Toggle */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 border border-slate-200"
              aria-label="Toggle navigation"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

          </div>
        </div>

        {/* SECONDARY SCROLLABLE TABS BAR (visible on medium screens < xl) */}
        <div className="hidden md:flex xl:hidden overflow-x-auto py-2 gap-1 border-t border-slate-100 no-scrollbar">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onNavigate(item.id)}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-400' : 'text-slate-500'}`} />
                <span>{item.label}</span>
                {item.badge !== undefined && (
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono border font-extrabold ${
                      isActive ? 'bg-emerald-400 text-slate-950 border-emerald-300' : item.badgeColor
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* MOBILE SLIDE-DOWN MENU (visible on small mobile screens) */}
        {mobileMenuOpen && (
          <div className="xl:hidden py-3 border-t border-slate-200 bg-white space-y-1">
            <div className="px-2 py-1 mb-2 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between text-xs font-bold">
              <span className="text-slate-700">{profile.businessName || 'Krishna Enterprises'}</span>
              <span className="text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded font-mono text-[10px]">
                Income Tax Act 2025 Active
              </span>
            </div>

            <div className="grid grid-cols-2 gap-1.5">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      onNavigate(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`p-2.5 rounded-lg text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                      isActive
                        ? 'bg-slate-900 text-white shadow-xs'
                        : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200/60'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-slate-600'}`} />
                      <span>{item.label}</span>
                    </div>
                    {item.badge !== undefined && (
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-rose-100 text-rose-800 border border-rose-300 font-extrabold">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}

      </div>
    </header>
  );
};
