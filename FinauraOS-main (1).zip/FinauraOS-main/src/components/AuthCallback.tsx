import React, { useEffect, useState } from 'react';
import { Loader2, AlertCircle, ArrowRight, RotateCw, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { supabase, mapSupabaseUserToAccount, supabaseSignInWithGoogle } from '../lib/supabase';
import { checkAndGetFinauraProfile } from '../lib/profile';
import { UserAccount, BusinessProfile } from '../types';
import { FinauraLogoMark } from './FinauraLogo';

interface AuthCallbackProps {
  onSuccess: (user: UserAccount, profile: BusinessProfile, destination: '/dashboard' | '/onboarding') => void;
  onNavigateToSignIn: (errorMessage?: string) => void;
}

export const AuthCallback: React.FC<AuthCallbackProps> = ({
  onSuccess,
  onNavigateToSignIn,
}) => {
  const [statusText, setStatusText] = useState<string>('Verifying Google authentication with Supabase...');
  const [hasError, setHasError] = useState<boolean>(false);
  const [isRetrying, setIsRetrying] = useState<boolean>(false);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  useEffect(() => {
    let isMounted = true;
    const isDev = Boolean(
      (import.meta as any).env?.DEV ||
      (typeof window !== 'undefined' &&
        (window.location.hostname === 'localhost' ||
          window.location.hostname === '127.0.0.1'))
    );

    async function handleAuthCallback() {
      try {
        if (isDev) {
          console.log('[OAuth Callback] callback route reached');
        }

        // 1. Check for errors returned in query parameters or hash
        const searchParams = new URLSearchParams(window.location.search);
        const hash = window.location.hash.substring(1);
        const hashParams = new URLSearchParams(hash);

        const errorParam = searchParams.get('error') || hashParams.get('error');
        const errorDescription =
          searchParams.get('error_description') ||
          hashParams.get('error_description') ||
          searchParams.get('message');

        if (errorParam || errorDescription) {
          if (isDev) {
            console.warn('[OAuth Callback] OAuth error parameters detected in URL:', {
              error: errorParam,
              description: errorDescription,
            });
          }
          if (isMounted) {
            setHasError(true);
          }
          return;
        }

        // 2. Retrieve authenticated Supabase user session (handling PKCE code or existing session)
        setStatusText('Retrieving authenticated Supabase session...');
        let session: any = null;

        // Check if session is already active (via Supabase detectSessionInUrl)
        const { data: initialSessionData } = await supabase.auth.getSession();
        if (initialSessionData?.session?.user) {
          session = initialSessionData.session;
        }

        // If not found yet and code is in URL, attempt code exchange
        const code = searchParams.get('code');
        if (!session && code) {
          setStatusText('Exchanging authorization code with Supabase...');
          const { data: exchangeData, error: exchangeError } = await supabase.auth.exchangeCodeForSession(code);
          if (exchangeData?.session?.user) {
            session = exchangeData.session;
          } else if (exchangeError && isDev) {
            console.warn('[OAuth Callback] exchangeCodeForSession notice:', exchangeError.message);
          }
        }

        // Check getSession again
        if (!session) {
          const { data: retrySessionData, error: sessionError } = await supabase.auth.getSession();
          if (retrySessionData?.session?.user) {
            session = retrySessionData.session;
          } else if (sessionError && isDev) {
            console.warn('[OAuth Callback] session retrieval notice:', sessionError.message);
          }
        }

        // If session is still propagating, listen briefly for auth state change
        if (!session?.user) {
          await new Promise<void>((resolve) => {
            const timeout = setTimeout(() => resolve(), 3500);
            const { data: listener } = supabase.auth.onAuthStateChange((_event, currentSession) => {
              if (currentSession?.user) {
                session = currentSession;
                clearTimeout(timeout);
                listener.subscription.unsubscribe();
                resolve();
              }
            });
          });
        }

        if (isDev) {
          console.log('[OAuth Callback] authenticated session', session ? 'found' : 'not found');
          if (session?.user?.id) {
            console.log('[OAuth Callback] authenticated user ID:', session.user.id);
          }
        }

        const authUser = session?.user;
        if (!authUser) {
          if (isMounted) {
            setHasError(true);
          }
          return;
        }

        if (!isMounted) return;
        const userAccount = mapSupabaseUserToAccount(authUser);

        // 3. Retrieve or Create FINAURA Profile
        setStatusText('Checking FINAURA profile and onboarding status...');
        const profileResult = await checkAndGetFinauraProfile(authUser);

        if (!isMounted) return;

        // 4. Determine destination based on onboarding_completed
        // - New user → /onboarding
        // - Existing user with onboarding_completed = true → /dashboard
        // - Existing user with onboarding_completed = false → /onboarding
        const destination: '/dashboard' | '/onboarding' = profileResult.onboarding_completed
          ? '/dashboard'
          : '/onboarding';

        if (isDev) {
          console.log('[OAuth Callback] profile', profileResult.profile ? 'found' : 'not found');
          console.log(
            '[OAuth Callback] onboarding status:',
            profileResult.onboarding_completed ? 'completed' : 'pending'
          );
          console.log('[OAuth Callback] final redirect destination:', destination);
        }

        setIsCompleted(true);
        setStatusText(
          profileResult.onboarding_completed
            ? 'Account verified! Redirecting to Dashboard...'
            : 'Welcome to FINAURA! Starting Guided Setup...'
        );

        // Micro-delay for smooth UX transition
        setTimeout(() => {
          if (isMounted) {
            onSuccess(userAccount, profileResult.profile, destination);
          }
        }, 400);
      } catch (err: any) {
        if (isDev) {
          console.error('[OAuth Callback] Exception:', err?.message || err);
        }
        if (isMounted) {
          setHasError(true);
        }
      }
    }

    handleAuthCallback();

    return () => {
      isMounted = false;
    };
  }, [onSuccess]);

  const handleTryAgain = async () => {
    setIsRetrying(true);
    setHasError(false);
    try {
      await supabaseSignInWithGoogle();
    } catch {
      setIsRetrying(false);
      setHasError(true);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-slate-900 font-sans">
      <div className="w-full max-w-md bg-white rounded-2xl border border-slate-200 shadow-sm p-8 text-center space-y-6">
        
        {/* Brand Logo */}
        <div className="inline-flex items-center justify-center p-3 rounded-2xl bg-slate-50 border border-slate-100 shadow-xs">
          <FinauraLogoMark size={40} />
        </div>

        {/* Dynamic State: User Error vs Loading / Success */}
        {hasError ? (
          <div className="space-y-4">
            <div className="w-12 h-12 rounded-full bg-amber-50 text-amber-700 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <h2 className="text-lg font-bold text-slate-900">
                Google sign-in could not be completed.
              </h2>
              <p className="text-xs text-slate-500 leading-relaxed max-w-xs mx-auto">
                We were unable to complete the verification with Google. Please try again or sign in with your email.
              </p>
            </div>

            <div className="pt-3 space-y-2">
              <button
                type="button"
                onClick={handleTryAgain}
                disabled={isRetrying}
                className="w-full h-11 bg-slate-900 hover:bg-black text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-xs disabled:opacity-50"
              >
                {isRetrying ? (
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                ) : (
                  <RotateCw className="w-3.5 h-3.5" />
                )}
                <span>Try Again</span>
              </button>

              <button
                type="button"
                onClick={() => onNavigateToSignIn()}
                className="w-full h-11 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 text-xs font-semibold rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <span>Back to Sign In</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center mx-auto">
              {isCompleted ? (
                <CheckCircle2 className="w-6 h-6 text-emerald-600 animate-in zoom-in-50" />
              ) : (
                <Loader2 className="w-6 h-6 text-emerald-600 animate-spin" />
              )}
            </div>

            <div className="space-y-1.5">
              <h2 className="text-base font-bold text-slate-900">
                {isCompleted ? 'Authentication Complete' : 'Connecting with Google'}
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                {statusText}
              </p>
            </div>

            <div className="pt-2 flex items-center justify-center gap-2 text-[11px] text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
              <span>Supabase Project: vnopxarfmzzmygsqsdhq</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
