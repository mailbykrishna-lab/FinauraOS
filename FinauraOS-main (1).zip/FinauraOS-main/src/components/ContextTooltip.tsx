import React, { useState } from 'react';
import { Info } from 'lucide-react';

interface ContextTooltipProps {
  term: string;
  definition?: string;
  children?: React.ReactNode;
}

const financialDictionary: Record<string, string> = {
  Receivables: 'Money customers still need to pay you for delivered goods or services.',
  Payables: 'Money your business needs to pay suppliers, vendors, or contractors.',
  Compliance: 'Statutory business requirements, tax filings, and actions you must complete on time.',
  'Cash Flow': 'Real money currently moving into and out of your operational bank accounts.',
  TDS: 'Tax Deducted at Source — tax withheld when paying vendors, deposited with the IT department.',
  ITC: 'Input Tax Credit — GST paid on business purchases that reduces your net tax output liability.',
  'GSTR-3B': 'Monthly self-declared summary GST return detailing sales, purchases, and tax payable.',
  'E-Invoicing': 'Direct real-time authentication of B2B invoices with the government Invoice Registration Portal (IRP).',
  'Section 194R': '10% tax deduction on business perks, gifts, or incentives exceeding ₹20,000/yr.',
  'Form AOC-4': 'Annual filing of audited balance sheet and P&L statements with the Registrar of Companies (ROC).',
  'Profit vs Cash Flow': 'Profit includes billed revenue not yet paid; Cash Flow is only cash physically received.',
};

export const ContextTooltip: React.FC<ContextTooltipProps> = ({
  term,
  definition,
  children,
}) => {
  const [show, setShow] = useState(false);
  const text = definition || financialDictionary[term] || 'Contextual business metric tracked by Finaura.';

  return (
    <span className="relative inline-flex items-center gap-1 group cursor-help">
      <span className="underline decoration-dotted decoration-slate-400 underline-offset-4 text-inherit font-medium">
        {children || term}
      </span>
      <button
        type="button"
        onClick={() => setShow(!show)}
        onMouseEnter={() => setShow(true)}
        onMouseLeave={() => setShow(false)}
        aria-label={`Definition and statutory context for ${term}`}
        aria-expanded={show}
        title={`Definition and statutory context for ${term}`}
        className="w-7 h-7 flex items-center justify-center text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer -my-1 -mr-1"
      >
        <Info className="w-4 h-4 text-slate-500" aria-hidden="true" />
      </button>

      {show && (
        <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-2.5 bg-slate-900 text-white text-xs rounded-lg shadow-xl z-50 pointer-events-none animate-in fade-in zoom-in-95 duration-150 border border-slate-800">
          <span className="font-bold text-slate-100 block mb-0.5">{term}</span>
          <span className="text-slate-300 leading-relaxed block">{text}</span>
          <span className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-900"></span>
        </span>
      )}
    </span>
  );
};
