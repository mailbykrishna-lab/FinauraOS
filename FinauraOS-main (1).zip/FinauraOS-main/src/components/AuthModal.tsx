import React, { useState } from 'react';
import {
  X,
  Mail,
  Lock,
  Eye,
  EyeOff,
  User,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Loader2,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { AuthProvider, UserAccount, UserPersona } from '../types';
import { FinauraLogoMark } from './FinauraLogo';
import {
  supabaseSignUp,
  supabaseSignIn,
  supabaseSignInWithGoogle,
  supabaseResetPassword,
  supabaseResendConfirmation,
} from '../lib/supabase';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'signup';
  onSuccess: (user: UserAccount, defaultPersona?: UserPersona, defaultBusinessName?: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'login',
  onSuccess,
}) => {
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot_password'>(initialMode);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  // States
  const [loadingProvider, setLoadingProvider] = useState<AuthProvider | null>(null);
  const [loadingStatus, setLoadingStatus] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [resetSuccessMessage, setResetSuccessMessage] = useState<string | null>(null);
  const [confirmationEmailPending, setConfirmationEmailPending] = useState<string | null>(null);
  const [isResendingConfirmation, setIsResendingConfirmation] = useState<boolean>(false);

  if (!isOpen) return null;

  // 1. Google OAuth Sign-In handler via Supabase
  const handleGoogleSignIn = async () => {
    setErrorMessage(null);
    setLoadingProvider('google');
    setLoadingStatus('Redirecting to Google...');

    try {
      const res = await supabaseSignInWithGoogle();
      if (res.error) {
        setLoadingProvider(null);
        setErrorMessage(res.error);
        return;
      }
      if (res.url) {
        window.location.assign(res.url);
      }
      // Browser will redirect to Google OAuth endpoint via Supabase
    } catch (err: any) {
      setLoadingProvider(null);
      setErrorMessage(err?.message || 'Google OAuth connection failed');
    }
  };

  // 2. Resend Confirmation Handler
  const handleResendConfirmation = async () => {
    if (!confirmationEmailPending) return;
    setIsResendingConfirmation(true);
    try {
      const res = await supabaseResendConfirmation(confirmationEmailPending);
      setIsResendingConfirmation(false);
      if (res.error) {
        setErrorMessage(`Could not resend email: ${res.error}`);
      } else {
        setResetSuccessMessage(`A new verification email was sent to ${confirmationEmailPending}.`);
      }
    } catch (err: any) {
      setIsResendingConfirmation(false);
      setErrorMessage(err?.message || 'Failed to resend confirmation email');
    }
  };

  // 3. Apple ID Sign-In handler
  const handleAppleSignIn = () => {
    setErrorMessage(null);
    setLoadingProvider('apple');
    setLoadingStatus('Connecting with Apple ID...');

    setTimeout(() => {
      const appleEmail = email.trim() || 'apple.user@icloud.com';
      const user: UserAccount = {
        id: `usr_apple_${Date.now()}`,
        name: 'Apple ID User',
        email: appleEmail,
        provider: 'apple',
        isEmailVerified: true,
        connectedAccounts: {
          apple: { email: appleEmail, connectedAt: new Date().toISOString() },
        },
      };

      setLoadingProvider(null);
      onSuccess(user, 'startup', 'Apple Connected Venture');
      onClose();
    }, 600);
  };

  // 4. Email/Password Submission handler via Supabase
  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!email.trim() || !email.includes('@')) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }

    if (mode === 'forgot_password') {
      setLoadingProvider('email');
      setLoadingStatus('Sending password reset link via Supabase...');
      const res = await supabaseResetPassword(email.trim());
      setLoadingProvider(null);
      if (res.error) {
        setErrorMessage(res.error);
      } else {
        setResetSuccessMessage(`A password recovery email was sent to ${email} via Supabase Auth.`);
      }
      return;
    }

    if (password.length < 6) {
      setErrorMessage('Password must be at least 6 characters long.');
      return;
    }

    if (mode === 'signup' && !name.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }

    setLoadingProvider('email');
    setLoadingStatus(mode === 'signup' ? 'Registering with Supabase...' : 'Verifying credentials with Supabase...');

    if (mode === 'signup') {
      const res = await supabaseSignUp(email.trim(), password, name.trim());
      setLoadingProvider(null);
      if (res.error) {
        if (res.error.toLowerCase().includes('already registered')) {
          setErrorMessage('This email is already registered in Supabase. Please sign in instead.');
          return;
        }
        setErrorMessage(res.error);
        return;
      }
      if (res.confirmationRequired) {
        setConfirmationEmailPending(email.trim());
        setResetSuccessMessage(
          `A verification link has been sent to ${email.trim()}. Please check your inbox (and spam folder) to confirm your account.`
        );
        return;
      }
      if (res.user) {
        onSuccess(res.user, 'startup', `${name.trim()}'s Enterprise`);
        onClose();
      }
    } else {
      // Login
      const res = await supabaseSignIn(email.trim(), password);
      setLoadingProvider(null);
      if (res.error) {
        if (res.error.toLowerCase().includes('email not confirmed')) {
          setConfirmationEmailPending(email.trim());
          setErrorMessage(
            'Your email has not been confirmed yet. Please verify your email before logging in, or click "Resend confirmation email" below.'
          );
        } else if (res.error.includes('Invalid login credentials')) {
          setErrorMessage('Invalid credentials. If you are a new user, click "Create an account" below.');
        } else {
          setErrorMessage(res.error);
        }
        return;
      }
      if (res.user) {
        onSuccess(res.user, 'startup', `${res.user.name}'s Enterprise`);
        onClose();
      }
    }
  };

  return (
    <div
      id="finaura-auth-modal-overlay"
      className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget && !loadingProvider) {
          onClose();
        }
      }}
    >
      <div
        id="finaura-auth-modal-card"
        className="bg-white rounded-3xl border border-slate-200/90 shadow-2xl max-w-[440px] w-full p-8 sm:p-10 relative overflow-hidden animate-in zoom-in-95 duration-200 my-auto"
      >
        {/* Subtle Close Button */}
        <button
          onClick={onClose}
          disabled={!!loadingProvider}
          className="absolute top-6 right-6 text-slate-400 hover:text-slate-700 p-2 rounded-full hover:bg-slate-100/80 transition-colors disabled:opacity-40"
          aria-label="Close"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Centered Brand Header */}
        <div className="text-center space-y-3 pt-1 pb-2">
          <div className="inline-flex items-center justify-center p-2 rounded-2xl bg-slate-50 border border-slate-100 shadow-xs mb-1">
            <FinauraLogoMark size={36} />
          </div>
          <div className="space-y-1.5">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-geist tracking-tight">
              {mode === 'login'
                ? 'Welcome back'
                : mode === 'signup'
                ? 'Create your account'
                : 'Reset your password'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 max-w-[320px] mx-auto leading-relaxed">
              {mode === 'login'
                ? 'Sign in to access your business financial OS'
                : mode === 'signup'
                ? 'Start managing compliance, invoices, and accounting seamlessly'
                : 'Enter your work email to receive instructions'}
            </p>
          </div>
        </div>

        {/* Prominent Google & Apple Buttons */}
        {mode !== 'forgot_password' && (
          <div className="space-y-3 pt-4">
            {/* Google Sign-in Button */}
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={!!loadingProvider}
              className="w-full h-12 bg-white hover:bg-slate-50/80 text-slate-800 border border-slate-300/90 font-medium text-sm rounded-2xl flex items-center justify-center gap-3 shadow-xs hover:border-slate-400 transition-all active:scale-[0.99] disabled:opacity-50"
            >
              {loadingProvider === 'google' ? (
                <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />
              ) : (
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
              )}
              <span className="font-medium">
                {loadingProvider === 'google'
                  ? loadingStatus
                  : 'Continue with Google'}
              </span>
            </button>

            {/* Apple ID Sign-in Button */}
            <button
              type="button"
              onClick={handleAppleSignIn}
              disabled={!!loadingProvider}
              className="w-full h-12 bg-black hover:bg-slate-900 text-white font-medium text-sm rounded-2xl flex items-center justify-center gap-3 shadow-xs transition-all active:scale-[0.99] disabled:opacity-50"
            >
              {loadingProvider === 'apple' ? (
                <Loader2 className="w-4 h-4 text-white animate-spin" />
              ) : (
                <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.61-.75 1.04-1.8 0.92-2.85-.9.04-1.98.6-2.61 1.34-.56.65-1.05 1.71-.92 2.73 1.01.08 2.01-.47 2.61-1.22z" />
                </svg>
              )}
              <span className="font-medium">
                {loadingProvider === 'apple'
                  ? loadingStatus
                  : mode === 'signup'
                  ? 'Sign up with Apple'
                  : 'Continue with Apple'}
              </span>
            </button>
          </div>
        )}

        {/* Minimalist Divider */}
        {mode !== 'forgot_password' && (
          <div className="relative flex items-center justify-center my-6">
            <div className="absolute inset-0 flex items-center" aria-hidden="true">
              <div className="w-full border-t border-slate-200/80" />
            </div>
            <span className="relative z-10 bg-white px-3.5 text-xs text-slate-400 font-normal text-center select-none">
              or continue with email
            </span>
          </div>
        )}

        {/* Error / Success Notifications */}
        {errorMessage && (
          <div className="mb-4 p-3 bg-red-50/90 border border-red-200/90 rounded-2xl text-xs text-red-700 flex flex-col gap-2 animate-in fade-in">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <span className="leading-relaxed">{errorMessage}</span>
            </div>
            {confirmationEmailPending && (
              <button
                type="button"
                onClick={handleResendConfirmation}
                disabled={isResendingConfirmation}
                className="self-start text-[11px] font-bold text-red-800 underline hover:text-red-900 disabled:opacity-50 cursor-pointer pl-6"
              >
                {isResendingConfirmation ? 'Resending verification email...' : 'Click here to resend confirmation email'}
              </button>
            )}
          </div>
        )}

        {resetSuccessMessage && (
          <div className="mb-4 p-3 bg-emerald-50/90 border border-emerald-200/90 rounded-2xl text-xs text-emerald-800 flex flex-col gap-2 animate-in fade-in">
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span className="leading-relaxed">{resetSuccessMessage}</span>
            </div>
            {confirmationEmailPending && (
              <button
                type="button"
                onClick={handleResendConfirmation}
                disabled={isResendingConfirmation}
                className="self-start text-[11px] font-bold text-emerald-800 underline hover:text-emerald-950 disabled:opacity-50 cursor-pointer pl-6"
              >
                {isResendingConfirmation ? 'Sending another email...' : 'Resend confirmation email'}
              </button>
            )}
          </div>
        )}

        {/* Minimal Form */}
        <form onSubmit={handleEmailSubmit} className="space-y-4">
          {mode === 'signup' && (
            <div className="space-y-1.5 text-left">
              <label className="text-xs font-semibold text-slate-700 block">
                Full Name
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Aditi Rao"
                  className="w-full h-11 pl-10 pr-4 bg-slate-50/60 hover:bg-slate-50 focus:bg-white border border-slate-200/90 rounded-2xl text-sm focus:outline-none focus:border-slate-900 focus:ring-1 focus:ring-slate-900 transition-all placeholder:text-slate-400"
                />
              </div>
            </div>
          )}

          <div className="space-y-1.5 text-left">
            <label className="text-xs font-semibold text-slate-700 block">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="founder@company.com"
                className="w-full h-11 pl-10 pr-4 bg-slate-50/60 hover:bg-slate-50 focus:bg-white border border-slate-200/90 rounded-2xl text-sm focus:outline-none focus:border-slate-900 focus:ring-1 focus:ring-slate-900 transition-all placeholder:text-slate-400"
              />
            </div>
          </div>

          {mode !== 'forgot_password' && (
            <div className="space-y-1.5 text-left">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-700">
                  Password
                </label>
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={() => {
                      setErrorMessage(null);
                      setResetSuccessMessage(null);
                      setMode('forgot_password');
                    }}
                    className="text-xs font-medium text-slate-500 hover:text-slate-900 transition-colors"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full h-11 pl-10 pr-11 bg-slate-50/60 hover:bg-slate-50 focus:bg-white border border-slate-200/90 rounded-2xl text-sm focus:outline-none focus:border-slate-900 focus:ring-1 focus:ring-slate-900 transition-all placeholder:text-slate-400"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 p-1"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          )}

          {mode === 'login' && (
            <div className="flex items-center gap-2 pt-0.5">
              <input
                type="checkbox"
                id="rememberMe"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="w-3.5 h-3.5 rounded text-slate-900 border-slate-300 focus:ring-0 cursor-pointer"
              />
              <label htmlFor="rememberMe" className="text-xs text-slate-600 cursor-pointer select-none">
                Keep me signed in
              </label>
            </div>
          )}

          <button
            type="submit"
            disabled={!!loadingProvider}
            className="w-full h-12 bg-slate-900 hover:bg-slate-800 text-white font-medium text-sm rounded-2xl flex items-center justify-center gap-2 shadow-sm transition-all active:scale-[0.99] disabled:opacity-50 mt-2"
          >
            {loadingProvider === 'email' ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{loadingStatus}</span>
              </>
            ) : (
              <>
                <span>
                  {mode === 'login'
                    ? 'Sign in to Workspace'
                    : mode === 'signup'
                    ? 'Create Account'
                    : 'Send Reset Link'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Centered Switcher Footer */}
        <div className="pt-6 mt-6 border-t border-slate-100 text-center space-y-3">
          <p className="text-xs text-slate-500">
            {mode === 'login' ? (
              <>
                Don&apos;t have an account?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setErrorMessage(null);
                    setResetSuccessMessage(null);
                    setMode('signup');
                  }}
                  className="font-semibold text-slate-900 hover:underline"
                >
                  Sign up free
                </button>
              </>
            ) : mode === 'signup' ? (
              <>
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setErrorMessage(null);
                    setResetSuccessMessage(null);
                    setMode('login');
                  }}
                  className="font-semibold text-slate-900 hover:underline"
                >
                  Sign in
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setErrorMessage(null);
                  setResetSuccessMessage(null);
                  setMode('login');
                }}
                className="font-semibold text-slate-900 hover:underline"
              >
                ← Back to sign in
              </button>
            )}
          </p>

          <div className="flex flex-col items-center justify-center gap-1.5 text-[11px] text-slate-400">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
              <span>256-bit encrypted • Bank-grade privacy</span>
            </div>
            <div className="flex items-center gap-1 text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Connected to Supabase (vnopxarfmzzmygsqsdhq)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
