import React, { useState } from 'react';
import {
  ChevronRight,
  Home,
  LayoutDashboard,
  Wallet,
  CreditCard,
  PieChart,
  FileText,
  ShieldCheck,
  Calculator,
  FolderLock,
  UserCheck,
  Sparkles,
  Search,
  Bell,
  Calendar,
  Building2,
  Users,
  Building,
  DollarSign,
  Package,
  BarChart3,
  PlugZap,
  Plus,
  Link2,
  Copy,
  Check,
} from 'lucide-react';
import { NavTab, BusinessProfile, UserAccount } from '../types';

interface BreadcrumbNavProps {
  currentTab: NavTab;
  currentSubTab?: string;
  onNavigate: (tab: NavTab, subTab?: string) => void;
  profile: BusinessProfile;
  currentUser?: UserAccount | null;
  onOpenAI: (prompt?: string) => void;
  onOpenAddTransaction?: () => void;
  onOpenCreateInvoice?: () => void;
  onOpenUploadDoc?: () => void;
  onOpenAskCA?: () => void;
  onOpenNotifications?: () => void;
}

interface TabMeta {
  label: string;
  category: string;
  icon: React.FC<{ className?: string }>;
  description: string;
}

const TAB_METADATA: Record<NavTab, TabMeta> = {
  home: {
    label: 'Home Overview',
    category: 'Executive Dashboard',
    icon: Home,
    description: 'Business overview, today priorities, statutory signals & cashflow',
  },
  dashboard: {
    label: 'Home Overview',
    category: 'Executive Dashboard',
    icon: Home,
    description: 'Business overview, today priorities, statutory signals & cashflow',
  },
  finance: {
    label: 'Finance Workspace',
    category: 'Treasury & Accounting',
    icon: Wallet,
    description: 'General ledger, transactions, invoices, expenses, receivables, payables and cash flow',
  },
  accounting: {
    label: 'Transactions & Ledger',
    category: 'Finance',
    icon: CreditCard,
    description: 'Double-entry automated ledger, reconciliation & P&L statements',
  },
  expenses: {
    label: 'Expenses & Spend Analytics',
    category: 'Finance',
    icon: PieChart,
    description: 'Tax-deductible expense tracking, vendor analysis & burn rate',
  },
  invoices: {
    label: 'Invoices & Receivables',
    category: 'Finance',
    icon: FileText,
    description: 'GST-compliant tax invoices, Section 31 compliance & payment tracking',
  },
  compliance: {
    label: 'Compliance HQ',
    category: 'Statutory Governance',
    icon: ShieldCheck,
    description: 'Compliance health score, upcoming deadlines, government circulars & MCA/ROC',
  },
  tax: {
    label: 'Tax Center',
    category: 'Statutory Filings',
    icon: Calculator,
    description: 'Income Tax Act 2025, GST Returns (GSTR-1/3B), TDS withholding & Advance Tax',
  },
  documents: {
    label: 'Document Vault',
    category: 'Records & Audits',
    icon: FolderLock,
    description: 'Financial records, vendor invoices, tax challans & registration certificates',
  },
  professionals: {
    label: 'CA & Professional Services',
    category: 'Chartered Accountants',
    icon: UserCheck,
    description: 'Verified Chartered Accountants on demand for statutory audits & filing',
  },
  ca_services: {
    label: 'CA & Professional Services',
    category: 'Chartered Accountants',
    icon: UserCheck,
    description: 'Verified Chartered Accountants on demand for statutory audits & filing',
  },
  ai: {
    label: 'Ask Finaura AI',
    category: 'Statutory Copilot',
    icon: Sparkles,
    description: 'Gemini 3.7 AI Tax Reasoner, Section 43B(h) simulator & smart spend insights',
  },
  ask_ai: {
    label: 'Ask Finaura AI',
    category: 'Statutory Copilot',
    icon: Sparkles,
    description: 'Gemini 3.7 AI Tax Reasoner, Section 43B(h) simulator & smart spend insights',
  },
  calendar: {
    label: 'Statutory Calendar',
    category: 'Deadlines & Tasks',
    icon: Calendar,
    description: 'Monthly statutory calendar with GST, TDS, advance tax & custom milestones',
  },
  customers: {
    label: 'Customers & CRM',
    category: 'Operations',
    icon: Users,
    description: 'Customer directory, lifetime billing, receivables & GSTIN verification',
  },
  vendors: {
    label: 'Vendors & MSME 43B(h)',
    category: 'Operations',
    icon: Building,
    description: 'Vendor directory, Udyam MSME classification & 45-day payment tracker',
  },
  payroll: {
    label: 'Payroll & Salaries',
    category: 'Operations',
    icon: DollarSign,
    description: 'Salary disbursement, EPF, PT and Section 192 TDS deductions',
  },
  inventory: {
    label: 'Inventory Management',
    category: 'Operations',
    icon: Package,
    description: 'Stock valuation (AS 2 / Ind AS 2), SKU tracking and tax cost model',
  },
  reports: {
    label: 'Financial Statements',
    category: 'Operations',
    icon: BarChart3,
    description: 'Balance sheet (Schedule III), P&L statement & GSTR-2B reconciliation',
  },
  integrations: {
    label: 'API Integrations',
    category: 'Operations',
    icon: PlugZap,
    description: 'Connected GSTN portal, Income Tax e-filing, MCA V3 & bank accounts',
  },
  receivables: {
    label: 'Receivables Aging',
    category: 'Finance',
    icon: FileText,
    description: 'Outstanding client invoices and payment collection status',
  },
  payables: {
    label: 'Payables & MSME 43B(h)',
    category: 'Finance',
    icon: Building,
    description: 'Vendor bills and statutory 45-day MSME payment tracking',
  },
  cashflow: {
    label: 'Cash Flow Forecast',
    category: 'Finance',
    icon: Wallet,
    description: 'Liquidity, burn rate and working capital projections',
  },
  settings: {
    label: 'Settings & Workspace',
    category: 'Configuration',
    icon: Building2,
    description: 'Entity profile, GSTIN, banking and security settings',
  },
  billing: {
    label: 'Plan & Billing',
    category: 'Workspace Management',
    icon: CreditCard,
    description: 'Manage subscription tier, monitor usage quotas, and download GST tax invoices',
  },
  help: {
    label: 'Help & Knowledge Hub',
    category: 'Support',
    icon: Home,
    description: 'System tours, statutory guides and live CA assistance',
  },
  notifications: {
    label: 'Statutory Notifications',
    category: 'Alerts',
    icon: Bell,
    description: 'Compliance triggers and critical tax deadlines',
  },
};

export const BreadcrumbNav: React.FC<BreadcrumbNavProps> = ({
  currentTab,
  currentSubTab,
  onNavigate,
  profile,
  currentUser,
  onOpenAI,
  onOpenAddTransaction,
  onOpenCreateInvoice,
  onOpenUploadDoc,
  onOpenAskCA,
  onOpenNotifications,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [copied, setCopied] = useState(false);
  const meta = TAB_METADATA[currentTab] || TAB_METADATA.home;
  const Icon = meta.icon;

  const currentPath = `/workspace/${currentTab}${currentSubTab ? `/${currentSubTab}` : ''}`;
  const currentUrlHash = `#${currentPath}`;

  const handleCopyUrl = async () => {
    try {
      const fullUrl = `${window.location.origin}${window.location.pathname}${currentUrlHash}`;
      await navigator.clipboard.writeText(fullUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="bg-white/95 backdrop-blur-md border-b border-slate-200/90 px-4 md:px-6 py-2.5 transition-colors">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        {/* Left: Clean workspace anchor with icon, title, and subtle category pill */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-200/70 flex items-center justify-center text-emerald-700 shrink-0 shadow-2xs">
            <Icon className="w-4 h-4" />
          </div>

          <div className="flex items-center gap-2 min-w-0 flex-wrap">
            <span className="font-bold text-slate-900 text-sm md:text-base font-geist tracking-tight truncate">
              {meta.label}
            </span>

            {currentSubTab && (
              <>
                <span className="text-slate-300 text-xs">/</span>
                <span className="text-xs font-semibold text-slate-600 capitalize bg-slate-100 px-2 py-0.5 rounded-md">
                  {currentSubTab}
                </span>
              </>
            )}

            <span className="hidden md:inline-flex items-center text-[10px] font-semibold text-slate-600 bg-slate-100/90 px-2 py-0.5 rounded-full border border-slate-200">
              {meta.category}
            </span>
          </div>
        </div>

        {/* Right / Side: Quick actions, Universal search & AI */}
        <div className="flex items-center gap-2 flex-wrap justify-start sm:justify-end">
          {/* Quick Universal Search Input with high contrast */}
          <div className="relative hidden md:block">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && searchQuery.trim()) {
                  onOpenAI(`Search workspace records and statutory rules for: "${searchQuery}"`);
                  setSearchQuery('');
                }
              }}
              placeholder="Search records, rules... (↵)"
              className="pl-8 pr-3 py-1.5 bg-slate-100/80 hover:bg-slate-100 focus:bg-white border border-slate-200 focus:border-slate-300 rounded-lg text-xs w-48 sm:w-52 focus:w-60 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 transition-all font-medium text-slate-900 placeholder:text-slate-500"
            />
          </div>

          {/* Quick Ask AI button */}
          <button
            type="button"
            onClick={() => onOpenAI()}
            className="px-3 py-1.5 bg-slate-900 hover:bg-black text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition-all active:scale-95"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Ask AI</span>
          </button>

          {/* Notifications bell */}
          {onOpenNotifications && (
            <button
              type="button"
              onClick={onOpenNotifications}
              className="p-1.5 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200/80 border border-slate-200 rounded-lg cursor-pointer relative transition-colors"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 absolute top-1 right-1" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
