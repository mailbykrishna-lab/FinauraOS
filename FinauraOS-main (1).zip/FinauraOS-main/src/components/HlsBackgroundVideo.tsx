import React, { useEffect, useRef, useState } from 'react';
import Hls from 'hls.js';

interface HlsBackgroundVideoProps {
  src: string;
  fallbackMp4?: string;
  className?: string;
  poster?: string;
}

export const HlsBackgroundVideo: React.FC<HlsBackgroundVideoProps> = ({
  src,
  fallbackMp4 = '/videos/overview_bg.mp4',
  className = 'w-full h-full object-cover',
  poster,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    let hls: Hls | null = null;
    let isCleanedUp = false;

    // DOM-level attributes must be set explicitly for strict browser autoplay policies
    video.muted = true;
    video.defaultMuted = true;
    video.playsInline = true;
    video.setAttribute('muted', '');
    video.setAttribute('playsinline', '');

    const tryPlay = () => {
      if (!video || isCleanedUp) return;
      video.muted = true;
      const promise = video.play();
      if (promise !== undefined) {
        promise
          .then(() => {
            if (!isCleanedUp) setIsPlaying(true);
          })
          .catch(() => {
            // If the browser restricted autoplay, play on the first user interaction
            const unlockPlay = () => {
              if (video && !isCleanedUp) {
                video.muted = true;
                video.play().then(() => setIsPlaying(true)).catch(() => {});
              }
              window.removeEventListener('click', unlockPlay);
              window.removeEventListener('touchstart', unlockPlay);
              window.removeEventListener('scroll', unlockPlay);
              window.removeEventListener('keydown', unlockPlay);
            };

            window.addEventListener('click', unlockPlay, { once: true });
            window.addEventListener('touchstart', unlockPlay, { once: true });
            window.addEventListener('scroll', unlockPlay, { once: true });
            window.addEventListener('keydown', unlockPlay, { once: true });
          });
      }
    };

    // Ensure seamless looping across all rendering engines
    const handleEnded = () => {
      if (video && !isCleanedUp) {
        video.currentTime = 0;
        tryPlay();
      }
    };

    const handlePlaying = () => {
      if (!isCleanedUp) setIsPlaying(true);
    };

    const handlePause = () => {
      // If paused unexpectedly, resume play
      if (!isCleanedUp && !video.ended) {
        tryPlay();
      }
    };

    video.addEventListener('ended', handleEnded);
    video.addEventListener('playing', handlePlaying);
    video.addEventListener('pause', handlePause);

    // Primary: High-speed local MP4 rendition for instant, zero-lag playback without HLS chunk stalling
    if (fallbackMp4) {
      video.src = fallbackMp4;
      video.load();
      tryPlay();
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      // Native HLS for Safari / iOS
      video.src = src;
      video.load();
      tryPlay();
    } else if (Hls.isSupported()) {
      // HLS.js for Chromium / Firefox
      hls = new Hls({
        enableWorker: true,
        lowLatencyMode: false,
        backBufferLength: 30,
        autoStartLoad: true,
      });

      hls.loadSource(src);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        tryPlay();
      });

      hls.on(Hls.Events.ERROR, (_event, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              hls?.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              hls?.recoverMediaError();
              break;
            default:
              if (fallbackMp4 && video) {
                video.src = fallbackMp4;
                video.load();
                tryPlay();
              }
              break;
          }
        }
      });
    }

    // IntersectionObserver to resume play whenever the element scrolls into viewport
    let observer: IntersectionObserver | null = null;
    if ('IntersectionObserver' in window) {
      observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting && video.paused) {
              tryPlay();
            }
          });
        },
        { threshold: 0.1 }
      );
      observer.observe(video);
    }

    return () => {
      isCleanedUp = true;
      if (observer) {
        observer.disconnect();
      }
      video.removeEventListener('ended', handleEnded);
      video.removeEventListener('playing', handlePlaying);
      video.removeEventListener('pause', handlePause);
      if (hls) {
        hls.destroy();
      }
    };
  }, [src, fallbackMp4]);

  return (
    <div className="relative w-full h-full overflow-hidden">
      <video
        ref={videoRef}
        autoPlay
        loop
        muted
        playsInline
        preload="auto"
        poster={poster}
        aria-hidden="true"
        tabIndex={-1}
        className={className}
        style={{
          transform: 'translateZ(0)',
          willChange: 'transform',
        }}
      />
    </div>
  );
};
