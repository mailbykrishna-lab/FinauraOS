import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, UserCheck, ArrowRight, ShieldCheck } from 'lucide-react';

interface ExplainWhyCardProps {
  title?: string;
  whatIsThis: string;
  whyAmISeeingThis: string;
  whatDoINeedToDo: string;
  whatHappensAfter: string;
  doINeedMyCA?: string;
  defaultExpanded?: boolean;
  onAskCA?: () => void;
  compact?: boolean;
}

export const ExplainWhyCard: React.FC<ExplainWhyCardProps> = ({
  title = 'Why am I seeing this?',
  whatIsThis,
  whyAmISeeingThis,
  whatDoINeedToDo,
  whatHappensAfter,
  doINeedMyCA = 'Optional. You can complete this yourself, or delegate to your CA with 1 tap.',
  defaultExpanded = false,
  onAskCA,
  compact = false,
}) => {
  const [isOpen, setIsOpen] = useState(defaultExpanded);

  if (compact && !isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-2.5 py-1 rounded-full border border-slate-200 transition-colors"
      >
        <HelpCircle className="w-3.5 h-3.5 text-slate-500" />
        <span>Why am I seeing this?</span>
      </button>
    );
  }

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm transition-all">
      <div
        className="flex items-center justify-between cursor-pointer select-none"
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-700">
            <HelpCircle className="w-4 h-4 text-slate-500" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-slate-900">{title}</h4>
            {!isOpen && (
              <p className="text-xs text-slate-500 line-clamp-1">{whyAmISeeingThis}</p>
            )}
          </div>
        </div>
        <button
          type="button"
          aria-label={isOpen ? "Collapse explanation" : "Expand explanation"}
          className="text-slate-400 hover:text-slate-700 p-1"
        >
          {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {isOpen && (
        <div className="mt-3.5 pt-3 border-t border-slate-100 space-y-3 text-xs">
          <div>
            <span className="font-semibold text-slate-900 block mb-0.5">1. What is this?</span>
            <p className="text-slate-600 leading-relaxed">{whatIsThis}</p>
          </div>

          <div>
            <span className="font-semibold text-slate-900 block mb-0.5">2. Why am I seeing it?</span>
            <p className="text-slate-600 leading-relaxed">{whyAmISeeingThis}</p>
          </div>

          <div>
            <span className="font-semibold text-slate-900 block mb-0.5">3. What do I need to do?</span>
            <p className="text-slate-800 font-medium leading-relaxed">{whatDoINeedToDo}</p>
          </div>

          <div>
            <span className="font-semibold text-slate-900 block mb-0.5">4. What happens after I do it?</span>
            <p className="text-slate-600 leading-relaxed">{whatHappensAfter}</p>
          </div>

          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-slate-700 shrink-0" />
              <div>
                <span className="font-semibold text-slate-900 block">Do I need my CA?</span>
                <span className="text-slate-600 text-[11px]">{doINeedMyCA}</span>
              </div>
            </div>
            {onAskCA && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onAskCA();
                }}
                className="shrink-0 flex items-center gap-1 bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 font-medium px-2.5 py-1 rounded-md text-[11px] transition-colors"
              >
                <UserCheck className="w-3.5 h-3.5 text-slate-600" />
                <span>Ask CA</span>
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
