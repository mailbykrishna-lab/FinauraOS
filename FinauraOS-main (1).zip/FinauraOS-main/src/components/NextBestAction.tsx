import React, { useState } from 'react';
import { ArrowRight, Sparkles, ChevronRight, HelpCircle, ShieldCheck } from 'lucide-react';

interface NextBestActionProps {
  category?: string;
  title: string;
  subtitle: string;
  urgency?: 'urgent' | 'important' | 'upcoming' | 'normal';
  whyAmISeeingThis: string;
  whatShouldIDo: string;
  whatHappensNext: string;
  actionLabel: string;
  onAction: () => void;
  secondaryActionLabel?: string;
  onSecondaryAction?: () => void;
  onAskCA?: () => void;
  compact?: boolean;
  featureBadge?: string;
}

export const NextBestAction: React.FC<NextBestActionProps> = ({
  category = 'Primary Focus Today',
  title,
  subtitle,
  urgency = 'important',
  whyAmISeeingThis,
  whatShouldIDo,
  whatHappensNext,
  actionLabel,
  onAction,
  secondaryActionLabel,
  onSecondaryAction,
  onAskCA,
  compact = false,
  featureBadge,
}) => {
  const [showExplanation, setShowExplanation] = useState(false);

  const urgencyStyles = {
    urgent: {
      badge: 'bg-red-50 text-red-700 border border-red-200',
      border: 'border-l-4 border-l-red-500',
      icon: 'text-red-500',
    },
    important: {
      badge: 'bg-emerald-50 text-emerald-800 border border-emerald-200',
      border: 'border-l-4 border-l-emerald-600',
      icon: 'text-emerald-600',
    },
    upcoming: {
      badge: 'bg-slate-100 text-slate-600 border border-slate-200',
      border: 'border-l-4 border-l-slate-400',
      icon: 'text-slate-500',
    },
    normal: {
      badge: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
      border: 'border-l-4 border-l-emerald-600',
      icon: 'text-emerald-600',
    },
  }[urgency];

  return (
    <div className={`bg-white rounded-2xl shadow-xs border border-slate-200/90 ${urgencyStyles.border} p-5 md:p-6 relative overflow-hidden group transition-all duration-150`}>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
        <div className="flex-1 space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="flex items-center gap-1.5 text-xs font-bold text-slate-800 font-geist">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              {category}
            </span>
            <span className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full ${urgencyStyles.badge}`}>
              {urgency}
            </span>
            {featureBadge && (
              <span className="text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-200 px-2 py-0.5 rounded-full">
                {featureBadge}
              </span>
            )}
          </div>

          <h2 className="text-base md:text-lg font-bold text-slate-900 tracking-tight leading-snug">{title}</h2>
          <p className="text-xs md:text-sm text-slate-600 leading-relaxed max-w-3xl">{subtitle}</p>
        </div>

        <div className="flex items-center flex-wrap gap-2.5 pt-1 md:pt-0 shrink-0">
          <button
            type="button"
            onClick={() => setShowExplanation(!showExplanation)}
            className="flex items-center gap-1.5 text-xs text-slate-700 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 px-3 py-2 rounded-xl font-semibold transition-all border border-slate-200 cursor-pointer shadow-2xs"
          >
            <HelpCircle className="w-3.5 h-3.5 text-slate-500" />
            <span>Why?</span>
          </button>

          {onAskCA && (
            <button
              type="button"
              onClick={onAskCA}
              className="flex items-center gap-1.5 text-xs text-slate-700 hover:bg-slate-50 bg-white border border-slate-200 px-3 py-2 rounded-xl font-semibold transition-all cursor-pointer shadow-2xs"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-slate-600" />
              <span>Ask CA</span>
            </button>
          )}

          {secondaryActionLabel && onSecondaryAction && (
            <button
              type="button"
              onClick={onSecondaryAction}
              className="flex items-center gap-1.5 bg-white border border-slate-300 text-slate-800 hover:bg-slate-50 text-xs font-semibold px-3.5 py-2 rounded-xl shadow-2xs transition-all active:scale-[0.98] cursor-pointer"
            >
              <span>{secondaryActionLabel}</span>
            </button>
          )}

          <button
            type="button"
            onClick={onAction}
            className="flex items-center gap-2 bg-slate-900 text-white hover:bg-slate-800 text-xs font-bold px-4 py-2 rounded-xl shadow-sm transition-all active:scale-[0.98] cursor-pointer ring-2 ring-slate-900/10"
          >
            <span>{actionLabel}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {showExplanation && (
        <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-1 md:grid-cols-3 gap-3.5 text-xs bg-slate-50/80 p-4 rounded-xl border border-slate-200/80 animate-in fade-in">
          <div>
            <span className="font-bold text-slate-900 block mb-1">Why am I seeing this?</span>
            <p className="text-slate-600 leading-relaxed">{whyAmISeeingThis}</p>
          </div>
          <div>
            <span className="font-bold text-slate-900 block mb-1">What should I do?</span>
            <p className="text-slate-800 font-semibold leading-relaxed">{whatShouldIDo}</p>
          </div>
          <div>
            <span className="font-bold text-slate-900 block mb-1">What happens next?</span>
            <p className="text-slate-600 leading-relaxed">{whatHappensNext}</p>
          </div>
        </div>
      )}
    </div>
  );
};
