import React, { useState, useEffect, useRef } from 'react';
import { useTypewriter } from '../hooks/useTypewriter';

interface MainframeHeroProps {
  onBackToFinaura?: () => void;
  onEnterApp?: () => void;
}

export const MainframeHeroView: React.FC<MainframeHeroProps> = ({
  onBackToFinaura,
  onEnterApp,
}) => {
  // Mobile navigation overlay state
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Pill buttons appearance animation state (shows 400ms after load)
  const [pillsVisible, setPillsVisible] = useState(false);

  // Copy email feedback
  const [copied, setCopied] = useState(false);

  // Background video refs and state for mouse-scrubbing
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const prevXRef = useRef<number | null>(null);
  const targetTimeRef = useRef<number>(0);
  const isSeekingRef = useRef<boolean>(false);

  // Typewriter hook for hero message
  const typewriterText = 'Glad you stopped in. Good taste tends to find us. Now, what are we building?';
  const { displayed, done } = useTypewriter({
    text: typewriterText,
    speed: 38,
    startDelay: 600,
  });

  // Action pill buttons become visible 400ms after page load
  useEffect(() => {
    const timer = setTimeout(() => {
      setPillsVisible(true);
    }, 400);
    return () => clearTimeout(timer);
  }, []);

  // Video mouse-scrub control
  useEffect(() => {
    const SENSITIVITY = 0.8;

    const handleMouseMove = (e: MouseEvent) => {
      if (prevXRef.current === null) {
        prevXRef.current = e.clientX;
        return;
      }
      const delta = e.clientX - prevXRef.current;
      prevXRef.current = e.clientX;

      const video = videoRef.current;
      if (!video || !video.duration || Number.isNaN(video.duration)) return;

      const timeOffset = (delta / window.innerWidth) * SENSITIVITY * video.duration;
      const newTarget = Math.max(0, Math.min(video.duration, targetTimeRef.current + timeOffset));
      targetTimeRef.current = newTarget;

      if (!isSeekingRef.current) {
        isSeekingRef.current = true;
        video.currentTime = newTarget;
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  const handleSeeked = () => {
    const video = videoRef.current;
    if (!video || !video.duration) {
      isSeekingRef.current = false;
      return;
    }
    if (Math.abs(video.currentTime - targetTimeRef.current) > 0.02) {
      video.currentTime = targetTimeRef.current;
    } else {
      isSeekingRef.current = false;
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      targetTimeRef.current = videoRef.current.currentTime || 0;
    }
  };

  const handleCopyEmail = async () => {
    try {
      await navigator.clipboard.writeText('hello@mainframe.co');
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div
      id="mainframe-hero-page"
      className="relative w-full h-screen overflow-hidden select-none bg-black text-black"
      style={{ fontFamily: 'var(--font-body)' }}
    >
      {/* Background Video with Mouse-Scrubbing */}
      <video
        ref={videoRef}
        id="mainframe-bg-video"
        className="fixed inset-0 w-full h-full object-cover z-0 pointer-events-none"
        style={{
          objectPosition: '70% center',
        }}
        src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260530_042513_df96a13b-6155-4f6e-8b93-c9dee66fba08.mp4"
        muted
        playsInline
        preload="auto"
        onSeeked={handleSeeked}
        onLoadedMetadata={handleLoadedMetadata}
      />

      {/* Return to Finaura Floating Pill */}
      {onBackToFinaura && (
        <button
          type="button"
          onClick={onBackToFinaura}
          className="fixed bottom-5 right-5 z-30 inline-flex items-center gap-2 px-4 py-2 bg-white/90 hover:bg-white text-slate-900 rounded-full text-xs font-semibold shadow-lg backdrop-blur-md border border-slate-200 hover:scale-105 transition-all"
        >
          <span>&larr; Back to Finaura OS</span>
        </button>
      )}

      {/* Navbar (Fixed, z-index: 10) */}
      <header
        id="mainframe-navbar"
        className="fixed top-0 left-0 right-0 z-10 w-full px-5 sm:px-8 py-4 sm:py-5 flex justify-between items-center"
      >
        <div
          id="mainframe-logo"
          className="flex items-center gap-3 cursor-pointer"
          onClick={onEnterApp}
        >
          <span
            className="text-[21px] sm:text-[26px] tracking-tight text-black font-medium leading-none"
            style={{ fontFamily: 'var(--font-heading)' }}
          >
            Mainframe&reg;
          </span>
          <span
            className="text-[25px] sm:text-[30px] text-black select-none leading-none"
            style={{ letterSpacing: '-0.02em' }}
            aria-hidden="true"
          >
            &#10035;&#xFE0E;
          </span>
        </div>

        {/* Desktop Nav Links */}
        <nav
          id="mainframe-desktop-nav"
          className="hidden md:flex items-center text-[23px] text-black"
        >
          <button
            type="button"
            onClick={onEnterApp}
            className="hover:opacity-60 transition-opacity bg-transparent border-0 p-0 text-[23px] text-black cursor-pointer"
          >
            Labs
          </button>
          <span className="select-none text-[23px] text-black">,&nbsp;</span>
          <button
            type="button"
            onClick={onEnterApp}
            className="hover:opacity-60 transition-opacity bg-transparent border-0 p-0 text-[23px] text-black cursor-pointer"
          >
            Studio
          </button>
          <span className="select-none text-[23px] text-black">,&nbsp;</span>
          <button
            type="button"
            onClick={onEnterApp}
            className="hover:opacity-60 transition-opacity bg-transparent border-0 p-0 text-[23px] text-black cursor-pointer"
          >
            Openings
          </button>
          <span className="select-none text-[23px] text-black">,&nbsp;</span>
          <button
            type="button"
            onClick={onEnterApp}
            className="hover:opacity-60 transition-opacity bg-transparent border-0 p-0 text-[23px] text-black cursor-pointer"
          >
            Shop
          </button>
        </nav>

        {/* Desktop CTA */}
        <div className="hidden md:block">
          <button
            type="button"
            onClick={handleCopyEmail}
            className="text-[23px] text-black underline underline-offset-2 hover:opacity-60 transition-opacity bg-transparent border-0 p-0 cursor-pointer"
          >
            Get in touch
          </button>
        </div>

        {/* Mobile Hamburger */}
        <button
          id="mainframe-mobile-hamburger"
          type="button"
          aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden flex flex-col justify-center items-center gap-[5px] w-8 h-8 focus:outline-none z-20 cursor-pointer"
        >
          <span
            className={`w-6 h-[2px] bg-black transition-all duration-300 transform origin-center ${
              mobileMenuOpen ? 'rotate-45 translate-y-[7px]' : 'rotate-0 translate-y-0'
            }`}
          />
          <span
            className={`w-6 h-[2px] bg-black transition-all duration-300 ${
              mobileMenuOpen ? 'opacity-0' : 'opacity-100'
            }`}
          />
          <span
            className={`w-6 h-[2px] bg-black transition-all duration-300 transform origin-center ${
              mobileMenuOpen ? '-rotate-45 -translate-y-[7px]' : 'rotate-0 translate-y-0'
            }`}
          />
        </button>
      </header>

      {/* Mobile Overlay */}
      <div
        id="mainframe-mobile-overlay"
        className={`fixed inset-0 z-[9] bg-white/95 backdrop-blur-sm flex flex-col justify-center px-8 gap-8 transition-opacity duration-300 md:hidden ${
          mobileMenuOpen
            ? 'opacity-100 pointer-events-auto'
            : 'opacity-0 pointer-events-none'
        }`}
      >
        <button
          type="button"
          onClick={() => {
            setMobileMenuOpen(false);
            if (onEnterApp) onEnterApp();
          }}
          className="text-left text-[32px] font-medium text-black hover:opacity-60 transition-opacity bg-transparent border-0 p-0"
        >
          Labs
        </button>
        <button
          type="button"
          onClick={() => {
            setMobileMenuOpen(false);
            if (onEnterApp) onEnterApp();
          }}
          className="text-left text-[32px] font-medium text-black hover:opacity-60 transition-opacity bg-transparent border-0 p-0"
        >
          Studio
        </button>
        <button
          type="button"
          onClick={() => {
            setMobileMenuOpen(false);
            if (onEnterApp) onEnterApp();
          }}
          className="text-left text-[32px] font-medium text-black hover:opacity-60 transition-opacity bg-transparent border-0 p-0"
        >
          Openings
        </button>
        <button
          type="button"
          onClick={() => {
            setMobileMenuOpen(false);
            if (onEnterApp) onEnterApp();
          }}
          className="text-left text-[32px] font-medium text-black hover:opacity-60 transition-opacity bg-transparent border-0 p-0"
        >
          Shop
        </button>
        <button
          type="button"
          onClick={() => {
            setMobileMenuOpen(false);
            handleCopyEmail();
          }}
          className="text-left text-[32px] font-medium text-black underline underline-offset-4 hover:opacity-60 transition-opacity bg-transparent border-0 p-0 pt-4"
        >
          Get in touch
        </button>
      </div>

      {/* Hero Content */}
      <main
        id="mainframe-hero-content"
        className="relative z-1 h-screen flex flex-col justify-end pb-12 md:justify-center md:pb-0 px-5 sm:px-8 md:px-10 overflow-hidden"
      >
        <div className="max-w-xl relative z-10">
          <div
            id="mainframe-aria-intro"
            className="pointer-events-none select-none mb-5 sm:mb-6 text-black"
            style={{
              fontSize: 'clamp(18px, 4vw, 26px)',
              lineHeight: '1.3',
              fontWeight: 400,
              filter: 'blur(4px)',
            }}
          >
            Hey there, meet A.R.I.A,
            <br />
            Mainframe&apos;s Adaptive Response Interface Agent
          </div>

          <p
            id="mainframe-typewriter-text"
            className="text-black mb-5 sm:mb-6"
            style={{
              fontSize: 'clamp(18px, 4vw, 26px)',
              lineHeight: '1.35',
              fontWeight: 400,
              minHeight: '54px',
            }}
          >
            {displayed}
            {!done && (
              <span
                className="inline-block w-[2px] h-[1.1em] bg-black align-middle ml-[2px] animate-blink"
                aria-hidden="true"
              />
            )}
          </p>

          <div
            id="mainframe-action-pills"
            className="flex flex-wrap gap-y-1"
            style={{
              opacity: pillsVisible ? 1 : 0,
              transform: pillsVisible ? 'translateY(0)' : 'translateY(8px)',
              transition: 'opacity 0.4s ease, transform 0.4s ease',
            }}
          >
            <button
              type="button"
              onClick={onEnterApp}
              className="inline-flex items-center justify-center bg-white text-black border border-black/10 rounded-full text-[13px] sm:text-[15px] px-4 sm:px-5 py-[0.3em] mx-[0.2em] mb-[0.4em] whitespace-nowrap hover:bg-black hover:text-white transition-colors duration-200 cursor-pointer"
            >
              Pitch us an idea
            </button>

            <button
              type="button"
              onClick={onEnterApp}
              className="inline-flex items-center justify-center bg-white text-black border border-black/10 rounded-full text-[13px] sm:text-[15px] px-4 sm:px-5 py-[0.3em] mx-[0.2em] mb-[0.4em] whitespace-nowrap hover:bg-black hover:text-white transition-colors duration-200 cursor-pointer"
            >
              Come work here
            </button>

            <button
              type="button"
              onClick={onEnterApp}
              className="inline-flex items-center justify-center bg-white text-black border border-black/10 rounded-full text-[13px] sm:text-[15px] px-4 sm:px-5 py-[0.3em] mx-[0.2em] mb-[0.4em] whitespace-nowrap hover:bg-black hover:text-white transition-colors duration-200 cursor-pointer"
            >
              Send a brief hello
            </button>

            <button
              type="button"
              onClick={onEnterApp}
              className="inline-flex items-center justify-center bg-white text-black border border-black/10 rounded-full text-[13px] sm:text-[15px] px-4 sm:px-5 py-[0.3em] mx-[0.2em] mb-[0.4em] whitespace-nowrap hover:bg-black hover:text-white transition-colors duration-200 cursor-pointer"
            >
              See how we operate
            </button>

            <button
              type="button"
              onClick={handleCopyEmail}
              title="Click to copy email"
              className="inline-flex items-center justify-center text-white bg-transparent border border-white rounded-full text-[13px] sm:text-[15px] px-4 sm:px-5 py-[0.3em] mx-[0.2em] mb-[0.4em] whitespace-nowrap gap-2 sm:gap-3 hover:bg-white hover:text-black transition-colors duration-200 cursor-pointer"
            >
              <span>
                {copied ? 'Copied to clipboard!' : (
                  <>
                    Reach us: <span className="underline underline-offset-1">hello@mainframe.co</span>
                  </>
                )}
              </span>
              <svg
                className="w-3 h-3 shrink-0"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
              </svg>
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};
