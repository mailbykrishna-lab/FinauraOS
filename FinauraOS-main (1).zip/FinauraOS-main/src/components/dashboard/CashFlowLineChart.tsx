import React, { useState } from 'react';
import { TrendingUp, Calendar } from 'lucide-react';

interface DataPoint {
  label: string;
  value: number;
  formatted: string;
}

interface CashFlowLineChartProps {
  totalRevenue: number;
  totalExpenses: number;
  themeMode?: 'cyber_mint' | 'classic_light';
}

export const CashFlowLineChart: React.FC<CashFlowLineChartProps> = ({
  totalRevenue,
  totalExpenses,
  themeMode = 'cyber_mint',
}) => {
  const [timeframe, setTimeframe] = useState<'week' | 'month' | 'quarter'>('month');
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const isLight = themeMode === 'classic_light';

  // Generate dynamic points based on revenue or realistic financial trajectory
  const baseValue = Math.max(totalRevenue > 0 ? totalRevenue / 4 : 45000, 30000);

  const monthPoints: DataPoint[] = [
    { label: 'Nov', value: Math.round(baseValue * 0.65), formatted: `₹${Math.round(baseValue * 0.65).toLocaleString('en-IN')}` },
    { label: 'Dec', value: Math.round(baseValue * 0.88), formatted: `₹${Math.round(baseValue * 0.88).toLocaleString('en-IN')}` },
    { label: 'Jan', value: Math.round(baseValue * 0.76), formatted: `₹${Math.round(baseValue * 0.76).toLocaleString('en-IN')}` },
    { label: 'Feb', value: Math.round(baseValue * 1.05), formatted: `₹${Math.round(baseValue * 1.05).toLocaleString('en-IN')}` },
    { label: 'Mar', value: Math.round(baseValue * 1.22), formatted: `₹${Math.round(baseValue * 1.22).toLocaleString('en-IN')}` },
    { label: 'Apr', value: Math.round(baseValue * 1.45), formatted: `₹${Math.round(baseValue * 1.45).toLocaleString('en-IN')}` },
  ];

  const weekPoints: DataPoint[] = [
    { label: 'Mon', value: Math.round(baseValue * 0.22), formatted: `₹${Math.round(baseValue * 0.22).toLocaleString('en-IN')}` },
    { label: 'Tue', value: Math.round(baseValue * 0.38), formatted: `₹${Math.round(baseValue * 0.38).toLocaleString('en-IN')}` },
    { label: 'Wed', value: Math.round(baseValue * 0.45), formatted: `₹${Math.round(baseValue * 0.45).toLocaleString('en-IN')}` },
    { label: 'Thu', value: Math.round(baseValue * 0.41), formatted: `₹${Math.round(baseValue * 0.41).toLocaleString('en-IN')}` },
    { label: 'Fri', value: Math.round(baseValue * 0.62), formatted: `₹${Math.round(baseValue * 0.62).toLocaleString('en-IN')}` },
    { label: 'Sat', value: Math.round(baseValue * 0.75), formatted: `₹${Math.round(baseValue * 0.75).toLocaleString('en-IN')}` },
  ];

  const quarterPoints: DataPoint[] = [
    { label: 'Q1 25', value: Math.round(baseValue * 2.1), formatted: `₹${Math.round(baseValue * 2.1).toLocaleString('en-IN')}` },
    { label: 'Q2 25', value: Math.round(baseValue * 2.6), formatted: `₹${Math.round(baseValue * 2.6).toLocaleString('en-IN')}` },
    { label: 'Q3 25', value: Math.round(baseValue * 3.1), formatted: `₹${Math.round(baseValue * 3.1).toLocaleString('en-IN')}` },
    { label: 'Q4 25', value: Math.round(baseValue * 3.7), formatted: `₹${Math.round(baseValue * 3.7).toLocaleString('en-IN')}` },
    { label: 'Q1 26', value: Math.round(baseValue * 4.4), formatted: `₹${Math.round(baseValue * 4.4).toLocaleString('en-IN')}` },
    { label: 'Q2 26', value: Math.round(baseValue * 5.2), formatted: `₹${Math.round(baseValue * 5.2).toLocaleString('en-IN')}` },
  ];

  const currentPoints = timeframe === 'week' ? weekPoints : timeframe === 'quarter' ? quarterPoints : monthPoints;

  // Chart dimensions
  const width = 540;
  const height = 180;
  const paddingX = 35;
  const paddingY = 25;

  const values = currentPoints.map((p) => p.value);
  const minVal = Math.min(...values) * 0.75;
  const maxVal = Math.max(...values) * 1.15;

  // Map data to coordinates
  const coords = currentPoints.map((pt, i) => {
    const x = paddingX + (i / (currentPoints.length - 1)) * (width - 2 * paddingX);
    const y = height - paddingY - ((pt.value - minVal) / (maxVal - minVal || 1)) * (height - 2 * paddingY);
    return { x, y, ...pt };
  });

  // Generate smooth cubic Bezier path
  const createSmoothPath = (points: { x: number; y: number }[]) => {
    if (points.length === 0) return '';
    if (points.length === 1) return `M ${points[0].x} ${points[0].y}`;

    let path = `M ${points[0].x} ${points[0].y}`;
    for (let i = 0; i < points.length - 1; i++) {
      const p0 = points[i === 0 ? 0 : i - 1];
      const p1 = points[i];
      const p2 = points[i + 1];
      const p3 = points[i + 2] || p2;

      const cp1x = p1.x + (p2.x - p0.x) / 6;
      const cp1y = p1.y + (p2.y - p0.y) / 6;
      const cp2x = p2.x - (p3.x - p1.x) / 6;
      const cp2y = p2.y - (p3.y - p1.y) / 6;

      path += ` C ${cp1x.toFixed(1)} ${cp1y.toFixed(1)}, ${cp2x.toFixed(1)} ${cp2y.toFixed(1)}, ${p2.x.toFixed(1)} ${p2.y.toFixed(1)}`;
    }
    return path;
  };

  const linePath = createSmoothPath(coords);
  const areaPath = coords.length > 0
    ? `${linePath} L ${coords[coords.length - 1].x} ${height - paddingY} L ${coords[0].x} ${height - paddingY} Z`
    : '';

  return (
    <div className={`rounded-2xl p-5 shadow-xl relative overflow-hidden flex flex-col justify-between h-full transition-colors ${
      isLight
        ? 'bg-white border border-slate-200 text-slate-900 shadow-sm'
        : 'bg-[#121c2e] border border-[#1e2f47] text-white shadow-xl'
    }`}>
      {/* Header & Time Controls */}
      <div className="flex items-center justify-between gap-3 mb-2">
        <div>
          <div className="flex items-center gap-2">
            <h3 className={`text-sm font-bold font-geist tracking-tight ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>
              Cash Dynamics & Inflows
            </h3>
            <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${
              isLight
                ? 'text-emerald-700 bg-emerald-50 border-emerald-200'
                : 'text-emerald-400 bg-emerald-950/80 border-emerald-800/60'
            }`}>
              Live Trajectory
            </span>
          </div>
          <p className={`text-[11px] mt-0.5 ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
            Dynamic liquidity projection with verified ledger reconciliations
          </p>
        </div>

        {/* Timeframe Switcher */}
        <div className={`inline-flex items-center p-0.5 rounded-lg border text-[11px] font-semibold ${
          isLight ? 'bg-slate-100 border-slate-200' : 'bg-[#0a111e] border-[#1e2f47]'
        }`}>
          {(['week', 'month', 'quarter'] as const).map((tf) => (
            <button
              key={tf}
              type="button"
              onClick={() => setTimeframe(tf)}
              className={`px-2.5 py-1 rounded-md transition-all cursor-pointer capitalize ${
                timeframe === tf
                  ? isLight
                    ? 'bg-slate-900 text-white font-bold shadow-xs'
                    : 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                  : isLight
                  ? 'text-slate-600 hover:text-slate-900'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* SVG Line Chart */}
      <div className="relative w-full aspect-[2.8/1] min-h-[160px] my-1">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-full overflow-visible"
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id="mintCurveGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#10b981" stopOpacity={isLight ? 0.25 : 0.32} />
              <stop offset="70%" stopColor="#10b981" stopOpacity={isLight ? 0.05 : 0.06} />
              <stop offset="100%" stopColor="#10b981" stopOpacity="0.00" />
            </linearGradient>
            <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#10b981" floodOpacity={isLight ? 0.3 : 0.45} />
            </filter>
          </defs>

          {/* Subtle Grid Lines */}
          {[0.25, 0.5, 0.75].map((pct, idx) => {
            const y = height - paddingY - pct * (height - 2 * paddingY);
            return (
              <line
                key={idx}
                x1={paddingX}
                y1={y}
                x2={width - paddingX}
                y2={y}
                stroke={isLight ? '#e2e8f0' : '#1e2f47'}
                strokeDasharray="3 3"
                strokeWidth="1"
              />
            );
          })}

          {/* Area Fill */}
          <path d={areaPath} fill="url(#mintCurveGradient)" />

          {/* Spline Line */}
          <path
            d={linePath}
            fill="none"
            stroke="#10b981"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            filter="url(#neonGlow)"
          />

          {/* Interactive Nodes */}
          {coords.map((c, idx) => {
            const isHovered = hoveredIndex === idx;
            return (
              <g
                key={idx}
                onMouseEnter={() => setHoveredIndex(idx)}
                onMouseLeave={() => setHoveredIndex(null)}
                className="cursor-pointer"
              >
                {/* Outer Glow Halo */}
                <circle
                  cx={c.x}
                  cy={c.y}
                  r={isHovered ? 8 : 4.5}
                  fill="#00e599"
                  opacity={isHovered ? 0.35 : 0.15}
                  className="transition-all duration-150"
                />
                {/* Core Dot */}
                <circle
                  cx={c.x}
                  cy={c.y}
                  r={isHovered ? 5.5 : 3.5}
                  fill={isLight ? '#ffffff' : '#ffffff'}
                  stroke="#10b981"
                  strokeWidth={isHovered ? 2.5 : 2}
                  className="transition-all duration-150"
                />
              </g>
            );
          })}
        </svg>

        {/* Hover Tooltip Overlay */}
        {hoveredIndex !== null && coords[hoveredIndex] && (
          <div
            className={`absolute z-10 pointer-events-none transform -translate-x-1/2 -translate-y-full mb-2 px-2.5 py-1.5 rounded-lg border shadow-xl text-center text-xs whitespace-nowrap ${
              isLight
                ? 'bg-slate-900 text-white border-slate-700'
                : 'bg-[#09101d] text-white border-emerald-500/50'
            }`}
            style={{
              left: `${(coords[hoveredIndex].x / width) * 100}%`,
              top: `${(coords[hoveredIndex].y / height) * 100}%`,
            }}
          >
            <div className="text-[10px] text-slate-400">{coords[hoveredIndex].label}</div>
            <div className="font-bold text-emerald-400">{coords[hoveredIndex].formatted}</div>
          </div>
        )}
      </div>

      {/* X-Axis Labels */}
      <div className={`flex justify-between px-3 text-[11px] font-medium border-t pt-2 ${
        isLight ? 'text-slate-600 border-slate-200' : 'text-slate-400 border-[#1a283e]'
      }`}>
        {coords.map((c, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => setHoveredIndex(idx)}
            className={`transition-colors cursor-pointer ${
              hoveredIndex === idx
                ? isLight ? 'text-emerald-700 font-bold' : 'text-emerald-400 font-bold'
                : isLight ? 'hover:text-slate-900' : 'hover:text-slate-200'
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>
    </div>
  );
};
