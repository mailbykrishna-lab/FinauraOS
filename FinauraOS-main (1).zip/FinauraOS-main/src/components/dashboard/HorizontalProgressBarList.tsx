import React from 'react';

interface OutflowItem {
  name: string;
  pct: number;
  amount: string;
}

interface HorizontalProgressBarListProps {
  themeMode?: 'cyber_mint' | 'classic_light';
}

export const HorizontalProgressBarList: React.FC<HorizontalProgressBarListProps> = ({
  themeMode = 'cyber_mint',
}) => {
  const isLight = themeMode === 'classic_light';

  const items: OutflowItem[] = [
    { name: 'Software & Cloud', pct: 35, amount: '₹43,500' },
    { name: 'Office Lease & Rent', pct: 24, amount: '₹30,000' },
    { name: 'Contractors & Payroll', pct: 18, amount: '₹22,500' },
    { name: 'Growth & Ads', pct: 13, amount: '₹16,200' },
    { name: 'GST & Statutory', pct: 10, amount: '₹12,400' },
  ];

  return (
    <div className={`rounded-2xl p-5 shadow-xl flex flex-col justify-between h-full transition-colors ${
      isLight
        ? 'bg-white border border-slate-200 text-slate-900 shadow-sm'
        : 'bg-[#121c2e] border border-[#1e2f47] text-white shadow-xl'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <h3 className={`text-sm font-bold font-geist tracking-tight ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>
          Outflow Allocation
        </h3>
        <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
          isLight
            ? 'text-slate-700 bg-slate-100 border-slate-200'
            : 'text-slate-400 bg-[#09101d] border-[#1e2f47]'
        }`}>
          Top Categories
        </span>
      </div>

      {/* Progress Bars Stack */}
      <div className="space-y-3 my-auto py-1">
        {items.map((item, idx) => (
          <div key={idx} className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className={`font-medium text-[11px] truncate max-w-[170px] ${
                isLight ? 'text-slate-800' : 'text-slate-300'
              }`}>
                {item.name}
              </span>
              <div className="flex items-center gap-2 shrink-0">
                <span className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                  {item.amount}
                </span>
                <span className={`font-bold text-[11px] w-7 text-right ${
                  isLight ? 'text-slate-900' : 'text-slate-100'
                }`}>
                  {item.pct}%
                </span>
              </div>
            </div>

            {/* Horizontal Bar */}
            <div className={`w-full h-2 rounded-full overflow-hidden p-0.5 ${
              isLight ? 'bg-slate-100' : 'bg-[#0b1322]'
            }`}>
              <div
                className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-700 shadow-xs"
                style={{ width: `${item.pct}%` }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Footer Summary */}
      <div className={`pt-2 border-t flex items-center justify-between text-[11px] ${
        isLight ? 'border-slate-200 text-slate-600' : 'border-[#1a283e] text-slate-400'
      }`}>
        <span>Total Tracked: <strong className={isLight ? 'text-slate-800' : 'text-slate-200'}>5 Categories</strong></span>
        <span className={`${isLight ? 'text-emerald-700' : 'text-emerald-400'} font-semibold`}>100% Tax Mapped</span>
      </div>
    </div>
  );
};
