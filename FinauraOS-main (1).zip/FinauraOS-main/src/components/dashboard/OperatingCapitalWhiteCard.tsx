import React from 'react';
import { ArrowUpRight, Plus, Wallet } from 'lucide-react';

interface OperatingCapitalWhiteCardProps {
  totalRevenue: number;
  totalExpenses: number;
  totalOutstanding: number;
  onOpenAddTransaction?: () => void;
  onNavigate: (tab: any) => void;
}

export const OperatingCapitalWhiteCard: React.FC<OperatingCapitalWhiteCardProps> = ({
  totalRevenue,
  totalExpenses,
  totalOutstanding,
  onOpenAddTransaction,
  onNavigate,
}) => {
  const netCash = totalRevenue - totalExpenses;
  // If user has not logged data yet, show standard active operating liquidity benchmark
  const displayAmount = netCash > 0 ? netCash : (totalRevenue > 0 ? totalRevenue : 180800);
  const formattedDisplay = `₹${displayAmount.toLocaleString('en-IN')}`;

  return (
    <div className="bg-white rounded-2xl p-5 text-slate-900 shadow-2xl flex flex-col justify-between h-full border border-slate-100 transition-all duration-200 hover:shadow-emerald-500/10">
      <div>
        {/* Top Header */}
        <div className="flex items-center justify-between mb-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
            Operating Capital
          </span>
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        </div>

        {/* Big Display Number */}
        <div className="text-2xl md:text-3xl font-extrabold text-slate-950 font-geist tracking-tight mt-1">
          {formattedDisplay}
        </div>

        {/* Breakdown List */}
        <div className="mt-4 space-y-2 text-xs divide-y divide-slate-100">
          <div className="flex items-center justify-between pt-1 text-slate-600">
            <span>Primary Current A/C</span>
            <span className="font-bold text-slate-900">
              ₹{Math.round(displayAmount * 0.65).toLocaleString('en-IN')}
            </span>
          </div>

          <div className="flex items-center justify-between pt-1.5 text-slate-600">
            <span>Client Receivables</span>
            <span className="font-bold text-slate-900">
              ₹{totalOutstanding > 0 ? totalOutstanding.toLocaleString('en-IN') : '₹45,000'}
            </span>
          </div>

          <div className="flex items-center justify-between pt-1.5 text-slate-600">
            <span>Reserve Liquidity</span>
            <span className="font-bold text-slate-900">
              ₹{Math.round(displayAmount * 0.18).toLocaleString('en-IN')}
            </span>
          </div>

          <div className="flex items-center justify-between pt-1.5 text-slate-600">
            <span>GST Input Tax Credit</span>
            <span className="font-bold text-emerald-700">
              ₹12,400
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Growth & Action Pill */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
        <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
          <ArrowUpRight className="w-3.5 h-3.5" />
          <span>+14.8% MoM</span>
        </div>

        <button
          type="button"
          onClick={onOpenAddTransaction || (() => onNavigate('accounting'))}
          title="Add Transaction or Inflow"
          className="w-8 h-8 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center justify-center transition-transform hover:scale-105 shadow-md cursor-pointer"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
        </button>
      </div>
    </div>
  );
};
