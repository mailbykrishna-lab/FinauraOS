import React from 'react';

interface ExpenseDonutChartProps {
  totalExpenses: number;
  themeMode?: 'cyber_mint' | 'classic_light';
}

export const ExpenseDonutChart: React.FC<ExpenseDonutChartProps> = ({
  totalExpenses,
  themeMode = 'cyber_mint',
}) => {
  const isLight = themeMode === 'classic_light';

  // Expense Breakdown
  const categories = [
    { label: 'Direct Operations', pct: 68, color: '#10b981', amount: totalExpenses > 0 ? totalExpenses * 0.68 : 84200 },
    { label: 'Cloud & Tech Infra', pct: 21, color: '#06b6d4', amount: totalExpenses > 0 ? totalExpenses * 0.21 : 26000 },
    { label: 'Tax & Compliance', pct: 11, color: isLight ? '#64748b' : '#334155', amount: totalExpenses > 0 ? totalExpenses * 0.11 : 13600 },
  ];

  // SVG Donut calculation
  const size = 160;
  const strokeWidth = 18;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;

  // Arc stroke dash offsets
  const arc1Length = (categories[0].pct / 100) * circumference;
  const arc2Length = (categories[1].pct / 100) * circumference;
  const arc3Length = (categories[2].pct / 100) * circumference;

  const gap = 3; // Gap between arcs

  return (
    <div className={`rounded-2xl p-5 shadow-xl flex flex-col justify-between h-full transition-colors ${
      isLight
        ? 'bg-white border border-slate-200 text-slate-900 shadow-sm'
        : 'bg-[#121c2e] border border-[#1e2f47] text-white shadow-xl'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-2">
        <h3 className={`text-sm font-bold font-geist tracking-tight ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>
          Expense Distribution
        </h3>
        <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
          isLight
            ? 'text-slate-700 bg-slate-100 border-slate-200'
            : 'text-slate-400 bg-[#09101d] border-[#1e2f47]'
        }`}>
          MTD
        </span>
      </div>

      {/* Donut Visual and Legend Grid */}
      <div className="flex items-center justify-between gap-4 my-auto py-1">
        {/* SVG Circular Donut */}
        <div className="relative w-32 h-32 shrink-0 flex items-center justify-center">
          <svg className="w-full h-full transform -rotate-90" viewBox={`0 0 ${size} ${size}`}>
            {/* Background Track */}
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="transparent"
              stroke={isLight ? '#f1f5f9' : '#0b1322'}
              strokeWidth={strokeWidth}
            />

            {/* Arc 1: Direct Operations (Mint Green) */}
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="transparent"
              stroke="#10b981"
              strokeWidth={strokeWidth}
              strokeDasharray={`${Math.max(arc1Length - gap, 0)} ${circumference}`}
              strokeDashoffset={0}
              strokeLinecap="round"
              className="transition-all duration-700"
            />

            {/* Arc 2: Cloud & Tech Infra (Cyan) */}
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="transparent"
              stroke="#06b6d4"
              strokeWidth={strokeWidth}
              strokeDasharray={`${Math.max(arc2Length - gap, 0)} ${circumference}`}
              strokeDashoffset={-arc1Length}
              strokeLinecap="round"
              className="transition-all duration-700"
            />

            {/* Arc 3: Tax & Compliance (Slate) */}
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="transparent"
              stroke={isLight ? '#94a3b8' : '#475569'}
              strokeWidth={strokeWidth}
              strokeDasharray={`${Math.max(arc3Length - gap, 0)} ${circumference}`}
              strokeDashoffset={-(arc1Length + arc2Length)}
              strokeLinecap="round"
              className="transition-all duration-700"
            />
          </svg>

          {/* Central Percentage */}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
            <span className={`text-xl font-black font-geist tracking-tight ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>
              68%
            </span>
            <span className={`text-[9px] uppercase font-bold ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              Primary
            </span>
          </div>
        </div>

        {/* Legend Column */}
        <div className="flex-1 space-y-2 text-xs">
          {categories.map((cat, idx) => (
            <div key={idx} className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 min-w-0">
                <span
                  className="w-2 h-2 rounded-full shrink-0"
                  style={{ backgroundColor: cat.color }}
                />
                <span className={`text-[11px] truncate ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                  {cat.label}
                </span>
              </div>
              <span className={`text-[11px] font-bold shrink-0 ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>
                {cat.pct}%
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Footer Metrics */}
      <div className={`pt-2 border-t flex items-center justify-between text-[11px] ${
        isLight ? 'border-slate-200 text-slate-600' : 'border-[#1a283e] text-slate-400'
      }`}>
        <span>Operating Ratio: <strong className={isLight ? 'text-emerald-700' : 'text-emerald-400'}>Optimal</strong></span>
        <span>Variance: <strong className={isLight ? 'text-slate-800' : 'text-slate-200'}>-4.2%</strong></span>
      </div>
    </div>
  );
};
