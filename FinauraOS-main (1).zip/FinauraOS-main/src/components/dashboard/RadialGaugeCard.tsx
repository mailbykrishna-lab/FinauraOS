import React from 'react';
import { Sparkles, ArrowRight, ShieldCheck } from 'lucide-react';

interface RadialGaugeCardProps {
  onAction: () => void;
  accuracyRate?: number;
  themeMode?: 'cyber_mint' | 'classic_light';
}

export const RadialGaugeCard: React.FC<RadialGaugeCardProps> = ({
  onAction,
  accuracyRate = 94,
  themeMode = 'cyber_mint',
}) => {
  const isLight = themeMode === 'classic_light';
  const size = 120;
  const strokeWidth = 12;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (accuracyRate / 100) * circumference;

  return (
    <div className={`rounded-2xl p-5 shadow-xl flex flex-col justify-between h-full transition-colors ${
      isLight
        ? 'bg-white border border-slate-200 text-slate-900 shadow-sm'
        : 'bg-[#121c2e] border border-[#1e2f47] text-white shadow-xl'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-1.5">
          <ShieldCheck className={`w-4 h-4 ${isLight ? 'text-emerald-700' : 'text-emerald-400'}`} />
          <h3 className={`text-sm font-bold font-geist tracking-tight ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>
            AI Ledger Audit
          </h3>
        </div>
        <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
          isLight
            ? 'text-emerald-700 bg-emerald-50 border-emerald-200'
            : 'text-emerald-400 bg-emerald-950/80 border-emerald-800/60'
        }`}>
          Clean
        </span>
      </div>

      {/* Circular Progress Gauge */}
      <div className="flex flex-col items-center justify-center my-auto py-2">
        <div className="relative w-28 h-28 flex items-center justify-center">
          <svg className="w-full h-full transform -rotate-90" viewBox={`0 0 ${size} ${size}`}>
            {/* Background Circle */}
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="transparent"
              stroke={isLight ? '#f1f5f9' : '#0b1322'}
              strokeWidth={strokeWidth}
            />
            {/* Active Mint Progress Arc */}
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="transparent"
              stroke="#10b981"
              strokeWidth={strokeWidth}
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              className="transition-all duration-700"
            />
          </svg>

          {/* Central Percentage */}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
            <span className={`text-2xl font-black font-geist tracking-tight ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>
              {accuracyRate}%
            </span>
            <span className={`text-[9px] uppercase font-bold ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              Reconciled
            </span>
          </div>
        </div>

        <p className={`text-[11px] text-center max-w-[200px] mt-2 ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
          Automated double-entry validation with zero mismatch anomalies.
        </p>
      </div>

      {/* Action Button */}
      <button
        type="button"
        onClick={onAction}
        className={`w-full font-bold text-xs py-2.5 px-4 rounded-xl transition-all duration-150 flex items-center justify-center gap-1.5 shadow-sm cursor-pointer active:scale-98 ${
          isLight
            ? 'bg-slate-900 hover:bg-black text-white'
            : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/20'
        }`}
      >
        <span>Auto-Reconcile</span>
        <ArrowRight className="w-3.5 h-3.5 stroke-[2.5]" />
      </button>
    </div>
  );
};
