import React from 'react';
import { Activity, Clock } from 'lucide-react';

interface DualRadialRingCardProps {
  runwayMonths?: number;
  collectionDays?: number;
  themeMode?: 'cyber_mint' | 'classic_light';
}

export const DualRadialRingCard: React.FC<DualRadialRingCardProps> = ({
  runwayMonths = 21,
  collectionDays = 11,
  themeMode = 'cyber_mint',
}) => {
  const isLight = themeMode === 'classic_light';
  const size = 100;
  const strokeWidth = 10;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;

  // Visual percentages for circular arcs
  const runwayPct = Math.min((runwayMonths / 24) * 100, 100);
  const runwayOffset = circumference - (runwayPct / 100) * circumference;

  const collectionPct = Math.min((collectionDays / 30) * 100, 100);
  const collectionOffset = circumference - (collectionPct / 100) * circumference;

  return (
    <div className={`rounded-2xl p-5 shadow-xl flex flex-col justify-between h-full transition-colors ${
      isLight
        ? 'bg-white border border-slate-200 text-slate-900 shadow-sm'
        : 'bg-[#121c2e] border border-[#1e2f47] text-white shadow-xl'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-2">
        <h3 className={`text-sm font-bold font-geist tracking-tight ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>
          Liquidity &amp; Velocity Radar
        </h3>
        <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
          isLight
            ? 'text-slate-700 bg-slate-100 border-slate-200'
            : 'text-slate-400 bg-[#09101d] border-[#1e2f47]'
        }`}>
          Metrics
        </span>
      </div>

      {/* Dual Rings Container */}
      <div className="grid grid-cols-2 gap-4 my-auto py-2">
        {/* Ring 1: Runway */}
        <div className="flex flex-col items-center text-center">
          <div className="relative w-24 h-24 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox={`0 0 ${size} ${size}`}>
              <circle
                cx={size / 2}
                cy={size / 2}
                r={radius}
                fill="transparent"
                stroke={isLight ? '#f1f5f9' : '#0b1322'}
                strokeWidth={strokeWidth}
              />
              <circle
                cx={size / 2}
                cy={size / 2}
                r={radius}
                fill="transparent"
                stroke="#10b981"
                strokeWidth={strokeWidth}
                strokeDasharray={circumference}
                strokeDashoffset={runwayOffset}
                strokeLinecap="round"
                className="transition-all duration-700"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={`text-xl font-black font-geist ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>
                {runwayMonths}
              </span>
              <span className={`text-[8px] uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Months
              </span>
            </div>
          </div>
          <span className={`text-xs font-bold mt-2 ${isLight ? 'text-slate-800' : 'text-slate-200'}`}>Cash Runway</span>
          <span className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Safe Capital Buffer</span>
        </div>

        {/* Ring 2: Collection DSO */}
        <div className="flex flex-col items-center text-center">
          <div className="relative w-24 h-24 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox={`0 0 ${size} ${size}`}>
              <circle
                cx={size / 2}
                cy={size / 2}
                r={radius}
                fill="transparent"
                stroke={isLight ? '#f1f5f9' : '#0b1322'}
                strokeWidth={strokeWidth}
              />
              <circle
                cx={size / 2}
                cy={size / 2}
                r={radius}
                fill="transparent"
                stroke="#059669"
                strokeWidth={strokeWidth}
                strokeDasharray={circumference}
                strokeDashoffset={collectionOffset}
                strokeLinecap="round"
                className="transition-all duration-700"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={`text-xl font-black font-geist ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>
                {collectionDays}
              </span>
              <span className={`text-[8px] uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Days
              </span>
            </div>
          </div>
          <span className={`text-xs font-bold mt-2 ${isLight ? 'text-slate-800' : 'text-slate-200'}`}>Collection DSO</span>
          <span className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Avg Settlement Speed</span>
        </div>
      </div>

      {/* Footer Indicators */}
      <div className={`pt-2 border-t flex items-center justify-between text-[11px] ${
        isLight ? 'border-slate-200 text-slate-600' : 'border-[#1a283e] text-slate-400'
      }`}>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          <span>Capital Runway: <strong>Healthy</strong></span>
        </div>
        <span className={`${isLight ? 'text-emerald-700' : 'text-emerald-400'} font-semibold`}>98.4% on-time</span>
      </div>
    </div>
  );
};
