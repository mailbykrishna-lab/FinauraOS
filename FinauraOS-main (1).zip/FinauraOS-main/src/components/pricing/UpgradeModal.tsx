import React, { useState } from 'react';
import {
  X,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  CreditCard,
  QrCode,
  Building,
  AlertCircle,
  Clock,
  Download,
} from 'lucide-react';
import {
  PlanTier,
  BillingCycle,
  UserSubscription,
  BillingInvoice,
} from '../../types';
import { PLANS, getPlan } from '../../lib/plans';
import { paymentService } from '../../lib/payment';
import { analytics } from '../../lib/analytics';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSubscription: UserSubscription;
  initialTargetPlan?: PlanTier;
  onSuccess: (updatedSub: UserSubscription, newInvoice: BillingInvoice) => void;
  businessName: string;
}

export const UpgradeModal: React.FC<UpgradeModalProps> = ({
  isOpen,
  onClose,
  currentSubscription,
  initialTargetPlan = 'business',
  onSuccess,
  businessName,
}) => {
  const [targetPlanId, setTargetPlanId] = useState<PlanTier>(initialTargetPlan);
  const [cycle, setCycle] = useState<BillingCycle>(currentSubscription.billingCycle || 'monthly');
  const [step, setStep] = useState<'select' | 'review' | 'payment' | 'success'>('select');
  const [paymentType, setPaymentType] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [upiVpa, setUpiVpa] = useState('founder@okhdfcbank');
  const [cardNumber, setCardNumber] = useState('4532 8912 3401 4242');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmedInvoice, setConfirmedInvoice] = useState<BillingInvoice | null>(null);

  if (!isOpen) return null;

  const currentPlan = getPlan(currentSubscription.planId);
  const targetPlan = getPlan(targetPlanId);

  const price = cycle === 'yearly' ? targetPlan.priceYearly : targetPlan.priceMonthly;
  const gst = Math.round(price * 0.18);
  const totalAmount = price + gst;

  const handleNextToPayment = () => {
    analytics.track('upgrade_started', { targetPlanId, cycle });
    setStep('payment');
  };

  const handleExecutePayment = async () => {
    setIsProcessing(true);
    setError(null);
    analytics.track('checkout_started', { planId: targetPlanId, amount: totalAmount });

    try {
      const res = await paymentService.processCheckout(currentSubscription, {
        planId: targetPlanId,
        billingCycle: cycle,
        paymentMethodType: paymentType,
        upiVpa: paymentType === 'upi' ? upiVpa : undefined,
      });

      if (res.success && res.updatedSubscription && res.newInvoice) {
        analytics.track('upgrade_completed', { planId: targetPlanId, amount: totalAmount });
        setConfirmedInvoice(res.newInvoice);
        setStep('success');
        onSuccess(res.updatedSubscription, res.newInvoice);
      } else {
        analytics.track('payment_failed', { error: res.error || 'Payment failed' });
        setError(res.error || 'Transaction could not be completed');
      }
    } catch (err: any) {
      setError(err?.message || 'Payment service error');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Top Modal Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                {step === 'success' ? 'Upgrade Completed' : 'Upgrade Your Finaura Workspace'}
              </h3>
              <span className="text-[11px] text-slate-500">{businessName}</span>
            </div>
          </div>
          {step !== 'success' && (
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-900 text-xs">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* STEP 1 & 2: SELECT PLAN & REVIEW WHAT CHANGES */}
          {step === 'select' && (
            <div className="space-y-6">
              {/* Cycle Toggle */}
              <div className="flex items-center justify-between bg-slate-100 p-1.5 rounded-2xl">
                <button
                  type="button"
                  onClick={() => setCycle('monthly')}
                  className={`flex-1 py-2 rounded-xl font-bold transition-all text-center cursor-pointer ${
                    cycle === 'monthly' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
                  }`}
                >
                  Monthly billing
                </button>
                <button
                  type="button"
                  onClick={() => setCycle('yearly')}
                  className={`flex-1 py-2 rounded-xl font-bold transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer ${
                    cycle === 'yearly' ? 'bg-slate-900 text-white shadow-2xs' : 'text-slate-600'
                  }`}
                >
                  <span>Yearly (Save 20%)</span>
                </button>
              </div>

              {/* Plan Cards Selection */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {(['growth', 'business', 'professional'] as PlanTier[]).map((pKey) => {
                  const p = PLANS[pKey];
                  const isCurrent = currentSubscription.planId === pKey;
                  const isSelected = targetPlanId === pKey;
                  const planPrice = cycle === 'yearly' ? p.monthlyEquivalentYearly : p.priceMonthly;

                  return (
                    <button
                      key={pKey}
                      type="button"
                      disabled={isCurrent}
                      onClick={() => setTargetPlanId(pKey)}
                      className={`p-4 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                        isSelected
                          ? 'border-emerald-600 bg-emerald-50/40 shadow-xs ring-2 ring-emerald-500/20'
                          : isCurrent
                          ? 'border-slate-200 bg-slate-100 opacity-60 cursor-not-allowed'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-sm text-slate-900">{p.name}</span>
                          {isCurrent && (
                            <span className="text-[10px] bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded font-bold">
                              Current
                            </span>
                          )}
                        </div>
                        <div className="text-lg font-black text-slate-900">
                          ₹{planPrice.toLocaleString('en-IN')}
                          <span className="text-[10px] text-slate-500 font-normal">/mo</span>
                        </div>
                      </div>
                      <span className="text-[10px] text-slate-500 mt-2 line-clamp-2">
                        {p.tagline}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* What Changes / Highlights */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <span className="font-bold uppercase tracking-wider text-[11px] text-slate-600 block">
                  What Unlocks on {targetPlan.name}:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {targetPlan.features.slice(0, 6).map((feat, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="text-slate-700">{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Price Breakdown Preview */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-slate-500 block">Total due now (incl. 18% GST):</span>
                  <span className="text-xl font-extrabold text-slate-900">
                    ₹{totalAmount.toLocaleString('en-IN')}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleNextToPayment}
                  className="px-6 py-3 rounded-xl bg-slate-900 hover:bg-black text-white font-bold text-xs flex items-center gap-2 shadow-sm cursor-pointer"
                >
                  <span>Continue to Payment</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: PAYMENT METHOD */}
          {step === 'payment' && (
            <div className="space-y-6">
              {/* Order Summary */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-slate-900">
                    Upgrading to {targetPlan.name} ({cycle === 'yearly' ? 'Annual' : 'Monthly'})
                  </span>
                  <p className="text-[11px] text-slate-500">
                    Subtotal: ₹{price.toLocaleString('en-IN')} + 18% GST: ₹{gst.toLocaleString('en-IN')}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-lg font-black text-slate-900">
                    ₹{totalAmount.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {/* Payment Method Selector */}
              <div>
                <label className="font-bold text-slate-700 block mb-2">Select Indian Payment Method:</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'upi', label: 'UPI / QR', icon: QrCode },
                    { id: 'card', label: 'Card', icon: CreditCard },
                    { id: 'netbanking', label: 'Netbanking', icon: Building },
                  ].map((m) => {
                    const Icon = m.icon;
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => setPaymentType(m.id as any)}
                        className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 text-center font-bold transition-all cursor-pointer ${
                          paymentType === m.id
                            ? 'border-emerald-600 bg-emerald-50/50 text-emerald-800'
                            : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <Icon className="w-5 h-5" />
                        <span>{m.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Method Details */}
              {paymentType === 'upi' && (
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                  <label className="text-[11px] font-bold text-slate-600 block">
                    Enter UPI ID / VPA:
                  </label>
                  <input
                    type="text"
                    value={upiVpa}
                    onChange={(e) => setUpiVpa(e.target.value)}
                    placeholder="name@okhdfcbank"
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-semibold focus:outline-emerald-600"
                  />
                  <span className="text-[10px] text-slate-400 block">
                    Supports Google Pay, PhonePe, Paytm, CRED &amp; BHIM. Instant verification.
                  </span>
                </div>
              )}

              {paymentType === 'card' && (
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-600 block mb-1">
                      Card Number
                    </label>
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono focus:outline-emerald-600"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="MM/YY"
                      defaultValue="08/29"
                      className="px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono"
                    />
                    <input
                      type="password"
                      placeholder="CVV"
                      defaultValue="888"
                      className="px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono"
                    />
                  </div>
                </div>
              )}

              {paymentType === 'netbanking' && (
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                  <span className="text-[11px] font-bold text-slate-600 block">
                    Supported Banks:
                  </span>
                  <div className="grid grid-cols-2 gap-2 text-xs font-medium text-slate-700">
                    <span className="p-2 bg-white rounded-lg border border-slate-200">HDFC Bank Ltd</span>
                    <span className="p-2 bg-white rounded-lg border border-slate-200">ICICI Bank</span>
                    <span className="p-2 bg-white rounded-lg border border-slate-200">State Bank of India</span>
                    <span className="p-2 bg-white rounded-lg border border-slate-200">Axis Bank Ltd</span>
                  </div>
                </div>
              )}

              {/* Demo Notice */}
              <div className="flex items-center gap-2 text-[11px] text-emerald-800 bg-emerald-50/70 p-3 rounded-xl border border-emerald-200">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  Demo Mode Simulation Active: No live debit will occur. Instant sandbox fulfillment.
                </span>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep('select')}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-bold hover:bg-slate-50 cursor-pointer"
                >
                  Back
                </button>
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handleExecutePayment}
                  className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-sm cursor-pointer disabled:opacity-50"
                >
                  {isProcessing ? (
                    <span>Authorizing Payment...</span>
                  ) : (
                    <>
                      <span>Pay ₹{totalAmount.toLocaleString('en-IN')} &amp; Activate</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: SUCCESS CONFIRMATION */}
          {step === 'success' && confirmedInvoice && (
            <div className="text-center py-6 space-y-5">
              <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div>
                <h3 className="text-xl font-black text-slate-900">
                  Your {targetPlan.name} Plan is Now Active!
                </h3>
                <p className="text-xs text-slate-600 mt-1">
                  All upgraded features, extra limits, and multi-user seats are immediately unlocked.
                </p>
              </div>

              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 max-w-md mx-auto text-left space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">Invoice Number:</span>
                  <span className="font-mono font-bold text-slate-900">{confirmedInvoice.invoiceNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Amount Paid:</span>
                  <span className="font-bold text-slate-900">₹{confirmedInvoice.amount.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Billing Term:</span>
                  <span className="font-bold text-slate-900">{confirmedInvoice.billingCycle.toUpperCase()}</span>
                </div>
              </div>

              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => paymentService.downloadInvoice(confirmedInvoice, businessName)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 font-bold text-slate-700 flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Tax Invoice</span>
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-black text-white font-bold cursor-pointer"
                >
                  Return to Workspace
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
