import React from 'react';
import { Lock, Sparkles, ArrowRight, ShieldCheck } from 'lucide-react';
import { PlanTier, FeatureKey } from '../../types';
import { hasFeature, isPlanAtLeast, getPlan } from '../../lib/plans';
import { analytics } from '../../lib/analytics';

interface FeatureGateProps {
  currentPlan: PlanTier;
  feature?: FeatureKey;
  requiredPlan?: PlanTier;
  title?: string;
  description?: string;
  onUpgradeClick?: (targetPlan: PlanTier) => void;
  children: React.ReactNode;
  inline?: boolean;
}

export const FeatureGate: React.FC<FeatureGateProps> = ({
  currentPlan,
  feature,
  requiredPlan,
  title,
  description,
  onUpgradeClick,
  children,
  inline = false,
}) => {
  // Check entitlement
  const isAllowed = feature
    ? hasFeature(currentPlan, feature)
    : requiredPlan
    ? isPlanAtLeast(currentPlan, requiredPlan)
    : true;

  if (isAllowed) {
    return <>{children}</>;
  }

  // Feature is locked
  const targetPlanKey: PlanTier = requiredPlan || (feature === 'ca_client_management' ? 'ca_pro' : 'business');
  const targetPlan = getPlan(targetPlanKey);

  const handleUpgrade = () => {
    analytics.track('upgrade_prompt_clicked', {
      featureKey: feature,
      requiredPlan: targetPlanKey,
      currentPlan,
    });
    if (onUpgradeClick) {
      onUpgradeClick(targetPlanKey);
    }
  };

  if (inline) {
    return (
      <div className="p-4 bg-gradient-to-r from-slate-900 to-slate-950 text-white rounded-2xl border border-slate-800 flex items-center justify-between gap-4 shadow-sm my-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <Lock className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white">
              {title || `Unlock with ${targetPlan.name} Plan`}
            </h4>
            <p className="text-[11px] text-slate-300">
              {description || `This feature requires ${targetPlan.name} tier (₹${targetPlan.priceMonthly}/mo).`}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={handleUpgrade}
          className="px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 shrink-0 cursor-pointer shadow-sm"
        >
          <span>Upgrade</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    );
  }

  return (
    <div className="relative rounded-3xl border border-slate-200 bg-white p-8 sm:p-12 text-center shadow-xs overflow-hidden my-6">
      {/* Background pattern */}
      <div className="absolute inset-0 bg-radial from-slate-50 to-transparent opacity-60 pointer-events-none" />

      <div className="relative z-10 max-w-lg mx-auto space-y-4">
        <div className="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center mx-auto shadow-md">
          <Lock className="w-6 h-6 text-emerald-400" />
        </div>

        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-bold uppercase tracking-wider mb-2">
            <Sparkles className="w-3 h-3 text-emerald-600" />
            <span>AVAILABLE ON {targetPlan.name.toUpperCase()} PLAN</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900">
            {title || `Ready to scale with ${targetPlan.name}?`}
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
            {description ||
              `This advanced capability is available on the ${targetPlan.name} plan. Upgrade your workspace to unlock immediate access.`}
          </p>
        </div>

        <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-left space-y-2 text-xs">
          <span className="font-bold text-slate-700 block">
            What you get on {targetPlan.name}:
          </span>
          <ul className="space-y-1.5 text-slate-600">
            {targetPlan.features.slice(0, 4).map((f, i) => (
              <li key={i} className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <span>{f}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            type="button"
            onClick={handleUpgrade}
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-slate-900 hover:bg-black text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm cursor-pointer"
          >
            <span>Upgrade to {targetPlan.name} (₹{targetPlan.priceMonthly}/mo)</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
