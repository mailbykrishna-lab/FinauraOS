import React, { useState } from 'react';
import {
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Building2,
  Users,
  Briefcase,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  X,
  FileCheck2,
  AlertCircle,
  Clock,
  Laptop,
} from 'lucide-react';
import { PlanTier, BillingCycle } from '../../types';
import { PLANS, COMPARISON_MATRIX, PRICING_FAQS } from '../../lib/plans';
import { analytics } from '../../lib/analytics';

interface PublicPricingSectionProps {
  onSelectPlan: (planId: PlanTier, cycle: BillingCycle) => void;
  onExploreCAPro?: () => void;
}

export const PublicPricingSection: React.FC<PublicPricingSectionProps> = ({
  onSelectPlan,
  onExploreCAPro,
}) => {
  const [billingCycle, setBillingCycle] = useState<BillingCycle>('monthly');
  const [showComparison, setShowComparison] = useState(false);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const handleToggleCycle = (cycle: BillingCycle) => {
    setBillingCycle(cycle);
    analytics.track('pricing_toggle_yearly', { billingCycle: cycle });
  };

  const handlePlanClick = (planId: PlanTier) => {
    analytics.track('pricing_cta_click', { planId, billingCycle });
    onSelectPlan(planId, billingCycle);
  };

  const businessPlanKeys: PlanTier[] = ['free', 'growth', 'business', 'professional'];
  const caPlan = PLANS.ca_pro;

  return (
    <section id="pricing" className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* 1. HEADER */}
      <div className="text-center max-w-3xl mx-auto mb-14">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-4">
          <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
          <span>TRANSPARENT VALUE-BASED PRICING</span>
        </div>
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight">
          Pricing that makes the decision simple.
        </h2>
        <p className="text-base sm:text-lg text-slate-600 mt-4 leading-relaxed">
          Choose the workspace that fits your business today — and upgrade as you grow.
        </p>

        {/* Monthly / Yearly Toggle */}
        <div className="mt-8 inline-flex items-center p-1.5 bg-slate-100/90 border border-slate-200 rounded-2xl shadow-2xs">
          <button
            type="button"
            onClick={() => handleToggleCycle('monthly')}
            className={`px-5 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all cursor-pointer ${
              billingCycle === 'monthly'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Monthly billing
          </button>
          <button
            type="button"
            onClick={() => handleToggleCycle('yearly')}
            className={`px-5 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
              billingCycle === 'yearly'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Yearly billing</span>
            <span className="text-xs uppercase tracking-wider font-extrabold px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950">
              Save 20%
            </span>
          </button>
        </div>
        {billingCycle === 'yearly' && (
          <p className="text-xs font-semibold text-emerald-700 mt-2">
            ✨ Billed annually — Enjoy 2+ months free across all paid tiers.
          </p>
        )}
      </div>

      {/* 2. BUSINESS TIER CARDS GRID (4 Plans) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
        {businessPlanKeys.map((planKey) => {
          const plan = PLANS[planKey];
          const isPopular = plan.isPopular;
          const price =
            billingCycle === 'yearly'
              ? plan.monthlyEquivalentYearly
              : plan.priceMonthly;

          return (
            <div
              key={planKey}
              className={`relative rounded-3xl p-6 sm:p-7 flex flex-col justify-between transition-all duration-200 ${
                isPopular
                  ? 'bg-slate-900 bg-gradient-to-b from-slate-900 to-slate-950 text-white border-2 border-emerald-500 shadow-xl lg:-translate-y-2'
                  : 'bg-white text-slate-900 border border-slate-200 shadow-sm hover:border-slate-300 hover:shadow-md'
              }`}
            >
              {/* Popular / Recommended Badge */}
              {isPopular && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3.5 py-1 rounded-full bg-emerald-500 text-slate-950 text-xs font-black uppercase tracking-wider shadow-sm flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  <span>MOST POPULAR</span>
                </div>
              )}

              <div>
                {/* Header */}
                <div className="flex items-center justify-between">
                  <div>
                    <h3
                      className={`text-xl font-black ${
                        isPopular ? 'text-white' : 'text-slate-900'
                      }`}
                    >
                      {plan.name}
                    </h3>
                    <p
                      className={`text-xs mt-1 min-h-[32px] ${
                        isPopular ? 'text-slate-300' : 'text-slate-600'
                      }`}
                    >
                      {plan.tagline}
                    </p>
                  </div>
                </div>

                {/* Price Display */}
                <div className="my-6 pb-6 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-baseline gap-1">
                    <span
                      className={`text-4xl font-extrabold tracking-tight ${
                        isPopular ? 'text-white' : 'text-slate-900'
                      }`}
                    >
                      ₹{price.toLocaleString('en-IN')}
                    </span>
                    <span
                      className={`text-xs font-semibold ${
                        isPopular ? 'text-slate-300' : 'text-slate-600'
                      }`}
                    >
                      /month
                    </span>
                  </div>
                  {billingCycle === 'yearly' && plan.priceYearly > 0 ? (
                    <div
                      className={`text-xs mt-1.5 font-medium ${
                        isPopular ? 'text-emerald-400' : 'text-emerald-700'
                      }`}
                    >
                      Billed ₹{plan.priceYearly.toLocaleString('en-IN')} annually
                    </div>
                  ) : (
                    <div
                      className={`text-xs mt-1.5 ${
                        isPopular ? 'text-slate-300' : 'text-slate-600'
                      }`}
                    >
                      {plan.priceMonthly === 0
                        ? 'No credit card required'
                        : 'Billed monthly'}
                    </div>
                  )}
                </div>

                {/* Primary CTA */}
                <button
                  type="button"
                  onClick={() => handlePlanClick(planKey)}
                  className={`w-full py-3 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm ${
                    isPopular
                      ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold'
                      : planKey === 'free'
                      ? 'bg-slate-900 hover:bg-black text-white'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-900 border border-slate-200'
                  }`}
                >
                  <span>{plan.ctaText}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                {/* Features Checklist - Focused on top 5 key differentiators */}
                <div className="mt-8 space-y-3">
                  <span
                    className={`text-xs font-bold uppercase tracking-wider block ${
                      isPopular ? 'text-slate-300' : 'text-slate-600'
                    }`}
                  >
                    Included Capabilities:
                  </span>
                  <ul className="space-y-2.5 text-xs">
                    {plan.features.slice(0, 5).map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-2.5">
                        <CheckCircle2
                          className={`w-4 h-4 shrink-0 mt-0.5 ${
                            isPopular ? 'text-emerald-400' : 'text-emerald-600'
                          }`}
                        />
                        <span
                          className={`leading-relaxed ${
                            isPopular ? 'text-slate-100' : 'text-slate-700'
                          }`}
                        >
                          {feat}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Target Audience Footer */}
              <div
                className={`mt-6 pt-4 border-t text-xs ${
                  isPopular
                    ? 'border-slate-800 text-slate-300'
                    : 'border-slate-100 text-slate-600'
                }`}
              >
                Best for: {plan.targetAudience}
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Link to Detailed Comparison Matrix */}
      <div className="mt-6 text-center">
        <button
          type="button"
          onClick={() => setShowComparison(true)}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 underline underline-offset-4 cursor-pointer"
        >
          <span>Need full specifications? Compare all 28+ features side-by-side</span>
          <ChevronDown className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 3. DISTINCT CA PRO SECTION (Phase 3 & 4 mandate: NOT just another business card) */}
      <div className="mt-16 bg-slate-950 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-950 text-white rounded-3xl p-8 sm:p-12 border border-indigo-800/60 shadow-2xl relative overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Description */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-bold uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-indigo-400" />
              <span>DEDICATED PRACTITIONER WORKSPACE</span>
            </div>

            <div>
              <h3 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white">
                FINAURA CA PRO
              </h3>
              <p className="text-base text-indigo-200/90 mt-2 font-medium">
                Built specifically for Chartered Accountants, accounting firms, tax professionals, and compliance practitioners.
              </p>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Do not force your clients onto clunky desktop spreadsheets. Finaura CA Pro connects you with your clients’ live ledgers, automates document chases, monitors GSTR-1/3B deadlines, and exports workpapers formatted for Tally Prime and ITD portals.
            </p>

            {/* Feature Highlights Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
              {[
                'Client management (up to 25 client accounts)',
                'Master statutory compliance calendar across all clients',
                'Automated client document requests & secure portal',
                'Financial review & one-click books validation',
                'AI client summaries & executive briefing notes',
                'Direct Tally & Income Tax portal XML export',
              ].map((feat, idx) => (
                <div key={idx} className="flex items-start gap-2 text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </div>
              ))}
            </div>

            <div className="pt-3 text-xs text-indigo-300 font-medium flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
              <span>Scales as your firm grows: 25 clients tier included • 100+ clients custom firm pricing available.</span>
            </div>
          </div>

          {/* Right Pricing Card */}
          <div className="lg:col-span-5 bg-slate-900/90 backdrop-blur-md border border-indigo-700/50 rounded-2xl p-7 sm:p-8 space-y-6 flex flex-col justify-between shadow-xl">
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-indigo-300 mb-2">
                <span>PRACTICE MANAGEMENT TIER</span>
                <span className="bg-indigo-500/30 text-indigo-200 px-2 py-0.5 rounded text-xs font-bold">
                  ICAI COMPATIBLE
                </span>
              </div>

              <div className="flex items-baseline gap-1 my-3">
                <span className="text-4xl sm:text-5xl font-extrabold text-white">
                  ₹
                  {(billingCycle === 'yearly'
                    ? caPlan.monthlyEquivalentYearly
                    : caPlan.priceMonthly
                  ).toLocaleString('en-IN')}
                </span>
                <span className="text-xs text-slate-300 font-medium">/month</span>
              </div>

              <p className="text-xs text-slate-300">
                {billingCycle === 'yearly'
                  ? `Billed annually at ₹${caPlan.priceYearly.toLocaleString('en-IN')}/year (Save ₹4,798)`
                  : 'Billed monthly. Cancel or expand client seats anytime.'}
              </p>
            </div>

            <div className="space-y-3 pt-4 border-t border-slate-800 text-xs text-slate-300">
              <div className="flex justify-between items-center">
                <span className="text-slate-300">Client Workspaces:</span>
                <span className="font-bold text-white">Up to 25 active clients</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-300">Team Auditor Seats:</span>
                <span className="font-bold text-white">10 Staff Members</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-300">Vault Storage:</span>
                <span className="font-bold text-white">150 GB Practitioner Vault</span>
              </div>
            </div>

            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  if (onExploreCAPro) {
                    onExploreCAPro();
                  } else {
                    handlePlanClick('ca_pro');
                  }
                }}
                className="w-full py-3.5 px-6 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
              >
                <span>Explore CA Pro for Firms</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <div className="text-center">
                <span className="text-xs text-slate-300">
                  Are you an accounting firm with 100+ clients? <a href="#ca-network" className="text-indigo-300 font-semibold underline hover:text-indigo-200">Contact firm desk</a>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4. PROFESSIONAL SERVICES SEPARATION (Phase 5 mandate) */}
      <div className="mt-12 bg-amber-50/60 border border-amber-200 rounded-2xl p-6 sm:p-8">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
              <span className="text-xs font-bold uppercase tracking-wider text-amber-900">
                TWO REVENUE LAYERS: SOFTWARE PLATFORM VS PROFESSIONAL SERVICES
              </span>
            </div>
            <h4 className="text-base sm:text-lg font-bold text-slate-900">
              Need certified CA filings or 1-on-1 statutory representations?
            </h4>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Your FINAURA subscription covers autonomous software, AI, ledgers, and compliance tooling. Certified Chartered Accountant services (such as formal audit sign-offs, statutory ITR filing representations, GST scrutiny response, or 1-on-1 tax advisory) are billed separately based on transparent, service-specific quotes starting from ₹999.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <a
              href="#ca-network"
              className="px-4 py-2.5 rounded-xl bg-white border border-amber-300 hover:bg-amber-100 text-amber-950 font-bold text-xs transition-colors shadow-2xs inline-flex items-center gap-1.5"
            >
              <span>View CA Marketplace &amp; Rates</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>

      {/* 5. DETAILED COMPARISON MATRIX (Progressive Disclosure) */}
      <div className="mt-16 text-center">
        <button
          type="button"
          onClick={() => setShowComparison(!showComparison)}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-800 text-xs sm:text-sm font-bold shadow-2xs transition-all cursor-pointer"
        >
          <span>{showComparison ? 'Hide Feature Comparison' : 'Compare All 28+ Features in Detail'}</span>
          {showComparison ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {showComparison && (
          <div className="mt-8 bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm overflow-x-auto text-left animate-in fade-in duration-200">
            <div className="min-w-[640px]">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-900">
                    <th className="py-4 px-3 font-bold text-left w-2/5">Feature &amp; Capability</th>
                    <th className="py-4 px-3 font-bold text-center w-[15%]">Free</th>
                    <th className="py-4 px-3 font-bold text-center w-[15%] text-emerald-800 bg-emerald-50/50 rounded-t-lg">
                      Growth
                    </th>
                    <th className="py-4 px-3 font-bold text-center w-[15%]">Business</th>
                    <th className="py-4 px-3 font-bold text-center w-[15%]">Professional</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {COMPARISON_MATRIX.map((cat, catIdx) => (
                    <React.Fragment key={catIdx}>
                      <tr className="bg-slate-50">
                        <td
                          colSpan={5}
                          className="py-3 px-3 font-extrabold text-xs text-slate-900 uppercase tracking-wider"
                        >
                          {cat.category}
                        </td>
                      </tr>
                      {cat.items.map((item, itemIdx) => (
                        <tr key={itemIdx} className="hover:bg-slate-50/60 transition-colors">
                          <td className="py-3 px-3 font-medium text-slate-800">{item.name}</td>
                          <td className="py-3 px-3 text-center">
                            {renderCellVal(item.free)}
                          </td>
                          <td className="py-3 px-3 text-center bg-emerald-50/20 font-semibold text-slate-900">
                            {renderCellVal(item.growth)}
                          </td>
                          <td className="py-3 px-3 text-center">
                            {renderCellVal(item.business)}
                          </td>
                          <td className="py-3 px-3 text-center">
                            {renderCellVal(item.professional)}
                          </td>
                        </tr>
                      ))}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* 6. PRICING FAQS */}
      <div className="mt-20 max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
            GOT QUESTIONS?
          </span>
          <h3 className="text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
            Frequently Asked Questions
          </h3>
        </div>

        <div className="space-y-3">
          {PRICING_FAQS.map((faq, idx) => {
            const isExpanded = expandedFaq === idx;
            return (
              <div
                key={idx}
                className="bg-white border border-slate-200 rounded-2xl overflow-hidden transition-all shadow-2xs"
              >
                <button
                  type="button"
                  onClick={() => setExpandedFaq(isExpanded ? null : idx)}
                  aria-expanded={isExpanded}
                  aria-controls={`faq-answer-${idx}`}
                  className="w-full px-5 py-4 text-left font-bold text-xs sm:text-sm text-slate-900 flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-50 transition-colors"
                >
                  <span className="flex-1 pr-2">{faq.question}</span>
                  <span className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center shrink-0 text-slate-600 transition-colors">
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4" />
                    ) : (
                      <ChevronDown className="w-4 h-4" />
                    )}
                  </span>
                </button>
                {isExpanded && (
                  <div
                    id={`faq-answer-${idx}`}
                    className="px-5 pb-4 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 pt-3 bg-slate-50/40"
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* 7. COMPLIANCE & STATUTORY DISCLAIMER (Phase 24 mandate) */}
      <div className="mt-16 text-center text-xs text-slate-500 max-w-3xl mx-auto border-t border-slate-200 pt-8 space-y-2">
        <p className="font-semibold text-slate-600">
          Statutory Compliance Notice:
        </p>
        <p className="leading-relaxed">
          FINAURA is an autonomous financial operating system developed by Finaura Inc. Finaura is not a government portal, statutory filing agency, or tax authority. All regulatory notices and tax calculation engines are deterministic references to the Income Tax Act 1961, CGST Act 2017, and MSMED Act 2006. Certified CA review should be conducted for formal statutory audit filings.
        </p>
      </div>
    </section>
  );
};

function renderCellVal(val: string | boolean) {
  if (typeof val === 'boolean') {
    return val ? (
      <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto" />
    ) : (
      <span className="text-slate-300 font-bold">—</span>
    );
  }
  return <span className="text-slate-700">{val}</span>;
}
