import React, { useState } from 'react';
import {
  X,
  AlertOctagon,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { UserSubscription } from '../../types';
import { getPlan } from '../../lib/plans';
import { paymentService } from '../../lib/payment';
import { analytics } from '../../lib/analytics';

interface CancellationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSubscription: UserSubscription;
  onSuccess: (updatedSub: UserSubscription) => void;
}

export const CancellationModal: React.FC<CancellationModalProps> = ({
  isOpen,
  onClose,
  currentSubscription,
  onSuccess,
}) => {
  const [reason, setReason] = useState('temporary_pause');
  const [feedback, setFeedback] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const currentPlan = getPlan(currentSubscription.planId);
  const periodEndDate = new Date(currentSubscription.currentPeriodEnd).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  const handleConfirmCancellation = async () => {
    setIsProcessing(true);
    analytics.track('subscription_cancelled', { planId: currentPlan.id, reason, feedback });

    try {
      const res = await paymentService.cancelSubscription(currentSubscription);
      if (res.success) {
        onSuccess(res.updatedSubscription);
        onClose();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col text-slate-900 text-xs">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center">
              <AlertOctagon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Cancel Subscription</h3>
              <span className="text-[11px] text-slate-500">Transparent &amp; No Hassle</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Main Notice */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
            <div className="font-bold text-slate-900 text-sm">
              Your {currentPlan.name} workspace stays active until {periodEndDate}.
            </div>
            <p className="text-slate-600 leading-relaxed text-xs">
              You will not be billed again after this date. Your invoices, double-entry ledger, and uploaded documents will be safely retained on the Free tier. We never delete historical tax records.
            </p>
          </div>

          {/* Reason Selector */}
          <div>
            <label className="font-bold text-slate-700 block mb-2">
              Help us understand why you are cancelling (optional):
            </label>
            <div className="space-y-2">
              {[
                { id: 'temporary_pause', label: 'Taking a temporary break from operations' },
                { id: 'missing_feature', label: 'Missing a specific accounting or tax feature' },
                { id: 'too_expensive', label: 'Price is too high for current business stage' },
                { id: 'ca_handles_everything', label: 'My external CA prefers their desktop software' },
                { id: 'other', label: 'Other reasons' },
              ].map((r) => (
                <label
                  key={r.id}
                  className="flex items-center gap-2.5 p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer text-slate-700 font-medium"
                >
                  <input
                    type="radio"
                    name="cancel_reason"
                    checked={reason === r.id}
                    onChange={() => setReason(r.id)}
                    className="accent-slate-900"
                  />
                  <span>{r.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Additional Notes */}
          <div>
            <textarea
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder="Any specific suggestions for the Finaura team? (Optional)"
              rows={2}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-slate-900"
            />
          </div>

          {/* Buttons */}
          <div className="pt-2 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-black text-white font-bold cursor-pointer"
            >
              Keep My Plan Active
            </button>
            <button
              type="button"
              disabled={isProcessing}
              onClick={handleConfirmCancellation}
              className="px-4 py-2.5 rounded-xl border border-rose-200 text-rose-700 font-bold hover:bg-rose-50 cursor-pointer disabled:opacity-50"
            >
              {isProcessing ? 'Cancelling...' : 'Confirm Cancellation'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
