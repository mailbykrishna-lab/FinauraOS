import React, { useState } from 'react';
import {
  X,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import {
  PlanTier,
  UserSubscription,
  UsageMetrics,
} from '../../types';
import { PLANS, getPlan } from '../../lib/plans';
import { paymentService } from '../../lib/payment';
import { analytics } from '../../lib/analytics';

interface DowngradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSubscription: UserSubscription;
  metrics: UsageMetrics;
  onSuccess: (updatedSub: UserSubscription) => void;
}

export const DowngradeModal: React.FC<DowngradeModalProps> = ({
  isOpen,
  onClose,
  currentSubscription,
  metrics,
  onSuccess,
}) => {
  const [targetPlanId, setTargetPlanId] = useState<PlanTier>('free');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentPlan = getPlan(currentSubscription.planId);
  const targetPlan = getPlan(targetPlanId);

  // Check potential limit conflicts
  const hasStorageConflict = metrics.storageUsedBytes > targetPlan.limits.storageGB * 1024 * 1024 * 1024;
  const hasMemberConflict = metrics.teamMembersCount > targetPlan.limits.teamMembers;

  const handleConfirmDowngrade = async () => {
    setIsProcessing(true);
    setError(null);
    analytics.track('downgrade_started', { from: currentPlan.id, to: targetPlanId });

    try {
      const res = await paymentService.scheduleDowngrade(currentSubscription, targetPlanId);
      if (res.success) {
        analytics.track('downgrade_completed', { from: currentPlan.id, to: targetPlanId });
        onSuccess(res.updatedSubscription);
        onClose();
      } else {
        setError(res.error || 'Could not schedule downgrade');
      }
    } catch (err: any) {
      setError(err?.message || 'Downgrade request failed');
    } finally {
      setIsProcessing(false);
    }
  };

  const periodEndDate = new Date(currentSubscription.currentPeriodEnd).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col text-slate-900 text-xs">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Change or Downgrade Plan</h3>
              <span className="text-[11px] text-slate-500">Scheduled for period end</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="font-bold text-slate-700 block mb-2">
              Select Target Plan to Switch to:
            </label>
            <div className="grid grid-cols-2 gap-2">
              {(['free', 'growth'] as PlanTier[]).map((pKey) => {
                if (pKey === currentSubscription.planId) return null;
                const p = PLANS[pKey];
                const isSelected = targetPlanId === pKey;
                return (
                  <button
                    key={pKey}
                    type="button"
                    onClick={() => setTargetPlanId(pKey)}
                    className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'border-slate-900 bg-slate-50 ring-2 ring-slate-900/10'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="font-bold text-sm text-slate-900">{p.name}</div>
                    <div className="text-xs text-slate-500 font-semibold mt-0.5">
                      ₹{p.priceMonthly.toLocaleString('en-IN')}/mo
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Retention & Loss Explanation */}
          <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-4 space-y-2">
            <span className="font-bold text-amber-900 block">
              What changes when switching from {currentPlan.name} to {targetPlan.name}:
            </span>
            <ul className="space-y-1.5 text-[11px] text-amber-800">
              <li>• Invoices reduced to {targetPlan.limits.invoicesPerMonth} / month.</li>
              <li>• AI Financial questions capped at {targetPlan.limits.aiQuestionsPerMonth} / month.</li>
              <li>• Document storage capped at {targetPlan.limits.storageGB} GB.</li>
              {targetPlanId === 'free' && (
                <li>• Automated GSTR-2B matching and Section 43B(h) vendor radar will be paused.</li>
              )}
            </ul>
          </div>

          {/* Conflict Warnings if any */}
          {(hasStorageConflict || hasMemberConflict) && (
            <div className="bg-red-50 border border-red-200 rounded-2xl p-4 space-y-1 text-red-800">
              <span className="font-bold flex items-center gap-1.5 text-xs">
                <AlertCircle className="w-4 h-4 text-red-600" />
                Usage Warning
              </span>
              <p className="text-[11px]">
                {hasStorageConflict && `Your vault currently uses ~${(metrics.storageUsedBytes / (1024*1024*1024)).toFixed(1)} GB, which exceeds ${targetPlan.name}'s ${targetPlan.limits.storageGB} GB limit. You may need to archive documents.`}
              </p>
            </div>
          )}

          {/* Schedule Notice */}
          <div className="text-[11px] text-slate-500 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-200">
            <strong>No immediate disruption:</strong> Your current {currentPlan.name} features will remain fully active until <strong>{periodEndDate}</strong>. Your account will automatically transition to {targetPlan.name} on that date.
          </div>

          {/* Buttons */}
          <div className="pt-2 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-bold hover:bg-slate-50 cursor-pointer"
            >
              Keep {currentPlan.name}
            </button>
            <button
              type="button"
              disabled={isProcessing}
              onClick={handleConfirmDowngrade}
              className="px-5 py-2.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-bold cursor-pointer disabled:opacity-50"
            >
              {isProcessing ? 'Scheduling...' : `Confirm Downgrade to ${targetPlan.name}`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
