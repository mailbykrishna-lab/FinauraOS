import React, { useState } from 'react';
import {
  Home,
  Wallet,
  Receipt,
  ShieldCheck,
  FolderLock,
  Sparkles,
  UserCheck,
  Calendar,
  Users,
  Building,
  DollarSign,
  Package,
  BarChart3,
  PlugZap,
  HelpCircle,
  Bell,
  Settings,
  User,
  ChevronDown,
  ChevronRight,
  Plus,
  CheckCircle2,
  Building2,
  LogOut,
  ExternalLink,
  ChevronLeft,
  Briefcase,
  CreditCard,
} from 'lucide-react';
import {
  NavTab,
  BusinessProfile,
  UserAccount,
  Invoice,
  ComplianceAction,
  Transaction,
} from '../types';
import { FinauraLogo } from './FinauraLogo';

interface SidebarNavProps {
  currentTab: NavTab;
  currentSubTab?: string;
  onNavigate: (tab: NavTab, subTab?: string) => void;
  profile: BusinessProfile;
  onSelectBusiness?: (business: BusinessProfile) => void;
  currentUser: UserAccount | null;
  onOpenAI: (prompt?: string) => void;
  onOpenAuthModal: () => void;
  onSignOut: () => void;
  onOpenSettings: () => void;
  onOpenNotifications: () => void;
  onOpenHelp: () => void;
  onViewPublicLanding: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  invoices?: Invoice[];
  complianceActions?: ComplianceAction[];
  transactions?: Transaction[];
  currentPlanId?: string;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  currentTab,
  currentSubTab,
  onNavigate,
  profile,
  onSelectBusiness,
  currentUser,
  onOpenAI,
  onOpenAuthModal,
  onSignOut,
  onOpenSettings,
  onOpenNotifications,
  onOpenHelp,
  onViewPublicLanding,
  isCollapsed,
  onToggleCollapse,
  invoices = [],
  complianceActions = [],
  transactions = [],
  currentPlanId = 'growth',
}) => {
  const [showBusinessDropdown, setShowBusinessDropdown] = useState(false);
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({
    finance: currentTab === 'finance' || currentTab === 'accounting' || currentTab === 'expenses' || currentTab === 'invoices',
    tax: currentTab === 'tax',
    compliance: currentTab === 'compliance',
    ai: currentTab === 'ai' || currentTab === 'ask_ai',
    professionals: currentTab === 'professionals' || currentTab === 'ca_services',
    more: ['customers', 'vendors', 'payroll', 'inventory', 'reports', 'integrations'].includes(currentTab),
  });

  const toggleCategory = (catKey: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedCategories((prev) => ({
      ...prev,
      [catKey]: !prev[catKey],
    }));
  };

  // Notification badges
  const pendingInvoicesCount = invoices.filter((i) => i.status !== 'paid').length;
  const urgentComplianceCount = complianceActions.filter((c) => c.status === 'pending').length;
  const pendingTxCount = transactions.filter((t) => t.status === 'needs_review').length;

  const isTabActive = (mainTab: NavTab, aliases: NavTab[] = []) => {
    return currentTab === mainTab || aliases.includes(currentTab);
  };

  return (
    <aside
      className={`bg-slate-900 text-slate-100 flex flex-col h-full border-r border-slate-800 select-none transition-all duration-200 z-30 ${
        isCollapsed ? 'w-20' : 'w-64 md:w-72'
      }`}
      style={{ minWidth: isCollapsed ? '5rem' : '16rem' }}
    >
      {/* 1. TOP LOGO & HEADER */}
      <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
        {!isCollapsed ? (
          <button
            type="button"
            onClick={() => onNavigate('home')}
            aria-label="Finaura Financial OS Home"
            className="flex items-center gap-2 cursor-pointer text-left bg-transparent border-0 p-0"
          >
            <FinauraLogo size="md" theme="dark" subtitle="FINANCIAL OS" />
          </button>
        ) : (
          <button
            type="button"
            onClick={() => onNavigate('home')}
            aria-label="Finaura Financial OS Home"
            title="Finaura Financial OS Home"
            className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-bold text-lg mx-auto cursor-pointer"
          >
            F
          </button>
        )}

        <button
          type="button"
          onClick={onToggleCollapse}
          aria-label={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors hidden md:block cursor-pointer"
          title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
        >
          <ChevronLeft className={`w-4 h-4 transition-transform ${isCollapsed ? 'rotate-180' : ''}`} aria-hidden="true" />
        </button>
      </div>

      {/* 2. CURRENT BUSINESS SWITCHER */}
      {!isCollapsed ? (
        <div className="p-3 border-b border-slate-800/80 relative">
          <button
            type="button"
            onClick={() => setShowBusinessDropdown(!showBusinessDropdown)}
            className="w-full p-2.5 bg-slate-800/80 hover:bg-slate-800 rounded-xl border border-slate-700/60 flex items-center justify-between text-left transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
                <Building2 className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-white truncate font-geist tracking-wide">
                  {profile.businessName.toUpperCase()}
                </div>
                <div className="text-[10px] text-slate-400 flex items-center gap-1">
                  <span>{profile.businessType.toUpperCase()}</span>
                  <span>•</span>
                  <span>{profile.state}</span>
                </div>
              </div>
            </div>
            <ChevronDown className="w-4 h-4 text-slate-400 group-hover:text-white shrink-0 ml-1 transition-transform" />
          </button>

          {/* Business switch dropdown menu */}
          {showBusinessDropdown && (
            <div className="absolute top-full left-3 right-3 mt-1 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl z-50 p-1.5 space-y-1 animate-in fade-in zoom-in-95">
              <div className="text-[10px] uppercase font-bold text-slate-400 px-2 py-1">
                Active Business Entity
              </div>
              <div className="w-full text-left p-2 rounded-lg text-xs flex items-center justify-between bg-emerald-700/80 text-white font-bold">
                <div className="truncate">
                  <div className="font-semibold truncate">{profile.businessName}</div>
                  <div className="text-[10px] opacity-75">{profile.gstin || 'GSTIN Unregistered'}</div>
                </div>
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0 text-emerald-200" />
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowBusinessDropdown(false);
                  onOpenSettings();
                }}
                className="w-full text-left p-2 rounded-lg text-xs flex items-center gap-1.5 text-slate-300 hover:bg-slate-700 hover:text-white transition-colors cursor-pointer"
              >
                <Settings className="w-3.5 h-3.5 text-slate-400" />
                <span>Entity Settings & GSTIN</span>
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="p-2 border-b border-slate-800/80 flex justify-center">
          <div
            className="w-10 h-10 rounded-xl bg-slate-800 text-emerald-400 flex items-center justify-center cursor-pointer"
            title={profile.businessName}
          >
            <Building2 className="w-5 h-5" />
          </div>
        </div>
      )}

      {/* 3. MAIN NAVIGATION SCROLLABLE LIST */}
      <nav className="flex-1 overflow-y-auto px-2 py-3 space-y-1 scrollbar-thin scrollbar-thumb-slate-800">
        
        {/* 🏠 1. HOME */}
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            isTabActive('home', ['dashboard'])
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
          }`}
          title="Home - Business overview and today's priorities"
        >
          <Home className="w-4 h-4 shrink-0" />
          {!isCollapsed && (
            <div className="flex-1 text-left">
              <span>Home</span>
            </div>
          )}
        </button>

        {/* 💰 2. FINANCE (Expandable) */}
        <div>
          <div
            onClick={() => onNavigate('finance', 'overview')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer group ${
              isTabActive('finance', ['accounting', 'expenses', 'invoices', 'receivables', 'payables', 'cashflow'])
                ? 'bg-slate-800 text-white border border-slate-700/80'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
            title="Finance - Accounting, transactions, invoices, expenses, receivables, payables and cash flow"
          >
            <div className="flex items-center gap-3 min-w-0">
              <Wallet className={`w-4 h-4 shrink-0 ${isTabActive('finance') ? 'text-emerald-400' : ''}`} />
              {!isCollapsed && <span className="truncate">Finance</span>}
            </div>

            {!isCollapsed && (
              <div className="flex items-center gap-1.5">
                {pendingTxCount > 0 && (
                  <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-1.5 py-0.2 rounded font-bold">
                    {pendingTxCount}
                  </span>
                )}
                <button
                  type="button"
                  onClick={(e) => toggleCategory('finance', e)}
                  aria-label={expandedCategories.finance ? "Collapse Finance section" : "Expand Finance section"}
                  aria-expanded={!!expandedCategories.finance}
                  className="p-1 text-slate-400 hover:text-white rounded cursor-pointer"
                >
                  {expandedCategories.finance ? (
                    <ChevronDown className="w-3.5 h-3.5" aria-hidden="true" />
                  ) : (
                    <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                  )}
                </button>
              </div>
            )}
          </div>

          {/* Finance Expanded Sub-items */}
          {!isCollapsed && expandedCategories.finance && (
            <div className="ml-4 pl-3 border-l border-slate-800 my-1 space-y-0.5 animate-in fade-in duration-100">
              {[
                { id: 'overview', label: 'Finance Overview' },
                { id: 'transactions', label: 'Transactions & Ledger' },
                { id: 'invoices', label: 'Invoices' },
                { id: 'expenses', label: 'Expenses' },
                { id: 'receivables', label: 'Receivables' },
                { id: 'payables', label: 'Payables (43B)' },
                { id: 'cashflow', label: 'Cash Flow' },
              ].map((sub) => (
                <button
                  key={sub.id}
                  type="button"
                  onClick={() => onNavigate('finance', sub.id)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-medium transition-colors cursor-pointer flex items-center justify-between ${
                    currentTab === 'finance' && currentSubTab === sub.id
                      ? 'text-emerald-400 font-bold bg-slate-800/60'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                  }`}
                >
                  <span>{sub.label}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* 🧾 3. TAX (Expandable) */}
        <div>
          <div
            onClick={() => onNavigate('tax')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              isTabActive('tax')
                ? 'bg-slate-800 text-white border border-slate-700/80'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
            title="Tax - GST, TDS, ITR and tax-related workflows"
          >
            <div className="flex items-center gap-3 min-w-0">
              <Receipt className={`w-4 h-4 shrink-0 ${isTabActive('tax') ? 'text-blue-400' : ''}`} />
              {!isCollapsed && <span className="truncate">Tax</span>}
            </div>

            {!isCollapsed && (
              <button
                type="button"
                onClick={(e) => toggleCategory('tax', e)}
                aria-label={expandedCategories.tax ? "Collapse Tax section" : "Expand Tax section"}
                aria-expanded={!!expandedCategories.tax}
                className="p-1 text-slate-400 hover:text-white rounded cursor-pointer"
              >
                {expandedCategories.tax ? (
                  <ChevronDown className="w-3.5 h-3.5" aria-hidden="true" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                )}
              </button>
            )}
          </div>

          {!isCollapsed && expandedCategories.tax && (
            <div className="ml-4 pl-3 border-l border-slate-800 my-1 space-y-0.5 animate-in fade-in duration-100">
              {[
                { id: 'tax', label: 'Tax Center Overview' },
                { id: 'gst', label: 'GST Returns (GSTR-1/3B)' },
                { id: 'tds', label: 'TDS Deductions' },
                { id: 'itr', label: 'ITR & Tax Act 2025' },
                { id: 'tax_calendar', label: 'Tax Deadlines' },
              ].map((sub) => (
                <button
                  key={sub.id}
                  type="button"
                  onClick={() => onNavigate('tax', sub.id)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-medium transition-colors cursor-pointer ${
                    currentTab === 'tax'
                      ? 'text-blue-400 font-bold bg-slate-800/60'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {sub.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ✅ 4. COMPLIANCE (Expandable) */}
        <div>
          <div
            onClick={() => onNavigate('compliance')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              isTabActive('compliance')
                ? 'bg-slate-800 text-white border border-slate-700/80'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
            title="Compliance - Compliance health, deadlines, government updates and MCA/ROC"
          >
            <div className="flex items-center gap-3 min-w-0">
              <ShieldCheck className={`w-4 h-4 shrink-0 ${isTabActive('compliance') ? 'text-emerald-400' : ''}`} />
              {!isCollapsed && <span className="truncate">Compliance</span>}
            </div>

            {!isCollapsed && (
              <div className="flex items-center gap-1.5">
                {urgentComplianceCount > 0 && (
                  <span className="text-[10px] bg-rose-500/20 text-rose-300 border border-rose-500/40 px-1.5 py-0.2 rounded font-bold">
                    {urgentComplianceCount}
                  </span>
                )}
                <button
                  type="button"
                  onClick={(e) => toggleCategory('compliance', e)}
                  aria-label={expandedCategories.compliance ? "Collapse Compliance section" : "Expand Compliance section"}
                  aria-expanded={!!expandedCategories.compliance}
                  className="p-1 text-slate-400 hover:text-white rounded cursor-pointer"
                >
                  {expandedCategories.compliance ? (
                    <ChevronDown className="w-3.5 h-3.5" aria-hidden="true" />
                  ) : (
                    <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                  )}
                </button>
              </div>
            )}
          </div>

          {!isCollapsed && expandedCategories.compliance && (
            <div className="ml-4 pl-3 border-l border-slate-800 my-1 space-y-0.5">
              {[
                { id: 'health', label: 'Compliance Health (Score 96)' },
                { id: 'deadlines', label: 'Upcoming Actions & Cutoffs' },
                { id: 'updates', label: 'Government Circulars' },
                { id: 'mca', label: 'MCA / ROC Secretarial' },
              ].map((sub) => (
                <button
                  key={sub.id}
                  type="button"
                  onClick={() => onNavigate('compliance')}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-medium text-slate-400 hover:text-slate-200"
                >
                  {sub.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* 📁 5. DOCUMENTS */}
        <button
          type="button"
          onClick={() => onNavigate('documents')}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            isTabActive('documents')
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
          }`}
          title="Documents - Financial and compliance documents"
        >
          <FolderLock className="w-4 h-4 shrink-0" />
          {!isCollapsed && <span className="truncate">Documents</span>}
        </button>

        {/* 🤖 6. AI (Expandable) */}
        <div>
          <div
            onClick={() => onNavigate('ai')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              isTabActive('ai', ['ask_ai'])
                ? 'bg-slate-800 text-white border border-slate-700/80'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
            title="AI - Ask Finaura, AI insights and AI alerts"
          >
            <div className="flex items-center gap-3 min-w-0">
              <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
              {!isCollapsed && (
                <div className="flex items-center gap-2 truncate">
                  <span className="truncate">AI Intelligence</span>
                  <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.2 bg-emerald-500/20 text-emerald-300 rounded border border-emerald-500/30">
                    Live
                  </span>
                </div>
              )}
            </div>

            {!isCollapsed && (
              <button
                type="button"
                onClick={(e) => toggleCategory('ai', e)}
                aria-label={expandedCategories.ai ? "Collapse AI Intelligence section" : "Expand AI Intelligence section"}
                aria-expanded={!!expandedCategories.ai}
                className="p-1 text-slate-400 hover:text-white rounded cursor-pointer"
              >
                {expandedCategories.ai ? (
                  <ChevronDown className="w-3.5 h-3.5" aria-hidden="true" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                )}
              </button>
            )}
          </div>

          {!isCollapsed && expandedCategories.ai && (
            <div className="ml-4 pl-3 border-l border-slate-800 my-1 space-y-0.5">
              {[
                { id: 'chat', label: 'Ask Finaura Chat' },
                { id: 'reasoner', label: 'Tax Act 2025 Reasoner' },
                { id: 'insights', label: 'Proactive Insights' },
                { id: 'alerts', label: 'AI Alerts' },
              ].map((sub) => (
                <button
                  key={sub.id}
                  type="button"
                  onClick={() => onNavigate('ai')}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-medium text-slate-400 hover:text-slate-200"
                >
                  {sub.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* 👨💼 7. PROFESSIONALS */}
        <div>
          <div
            onClick={() => onNavigate('professionals')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              isTabActive('professionals', ['ca_services'])
                ? 'bg-slate-800 text-white border border-slate-700/80'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
            title="Professionals - CA, accountant, auditor and other professional services"
          >
            <div className="flex items-center gap-3 min-w-0">
              <UserCheck className="w-4 h-4 shrink-0 text-amber-400" />
              {!isCollapsed && <span className="truncate">Professionals</span>}
            </div>

            {!isCollapsed && (
              <button
                type="button"
                onClick={(e) => toggleCategory('professionals', e)}
                aria-label={expandedCategories.professionals ? "Collapse Professionals section" : "Expand Professionals section"}
                aria-expanded={!!expandedCategories.professionals}
                className="p-1 text-slate-400 hover:text-white rounded cursor-pointer"
              >
                {expandedCategories.professionals ? (
                  <ChevronDown className="w-3.5 h-3.5" aria-hidden="true" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                )}
              </button>
            )}
          </div>

          {!isCollapsed && expandedCategories.professionals && (
            <div className="ml-4 pl-3 border-l border-slate-800 my-1 space-y-0.5">
              {[
                { id: 'ca', label: 'CA Marketplace' },
                { id: 'active', label: 'Active CA Requests (1)' },
                { id: 'audit', label: 'Book Statutory Audit' },
              ].map((sub) => (
                <button
                  key={sub.id}
                  type="button"
                  onClick={() => onNavigate('professionals')}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-medium text-slate-400 hover:text-slate-200"
                >
                  {sub.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* 📅 8. CALENDAR */}
        <button
          type="button"
          onClick={() => onNavigate('calendar')}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            isTabActive('calendar')
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
          }`}
          title="Calendar - Finance, tax, compliance and business tasks"
        >
          <Calendar className="w-4 h-4 shrink-0" />
          {!isCollapsed && <span className="truncate">Calendar</span>}
        </button>

        {/* 4. MORE SECTION (Collapsible) */}
        <div className="pt-2 border-t border-slate-800/80">
          {!isCollapsed ? (
            <div>
              <button
                type="button"
                onClick={(e) => toggleCategory('more', e)}
                className="w-full flex items-center justify-between px-3 py-2 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                <span>MORE</span>
                {expandedCategories.more ? (
                  <ChevronDown className="w-3.5 h-3.5" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5" />
                )}
              </button>

              {expandedCategories.more && (
                <div className="space-y-0.5 pl-1 animate-in fade-in duration-100">
                  {[
                    { id: 'customers', label: 'Customers', icon: Users },
                    { id: 'vendors', label: 'Vendors (43B)', icon: Building },
                    { id: 'payroll', label: 'Payroll', icon: DollarSign },
                    { id: 'inventory', label: 'Inventory', icon: Package },
                    { id: 'reports', label: 'Reports', icon: BarChart3 },
                    { id: 'integrations', label: 'Integrations', icon: PlugZap },
                  ].map((sub) => {
                    const SubIcon = sub.icon;
                    return (
                      <button
                        key={sub.id}
                        type="button"
                        onClick={() => onNavigate(sub.id as NavTab)}
                        className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-colors cursor-pointer ${
                          currentTab === sub.id
                            ? 'bg-slate-800 text-emerald-400 font-bold'
                            : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                        }`}
                      >
                        <SubIcon className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">{sub.label}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          ) : (
            <div className="flex justify-center py-2">
              <div className="w-6 h-0.5 bg-slate-800 rounded" />
            </div>
          )}
        </div>

      </nav>

      {/* 5. UTILITY & SYSTEM NAVIGATION */}
      <div className="p-2 border-t border-slate-800/80 bg-slate-950/40 space-y-0.5">
        {!isCollapsed && (
          <div className="px-3 pt-1 pb-1 text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
            System &amp; Support
          </div>
        )}
        
        {/* Help */}
        <button
          type="button"
          onClick={onOpenHelp}
          className="w-full flex items-center gap-3 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800/60 cursor-pointer transition-colors"
          title="Help & Guidance"
        >
          <HelpCircle className="w-4 h-4 shrink-0 text-slate-400" />
          {!isCollapsed && <span>Help</span>}
        </button>

        {/* Notifications */}
        <button
          type="button"
          onClick={onOpenNotifications}
          className="w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800/60 cursor-pointer transition-colors"
          title="Notifications"
        >
          <div className="flex items-center gap-3">
            <Bell className="w-4 h-4 shrink-0 text-slate-400" />
            {!isCollapsed && <span>Notifications</span>}
          </div>
          {!isCollapsed && (
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
          )}
        </button>

        {/* Plan & Billing */}
        <button
          type="button"
          onClick={() => onNavigate('billing')}
          className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
            currentTab === 'billing'
              ? 'bg-slate-800 text-emerald-400 font-bold'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
          title="Plan & Billing"
        >
          <div className="flex items-center gap-3">
            <CreditCard className="w-4 h-4 shrink-0 text-slate-400" />
            {!isCollapsed && <span>Plan &amp; Billing</span>}
          </div>
          {!isCollapsed && (
            <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              {currentPlanId.toUpperCase()}
            </span>
          )}
        </button>

        {/* Settings */}
        <button
          type="button"
          onClick={onOpenSettings}
          className="w-full flex items-center gap-3 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800/60 cursor-pointer transition-colors"
          title="Settings"
        >
          <Settings className="w-4 h-4 shrink-0 text-slate-400" />
          {!isCollapsed && <span>Settings</span>}
        </button>

        {/* Profile Card */}
        <div className="pt-1 border-t border-slate-800/60">
          {!isCollapsed ? (
            <div className="p-2 bg-slate-800/60 rounded-xl flex items-center justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-7 h-7 rounded-full bg-emerald-700 text-white flex items-center justify-center text-xs font-bold shrink-0">
                  {currentUser?.name ? currentUser.name.charAt(0) : 'A'}
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-white truncate">
                    {currentUser?.name || 'Aura Director'}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate">
                    {currentUser?.email || 'director@aurastudio.in'}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={onSignOut}
                className="p-1 text-slate-400 hover:text-rose-400 rounded cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={onOpenSettings}
              className="w-full flex justify-center py-1 cursor-pointer"
            >
              <div className="w-8 h-8 rounded-full bg-emerald-700 text-white flex items-center justify-center text-xs font-bold">
                {currentUser?.name ? currentUser.name.charAt(0) : 'A'}
              </div>
            </button>
          )}
        </div>

      </div>
    </aside>
  );
};
