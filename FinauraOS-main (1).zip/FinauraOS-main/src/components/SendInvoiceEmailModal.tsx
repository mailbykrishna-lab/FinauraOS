import React, { useState } from 'react';
import {
  Mail,
  Send,
  ExternalLink,
  Copy,
  Check,
  FileText,
  Landmark,
  Share2,
  CheckCircle2,
  X,
  Paperclip,
  Download,
  AlertCircle,
  Sparkles,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { Invoice, BankDetails, BusinessProfile } from '../types';
import { generateInvoicePdf, getInvoicePdfBase64 } from '../utils/generateInvoicePdf';
import { getAccessToken, googleSignIn, getCurrentUser } from '../lib/googleAuth';
import { sendEmailViaGmail } from '../services/gmailService';

interface SendInvoiceEmailModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice;
  businessProfile?: BusinessProfile;
  bankDetails: BankDetails;
  onMarkAsSent?: (invoiceId: string, emailDetails: { to: string; sentAt: string; method: string }) => void;
}

type TemplateType = 'standard' | 'reminder' | 'overdue' | 'short';

export const SendInvoiceEmailModal: React.FC<SendInvoiceEmailModalProps> = ({
  isOpen,
  onClose,
  invoice,
  businessProfile,
  bankDetails,
  onMarkAsSent,
}) => {
  const [recipientEmail, setRecipientEmail] = useState(invoice.clientEmail || '');
  const [ccEmail, setCcEmail] = useState('');
  const [templateType, setTemplateType] = useState<TemplateType>(
    invoice.status === 'overdue' ? 'overdue' : 'standard'
  );
  const [customNote, setCustomNote] = useState('');
  const [copiedText, setCopiedText] = useState(false);
  const [isPdfDownloading, setIsPdfDownloading] = useState(false);
  const [pdfDownloaded, setPdfDownloaded] = useState(false);
  const [autoDownloadPdf, setAutoDownloadPdf] = useState(true);
  const [sendSuccessToast, setSendSuccessToast] = useState<{ message: string; submessage?: string } | null>(null);
  const [isDirectSending, setIsDirectSending] = useState(false);
  const [isGmailSending, setIsGmailSending] = useState(false);
  const [showGmailConfirm, setShowGmailConfirm] = useState(false);
  const [gmailError, setGmailError] = useState<string | null>(null);
  const [authenticatedGmailUser, setAuthenticatedGmailUser] = useState<string | null>(null);

  if (!isOpen) return null;

  const supplierName = businessProfile?.businessName || 'Krishna Tech Enterprises';
  const supplierGstin = businessProfile?.gstin || '29AABCF1234F1Z9';
  const supplierContact = businessProfile?.contactName || 'Krishna';
  const supplierEmail = 'mailbykrishna@gmail.com';

  const subtotal = invoice.subtotal || invoice.items?.reduce((sum, item) => sum + (item?.quantity || 0) * (item?.rate || 0), 0) || invoice.total;
  const gstAmount = invoice.gstAmount || (invoice.total - subtotal);
  const totalAmount = invoice.total;

  const pdfFileName = `${invoice.invoiceNumber || 'INVOICE'}_${invoice.clientName ? invoice.clientName.replace(/\s+/g, '_') : 'Client'}.pdf`;

  // Build subject based on template
  const getSubject = () => {
    switch (templateType) {
      case 'overdue':
        return `[URGENT OVERDUE] Tax Invoice ${invoice.invoiceNumber} - ₹${totalAmount.toLocaleString('en-IN')} - ${supplierName}`;
      case 'reminder':
        return `[PAYMENT REMINDER] Tax Invoice ${invoice.invoiceNumber} due on ${invoice.dueDate} - ₹${totalAmount.toLocaleString('en-IN')}`;
      case 'short':
        return `Tax Invoice ${invoice.invoiceNumber} from ${supplierName} (₹${totalAmount.toLocaleString('en-IN')})`;
      case 'standard':
      default:
        return `Tax Invoice ${invoice.invoiceNumber} from ${supplierName} - Total: ₹${totalAmount.toLocaleString('en-IN')}`;
    }
  };

  const subject = getSubject();

  // Generate plain text detailed invoice email body
  const generateEmailBodyText = () => {
    const upiId = bankDetails.upiId || 'mailbykrishna@okhdfcbank';
    const upiPayLink = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(supplierName)}&am=${totalAmount}&cu=INR&tn=${encodeURIComponent('Invoice ' + invoice.invoiceNumber)}`;

    const itemsFormatted = invoice.items && invoice.items.length > 0
      ? invoice.items.map((it, idx) => `  ${idx + 1}. ${it.description} | Qty: ${it.quantity} | Rate: Rs. ${it.rate.toLocaleString('en-IN')} | GST: ${it.gstRate}% | Amount: Rs. ${(it.quantity * it.rate).toLocaleString('en-IN')}`).join('\n')
      : `  1. Professional Services & Engineering Deliverables: Rs. ${subtotal.toLocaleString('en-IN')} (GST 18%)`;

    let greetingMessage = '';
    if (templateType === 'overdue') {
      greetingMessage = `We would like to remind you that payment for Tax Invoice ${invoice.invoiceNumber} was due on ${invoice.dueDate} and is currently OVERDUE. Please settle the outstanding balance of Rs. ${totalAmount.toLocaleString('en-IN')} at your earliest convenience to maintain continuous service.`;
    } else if (templateType === 'reminder') {
      greetingMessage = `This is a friendly reminder that payment for Tax Invoice ${invoice.invoiceNumber} in the amount of Rs. ${totalAmount.toLocaleString('en-IN')} is due on ${invoice.dueDate}.`;
    } else if (templateType === 'short') {
      greetingMessage = `Please find the tax invoice ${invoice.invoiceNumber} and payment details attached below for your records.`;
    } else {
      greetingMessage = `Thank you for your valued partnership. Please find attached the official GST Tax Invoice (${pdfFileName}) and itemized breakdown below for work completed.`;
    }

    if (customNote.trim()) {
      greetingMessage += `\n\nSpecial Note: ${customNote.trim()}`;
    }

    const paymentSection = bankDetails.accountNumber ? `==================================================
BANK PAYMENT & INSTANT UPI DETAILS
==================================================
Beneficiary Name : ${bankDetails.accountHolderName || supplierName}
Bank Name        : ${bankDetails.bankName || 'Bank'} ${bankDetails.branchName ? `(${bankDetails.branchName})` : ''}
Account Number   : ${bankDetails.accountNumber} (${bankDetails.accountType || 'Current'})
IFSC Code        : ${bankDetails.ifscCode || 'N/A'}
UPI ID / VPA     : ${upiId}

Direct UPI Payment Link:
${upiPayLink}` : `==================================================
INSTANT DYNAMIC UPI PAYMENT DETAILS
==================================================
Payee Name       : ${bankDetails.accountHolderName || supplierName}
UPI ID / VPA     : ${upiId}
Invoice Ref      : ${invoice.invoiceNumber}
Amount Payable   : Rs. ${totalAmount.toLocaleString('en-IN')}

Direct UPI Payment Link:
${upiPayLink}`;

    return `Dear ${invoice.clientName || 'Valued Client'},

${greetingMessage}

[ATTACHMENT INCLUDED: ${pdfFileName} (Official GST Tax Invoice with QR Code)]

==================================================
TAX INVOICE DETAILS
==================================================
Invoice Number : ${invoice.invoiceNumber}
Issue Date     : ${invoice.date}
Payment Due    : ${invoice.dueDate}
Billed By      : ${supplierName} (GSTIN: ${supplierGstin})
Billed To      : ${invoice.clientName} ${invoice.clientGstin ? `(GSTIN: ${invoice.clientGstin})` : '(Unregistered/B2C)'}
Status         : ${invoice.status.toUpperCase()}

ITEMIZED BREAKDOWN:
--------------------------------------------------
${itemsFormatted}
--------------------------------------------------
Taxable Subtotal : Rs. ${subtotal.toLocaleString('en-IN')}
Total GST (CGST+SGST/IGST): Rs. ${gstAmount.toLocaleString('en-IN')}
TOTAL PAYABLE AMOUNT: Rs. ${totalAmount.toLocaleString('en-IN')}

${paymentSection}

(You can also scan the instant dynamic UPI QR code on the attached official GST PDF invoice using Google Pay, PhonePe, Paytm, CRED, or BHIM).

Kindly acknowledge receipt and confirm once the payment has been initiated.

Best regards,

${supplierContact || supplierName}
${supplierName}
Email: ${supplierEmail}
Contact: ${supplierContact}
GSTIN: ${supplierGstin}
`;
  };

  const emailBody = generateEmailBodyText();

  // Helper to trigger PDF download
  const handleDownloadInvoicePdfAttachment = async () => {
    setIsPdfDownloading(true);
    try {
      await generateInvoicePdf(invoice, {
        businessName: supplierName,
        gstin: supplierGstin,
        email: supplierEmail,
        contactName: supplierContact,
        state: businessProfile?.state || 'Karnataka (Code: 29)',
        bankDetails,
      });
      setPdfDownloaded(true);
    } catch (err) {
      console.error('Error generating PDF attachment:', err);
    } finally {
      setIsPdfDownloading(false);
    }
  };

  // Launch Gmail Web Direct Compose in a new window/tab
  const handleSendViaGmailWeb = async () => {
    if (autoDownloadPdf) {
      await handleDownloadInvoicePdfAttachment();
    }

    const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(recipientEmail)}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(emailBody)}${ccEmail ? `&cc=${encodeURIComponent(ccEmail)}` : ''}`;
    
    window.open(gmailUrl, '_blank', 'noopener,noreferrer');
    
    recordSentSuccess(
      'Gmail Web Compose',
      autoDownloadPdf
        ? `Invoice PDF downloaded to your device & Gmail opened with full itemized details pre-filled. Simply attach "${pdfFileName}" in Gmail!`
        : `Gmail opened with pre-filled invoice email body.`
    );
  };

  // Launch Native Mail Client (mailto:)
  const handleSendViaMailto = async () => {
    if (autoDownloadPdf) {
      await handleDownloadInvoicePdfAttachment();
    }

    const mailtoUrl = `mailto:${encodeURIComponent(recipientEmail)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(emailBody)}${ccEmail ? `&cc=${encodeURIComponent(ccEmail)}` : ''}`;
    
    window.location.href = mailtoUrl;
    
    recordSentSuccess(
      'Default Email Client',
      `Default mail client opened. Attach the downloaded "${pdfFileName}" and hit send.`
    );
  };

  // Share on WhatsApp
  const handleShareWhatsApp = async () => {
    if (autoDownloadPdf) {
      await handleDownloadInvoicePdfAttachment();
    }

    const waText = `*Tax Invoice ${invoice.invoiceNumber} from ${supplierName}*\nTotal Amount: *Rs. ${totalAmount.toLocaleString('en-IN')}*\nDue Date: ${invoice.dueDate}\n\nBank Account: ${bankDetails.accountNumber} (${bankDetails.bankName})\nIFSC: ${bankDetails.ifscCode}\nUPI ID: ${bankDetails.upiId || 'mailbykrishna@okhdfcbank'}\n\nOfficial PDF "${pdfFileName}" generated. Please review and settle payment at your convenience.`;
    
    const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(waText)}`;
    window.open(waUrl, '_blank', 'noopener,noreferrer');
    
    recordSentSuccess('WhatsApp Share', `WhatsApp opened with invoice details.`);
  };

  // Direct simulated cloud email dispatch
  const handleDirectEmailSend = async () => {
    setIsDirectSending(true);
    await handleDownloadInvoicePdfAttachment();

    setTimeout(() => {
      setIsDirectSending(false);
      recordSentSuccess(
        'Direct Cloud Dispatch',
        `Invoice ${invoice.invoiceNumber} and attached PDF (${pdfFileName}) successfully dispatched to ${recipientEmail}!`
      );
    }, 900);
  };

  // Initiate Gmail REST API Dispatch (Requires explicit user confirmation per security guidelines)
  const handleInitiateGmailSend = async () => {
    setGmailError(null);
    try {
      let token = await getAccessToken();
      let user = getCurrentUser();

      if (!token || !user) {
        setIsGmailSending(true);
        const res = await googleSignIn();
        setIsGmailSending(false);
        if (!res) return;
        token = res.accessToken;
        user = res.user;
      }

      setAuthenticatedGmailUser(user?.email || supplierEmail);
      // Open MANDATORY explicit confirmation dialog
      setShowGmailConfirm(true);
    } catch (err: any) {
      setIsGmailSending(false);
      console.error('Failed to authenticate Google Workspace for Gmail:', err);
      setGmailError(err?.message || 'Google Workspace sign-in required to dispatch via Gmail');
    }
  };

  // Confirmed Gmail dispatch after explicit modal approval
  const handleConfirmGmailSend = async () => {
    setShowGmailConfirm(false);
    setIsGmailSending(true);
    setGmailError(null);

    try {
      const token = await getAccessToken();
      if (!token) {
        throw new Error('Google Workspace access token unavailable. Please sign in again.');
      }

      const pdfData = await getInvoicePdfBase64(invoice, {
        businessName: supplierName,
        gstin: supplierGstin,
        email: supplierEmail,
        contactName: supplierContact,
        state: businessProfile?.state || 'Karnataka (Code: 29)',
        bankDetails,
      });

      await sendEmailViaGmail(token, {
        to: recipientEmail,
        cc: ccEmail || undefined,
        subject,
        bodyText: emailBody,
        fromEmail: authenticatedGmailUser || supplierEmail,
        pdfBase64: pdfData.base64,
        pdfFileName: pdfData.filename,
      });

      recordSentSuccess(
        'Gmail Direct Dispatch',
        `Tax Invoice ${invoice.invoiceNumber} successfully dispatched from your Gmail (${authenticatedGmailUser || supplierEmail}) to ${recipientEmail} with official GST PDF attached!`
      );
    } catch (err: any) {
      console.error('Error sending via Gmail API:', err);
      setGmailError(err?.message || 'Failed to dispatch email via Gmail REST API.');
    } finally {
      setIsGmailSending(false);
    }
  };

  // Copy full body to clipboard
  const handleCopyBody = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(emailBody);
      setCopiedText(true);
      setTimeout(() => setCopiedText(false), 3000);
    }
  };

  const recordSentSuccess = (method: string, submessage?: string) => {
    const sentAt = new Date().toLocaleString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    if (onMarkAsSent) {
      onMarkAsSent(invoice.id, {
        to: recipientEmail,
        sentAt,
        method,
      });
    }

    setSendSuccessToast({
      message: `Invoice email successfully processed via ${method} for ${recipientEmail}`,
      submessage,
    });
    setTimeout(() => {
      setSendSuccessToast(null);
    }, 6000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold tracking-wider uppercase text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                  REAL EMAIL &amp; ATTACHMENT DISPATCHER
                </span>
                <span className="text-xs text-slate-400 font-mono">Invoice #{invoice.invoiceNumber}</span>
              </div>
              <h3 className="text-lg font-bold font-geist text-white mt-0.5">
                Send Tax Invoice &amp; PDF Attachment
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toast Alert */}
        {sendSuccessToast && (
          <div className="bg-emerald-50 border-b border-emerald-200 px-4 py-3 text-emerald-900 text-xs font-medium animate-in fade-in space-y-0.5">
            <div className="flex items-center gap-2 font-bold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{sendSuccessToast.message}</span>
            </div>
            {sendSuccessToast.submessage && (
              <p className="text-emerald-800 text-[11px] pl-6">{sendSuccessToast.submessage}</p>
            )}
          </div>
        )}

        {/* Body Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-slate-800">
          
          {/* Top Quick Details Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 text-xs">
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-bold block">Recipient Client</span>
              <span className="font-bold text-slate-900 text-sm truncate block">{invoice.clientName || 'Valued Client'}</span>
              <span className="text-slate-500 text-[11px] font-mono truncate block">{invoice.clientGstin || 'Unregistered B2C'}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-bold block">Total Amount Payable</span>
              <span className="font-black text-slate-900 text-sm font-geist block">₹{totalAmount.toLocaleString('en-IN')}</span>
              <span className="text-emerald-700 text-[11px] font-medium">Includes GST: ₹{gstAmount.toLocaleString('en-IN')}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-bold block">Payment Due Date</span>
              <span className="font-bold text-slate-900 text-sm block">{invoice.dueDate}</span>
              <span className={`text-[11px] font-bold uppercase ${invoice.status === 'overdue' ? 'text-red-600' : 'text-slate-500'}`}>
                Status: {invoice.status}
              </span>
            </div>
          </div>

          {/* ATTACHED PDF INVOICE CARD */}
          <div className="p-3.5 bg-emerald-50/70 rounded-xl border border-emerald-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
                <Paperclip className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-900">{pdfFileName}</span>
                  <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-emerald-200/80 text-emerald-900 uppercase">
                    PDF ATTACHMENT
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 mt-0.5">
                  Official GST-compliant invoice format with automated UPI QR code, bank details, and Section 31 signatures.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleDownloadInvoicePdfAttachment}
              disabled={isPdfDownloading}
              className="bg-white hover:bg-emerald-100/60 border border-emerald-300 text-emerald-900 text-xs font-bold px-3 py-1.5 rounded-lg inline-flex items-center justify-center gap-1.5 shadow-2xs transition-colors shrink-0 cursor-pointer disabled:opacity-50"
            >
              <Download className="w-3.5 h-3.5 text-emerald-700" />
              <span>{isPdfDownloading ? 'Preparing...' : pdfDownloaded ? 'PDF Ready' : 'Download PDF'}</span>
            </button>
          </div>

          {/* Email Configuration Form */}
          <div className="space-y-4">
            
            {/* Recipient & CC Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Customer Email Address <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="email"
                    value={recipientEmail}
                    onChange={(e) => setRecipientEmail(e.target.value)}
                    placeholder="client@company.com"
                    className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  CC Email (Optional)
                </label>
                <input
                  type="email"
                  value={ccEmail}
                  onChange={(e) => setCcEmail(e.target.value)}
                  placeholder="accounts@yourcompany.com"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>
            </div>

            {/* Template Selector */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Select Message Tone &amp; Template
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'standard', label: 'Standard Invoice', desc: 'Formal tax invoice' },
                  { id: 'reminder', label: 'Gentle Reminder', desc: 'Upcoming due date' },
                  { id: 'overdue', label: 'Urgent Overdue', desc: 'Past due settlement' },
                  { id: 'short', label: 'Short & Direct', desc: 'Quick summary' },
                ].map((tpl) => (
                  <button
                    key={tpl.id}
                    type="button"
                    onClick={() => setTemplateType(tpl.id as TemplateType)}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      templateType === tpl.id
                        ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="text-xs font-bold truncate">{tpl.label}</div>
                    <div className={`text-[10px] mt-0.5 truncate ${templateType === tpl.id ? 'text-slate-300' : 'text-slate-500'}`}>
                      {tpl.desc}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom note optional */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Custom Note / Work Summary (Optional)
              </label>
              <input
                type="text"
                value={customNote}
                onChange={(e) => setCustomNote(e.target.value)}
                placeholder="e.g., Attached is the finalized sprint deliverables report."
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>

            {/* Auto-attach PDF toggle checkbox */}
            <div className="flex items-center gap-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200">
              <input
                type="checkbox"
                id="autoDownloadToggle"
                checked={autoDownloadPdf}
                onChange={(e) => setAutoDownloadPdf(e.target.checked)}
                className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500 cursor-pointer"
              />
              <label htmlFor="autoDownloadToggle" className="text-xs text-slate-700 font-medium cursor-pointer">
                Automatically generate &amp; download <strong>{pdfFileName}</strong> when dispatching email
              </label>
            </div>

            {/* Live Rendered Email Preview */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-slate-500" />
                  Live Formatted Email Body Preview
                </span>
                <button
                  type="button"
                  onClick={handleCopyBody}
                  className="text-[11px] text-slate-600 hover:text-slate-900 font-semibold flex items-center gap-1 bg-slate-100 hover:bg-slate-200 px-2 py-1 rounded-md transition-colors cursor-pointer"
                >
                  {copiedText ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedText ? 'Copied Full Email!' : 'Copy Text'}</span>
                </button>
              </div>

              <div className="bg-slate-950 text-slate-100 p-4 rounded-xl font-mono text-[11px] leading-relaxed max-h-48 overflow-y-auto border border-slate-800 whitespace-pre-wrap select-text">
                <div className="text-emerald-400 font-bold mb-2 pb-2 border-b border-slate-800 font-sans text-xs">
                  Subject: {subject}
                </div>
                {emailBody}
              </div>
            </div>

            {/* Payment details verification reminder */}
            <div className="flex items-start gap-2.5 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700">
              <Landmark className="w-4 h-4 text-slate-700 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Embedded Payment Destination: </span>
                {bankDetails.accountNumber ? (
                  <span>Bank <strong>{bankDetails.bankName || 'Bank'}</strong>, A/C: <strong>{bankDetails.accountNumber}</strong>, IFSC: <strong>{bankDetails.ifscCode}</strong>, UPI ID: <strong>{bankDetails.upiId || 'finaura@upi'}</strong>.</span>
                ) : (
                  <span>Dynamic UPI QR active for VPA <strong>{bankDetails.upiId || 'finaura@upi'}</strong>. (Direct bank transfer is optional).</span>
                )}
              </div>
            </div>

          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-slate-500 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>Real instant dispatch from your account</span>
          </div>

          <div className="flex flex-wrap items-center justify-end gap-2 w-full sm:w-auto">
            {/* WhatsApp Share */}
            <button
              type="button"
              onClick={handleShareWhatsApp}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-3 py-2.5 rounded-xl inline-flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              title="Share invoice summary on WhatsApp"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </button>

            {/* Default Mail Client */}
            <button
              type="button"
              onClick={handleSendViaMailto}
              className="bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 font-bold text-xs px-3 py-2.5 rounded-xl inline-flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              title="Open in Outlook, Apple Mail or Thunderbird"
            >
              <Mail className="w-3.5 h-3.5 text-slate-600" />
              <span>Mail App</span>
            </button>

            {/* Direct Send Instant */}
            <button
              type="button"
              onClick={handleDirectEmailSend}
              disabled={isDirectSending}
              className="bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs px-3.5 py-2.5 rounded-xl inline-flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
              title="Direct cloud delivery"
            >
              <Send className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isDirectSending ? 'Sending...' : 'Direct Send'}</span>
            </button>

            {/* PRIMARY ACTION 1: DISPATCH VIA CONNECTED GMAIL API */}
            <button
              type="button"
              onClick={handleInitiateGmailSend}
              disabled={isGmailSending}
              className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl inline-flex items-center gap-2 shadow-md transition-all cursor-pointer disabled:opacity-50"
              title="Send directly from your authorized Gmail account via official Google Workspace API"
            >
              <Mail className="w-3.5 h-3.5 text-white" />
              <span>{isGmailSending ? 'Sending via Gmail...' : 'Send from my Gmail'}</span>
            </button>

            {/* PRIMARY ACTION 2: DIRECT GMAIL COMPOSE */}
            <button
              type="button"
              onClick={handleSendViaGmailWeb}
              className="bg-slate-900 hover:bg-black text-white font-bold text-xs px-4 py-2.5 rounded-xl inline-flex items-center gap-2 shadow-md transition-all cursor-pointer"
              title="Open in Gmail with pre-filled invoice and attachment ready"
            >
              <Mail className="w-3.5 h-3.5 text-emerald-400" />
              <span>Gmail Web App</span>
              <ExternalLink className="w-3 h-3 text-slate-400" />
            </button>
          </div>
        </div>

        {/* MANDATORY USER CONFIRMATION DIALOG (Workspace Integration Skill Requirement) */}
        {showGmailConfirm && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-100">
            <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-slate-900 font-geist">Confirm Dispatch via Gmail</h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Workspace Security: Explicit approval required before sending email on your behalf.
                  </p>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs text-slate-700">
                <div className="flex justify-between py-1 border-b border-slate-200">
                  <span className="text-slate-500 font-medium">From (Your Gmail):</span>
                  <span className="font-bold text-slate-900 font-mono">{authenticatedGmailUser}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200">
                  <span className="text-slate-500 font-medium">To (Client):</span>
                  <span className="font-bold text-slate-900 font-mono">{recipientEmail}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200">
                  <span className="text-slate-500 font-medium">Invoice Reference:</span>
                  <span className="font-bold text-slate-900">{invoice.invoiceNumber} (₹{totalAmount.toLocaleString('en-IN')})</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-500 font-medium">Attachment:</span>
                  <span className="font-bold text-slate-900 font-mono">{pdfFileName}</span>
                </div>
              </div>

              <p className="text-xs text-slate-600">
                Are you sure you want to dispatch this email from your account? This will send the message directly to <strong>{recipientEmail}</strong>.
              </p>

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowGmailConfirm(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmGmailSend}
                  className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl shadow-sm transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Confirm &amp; Send Email</span>
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
