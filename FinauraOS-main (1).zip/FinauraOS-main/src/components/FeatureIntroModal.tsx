import React from 'react';
import { Sparkles, CheckCircle2, ArrowRight, ShieldCheck, X } from 'lucide-react';
import { FeatureIntro } from '../types';

interface FeatureIntroModalProps {
  intro: FeatureIntro;
  onClose: () => void;
}

export const FeatureIntroModal: React.FC<FeatureIntroModalProps> = ({ intro, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 md:p-8 shadow-xl border border-slate-200 relative overflow-hidden">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1.5 rounded-full hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-3">
          <span className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 text-slate-800 text-xs font-bold rounded-full uppercase tracking-wider border border-slate-200">
            <Sparkles className="w-3.5 h-3.5 text-slate-600" />
            {intro.badge}
          </span>
        </div>

        <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight mb-2">
          {intro.title}
        </h2>

        <p className="text-sm text-slate-600 mb-6 leading-relaxed">
          {intro.headline}
        </p>

        {/* 4 Standard Explanatory Pillars */}
        <div className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs mb-6">
          <div>
            <span className="font-bold text-slate-900 block mb-0.5">What changed?</span>
            <span className="text-slate-600 leading-relaxed block">{intro.whatChanged}</span>
          </div>

          <div>
            <span className="font-bold text-slate-900 block mb-0.5">Does it affect me?</span>
            <span className="text-slate-600 leading-relaxed block">{intro.doesItAffectMe}</span>
          </div>

          <div>
            <span className="font-bold text-slate-900 block mb-0.5">What should I do?</span>
            <span className="text-slate-800 font-semibold leading-relaxed block">{intro.whatShouldIDo}</span>
          </div>

          <div className="pt-2 border-t border-slate-200 flex items-center gap-1.5 text-[11px] text-slate-500">
            <ShieldCheck className="w-3.5 h-3.5 text-slate-600" />
            <span>Source: {intro.source}</span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full bg-slate-900 text-white hover:bg-slate-800 font-semibold py-3 px-6 rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all active:scale-[0.99]"
        >
          <span>GOT IT — SHOW MY WORKSPACE</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
