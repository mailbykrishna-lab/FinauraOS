import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  ArrowRight,
  ArrowLeft,
  Upload,
  FileSpreadsheet,
  FileText,
  CreditCard,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Building2,
  Layers,
  ArrowUpRight,
  TrendingUp,
  Cpu,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { BusinessProfile, UserPersona, BusinessType, GSTStatus, PlanTier } from '../types';
import { defaultEmptyBusinessProfile } from '../lib/profile';
import { FinauraLogo } from './FinauraLogo';
import { getRecommendedPlan, getPlan } from '../lib/plans';

interface OnboardingFlowProps {
  onComplete: (profile: BusinessProfile, chosenPlan?: PlanTier) => void;
  onBack?: () => void;
  initialProfile?: BusinessProfile;
}

export const OnboardingFlow: React.FC<OnboardingFlowProps> = ({
  onComplete,
  onBack,
  initialProfile = defaultEmptyBusinessProfile,
}) => {
  // Stage in onboarding: 'welcome' | 'business' | 'finance' | 'import' | 'ai_scan' | 'first_moment' | 'plan_recommendation'
  const [stage, setStage] = useState<'welcome' | 'business' | 'finance' | 'import' | 'ai_scan' | 'first_moment' | 'plan_recommendation'>('welcome');
  
  // Profile form data
  const [profile, setProfile] = useState<BusinessProfile>(initialProfile || defaultEmptyBusinessProfile);
  
  // Finance step sub-progress (e.g. 3 of 5)
  const [financeStep, setFinanceStep] = useState(1);
  const [selectedImportSource, setSelectedImportSource] = useState<'bank' | 'invoices' | 'expenses' | 'manual' | null>('bank');
  
  // AI scanning steps
  const [aiScanStep, setAiScanStep] = useState<'reading' | 'identifying' | 'categorizing' | 'checking' | 'completed'>('reading');

  useEffect(() => {
    if (stage === 'ai_scan') {
      const t1 = setTimeout(() => setAiScanStep('identifying'), 900);
      const t2 = setTimeout(() => setAiScanStep('categorizing'), 1800);
      const t3 = setTimeout(() => setAiScanStep('checking'), 2700);
      const t4 = setTimeout(() => setAiScanStep('completed'), 3600);
      return () => {
        clearTimeout(t1);
        clearTimeout(t2);
        clearTimeout(t3);
        clearTimeout(t4);
      };
    }
  }, [stage]);

  // Persona selections
  const personas: { id: UserPersona; title: string; desc: string; focus: string }[] = [
    { id: 'startup', title: 'Startup', desc: 'Fast growth & fundraising', focus: 'Cash runway, GST & MCA filings' },
    { id: 'msme', title: 'MSME / Business', desc: 'Trading & production', focus: 'Inventory, Cash flow & Tax offsets' },
    { id: 'agency', title: 'Agency / Studio', desc: 'Client services & retainers', focus: 'Client invoicing, Profitability & Tax' },
    { id: 'freelancer', title: 'Freelancer / Consultant', desc: 'Solo professional', focus: 'Simple invoices, 44ADA Tax & Receivables' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 md:p-6 text-slate-900 relative overflow-hidden">
      {/* Top Brand Bar */}
      <header className="fixed top-0 left-0 w-full px-6 py-4 flex items-center justify-between z-40 bg-white/90 backdrop-blur-md border-b border-slate-200">
        <FinauraLogo size="sm" />
        <div className="text-xs text-slate-500 flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>Guided Setup Active</span>
        </div>
      </header>

      {/* Main Stepper Card */}
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-sm border border-slate-200 p-6 md:p-10 relative z-10 mt-14">
        {/* Progress Tracker (4 Steps) */}
        {stage !== 'welcome' && (
          <div className="mb-8">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-500 mb-2 font-geist">
              <span className={stage === 'business' ? 'text-slate-900 font-bold' : ''}>1 Business Profile</span>
              <span>→</span>
              <span className={stage === 'finance' || stage === 'import' ? 'text-slate-900 font-bold' : ''}>2 Finance Setup</span>
              <span>→</span>
              <span className={stage === 'ai_scan' ? 'text-slate-900 font-bold' : ''}>3 Compliance & AI</span>
              <span>→</span>
              <span className={stage === 'first_moment' ? 'text-emerald-700 font-bold' : ''}>4 Ready</span>
            </div>
            <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden flex">
              <div
                className="h-full bg-slate-900 transition-all duration-500 rounded-full"
                style={{
                  width:
                    stage === 'business'
                      ? '25%'
                      : stage === 'finance' || stage === 'import'
                      ? '50%'
                      : stage === 'ai_scan'
                      ? '75%'
                      : '100%',
                }}
              ></div>
            </div>
          </div>
        )}

        {/* 01. WELCOME TO FINAURA */}
        {stage === 'welcome' && (
          <div className="text-center py-4 space-y-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-slate-100 text-3xl shadow-sm mb-2">
              👋
            </div>

            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-700 tracking-wider uppercase font-geist bg-slate-100 border border-slate-200 px-3 py-1 rounded-full">
                Step-by-Step Experience
              </span>
              <h1 className="text-2xl md:text-4xl font-black text-slate-900 font-geist tracking-tight">
                WELCOME TO FINAURA
              </h1>
              <p className="text-base md:text-lg text-slate-600 max-w-md mx-auto">
                Let's get your business finance workspace ready without needing accounting or tax expertise.
              </p>
            </div>

            {/* 4 Steps Roadmap */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-left pt-2 pb-4">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div className="w-6 h-6 rounded-full bg-slate-900 text-white text-xs font-bold flex items-center justify-center mb-2 font-geist">
                  1
                </div>
                <div className="font-bold text-xs text-slate-900">Business Profile</div>
                <div className="text-[11px] text-slate-500">Name &amp; Structure</div>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div className="w-6 h-6 rounded-full bg-slate-600 text-white text-xs font-bold flex items-center justify-center mb-2 font-geist">
                  2
                </div>
                <div className="font-bold text-xs text-slate-900">Finance Setup</div>
                <div className="text-[11px] text-slate-500">Bank &amp; Invoices</div>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div className="w-6 h-6 rounded-full bg-slate-600 text-white text-xs font-bold flex items-center justify-center mb-2 font-geist">
                  3
                </div>
                <div className="font-bold text-xs text-slate-900">Compliance Setup</div>
                <div className="text-[11px] text-slate-500">GST &amp; Deadlines</div>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div className="w-6 h-6 rounded-full bg-emerald-600 text-white text-xs font-bold flex items-center justify-center mb-2 font-geist">
                  4
                </div>
                <div className="font-bold text-xs text-slate-900">Ready</div>
                <div className="text-[11px] text-slate-500">Guided Insights</div>
              </div>
            </div>

            {/* Fast Connect Options */}
            <div className="pt-2 pb-1">
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 max-w-md mx-auto">
                <button
                  type="button"
                  onClick={() => {
                    setProfile((prev) => ({
                      ...prev,
                      contactName: prev.contactName || 'Krishna Murthy',
                      businessName: prev.businessName || 'Krishna Consulting Pvt Ltd',
                    }));
                    setStage('business');
                  }}
                  className="w-full sm:w-1/2 bg-white hover:bg-slate-50 text-slate-800 border border-slate-200 font-medium text-xs py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 shadow-xs transition-all"
                >
                  <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>Connect with Google</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setProfile((prev) => ({
                      ...prev,
                      contactName: prev.contactName || 'Apple ID User',
                      businessName: prev.businessName || 'Apple Verified Business',
                    }));
                    setStage('business');
                  }}
                  className="w-full sm:w-1/2 bg-black hover:bg-slate-900 text-white font-medium text-xs py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 shadow-xs transition-all"
                >
                  <svg className="w-3.5 h-3.5 fill-current shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.61-.75 1.04-1.8 0.92-2.85-.9.04-1.98.6-2.61 1.34-.56.65-1.05 1.71-.92 2.73 1.01.08 2.01-.47 2.61-1.22z" />
                  </svg>
                  <span>Connect with Apple</span>
                </button>
              </div>
            </div>

            <button
              onClick={() => setStage('business')}
              className="w-full sm:w-auto min-w-[240px] bg-slate-900 text-white hover:bg-slate-800 font-semibold text-base py-3.5 px-8 rounded-xl flex items-center justify-center gap-2 mx-auto shadow-sm transition-all active:scale-[0.99]"
            >
              <span>GET STARTED WITH MANUAL SETUP</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* 02. BUSINESS SETUP */}
        {stage === 'business' && (
          <div className="space-y-6">
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider font-geist">
                STEP 1 — YOUR BUSINESS
              </span>
              <h2 className="text-2xl font-black text-slate-900 font-geist tracking-tight mt-1">
                LET'S SET UP YOUR BUSINESS
              </h2>
              <p className="text-sm text-slate-600 mt-1">
                We ask only essential questions to tailor your workspace without complicated accounting terms.
              </p>
            </div>

            {/* Persona Picker for Personalized Guidance (Section 28) */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-900 block">
                How do you describe your work structure?
              </label>
              <div className="grid grid-cols-2 gap-2.5">
                {personas.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => setProfile({ ...profile, persona: p.id })}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      profile.persona === p.id
                        ? 'border-slate-900 bg-slate-100 shadow-sm ring-1 ring-slate-900'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="font-bold text-xs text-slate-900">{p.title}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">{p.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="text-xs font-bold text-slate-900 block mb-1">Your Full Name (Founder / Primary Contact)</label>
                  <input
                    type="text"
                    value={profile.contactName}
                    onChange={(e) => setProfile({ ...profile, contactName: e.target.value })}
                    placeholder="e.g. Priya Sharma"
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm focus:outline-none focus:border-slate-900 focus:ring-1 focus:ring-slate-900"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-900 block mb-1">Business Name</label>
                  <input
                    type="text"
                    value={profile.businessName}
                    onChange={(e) => setProfile({ ...profile, businessName: e.target.value })}
                    placeholder="e.g. Acme Innovations Pvt Ltd"
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm focus:outline-none focus:border-slate-900 focus:ring-1 focus:ring-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="text-xs font-bold text-slate-900 block mb-1">Business Type</label>
                  <select
                    value={profile.businessType}
                    onChange={(e) => setProfile({ ...profile, businessType: e.target.value as BusinessType })}
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm focus:outline-none focus:border-slate-900"
                  >
                    <option value="pvt_ltd">Private Limited Company</option>
                    <option value="llp">LLP (Limited Liability Partnership)</option>
                    <option value="proprietorship">Sole Proprietorship</option>
                    <option value="partnership">Partnership Firm</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-900 block mb-1">Industry</label>
                  <input
                    type="text"
                    value={profile.industry}
                    onChange={(e) => setProfile({ ...profile, industry: e.target.value })}
                    placeholder="e.g. SaaS, Consulting, Retail"
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm focus:outline-none focus:border-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="text-xs font-bold text-slate-900 block mb-1">State of Registration</label>
                  <select
                    value={profile.state}
                    onChange={(e) => setProfile({ ...profile, state: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm focus:outline-none focus:border-slate-900"
                  >
                    <option value="Karnataka">Karnataka</option>
                    <option value="Maharashtra">Maharashtra</option>
                    <option value="Delhi">Delhi NCR</option>
                    <option value="Tamil Nadu">Tamil Nadu</option>
                    <option value="Telangana">Telangana</option>
                    <option value="Gujarat">Gujarat</option>
                    <option value="Other">Other State</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-900 block mb-1">GST Status</label>
                  <select
                    value={profile.gstStatus}
                    onChange={(e) => setProfile({ ...profile, gstStatus: e.target.value as GSTStatus })}
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm focus:outline-none focus:border-slate-900"
                  >
                    <option value="registered">Registered (Standard GSTIN)</option>
                    <option value="composition">Composition Scheme</option>
                    <option value="unregistered">Not Registered / Below Threshold</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setStage('finance')}
                className="bg-slate-900 text-white hover:bg-slate-800 font-semibold text-sm py-3 px-6 rounded-xl flex items-center gap-2 shadow-sm transition-all"
              >
                <span>NEXT: SET UP YOUR FINANCE</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* 03 & 04. FINANCE SETUP & IMPORT DATA */}
        {stage === 'finance' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-600 uppercase tracking-wider font-geist">
                  3 of 5 completed
                </span>
                <h2 className="text-2xl font-black text-slate-900 font-geist tracking-tight mt-1">
                  LET’S UNDERSTAND YOUR MONEY.
                </h2>
                <p className="text-sm text-slate-600 mt-1">
                  Import data to unlock automated bookkeeping, or choose manual entry.
                </p>
              </div>
            </div>

            {/* Step list (Section 03) */}
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs space-y-2">
              <div className="flex items-center gap-2 font-medium text-slate-800">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>1. Connect / import financial data</span>
              </div>
              <div className="flex items-center gap-2 font-medium text-slate-800">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>2. Add bank / account information where supported</span>
              </div>
              <div className="flex items-center gap-2 font-semibold text-slate-900">
                <div className="w-4 h-4 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px]">3</div>
                <span>3. Import invoices &amp; bills</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <div className="w-4 h-4 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center text-[10px]">4</div>
                <span>4. Import expenses</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <div className="w-4 h-4 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center text-[10px]">5</div>
                <span>5. Review initial transactions</span>
              </div>
            </div>

            {/* 4 Choices (Section 04) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div
                onClick={() => setSelectedImportSource('bank')}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  selectedImportSource === 'bank'
                    ? 'border-slate-900 bg-slate-100 shadow-sm ring-1 ring-slate-900'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2 mb-1.5">
                  <FileSpreadsheet className="w-5 h-5 text-slate-700" />
                  <span className="font-bold text-xs uppercase text-slate-900">IMPORT BANK STATEMENT</span>
                </div>
                <p className="text-xs text-slate-600">CSV, Excel, or PDF bank statement exports with automatic transaction extraction.</p>
              </div>

              <div
                onClick={() => setSelectedImportSource('invoices')}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  selectedImportSource === 'invoices'
                    ? 'border-slate-900 bg-slate-100 shadow-sm ring-1 ring-slate-900'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2 mb-1.5">
                  <FileText className="w-5 h-5 text-slate-600" />
                  <span className="font-bold text-xs uppercase text-slate-900">IMPORT INVOICES</span>
                </div>
                <p className="text-xs text-slate-600">Upload customer bills and track receivables in real-time.</p>
              </div>

              <div
                onClick={() => setSelectedImportSource('expenses')}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  selectedImportSource === 'expenses'
                    ? 'border-slate-900 bg-slate-100 shadow-sm ring-1 ring-slate-900'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2 mb-1.5">
                  <CreditCard className="w-5 h-5 text-slate-600" />
                  <span className="font-bold text-xs uppercase text-slate-900">IMPORT EXPENSES</span>
                </div>
                <p className="text-xs text-slate-600">Upload vendor receipts and recurring software subscriptions.</p>
              </div>

              <div
                onClick={() => setSelectedImportSource('manual')}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  selectedImportSource === 'manual'
                    ? 'border-slate-900 bg-slate-100 shadow-sm ring-1 ring-slate-900'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2 mb-1.5">
                  <Building2 className="w-5 h-5 text-slate-500" />
                  <span className="font-bold text-xs uppercase text-slate-900">START MANUALLY</span>
                </div>
                <p className="text-xs text-slate-600">For new businesses without historical accounting spreadsheets.</p>
              </div>
            </div>

            {/* Drag & Drop mockup container */}
            <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center bg-slate-50 hover:bg-slate-100 transition-colors cursor-pointer">
              <Upload className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <p className="text-xs font-semibold text-slate-900">
                Drop your statement file here or click to browse
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                Sample loaded: <span className="font-mono text-slate-900 font-semibold">HDFC_Current_Account_Q1.csv</span> (84 transactions)
              </p>
            </div>

            <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              {/* Skip for now with clear warning per Section 04 */}
              <button
                onClick={() => setStage('first_moment')}
                className="text-xs text-slate-500 hover:text-red-600 transition-colors underline"
                title="Skipping means automated reconciliation and cash forecasting will remain inactive until statement upload."
              >
                SKIP FOR NOW (Limits automated cash forecasting)
              </button>

              <button
                onClick={() => setStage('ai_scan')}
                className="w-full sm:w-auto bg-slate-900 text-white hover:bg-slate-800 font-semibold text-sm py-3 px-6 rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                <span>CONTINUE WITH SAMPLE DATA</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* 05. AI DATA ORGANIZATION (Animation & Summary) */}
        {stage === 'ai_scan' && (
          <div className="text-center py-6 space-y-6">
            <div className="inline-flex p-3 rounded-2xl bg-slate-100 text-slate-800 border border-slate-200 shadow-sm">
              <Cpu className="w-8 h-8 text-slate-700 animate-spin" style={{ animationDuration: '3s' }} />
            </div>

            <div>
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider font-geist">
                Intelligent Parser
              </span>
              <h2 className="text-2xl md:text-3xl font-black text-slate-900 font-geist tracking-tight mt-1">
                FINAURA IS ORGANIZING YOUR DATA.
              </h2>
              <p className="text-sm text-slate-600 max-w-md mx-auto mt-1">
                Structuring transactions, identifying vendor names, and checking statutory GST/TDS relevance.
              </p>
            </div>

            {/* Stepped Progress Pills */}
            <div className="grid grid-cols-4 gap-2 max-w-md mx-auto text-xs font-semibold">
              <div
                className={`py-2 px-1 rounded-lg border transition-all ${
                  aiScanStep === 'reading' || aiScanStep === 'identifying' || aiScanStep === 'categorizing' || aiScanStep === 'checking' || aiScanStep === 'completed'
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-slate-100 text-slate-400 border-slate-200'
                }`}
              >
                1. Reading
              </div>

              <div
                className={`py-2 px-1 rounded-lg border transition-all ${
                  aiScanStep === 'identifying' || aiScanStep === 'categorizing' || aiScanStep === 'checking' || aiScanStep === 'completed'
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-slate-100 text-slate-400 border-slate-200'
                }`}
              >
                2. Identifying
              </div>

              <div
                className={`py-2 px-1 rounded-lg border transition-all ${
                  aiScanStep === 'categorizing' || aiScanStep === 'checking' || aiScanStep === 'completed'
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-slate-100 text-slate-400 border-slate-200'
                }`}
              >
                3. Categorizing
              </div>

              <div
                className={`py-2 px-1 rounded-lg border transition-all ${
                  aiScanStep === 'checking' || aiScanStep === 'completed'
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-slate-100 text-slate-400 border-slate-200'
                }`}
              >
                4. Checking
              </div>
            </div>

            {/* Found Summary Card */}
            {aiScanStep === 'completed' && (
              <div className="bg-slate-50 rounded-xl p-5 border border-slate-200 max-w-md mx-auto space-y-3 animate-in fade-in zoom-in-95 duration-300">
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider font-geist">
                  SCAN COMPLETED
                </div>
                <h3 className="text-xl font-black text-slate-900 font-geist">
                  WE FOUND 84 TRANSACTIONS
                </h3>
                <div className="flex items-center justify-center gap-4 text-xs">
                  <span className="flex items-center gap-1 text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    76 categorized
                  </span>
                  <span className="flex items-center gap-1 text-red-700 font-bold bg-red-50 px-2.5 py-1 rounded-full border border-red-200">
                    <AlertCircle className="w-4 h-4 text-red-600" />
                    8 need review
                  </span>
                </div>
                <button
                  onClick={() => setStage('first_moment')}
                  className="w-full bg-slate-900 text-white hover:bg-slate-800 font-semibold text-sm py-3 rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all mt-2"
                >
                  <span>SEE FIRST INSIGHT &amp; REVIEW</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* 06. FIRST AI MOMENT */}
        {stage === 'first_moment' && (
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 text-slate-800 text-xs font-bold rounded-full uppercase tracking-wider font-geist border border-slate-200">
                <Sparkles className="w-3.5 h-3.5 text-slate-600" />
                FIRST AI MOMENT
              </span>
            </div>

            <div>
              <h2 className="text-2xl md:text-3xl font-black text-slate-900 font-geist tracking-tight">
                HERE’S WHAT FINAURA NOTICED.
              </h2>
              <p className="text-sm text-slate-600 mt-1">
                Your financial baseline is structured and ready for guided review.
              </p>
            </div>

            {/* 3 Metrics Row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <span className="text-xs font-semibold text-slate-500 block mb-1">Monthly Revenue</span>
                <span className="text-2xl font-black text-slate-900 font-geist">₹8.64L</span>
                <span className="text-[11px] text-emerald-700 font-medium block mt-1">+12.5% vs last month</span>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <span className="text-xs font-semibold text-slate-500 block mb-1">Monthly Expenses</span>
                <span className="text-2xl font-black text-slate-900 font-geist">₹3.82L</span>
                <span className="text-[11px] text-red-600 font-medium block mt-1">Software increased 24%</span>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <span className="text-xs font-semibold text-slate-500 block mb-1">Currently Outstanding</span>
                <span className="text-2xl font-black text-slate-900 font-geist">₹1.20L</span>
                <span className="text-[11px] text-slate-500 block mt-1">2 invoices pending</span>
              </div>
            </div>

            {/* One Thing to Know */}
            <div className="bg-white p-4 md:p-5 rounded-xl border-l-4 border-l-slate-900 border border-slate-200 shadow-sm space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider font-geist">
                  ONE THING TO KNOW
                </span>
                <span className="text-xs text-slate-500 font-medium">Proactive Alert</span>
              </div>
              <h3 className="text-base font-bold text-slate-900">
                Your receivables increased 18% this month.
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                ₹1.20L remains pending from 2 clients. Following up will strengthen your operating cash buffer before the upcoming TDS and GST cutoffs.
              </p>
            </div>

            <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <span className="text-xs text-slate-500">
                Baseline structured. Next: tailored plan recommendation.
              </span>
              <button
                onClick={() => setStage('plan_recommendation')}
                className="w-full sm:w-auto bg-slate-900 text-white hover:bg-slate-800 font-semibold text-sm py-3 px-8 rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                <span>CONTINUE TO PLAN SETUP</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* 07. POST-ONBOARDING PLAN RECOMMENDATION (Phase 6) */}
        {stage === 'plan_recommendation' && (() => {
          const recommendation = getRecommendedPlan(profile);
          const recPlan = getPlan(recommendation.recommendedPlan);

          return (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-full uppercase tracking-wider font-geist border border-emerald-200">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  TAILORED PLAN RECOMMENDATION
                </span>
              </div>

              <div>
                <h2 className="text-2xl md:text-3xl font-black text-slate-900 font-geist tracking-tight">
                  RECOMMENDED FOR {profile.businessName.toUpperCase()}: {recPlan.name.toUpperCase()}
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 mt-1.5 leading-relaxed">
                  {recommendation.primaryReason}
                </p>
              </div>

              {/* Recommended Plan Showcase Box */}
              <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white p-6 rounded-2xl border border-slate-800 shadow-lg space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs text-emerald-400 font-bold uppercase tracking-wider">
                      Optimal Plan Tier
                    </span>
                    <h3 className="text-2xl font-black text-white">{recPlan.name} Plan</h3>
                  </div>
                  <div className="text-right">
                    <span className="text-3xl font-extrabold text-white">
                      ₹{recPlan.priceMonthly.toLocaleString('en-IN')}
                    </span>
                    <span className="text-xs text-slate-400">/mo</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 space-y-2 text-xs">
                  <span className="text-slate-400 block font-semibold">
                    Why this tier matches your profile:
                  </span>
                  {recommendation.supportingReasons.map((reason, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-slate-200">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{reason}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3 pt-2">
                <button
                  onClick={() => onComplete(profile, recPlan.id)}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm py-3.5 px-6 rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
                >
                  <span>ENTER WORKSPACE WITH {recPlan.name.toUpperCase()}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <div className="text-center">
                  <button
                    type="button"
                    onClick={() => onComplete(profile, 'free')}
                    className="text-xs text-slate-500 hover:text-slate-800 font-semibold underline cursor-pointer"
                  >
                    Or start with Free Plan (Upgrade anytime with 1-click)
                  </button>
                </div>
              </div>
            </div>
          );
        })()}
      </div>
    </div>
  );
};
