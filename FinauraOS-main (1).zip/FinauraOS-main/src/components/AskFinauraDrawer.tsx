import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  X,
  Send,
  UserCheck,
  ArrowRight,
  HelpCircle,
  ShieldCheck,
  CheckCircle2,
  TrendingUp,
  BrainCircuit,
  Calculator,
  Sliders,
  FileCheck2,
  AlertTriangle,
  Copy,
  Check,
  RotateCcw,
  BookOpen,
  Scale,
  Zap,
  ChevronDown,
  ChevronUp,
  Flame,
  ArrowUpRight,
} from 'lucide-react';
import { NavTab, BusinessProfile, Transaction, Invoice } from '../types';
import { solveQueryLocally } from '../utils/statutorySolver';
import { subscriptionManager } from '../lib/subscription';

interface AskFinauraDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  initialPrompt?: string;
  onNavigate: (tab: NavTab) => void;
  profile?: BusinessProfile;
  transactions?: Transaction[];
  invoices?: Invoice[];
}

type AIMode = 'problem_solver' | 'chat' | 'scenario_simulator';

interface ProblemPreset {
  id: string;
  title: string;
  category: string;
  prompt: string;
  icon: string;
  difficulty: 'Complex' | 'Standard' | 'Statutory';
}

const PROBLEM_PRESETS: ProblemPreset[] = [
  {
    id: '44ada_vs_audit',
    title: '44ADA vs. Regular Tax Audit',
    category: 'Income Tax 2025',
    prompt:
      'Evaluate whether my business should declare profits under Section 44ADA (50% presumptive) or opt for Regular Books of Accounts with Section 44AB CA Audit under Income Tax Act 2025 given ₹68L turnover and ₹42L operating expenses. Provide exact tax variance and statutory proofs.',
    icon: '🧮',
    difficulty: 'Complex',
  },
  {
    id: 'sec_43bh_msme',
    title: 'Sec 43B(h) MSME 45-Day Overdue',
    category: 'MSME Compliance',
    prompt:
      'We have ₹4.80L in unpaid invoices from MSME-registered vendors that have crossed 45 days. Calculate the tax disallowance under Section 43B(h) of the Income Tax Act 2025 and the non-deductible penal interest under Section 16 of the MSMED Act.',
    icon: '⚖️',
    difficulty: 'Statutory',
  },
  {
    id: 'gst_itc_reversal',
    title: 'GSTR-2B Mismatch & ITC Reversal',
    category: 'GST Law',
    prompt:
      'A key vendor did not file GSTR-1 for an invoice of ₹1.24L (+ ₹22,320 GST). Under CGST Rule 36(4) and Section 16(2)(aa), can we claim ITC in GSTR-3B? Calculate interest liability under Section 50(1) if claimed incorrectly.',
    icon: '🛡️',
    difficulty: 'Statutory',
  },
  {
    id: 'tax_salary_calculation',
    title: 'Tax on ₹18L Salary under 2025 Act',
    category: 'Income Tax 2025',
    prompt:
      'Calculate the total direct tax liability on ₹18,00,000 annual income under the modernized Income Tax Act 2025 new tax regime, including standard deduction ₹75k, slab tax breakdown, and 4% cess.',
    icon: '📊',
    difficulty: 'Standard',
  },
  {
    id: 'cashflow_stress_test',
    title: '35% Revenue Crunch Stress Test',
    category: 'Cash Flow',
    prompt:
      'Stress-test our 6-month cash runway if monthly revenue drops 35% from ₹8.64L to ₹5.61L while fixed costs stay at ₹3.85L/mo. Formulate an expense reduction matrix and working capital preservation plan.',
    icon: '📉',
    difficulty: 'Complex',
  },
  {
    id: 'partner_remuneration',
    title: 'LLP Profit vs. Salary Tax Proof',
    category: 'Tax Structuring',
    prompt:
      'Calculate the optimal split between partner salary (Section 40(b) limits) vs. share of profit (Section 10(2A) tax exempt) for an LLP generating ₹36 Lakhs net profit before partner remuneration.',
    icon: '💰',
    difficulty: 'Standard',
  },
  {
    id: 'tds_194c_vs_194j',
    title: 'Vendor TDS: 194C vs 194J Classification',
    category: 'TDS Withholding',
    prompt:
      'We hired a digital agency for ₹2.5L providing UI design, custom code, and routine server management. Deconstruct whether TDS should be deducted @ 2% under Sec 194C or @ 10%/2% under Sec 194J(1)(ba) under Income Tax Act 2025.',
    icon: '📑',
    difficulty: 'Statutory',
  },
];

export const AskFinauraDrawer: React.FC<AskFinauraDrawerProps> = ({
  isOpen,
  onClose,
  initialPrompt,
  onNavigate,
  profile,
  transactions = [],
  invoices = [],
}) => {
  const [activeMode, setActiveMode] = useState<AIMode>('problem_solver');
  const [messages, setMessages] = useState<
    Array<{
      role: 'user' | 'assistant';
      text: string;
      reasoningSteps?: string[];
      source?: string;
      timestamp?: string;
    }>
  >([
    {
      role: 'assistant',
      text: "### Finaura Gemini AI Financial & Statutory Reasoner\nI am powered by **Gemini 3.7 Flash** and calibrated to the **Income Tax Act 2025 (New Direct Tax Code)**, CGST/SGST Acts, and MSMED Act 2006. I can compute exact numbers, calculate tax under revised 2025 slabs, model cash flow runway, reconcile GST ITC reversals, or optimize corporate deductions.\n\nType any query or financial scenario to receive an immediate, mathematically verified statutory breakdown.",
      timestamp: 'Just now',
      source: 'Gemini 3.7 AI • Income Tax Act 2025',
    },
  ]);

  const [inputQuery, setInputQuery] = useState('');
  const [isSolving, setIsSolving] = useState(false);
  const [solvingStage, setSolvingStage] = useState<string>('');
  const [showThoughtProcess, setShowThoughtProcess] = useState<Record<number, boolean>>({});
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  // Scenario Simulator interactive parameters
  const [simTurnover, setSimTurnover] = useState(68);
  const [simExpenses, setSimExpenses] = useState(42);
  const [simMsmeDelay, setSimMsmeDelay] = useState(52);
  const [simRevenueDrop, setSimRevenueDrop] = useState(30);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialPrompt && isOpen) {
      handleSolveProblem(initialPrompt);
    }
  }, [initialPrompt, isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isSolving]);

  const handleSolveProblem = async (query: string) => {
    if (!query.trim() || isSolving) return;

    const userMessage = query.trim();
    setInputQuery('');
    setMessages((prev) => [
      ...prev,
      {
        role: 'user',
        text: userMessage,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);

    setIsSolving(true);
    setSolvingStage('Deconstructing financial variables & statutory provisions...');

    const stageTimer1 = setTimeout(() => {
      setSolvingStage('Applying Income Tax Act 2025 & CGST statutory formulas...');
    }, 400);

    const stageTimer2 = setTimeout(() => {
      setSolvingStage('Computing sensitivity matrix & mathematical proofs...');
    }, 800);

    try {
      // Call server-side reasoning endpoint with prompt, history, and context
      const response = await fetch('/api/gemini/reason', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          problem: userMessage,
          mode: activeMode,
          history: messages.map((m) => ({
            role: m.role,
            text: m.text,
          })),
          context: {
            profile: profile || {
              businessName: 'Krishna Enterprises',
              persona: 'startup',
              turnoverRange: '₹50L - ₹1Cr',
              gstStatus: 'registered',
            },
            stats: {
              revenue: '8,64,000',
              gstLiability: '22,320',
              uncategorizedCount: 3,
            },
            transactions,
            invoices,
          },
        }),
      });

      const data = await response.json();
      clearTimeout(stageTimer1);
      clearTimeout(stageTimer2);

      let finalOutput = '';
      let finalSource = data.source || 'Gemini 3.8 AI • Income Tax Act 2025';

      if (data.reasoning) {
        finalOutput = data.reasoning;
      } else if (data.data?.reasoning) {
        finalOutput = data.data.reasoning;
      } else if (data.reply) {
        finalOutput = data.reply;
      } else {
        const localSolution = solveQueryLocally(userMessage, profile);
        finalOutput = localSolution.markdown;
        finalSource = localSolution.source;
      }

      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: finalOutput,
          source: finalSource,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch (err: any) {
      console.warn('Network issue encountered, using statutory engine:', err);
      clearTimeout(stageTimer1);
      clearTimeout(stageTimer2);
      
      const localSolution = solveQueryLocally(userMessage, profile);
      subscriptionManager.incrementAIQuestionsUsed();
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: localSolution.markdown,
          source: localSolution.source,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsSolving(false);
      setSolvingStage('');
    }
  };

  const handleCopyText = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const renderActionButtons = (text: string) => {
    const actions: { label: string; tab: NavTab; icon: React.FC<{ className?: string }> }[] = [];

    if (text.includes('[ACTION:accounting]') || text.includes('Review in Accounting')) {
      actions.push({ label: 'Open Smart Accounting', tab: 'accounting', icon: ArrowUpRight });
    }
    if (text.includes('[ACTION:tax]') || text.includes('Tax Calculator') || text.includes('advance tax')) {
      actions.push({ label: 'Open Tax Workflow', tab: 'tax', icon: Calculator });
    }
    if (text.includes('[ACTION:compliance]') || text.includes('Compliance') || text.includes('GSTR')) {
      actions.push({ label: 'Open Compliance HQ', tab: 'compliance', icon: ShieldCheck });
    }
    if (text.includes('[ACTION:invoices]') || text.includes('Invoicing') || text.includes('MSME aging')) {
      actions.push({ label: 'Open Invoicing & GST', tab: 'invoices', icon: FileCheck2 });
    }
    if (text.includes('[ACTION:ca_services]') || text.includes('CA Rajesh') || text.includes('CA Audit')) {
      actions.push({ label: 'Connect with CA Expert', tab: 'ca_services', icon: UserCheck });
    }

    if (actions.length === 0) return null;

    return (
      <div className="mt-3.5 pt-3 border-t border-slate-200/80 flex flex-wrap gap-2">
        {actions.map((act, idx) => {
          const Icon = act.icon;
          return (
            <button
              key={idx}
              type="button"
              onClick={() => {
                onClose();
                onNavigate(act.tab);
              }}
              className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-[11px] font-bold flex items-center gap-1.5 transition-all shadow-xs hover:shadow-sm cursor-pointer"
            >
              <Icon className="w-3.5 h-3.5 text-emerald-400" />
              <span>{act.label}</span>
            </button>
          );
        })}
      </div>
    );
  };

  const renderFormattedMarkdown = (text: string) => {
    // Strip action tags for clean rendering
    const cleanText = text.replace(/\[ACTION:[a-z_]+\]/g, '').trim();

    return (
      <div className="space-y-3 leading-relaxed text-slate-800 text-xs selection:bg-emerald-100">
        {cleanText.split('\n\n').map((paragraph, pIdx) => {
          if (paragraph.startsWith('### ')) {
            return (
              <h4
                key={pIdx}
                className="text-xs font-bold text-slate-950 uppercase tracking-wide flex items-center gap-1.5 pt-1 border-b border-slate-200 pb-1"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>{paragraph.replace('### ', '')}</span>
              </h4>
            );
          }
          if (paragraph.startsWith('#### ')) {
            return (
              <h5 key={pIdx} className="text-xs font-bold text-slate-900 pt-0.5">
                {paragraph.replace('#### ', '')}
              </h5>
            );
          }
          if (paragraph.startsWith('|') && paragraph.includes('|')) {
            // Render table format
            const rows = paragraph.split('\n').filter((r) => r.trim().startsWith('|'));
            if (rows.length >= 2) {
              const headers = rows[0]
                .split('|')
                .filter((c) => c.trim().length > 0)
                .map((c) => c.trim());
              const bodyRows = rows.slice(2).map((r) =>
                r
                  .split('|')
                  .filter((c) => c.trim().length > 0)
                  .map((c) => c.trim())
              );

              return (
                <div key={pIdx} className="overflow-x-auto my-2 rounded-lg border border-slate-200 bg-white">
                  <table className="w-full text-[11px] text-left">
                    <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                      <tr>
                        {headers.map((h, hIdx) => (
                          <th key={hIdx} className="px-2.5 py-1.5">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {bodyRows.map((bRow, rIdx) => (
                        <tr key={rIdx} className={rIdx % 2 === 0 ? 'bg-white' : 'bg-slate-50/60'}>
                          {bRow.map((cell, cIdx) => (
                            <td key={cIdx} className="px-2.5 py-1.5 font-medium text-slate-800">
                              {cell.replace(/\*\*/g, '')}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              );
            }
          }
          if (paragraph.startsWith('- ') || paragraph.startsWith('* ')) {
            return (
              <ul key={pIdx} className="space-y-1.5 pl-4 list-disc marker:text-emerald-500 text-slate-700">
                {paragraph.split('\n').map((item, itemIdx) => (
                  <li key={itemIdx} className="leading-normal">
                    {item.replace(/^[-*]\s+/, '').replace(/\*\*(.*?)\*\*/g, '$1')}
                  </li>
                ))}
              </ul>
            );
          }
          if (paragraph.startsWith('1. ') || paragraph.startsWith('2. ')) {
            return (
              <ol key={pIdx} className="space-y-1.5 pl-4 list-decimal marker:font-bold marker:text-slate-800 text-slate-700">
                {paragraph.split('\n').map((item, itemIdx) => (
                  <li key={itemIdx} className="leading-normal">
                    {item.replace(/^\d+\.\s+/, '').replace(/\*\*(.*?)\*\*/g, '$1')}
                  </li>
                ))}
              </ol>
            );
          }

          return (
            <p key={pIdx} className="leading-relaxed text-slate-700">
              {paragraph.replace(/\*\*(.*?)\*\*/g, '$1')}
            </p>
          );
        })}
      </div>
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-in fade-in">
      <div className="absolute inset-0 bg-slate-950/50 backdrop-blur-xs" onClick={onClose} />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-6 sm:pl-10">
        <div className="w-screen max-w-xl bg-white shadow-2xl flex flex-col border-l border-slate-200">
          
          {/* TOP HEADER */}
          <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-900 text-white flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-bold shadow-md shadow-emerald-950/40">
                  <BrainCircuit className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-white tracking-tight">Ask Finaura AI Reasoner</h3>
                    <span className="text-[10px] font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-800/80 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Scale className="w-2.5 h-2.5 text-emerald-400" />
                      Income Tax Act 2025
                    </span>
                    <span className="text-[10px] font-semibold bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded-full">
                      {subscriptionManager.getAIQuestionsUsed()} / 75 questions used
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Direct Tax Code 2025 mathematical derivations, statutory tax proofs & cash flow engineering
                  </p>
                </div>
              </div>
              
              <button
                type="button"
                onClick={onClose}
                className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                title="Close AI Reasoner"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mode Switcher Tabs */}
            <div className="grid grid-cols-3 gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setActiveMode('problem_solver')}
                className={`py-1.5 px-2 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  activeMode === 'problem_solver'
                    ? 'bg-emerald-600 text-white shadow-xs font-bold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <BrainCircuit className="w-3.5 h-3.5" />
                <span>Problem Solver</span>
              </button>
              
              <button
                type="button"
                onClick={() => setActiveMode('scenario_simulator')}
                className={`py-1.5 px-2 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  activeMode === 'scenario_simulator'
                    ? 'bg-emerald-600 text-white shadow-xs font-bold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Simulate & Stress Test</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveMode('chat')}
                className={`py-1.5 px-2 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  activeMode === 'chat'
                    ? 'bg-emerald-600 text-white shadow-xs font-bold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Copilot Chat</span>
              </button>
            </div>
          </div>

          {/* INTERACTIVE SCENARIO SIMULATOR DRAWER PANEL (When in Simulator Mode) */}
          {activeMode === 'scenario_simulator' && (
            <div className="p-3.5 bg-slate-900 text-white border-b border-slate-800 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-emerald-400 flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5" />
                  Live Stress-Test Parameter Studio
                </span>
                <button
                  type="button"
                  onClick={() => {
                    handleSolveProblem(
                      `Run stress-test analysis: Turnover ₹${simTurnover}L, operating expenses ₹${simExpenses}L, MSME vendor delay ${simMsmeDelay} days, potential revenue drop of ${simRevenueDrop}%. Calculate runway and tax impact.`
                    );
                  }}
                  className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg text-[11px] flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Zap className="w-3 h-3" />
                  Run Proof
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3 text-[11px]">
                {/* Turnover slider */}
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 space-y-1">
                  <div className="flex justify-between text-slate-300">
                    <span>Turnover</span>
                    <span className="font-mono font-bold text-white">₹{simTurnover} Lakhs</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="200"
                    value={simTurnover}
                    onChange={(e) => setSimTurnover(Number(e.target.value))}
                    className="w-full accent-emerald-400 h-1 bg-slate-800 rounded-lg cursor-pointer"
                  />
                </div>

                {/* Expenses slider */}
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 space-y-1">
                  <div className="flex justify-between text-slate-300">
                    <span>Annual Expenses</span>
                    <span className="font-mono font-bold text-white">₹{simExpenses} Lakhs</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="150"
                    value={simExpenses}
                    onChange={(e) => setSimExpenses(Number(e.target.value))}
                    className="w-full accent-emerald-400 h-1 bg-slate-800 rounded-lg cursor-pointer"
                  />
                </div>

                {/* MSME Delay */}
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 space-y-1">
                  <div className="flex justify-between text-slate-300">
                    <span>MSME Vendor Delay</span>
                    <span className="font-mono font-bold text-amber-400">{simMsmeDelay} Days</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="90"
                    value={simMsmeDelay}
                    onChange={(e) => setSimMsmeDelay(Number(e.target.value))}
                    className="w-full accent-amber-400 h-1 bg-slate-800 rounded-lg cursor-pointer"
                  />
                </div>

                {/* Revenue drop stress */}
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 space-y-1">
                  <div className="flex justify-between text-slate-300">
                    <span>Revenue Crunch</span>
                    <span className="font-mono font-bold text-red-400">-{simRevenueDrop}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="60"
                    value={simRevenueDrop}
                    onChange={(e) => setSimRevenueDrop(Number(e.target.value))}
                    className="w-full accent-red-400 h-1 bg-slate-800 rounded-lg cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}

          {/* PROBLEM PRESETS BAR (When in Problem Solver Mode) */}
          {activeMode === 'problem_solver' && (
            <div className="p-3 bg-slate-100 border-b border-slate-200">
              <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center justify-between">
                <span>Verified Statutory Problem Templates (One-Click Solve)</span>
                <span className="text-emerald-700 font-mono">6 Scenarios Ready</span>
              </div>
              <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
                {PROBLEM_PRESETS.map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => handleSolveProblem(preset.prompt)}
                    className="shrink-0 p-2 bg-white border border-slate-300 hover:border-emerald-600 rounded-xl text-left shadow-2xs hover:shadow-xs transition-all w-52 cursor-pointer group"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm">{preset.icon}</span>
                      <span
                        className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold ${
                          preset.difficulty === 'Statutory'
                            ? 'bg-purple-100 text-purple-800'
                            : preset.difficulty === 'Complex'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {preset.category}
                      </span>
                    </div>
                    <div className="text-[11px] font-bold text-slate-900 line-clamp-1 group-hover:text-emerald-700">
                      {preset.title}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* MESSAGE & REASONING STREAM CONTAINER */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 text-xs bg-slate-50">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex flex-col ${
                  msg.role === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                {/* Header label */}
                <div className="text-[10px] text-slate-400 mb-1 px-1 flex items-center gap-1.5">
                  {msg.role === 'user' ? (
                    <span>You</span>
                  ) : (
                    <>
                      <span className="font-bold text-emerald-800 flex items-center gap-1">
                        <Sparkles className="w-2.5 h-2.5 text-emerald-600" />
                        Finaura Reasoner
                      </span>
                      <span>•</span>
                      <span className="font-mono text-slate-500">{msg.source || 'gemini-3.7-flash'}</span>
                    </>
                  )}
                  {msg.timestamp && <span>• {msg.timestamp}</span>}
                </div>

                {/* Message Bubble Card */}
                <div
                  className={`p-4 rounded-2xl max-w-[96%] shadow-xs ${
                    msg.role === 'user'
                      ? 'bg-slate-900 text-white rounded-tr-none font-medium'
                      : 'bg-white text-slate-800 rounded-tl-none border border-slate-200/90'
                  }`}
                >
                  {msg.role === 'user' ? (
                    <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                  ) : (
                    <div>
                      {renderFormattedMarkdown(msg.text)}
                      {renderActionButtons(msg.text)}

                      {/* Card Footer utilities */}
                      <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
                        <span className="flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                          Verified with Indian Statutory Laws
                        </span>

                        <button
                          type="button"
                          onClick={() => handleCopyText(msg.text, idx)}
                          className="hover:text-slate-700 flex items-center gap-1 cursor-pointer font-medium"
                          title="Copy solution text"
                        >
                          {copiedIndex === idx ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" />
                              <span className="text-emerald-600">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Copy Proof</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}

            {/* LIVE SOLVING / THINKING ANIMATION */}
            {isSolving && (
              <div className="p-4 bg-white rounded-2xl border border-emerald-200 shadow-sm space-y-2.5 max-w-[92%] animate-pulse">
                <div className="flex items-center gap-2 text-emerald-800 font-bold text-xs">
                  <BrainCircuit className="w-4 h-4 text-emerald-600 animate-spin" />
                  <span>Gemini 3.7 Deep Reasoning in Progress...</span>
                </div>
                <div className="text-[11px] text-slate-600 font-medium pl-6 border-l-2 border-emerald-500">
                  {solvingStage || 'Deconstructing scenario & checking Income Tax clauses...'}
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* BOTTOM QUERY INPUT BAR */}
          <div className="p-3.5 border-t border-slate-200 bg-white shadow-lg space-y-2">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSolveProblem(inputQuery);
              }}
              className="flex gap-2"
            >
              <div className="relative flex-1">
                <input
                  type="text"
                  value={inputQuery}
                  onChange={(e) => setInputQuery(e.target.value)}
                  placeholder={
                    activeMode === 'problem_solver'
                      ? 'Type custom tax/cashflow scenario, e.g. "Calculate 234B penalty on ₹45k shortfall"...'
                      : 'Ask about cash runway, GST filing, invoices, or audit rules...'
                  }
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:outline-none focus:border-emerald-600 focus:bg-white text-slate-900 placeholder:text-slate-400 font-medium"
                />
              </div>

              <button
                type="submit"
                disabled={!inputQuery.trim() || isSolving}
                className="bg-emerald-600 hover:bg-emerald-500 text-white p-2.5 rounded-xl disabled:opacity-40 transition-all font-bold flex items-center justify-center shrink-0 cursor-pointer shadow-sm active:scale-95"
                title="Solve Scenario with Gemini"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>

            <div className="flex items-center justify-between text-[10px] text-slate-500 pt-0.5">
              <span className="flex items-center gap-1 font-mono">
                <ShieldCheck className="w-3 h-3 text-emerald-600" />
                Income Tax Act 2025 • CGST Rules • MSMED Act 2006
              </span>

              <button
                type="button"
                onClick={() => {
                  onClose();
                  onNavigate('ca_services');
                }}
                className="text-slate-700 hover:text-emerald-700 hover:underline font-bold flex items-center gap-1 cursor-pointer"
              >
                <UserCheck className="w-3 h-3 text-emerald-600" />
                <span>Handover to CA Rajesh</span>
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
