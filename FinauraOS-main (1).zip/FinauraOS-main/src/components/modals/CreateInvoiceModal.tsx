import React, { useState } from 'react';
import { X, CheckCircle2, ArrowRight, ArrowLeft, Plus, Trash2, IndianRupee, FileText, AlertCircle } from 'lucide-react';
import { Invoice } from '../../types';

interface CreateInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (invoice: Invoice) => void;
}

interface FormInvoiceItem {
  description: string;
  quantity: number | string;
  rate: number | string;
  gstRate: number;
  amount: number;
}

export const CreateInvoiceModal: React.FC<CreateInvoiceModalProps> = ({
  isOpen,
  onClose,
  onSave,
}) => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [clientName, setClientName] = useState<string>('');
  const [clientEmail, setClientEmail] = useState<string>('');
  const [clientGstin, setClientGstin] = useState<string>('');
  const [invoiceNumber, setInvoiceNumber] = useState<string>(`INV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`);
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [dueDate, setDueDate] = useState<string>(new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0]);
  const [items, setItems] = useState<FormInvoiceItem[]>([
    {
      description: '',
      quantity: 1,
      rate: '',
      gstRate: 18,
      amount: 0,
    },
  ]);
  const [stepErrors, setStepErrors] = useState<string[]>([]);

  if (!isOpen) return null;

  const getItemSubtotal = (item: FormInvoiceItem) => {
    const q = typeof item.quantity === 'number' ? item.quantity : parseFloat(item.quantity) || 0;
    const r = typeof item.rate === 'number' ? item.rate : parseFloat(item.rate) || 0;
    return q * r;
  };

  const subtotal = items.reduce((acc, item) => acc + getItemSubtotal(item), 0);
  const gstAmount = items.reduce((acc, item) => {
    const s = getItemSubtotal(item);
    return acc + (s * item.gstRate) / 100;
  }, 0);
  const total = subtotal + gstAmount;

  const handleAddItem = () => {
    setItems([
      ...items,
      {
        description: '',
        quantity: 1,
        rate: '',
        gstRate: 18,
        amount: 0,
      },
    ]);
  };

  const handleRemoveItem = (index: number) => {
    if (items.length <= 1) return;
    setItems(items.filter((_, i) => i !== index));
  };

  const validateStep = (currentStep: number): boolean => {
    const errors: string[] = [];

    if (currentStep === 1) {
      if (!clientName.trim()) {
        errors.push('Client / Business Name is required.');
      }
      if (!clientEmail.trim()) {
        errors.push('Client Email is required.');
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clientEmail.trim())) {
        errors.push('Please enter a valid client email address.');
      }
      if (!date) {
        errors.push('Invoice Date is required.');
      }
      if (!dueDate) {
        errors.push('Payment Due Date is required.');
      }
      if (date && dueDate && new Date(dueDate) < new Date(date)) {
        errors.push('Payment Due Date cannot be earlier than Invoice Date.');
      }
    }

    if (currentStep === 2) {
      if (items.length === 0) {
        errors.push('At least one line item is required.');
      }
      items.forEach((item, idx) => {
        if (!item.description.trim()) {
          errors.push(`Line Item #${idx + 1}: Description is required.`);
        }
        const qtyNum = typeof item.quantity === 'number' ? item.quantity : parseFloat(item.quantity);
        if (isNaN(qtyNum) || qtyNum <= 0) {
          errors.push(`Line Item #${idx + 1}: Quantity must be greater than 0.`);
        }
        const rateNum = typeof item.rate === 'number' ? item.rate : parseFloat(item.rate);
        if (isNaN(rateNum) || rateNum <= 0) {
          errors.push(`Line Item #${idx + 1}: Rate must be greater than ₹0 (0 or empty is not permitted).`);
        }
      });
      if (subtotal <= 0) {
        errors.push('Total invoice value must be greater than ₹0.');
      }
    }

    setStepErrors(errors);
    return errors.length === 0;
  };

  const handleContinue = () => {
    if (validateStep(step)) {
      setStepErrors([]);
      setStep((s) => (s + 1) as any);
    }
  };

  const handleSaveInvoice = () => {
    if (!validateStep(1) || !validateStep(2)) {
      return;
    }

    onSave({
      id: `inv-${Date.now()}`,
      invoiceNumber,
      clientName: clientName.trim(),
      clientEmail: clientEmail.trim(),
      clientGstin: clientGstin.trim() || undefined,
      date,
      dueDate,
      items: items.map((it) => {
        const q = typeof it.quantity === 'number' ? it.quantity : parseFloat(it.quantity) || 1;
        const r = typeof it.rate === 'number' ? it.rate : parseFloat(it.rate) || 0;
        return {
          description: it.description.trim(),
          quantity: q,
          rate: r,
          gstRate: it.gstRate,
          amount: q * r,
        };
      }),
      subtotal,
      gstAmount,
      total,
      status: 'pending',
    });

    // Reset
    setClientName('');
    setClientEmail('');
    setClientGstin('');
    setItems([{ description: '', quantity: 1, rate: '', gstRate: 18, amount: 0 }]);
    setStepErrors([]);
    onClose();
    setStep(1);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Guided Invoice Generator • Step {step} of 4
            </span>
            <h3 className="text-base font-bold text-slate-900 mt-1">Create GST Tax Invoice</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-100 h-1">
          <div
            className="bg-emerald-600 h-1 transition-all duration-300"
            style={{ width: `${(step / 4) * 100}%` }}
          />
        </div>

        {/* Validation Errors Notice */}
        {stepErrors.length > 0 && (
          <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-rose-900">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>Please correct the following before continuing:</span>
            </div>
            <ul className="list-disc pl-5 space-y-0.5">
              {stepErrors.map((err, i) => (
                <li key={i}>{err}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Content */}
        <div className="p-6">
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <span>Client / Business Name</span>
                  <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Reliance Retail, Zeta Corp, Tech Innovations"
                  value={clientName}
                  onChange={(e) => {
                    setClientName(e.target.value);
                    if (stepErrors.length > 0) setStepErrors([]);
                  }}
                  className={`w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                    !clientName.trim() && stepErrors.length > 0 ? 'border-rose-400 bg-rose-50/30' : 'border-slate-200'
                  }`}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                    <span>Client Email</span>
                    <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="billing@client.com"
                    value={clientEmail}
                    onChange={(e) => {
                      setClientEmail(e.target.value);
                      if (stepErrors.length > 0) setStepErrors([]);
                    }}
                    className={`w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                      !clientEmail.trim() && stepErrors.length > 0 ? 'border-rose-400 bg-rose-50/30' : 'border-slate-200'
                    }`}
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 mb-1 block">Client GSTIN (Optional)</label>
                  <input
                    type="text"
                    value={clientGstin}
                    onChange={(e) => setClientGstin(e.target.value)}
                    placeholder="e.g. 29ABCDE1234F1Z5"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono uppercase focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                    <span>Invoice Date</span>
                    <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => {
                      setDate(e.target.value);
                      if (stepErrors.length > 0) setStepErrors([]);
                    }}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                    <span>Payment Due Date</span>
                    <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={dueDate}
                    onChange={(e) => {
                      setDueDate(e.target.value);
                      if (stepErrors.length > 0) setStepErrors([]);
                    }}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Line Items (Mandatory Non-Zero)</span>
                <button
                  type="button"
                  onClick={handleAddItem}
                  className="text-xs text-emerald-700 font-bold hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Item
                </button>
              </div>

              <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
                {items.map((item, index) => {
                  const itemRateNum = typeof item.rate === 'number' ? item.rate : parseFloat(item.rate) || 0;
                  const itemQtyNum = typeof item.quantity === 'number' ? item.quantity : parseFloat(item.quantity) || 0;
                  const lineTotal = (itemRateNum * itemQtyNum * (100 + item.gstRate)) / 100;

                  return (
                    <div key={index} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <input
                          type="text"
                          required
                          value={item.description}
                          onChange={(e) => {
                            const newItems = [...items];
                            newItems[index].description = e.target.value;
                            setItems(newItems);
                            if (stepErrors.length > 0) setStepErrors([]);
                          }}
                          placeholder="Service or product description (Required)..."
                          className={`flex-1 px-2.5 py-1.5 bg-white border rounded-lg text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500 ${
                            !item.description.trim() && stepErrors.length > 0 ? 'border-rose-400 bg-rose-50/20' : 'border-slate-200'
                          }`}
                        />
                        {items.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(index)}
                            className="text-slate-400 hover:text-rose-600 p-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-4 gap-2 text-xs">
                        <div>
                          <span className="text-[10px] text-slate-500 font-semibold block">Qty *</span>
                          <input
                            type="number"
                            required
                            min="1"
                            step="1"
                            value={item.quantity}
                            onChange={(e) => {
                              const newItems = [...items];
                              newItems[index].quantity = e.target.value === '' ? '' : Math.max(1, parseInt(e.target.value, 10) || 1);
                              setItems(newItems);
                              if (stepErrors.length > 0) setStepErrors([]);
                            }}
                            className="w-full px-2 py-1 bg-white border border-slate-200 rounded-lg text-xs font-bold text-center"
                          />
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-500 font-semibold block">Rate (₹) *</span>
                          <input
                            type="number"
                            required
                            min="0.01"
                            step="any"
                            placeholder="e.g. 50000"
                            value={item.rate}
                            onChange={(e) => {
                              const newItems = [...items];
                              newItems[index].rate = e.target.value;
                              setItems(newItems);
                              if (stepErrors.length > 0) setStepErrors([]);
                            }}
                            className={`w-full px-2 py-1 bg-white border rounded-lg text-xs font-bold ${
                              (!item.rate || Number(item.rate) <= 0) && stepErrors.length > 0
                                ? 'border-rose-400 bg-rose-50/20'
                                : 'border-slate-200'
                            }`}
                          />
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-500 font-semibold block">GST Rate</span>
                          <select
                            value={item.gstRate}
                            onChange={(e) => {
                              const newItems = [...items];
                              newItems[index].gstRate = parseInt(e.target.value, 10);
                              setItems(newItems);
                            }}
                            className="w-full px-2 py-1 bg-white border border-slate-200 rounded-lg text-xs font-medium"
                          >
                            <option value={18}>18% (Standard)</option>
                            <option value={12}>12%</option>
                            <option value={5}>5%</option>
                            <option value={0}>0% (Exempt)</option>
                          </select>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-500 font-semibold block">Line Total</span>
                          <div className="font-bold text-slate-900 pt-1 text-[11px] truncate">
                            ₹{lineTotal.toLocaleString('en-IN')}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex justify-between items-center text-xs">
                <span className="text-slate-500">Calculated Subtotal: ₹{subtotal.toLocaleString('en-IN')}</span>
                <span className="font-bold text-slate-900">Total with GST: ₹{total.toLocaleString('en-IN')}</span>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-900 text-white rounded-xl space-y-3">
                <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                  <span className="text-xs font-mono text-emerald-400 font-bold">{invoiceNumber}</span>
                  <span className="text-xs text-slate-400">Due: {dueDate}</span>
                </div>
                <div className="text-sm font-bold">{clientName}</div>
                <div className="text-xs text-slate-400">GSTIN: {clientGstin || 'Unregistered B2C'}</div>
                
                <div className="pt-2 border-t border-slate-800 flex justify-between items-center">
                  <span className="text-xs text-slate-400">Grand Total (Incl. GST)</span>
                  <span className="text-lg font-extrabold text-emerald-400">₹{total.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900">
                <strong>Statutory Note: </strong>
                This invoice will automatically sync with your GSTR-1 outward supply table and schedule 3-day automated payment reminders.
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="py-6 text-center space-y-3">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h4 className="text-base font-bold text-slate-900">Ready to Issue & Transmit</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Issue tax invoice to {clientName} ({clientEmail}) and add ₹{total.toLocaleString('en-IN')} to expected receivables.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/70 flex items-center justify-between">
          {step > 1 ? (
            <button
              type="button"
              onClick={() => {
                setStepErrors([]);
                setStep((s) => (s - 1) as any);
              }}
              className="px-3.5 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 flex items-center gap-1 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Back
            </button>
          ) : (
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 cursor-pointer"
            >
              Cancel
            </button>
          )}

          {step < 4 ? (
            <button
              type="button"
              onClick={handleContinue}
              className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl flex items-center gap-1.5 shadow-2xs cursor-pointer"
            >
              Continue <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSaveInvoice}
              className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl flex items-center gap-1.5 shadow-2xs cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" /> Issue Invoice
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
