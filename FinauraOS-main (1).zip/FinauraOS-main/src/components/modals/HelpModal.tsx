import React from 'react';
import { X, HelpCircle, Sparkles, BookOpen, MessageCircle, Phone, ArrowRight, ShieldCheck } from 'lucide-react';
import { NavTab } from '../../types';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: NavTab) => void;
  onOpenAI: (prompt?: string) => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onOpenAI,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Finaura Help & Guidance Hub</h3>
              <span className="text-[10px] text-slate-500">Statutory guidance, system tours & live support</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4 max-h-96 overflow-y-auto">
          {/* Ask AI quick card */}
          <div
            onClick={() => {
              onOpenAI('How does Finaura calculate Income Tax Act 2025 advance tax buffers?');
              onClose();
            }}
            className="p-4 bg-emerald-50/80 border border-emerald-200 rounded-xl cursor-pointer hover:bg-emerald-100/70 transition-all flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-emerald-950">Instant AI Statutory Copilot</h4>
                <p className="text-[11px] text-emerald-800">Ask any GST, TDS, Section 43B(h), or Tax Act 2025 question</p>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-emerald-700" />
          </div>

          {/* Quick FAQ items */}
          <div className="space-y-2">
            <h5 className="text-xs font-bold uppercase tracking-wider text-slate-500">Popular Guides</h5>
            
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
              <div className="text-xs font-bold text-slate-900">How to handle Section 43B(h) MSME payments?</div>
              <p className="text-[11px] text-slate-600">
                All purchases from registered Micro/Small enterprises must be paid within 15 days (or 45 days if agreed in writing) to claim tax deduction in the current financial year.
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
              <div className="text-xs font-bold text-slate-900">When should I consult a CA on Finaura?</div>
              <p className="text-[11px] text-slate-600">
                You can book ICAI-verified Chartered Accountants for ITR filing, Tax Audit, GSTR-9C annual returns, or MCA secretarial filings with transparent status tracking.
              </p>
            </div>
          </div>
        </div>

        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/70 flex items-center justify-between">
          <button
            type="button"
            onClick={() => {
              onNavigate('professionals');
              onClose();
            }}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800"
          >
            Connect with Dedicated CA →
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
