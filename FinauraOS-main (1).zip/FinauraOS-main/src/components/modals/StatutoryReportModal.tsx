import React, { useState } from 'react';
import {
  X,
  Download,
  FileSpreadsheet,
  Printer,
  ShieldCheck,
  CheckCircle2,
  Building,
  Calendar,
  FileText,
  BadgeCheck,
} from 'lucide-react';
import { BusinessProfile } from '../../types';
import {
  StatutoryReportData,
  downloadReportCsv,
  downloadReportPdf,
} from '../../utils/statutoryReportsEngine';

interface StatutoryReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialReportType: 'pl' | 'balance_sheet' | 'gstr2b' | 'tds';
  data: StatutoryReportData;
  profile: BusinessProfile;
}

export const StatutoryReportModal: React.FC<StatutoryReportModalProps> = ({
  isOpen,
  onClose,
  initialReportType,
  data,
  profile,
}) => {
  const [activeTab, setActiveTab] = useState<'pl' | 'balance_sheet' | 'gstr2b' | 'tds'>(initialReportType);

  if (!isOpen) return null;

  const businessName = profile?.businessName || 'Business Entity';
  const gstin = profile?.gstin || '27AABCA9876K1Z8';
  const pan = gstin.slice(2, 12);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto animate-in fade-in">
      <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-emerald-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">Statutory Financial Report & Audit Dossier</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  MCA &amp; IT Act 2025 Verified
                </span>
              </div>
              <p className="text-xs text-slate-300">
                {businessName} • GSTIN: {gstin} • PAN: {pan}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => downloadReportPdf(activeTab, data, profile)}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
              title="Download Official PDF in 1-Click"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF</span>
            </button>

            <button
              type="button"
              onClick={() => downloadReportCsv(activeTab, data, profile)}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
              title="Download Excel / CSV in 1-Click"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span>Excel / CSV</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              title="Print Statement"
            >
              <Printer className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 px-6 py-2.5 bg-slate-50 border-b border-slate-200 overflow-x-auto">
          {[
            { id: 'pl', label: '1. Profit & Loss (Ind AS 1)', standard: 'Schedule III Part II & Act 2025' },
            { id: 'balance_sheet', label: '2. Balance Sheet', standard: 'Schedule III Part I (MCA)' },
            { id: 'gstr2b', label: '3. GSTR-2B Reconciliation', standard: 'CBIC Rule 36(4)' },
            { id: 'tds', label: '4. TDS Withholding Summary', standard: 'Income Tax Act 2025 (Ch XVII-B)' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                activeTab === tab.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <span>{tab.label}</span>
              <span className={`text-[10px] font-normal opacity-80 ${activeTab === tab.id ? 'text-slate-300' : 'text-slate-500'}`}>
                ({tab.standard})
              </span>
            </button>
          ))}
        </div>

        {/* Modal Body / Report Presentation */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 bg-white text-slate-900">
          {/* Statutory Compliance Banner */}
          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-3">
            <BadgeCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div className="text-xs text-emerald-950">
              <span className="font-bold">Automated Dynamic Statutory Computation:</span> This statement is computed
              directly from your General Ledger vouchers and verified customer invoices. It conforms strictly to the
              Indian Accounting Standards (Ind AS / AS), Ministry of Corporate Affairs (MCA) Schedule III taxonomy, and
              the Income Tax Department Act 2025.
            </div>
          </div>

          {/* TAB 1: P&L Statement */}
          {activeTab === 'pl' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Statement of Profit and Loss for the Period Ended 31st August 2026
                  </h3>
                  <p className="text-xs text-slate-500">
                    In compliance with Schedule III (Part II) of the Companies Act 2013 and Section 145 of the Income Tax Act 2025
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[11px] font-bold text-slate-500">Currency</span>
                  <div className="text-xs font-bold text-slate-900">INR (₹)</div>
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                <table className="w-full text-left">
                  <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-4">Particulars</th>
                      <th className="py-2.5 px-4 w-28 text-center">Schedule</th>
                      <th className="py-2.5 px-4 w-40 text-right">Amount (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    <tr className="bg-slate-50/70 font-semibold text-slate-900">
                      <td colSpan={3} className="py-2 px-4">I. REVENUE FROM OPERATIONS</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-6 text-slate-700">Gross Invoiced Revenue from Sales &amp; Technical Services</td>
                      <td className="py-2 px-4 text-center text-slate-500">Note 1</td>
                      <td className="py-2 px-4 text-right font-medium font-geist">
                        ₹{data.pl.revenueFromOperations.toLocaleString('en-IN')}
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2 px-6 text-slate-700">Other Income (Bank Interest &amp; Forex Adjustments)</td>
                      <td className="py-2 px-4 text-center text-slate-500">Note 2</td>
                      <td className="py-2 px-4 text-right font-medium font-geist">
                        ₹{data.pl.otherIncome.toLocaleString('en-IN')}
                      </td>
                    </tr>
                    <tr className="bg-emerald-50/40 font-bold text-emerald-950">
                      <td className="py-2 px-4">TOTAL REVENUE (I)</td>
                      <td className="py-2 px-4 text-center">-</td>
                      <td className="py-2 px-4 text-right font-geist">
                        ₹{data.pl.totalRevenue.toLocaleString('en-IN')}
                      </td>
                    </tr>

                    <tr className="bg-slate-50/70 font-semibold text-slate-900">
                      <td colSpan={3} className="py-2 px-4">II. EXPENSES (Ind AS 1 Framework)</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-6 text-slate-700">Cost of Direct Services &amp; Subcontractors (Sec 194C/J)</td>
                      <td className="py-2 px-4 text-center text-slate-500">Note 3</td>
                      <td className="py-2 px-4 text-right font-medium font-geist">
                        ₹{data.pl.costOfServices.toLocaleString('en-IN')}
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2 px-6 text-slate-700">Employee Benefits Expense (Salaries, PF &amp; Bonuses)</td>
                      <td className="py-2 px-4 text-center text-slate-500">Note 4</td>
                      <td className="py-2 px-4 text-right font-medium font-geist">
                        ₹{data.pl.employeeBenefits.toLocaleString('en-IN')}
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2 px-6 text-slate-700">Finance Costs (Bank Charges &amp; Processing Fees)</td>
                      <td className="py-2 px-4 text-center text-slate-500">Note 5</td>
                      <td className="py-2 px-4 text-right font-medium font-geist">
                        ₹{data.pl.financeCosts.toLocaleString('en-IN')}
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2 px-6 text-slate-700">Depreciation and Amortization (Computers &amp; Hardware)</td>
                      <td className="py-2 px-4 text-center text-slate-500">Note 6</td>
                      <td className="py-2 px-4 text-right font-medium font-geist">
                        ₹{data.pl.depreciationAmortization.toLocaleString('en-IN')}
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2 px-6 text-slate-700">Other Operating Overheads (Software, Rent &amp; Utilities)</td>
                      <td className="py-2 px-4 text-center text-slate-500">Note 7</td>
                      <td className="py-2 px-4 text-right font-medium font-geist">
                        ₹{data.pl.totalOtherExpenses.toLocaleString('en-IN')}
                      </td>
                    </tr>
                    <tr className="bg-rose-50/40 font-bold text-rose-950">
                      <td className="py-2 px-4">TOTAL EXPENSES (II)</td>
                      <td className="py-2 px-4 text-center">-</td>
                      <td className="py-2 px-4 text-right font-geist">
                        ₹{data.pl.totalExpenses.toLocaleString('en-IN')}
                      </td>
                    </tr>

                    <tr className="bg-slate-50 font-bold text-slate-900">
                      <td className="py-2.5 px-4">III. OPERATING EBITDA</td>
                      <td className="py-2.5 px-4 text-center">-</td>
                      <td className="py-2.5 px-4 text-right font-geist text-blue-700">
                        ₹{data.pl.ebitda.toLocaleString('en-IN')}
                      </td>
                    </tr>
                    <tr className="font-bold text-slate-900">
                      <td className="py-2.5 px-4">IV. PROFIT BEFORE TAX (PBT) (I - II)</td>
                      <td className="py-2.5 px-4 text-center">-</td>
                      <td className="py-2.5 px-4 text-right font-geist">
                        ₹{data.pl.profitBeforeTax.toLocaleString('en-IN')}
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2 px-6 text-slate-700">
                        V. Provision for Income Tax ({data.pl.taxRatePercentage}% per Income Tax Act 2025)
                      </td>
                      <td className="py-2 px-4 text-center text-slate-500">Tax Note</td>
                      <td className="py-2 px-4 text-right font-medium font-geist text-rose-600">
                        ₹{data.pl.taxProvision.toLocaleString('en-IN')}
                      </td>
                    </tr>
                    <tr className="bg-emerald-100/70 font-black text-emerald-950 text-sm">
                      <td className="py-3 px-4">VI. PROFIT AFTER TAX (PAT) / NET SURPLUS</td>
                      <td className="py-3 px-4 text-center">-</td>
                      <td className="py-3 px-4 text-right font-geist">
                        ₹{data.pl.profitAfterTax.toLocaleString('en-IN')}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: Balance Sheet */}
          {activeTab === 'balance_sheet' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Statutory Balance Sheet as on 31st August 2026
                  </h3>
                  <p className="text-xs text-slate-500">
                    Prepared under Schedule III (Part I) of the Companies Act 2013 and Ministry of Corporate Affairs (MCA) Taxonomy
                  </p>
                </div>
                <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-50 border border-emerald-300 rounded-lg text-emerald-800 text-xs font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>MCA Balanced: Double-Entry Verified</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Equity & Liabilities */}
                <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                  <div className="bg-slate-900 text-white font-bold py-2.5 px-4 flex items-center justify-between">
                    <span>I. EQUITY AND LIABILITIES</span>
                    <span className="font-mono">Amount (₹)</span>
                  </div>
                  <div className="p-4 space-y-3">
                    <div>
                      <div className="font-bold text-slate-900 mb-1">1. Shareholders' Funds</div>
                      <div className="flex justify-between py-1 text-slate-700 pl-3">
                        <span>Paid-up Capital</span>
                        <span className="font-bold font-geist">₹{data.balanceSheet.shareCapital.toLocaleString('en-IN')}</span>
                      </div>
                      <div className="flex justify-between py-1 text-slate-700 pl-3">
                        <span>Reserves &amp; Surplus (P&amp;L Retained PAT)</span>
                        <span className="font-bold font-geist">₹{data.balanceSheet.reservesAndSurplus.toLocaleString('en-IN')}</span>
                      </div>
                    </div>

                    <div>
                      <div className="font-bold text-slate-900 mb-1">2. Non-Current Liabilities</div>
                      <div className="flex justify-between py-1 text-slate-700 pl-3">
                        <span>Long-Term Borrowings</span>
                        <span className="font-bold font-geist">₹0</span>
                      </div>
                    </div>

                    <div>
                      <div className="font-bold text-slate-900 mb-1">3. Current Liabilities</div>
                      <div className="flex justify-between py-1 text-slate-700 pl-3">
                        <div>
                          <span>Trade Payables (Sundry Creditors)</span>
                          <span className="block text-[10px] text-slate-400">
                            Includes MSME 43B(h) due: ₹{data.balanceSheet.msmePayables43B.toLocaleString('en-IN')}
                          </span>
                        </div>
                        <span className="font-bold font-geist">₹{data.balanceSheet.tradePayables.toLocaleString('en-IN')}</span>
                      </div>
                      <div className="flex justify-between py-1 text-slate-700 pl-3">
                        <span>Other Statutory Liabilities (GST &amp; TDS Payable)</span>
                        <span className="font-bold font-geist">₹{data.balanceSheet.otherCurrentLiabilities.toLocaleString('en-IN')}</span>
                      </div>
                      <div className="flex justify-between py-1 text-slate-700 pl-3">
                        <span>Short-Term Provisions (Tax Provision)</span>
                        <span className="font-bold font-geist">₹{data.balanceSheet.taxProvisions.toLocaleString('en-IN')}</span>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-200 flex justify-between font-black text-slate-900 text-sm">
                      <span>TOTAL EQUITY &amp; LIABILITIES</span>
                      <span className="font-geist text-emerald-700">
                        ₹{data.balanceSheet.totalEquityAndLiabilities.toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Assets */}
                <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                  <div className="bg-slate-900 text-white font-bold py-2.5 px-4 flex items-center justify-between">
                    <span>II. ASSETS</span>
                    <span className="font-mono">Amount (₹)</span>
                  </div>
                  <div className="p-4 space-y-3">
                    <div>
                      <div className="font-bold text-slate-900 mb-1">1. Non-Current Assets</div>
                      <div className="flex justify-between py-1 text-slate-700 pl-3">
                        <span>Property, Plant &amp; Equipment (PPE)</span>
                        <span className="font-bold font-geist">₹{data.balanceSheet.fixedAssetsPPE.toLocaleString('en-IN')}</span>
                      </div>
                    </div>

                    <div>
                      <div className="font-bold text-slate-900 mb-1">2. Current Assets</div>
                      <div className="flex justify-between py-1 text-slate-700 pl-3">
                        <span>Trade Receivables (Outstanding Invoices)</span>
                        <span className="font-bold font-geist">₹{data.balanceSheet.tradeReceivables.toLocaleString('en-IN')}</span>
                      </div>
                      <div className="flex justify-between py-1 text-slate-700 pl-3">
                        <span>Cash &amp; Bank Balances (HDFC Current A/c)</span>
                        <span className="font-bold font-geist">₹{data.balanceSheet.cashAndBank.toLocaleString('en-IN')}</span>
                      </div>
                      <div className="flex justify-between py-1 text-slate-700 pl-3">
                        <span>Input Tax Credit (Electronic Credit Ledger)</span>
                        <span className="font-bold font-geist">₹{data.balanceSheet.itcAssetBalance.toLocaleString('en-IN')}</span>
                      </div>
                      <div className="flex justify-between py-1 text-slate-700 pl-3">
                        <span>Advance Tax &amp; TDS Receivable (Form 26AS)</span>
                        <span className="font-bold font-geist">₹{data.balanceSheet.tdsReceivable26AS.toLocaleString('en-IN')}</span>
                      </div>
                    </div>

                    <div className="pt-10 border-t border-slate-200 flex justify-between font-black text-slate-900 text-sm">
                      <span>TOTAL ASSETS</span>
                      <span className="font-geist text-emerald-700">
                        ₹{data.balanceSheet.totalAssets.toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: GSTR-2B vs Books Reco */}
          {activeTab === 'gstr2b' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    GSTR-2B vs Purchase Register (Books) Reconciliation Statement
                  </h3>
                  <p className="text-xs text-slate-500">
                    Automated audit conforming to CBIC GST Rule 36(4) &amp; Section 16(2)(aa) of the CGST Act 2017
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[11px] font-bold text-slate-500">Audit Status</span>
                  <div className="text-xs font-bold text-emerald-600">
                    {data.gstr2bReco.reconciliationPercentage}% Reconciled
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[11px] text-slate-500 font-semibold block">Total Books ITC</span>
                  <div className="text-lg font-bold font-geist text-slate-900 mt-1">
                    ₹{data.gstr2bReco.totalBooksItc.toLocaleString('en-IN')}
                  </div>
                  <span className="text-[10px] text-slate-500">From purchase ledger vouchers</span>
                </div>
                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
                  <span className="text-[11px] text-emerald-700 font-semibold block">Matched ITC in 2B</span>
                  <div className="text-lg font-bold font-geist text-emerald-900 mt-1">
                    ₹{data.gstr2bReco.matchedVendorItc.toLocaleString('en-IN')}
                  </div>
                  <span className="text-[10px] text-emerald-700">{data.gstr2bReco.matchedCount} Vendors auto-matched</span>
                </div>
                <div className="p-3 bg-rose-50 rounded-xl border border-rose-200">
                  <span className="text-[11px] text-rose-700 font-semibold block">Unmatched / At Risk</span>
                  <div className="text-lg font-bold font-geist text-rose-900 mt-1">
                    ₹{data.gstr2bReco.unmatchedVendorItc.toLocaleString('en-IN')}
                  </div>
                  <span className="text-[10px] text-rose-700">Vendor GSTR-1 not filed yet</span>
                </div>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <h4 className="font-bold text-xs text-slate-900">GSTR-3B Table 4(A)(5) Claimable Breakdown</h4>
                <div className="grid grid-cols-3 gap-3 text-xs">
                  <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 font-bold block">CGST CLAIMABLE</span>
                    <span className="font-geist font-bold text-slate-900 text-sm">
                      ₹{data.gstr2bReco.cgst.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 font-bold block">SGST CLAIMABLE</span>
                    <span className="font-geist font-bold text-slate-900 text-sm">
                      ₹{data.gstr2bReco.sgst.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 font-bold block">IGST CLAIMABLE</span>
                    <span className="font-geist font-bold text-slate-900 text-sm">
                      ₹{data.gstr2bReco.igst.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: TDS Withholding Summary */}
          {activeTab === 'tds' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    TDS Withholding Tax Register &amp; Statutory Return Summary
                  </h3>
                  <p className="text-xs text-slate-500">
                    Compliant with Chapter XVII-B of the Income Tax Act 2025 and quarterly e-TDS Form 26Q/24Q standards
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[11px] font-bold text-slate-500">Challan ITNS 281 Due Date</span>
                  <div className="text-xs font-bold text-slate-900">{data.tdsSummary.challan281DueDate}</div>
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                <table className="w-full text-left">
                  <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-4">Section &amp; Nature of Payment</th>
                      <th className="py-2.5 px-4 w-32 text-center">Standard Rate</th>
                      <th className="py-2.5 px-4 w-40 text-right">TDS Deducted (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    <tr>
                      <td className="py-2.5 px-4">
                        <span className="font-bold text-slate-900 block">Section 194J</span>
                        <span className="text-slate-500 text-[11px]">Fees for Professional or Technical Services (Developers, Legal, Designers)</span>
                      </td>
                      <td className="py-2.5 px-4 text-center font-medium">10% / 2%</td>
                      <td className="py-2.5 px-4 text-right font-geist font-bold">
                        ₹{data.tdsSummary.sec194JProfessional.toLocaleString('en-IN')}
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-4">
                        <span className="font-bold text-slate-900 block">Section 194C</span>
                        <span className="text-slate-500 text-[11px]">Payments to Contractors, Subcontractors &amp; Advertising Agencies</span>
                      </td>
                      <td className="py-2.5 px-4 text-center font-medium">1% / 2%</td>
                      <td className="py-2.5 px-4 text-right font-geist font-bold">
                        ₹{data.tdsSummary.sec194CContractor.toLocaleString('en-IN')}
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-4">
                        <span className="font-bold text-slate-900 block">Section 192</span>
                        <span className="text-slate-500 text-[11px]">Salaries and Employee Payroll Withholding</span>
                      </td>
                      <td className="py-2.5 px-4 text-center font-medium">Slab Average</td>
                      <td className="py-2.5 px-4 text-right font-geist font-bold">
                        ₹{data.tdsSummary.sec192Salary.toLocaleString('en-IN')}
                      </td>
                    </tr>
                    <tr className="bg-emerald-50/60 font-bold text-emerald-950 text-sm">
                      <td className="py-3 px-4">TOTAL TDS WITHHOLDING LIABILITY (PAYABLE VIA CHALLAN 281)</td>
                      <td className="py-3 px-4 text-center">-</td>
                      <td className="py-3 px-4 text-right font-geist">
                        ₹{data.tdsSummary.totalTdsDeducted.toLocaleString('en-IN')}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-slate-900 block">Quarterly e-TDS Return Status</span>
                  <span className="text-slate-500">{data.tdsSummary.form26QStatus}</span>
                </div>
                <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full font-bold text-[10px]">
                  NSDL FVU Validated
                </span>
              </div>
            </div>
          )}

          {/* Statutory Signoff Footer */}
          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-slate-500 text-[11px]">
            <div>
              Generated for <span className="font-bold text-slate-700">{businessName}</span> (PAN: {pan}) under
              Companies Act 2013 &amp; Income Tax Act 2025.
            </div>
            <div className="flex items-center gap-3">
              <span className="font-medium">Director: ___________________</span>
              <span className="font-medium">Auditor: ___________________</span>
            </div>
          </div>
        </div>

        {/* Modal Bottom Action Bar */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            Clicking download exports the complete Schedule III statement formatted for legal filing.
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => downloadReportCsv(activeTab, data, profile)}
              className="px-3 py-1.5 bg-white border border-slate-300 hover:border-slate-400 text-slate-700 text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-2xs"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>Download Excel/CSV</span>
            </button>

            <button
              type="button"
              onClick={() => downloadReportPdf(activeTab, data, profile)}
              className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>Download Official PDF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
