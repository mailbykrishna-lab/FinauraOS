import React, { useState, useEffect } from 'react';
import { X, CheckCircle2, ArrowRight, ArrowLeft, Plus, IndianRupee, ShieldCheck, Tag, Building2, Calendar, AlertCircle } from 'lucide-react';
import { Transaction } from '../../types';

interface AddTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (transaction: Partial<Transaction>) => void;
}

export const AddTransactionModal: React.FC<AddTransactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
}) => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [amount, setAmount] = useState<string>('');
  const [type, setType] = useState<'debit' | 'credit'>('debit');
  const [vendor, setVendor] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [category, setCategory] = useState<string>('Software & Cloud');
  const [taxDeductible, setTaxDeductible] = useState<boolean>(true);
  const [gstEligible, setGstEligible] = useState<boolean>(true);
  const [gstin, setGstin] = useState<string>('');
  const [stepErrors, setStepErrors] = useState<string[]>([]);

  // Keep input blank on modal open so the user can enter their own input without defaults
  useEffect(() => {
    if (isOpen) {
      setAmount('');
      setVendor('');
      setDescription('');
      setGstin('');
      setStepErrors([]);
      setStep(1);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const validateCurrentStep = (currentStep: number): boolean => {
    const errors: string[] = [];

    if (currentStep === 1) {
      const parsedAmount = parseFloat(amount);
      if (!amount || amount.trim() === '') {
        errors.push('Transaction amount is mandatory and cannot be empty.');
      } else if (isNaN(parsedAmount) || parsedAmount <= 0) {
        errors.push('Transaction amount must be strictly greater than ₹0 (0 is not permitted).');
      }
      if (!date) {
        errors.push('Transaction date is mandatory.');
      }
    }

    if (currentStep === 2) {
      if (!vendor.trim()) {
        errors.push(type === 'debit' ? 'Vendor / Payee Name is mandatory.' : 'Client / Payer Name is mandatory.');
      }
      if (!description.trim()) {
        errors.push('Transaction description / business purpose is mandatory.');
      }
      if (gstin.trim() && !/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/i.test(gstin.trim())) {
        errors.push('Vendor GSTIN must follow the valid 15-character Indian GST format (e.g. 27AAACA1234J1Z5).');
      }
    }

    setStepErrors(errors);
    return errors.length === 0;
  };

  const handleContinue = () => {
    if (validateCurrentStep(step)) {
      setStepErrors([]);
      setStep((s) => (s + 1) as any);
    }
  };

  const handleComplete = () => {
    if (!validateCurrentStep(1) || !validateCurrentStep(2)) {
      return;
    }

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) return;

    onSave({
      id: `tx-${Date.now()}`,
      amount: parsedAmount,
      type,
      vendor: vendor.trim(),
      description: description.trim(),
      date: date || new Date().toISOString().split('T')[0],
      suggestedCategory: category,
      userCategory: category,
      confidence: 1.0,
      status: 'approved',
      taxDeductible,
      gstEligible,
      whatHappensNext: 'Categorized to general ledger with updated financial analytics and tax computations.',
    });
    // Reset form
    setAmount('');
    setVendor('');
    setDescription('');
    setGstin('');
    setStepErrors([]);
    setStep(1);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Guided Step {step} of 4
            </span>
            <h3 className="text-base font-bold text-slate-900 mt-1">Add Ledger Transaction</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-100 h-1">
          <div
            className="bg-emerald-600 h-1 transition-all duration-300"
            style={{ width: `${(step / 4) * 100}%` }}
          />
        </div>

        {/* Validation Errors Box */}
        {stepErrors.length > 0 && (
          <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-rose-900">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>Please resolve the following required fields:</span>
            </div>
            <ul className="list-disc pl-5 space-y-0.5">
              {stepErrors.map((err, i) => (
                <li key={i}>{err}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Step Content */}
        <div className="p-6">
          {step === 1 && (
            <div className="space-y-4">
              <div className="text-center py-2">
                <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-2">
                  Transaction Type & Amount <span className="text-rose-500">*</span>
                </label>
                <div className="flex justify-center gap-2 mb-4">
                  <button
                    type="button"
                    onClick={() => setType('debit')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      type === 'debit'
                        ? 'bg-rose-50 border-rose-300 text-rose-700 shadow-2xs'
                        : 'bg-slate-50 border-slate-200 text-slate-600'
                    }`}
                  >
                    Debit (Money Out / Expense)
                  </button>
                  <button
                    type="button"
                    onClick={() => setType('credit')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      type === 'credit'
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-700 shadow-2xs'
                        : 'bg-slate-50 border-slate-200 text-slate-600'
                    }`}
                  >
                    Credit (Money In / Revenue)
                  </button>
                </div>
                <div className="relative max-w-xs mx-auto">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl font-bold text-slate-400">
                    ₹
                  </span>
                  <input
                    id="transaction-amount-input"
                    type="number"
                    required
                    min="0.01"
                    step="any"
                    value={amount}
                    onChange={(e) => {
                      setAmount(e.target.value);
                      if (stepErrors.length > 0) setStepErrors([]);
                    }}
                    placeholder="Enter amount..."
                    autoFocus
                    className={`w-full pl-10 pr-4 py-3 text-3xl font-extrabold text-slate-900 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-center bg-white ${
                      (!amount || parseFloat(amount) <= 0) && stepErrors.length > 0
                        ? 'border-rose-400 bg-rose-50/20'
                        : 'border-slate-300'
                    }`}
                  />
                </div>
                <span className="text-[11px] text-slate-500 mt-1 block">
                  Mandatory field • Must be greater than ₹0 (Default 0 is prohibited)
                </span>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <span>Transaction Date</span>
                  <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => {
                    setDate(e.target.value);
                    if (stepErrors.length > 0) setStepErrors([]);
                  }}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <span>{type === 'debit' ? 'Vendor / Payee Name' : 'Client / Payer Name'}</span>
                  <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={vendor}
                  onChange={(e) => {
                    setVendor(e.target.value);
                    if (stepErrors.length > 0) setStepErrors([]);
                  }}
                  placeholder="e.g. AWS Cloud Services, Google Workspace, Zeta Corp"
                  className={`w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                    !vendor.trim() && stepErrors.length > 0 ? 'border-rose-400 bg-rose-50/20' : 'border-slate-200'
                  }`}
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <span>Description / Purpose</span>
                  <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={3}
                  required
                  value={description}
                  onChange={(e) => {
                    setDescription(e.target.value);
                    if (stepErrors.length > 0) setStepErrors([]);
                  }}
                  placeholder="Describe goods, services or contractual scope (Required)..."
                  className={`w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                    !description.trim() && stepErrors.length > 0 ? 'border-rose-400 bg-rose-50/20' : 'border-slate-200'
                  }`}
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 block">Vendor GSTIN (Optional)</label>
                <input
                  type="text"
                  value={gstin}
                  onChange={(e) => {
                    setGstin(e.target.value);
                    if (stepErrors.length > 0) setStepErrors([]);
                  }}
                  placeholder="e.g. 27AAACA1234J1Z5"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono uppercase focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 block">Ledger Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="Software & Cloud">Software & Cloud Services</option>
                  <option value="Marketing & Advertising">Marketing & Advertising</option>
                  <option value="Contractor & Legal Fees">Contractor & Legal (Sec 194J)</option>
                  <option value="Office Rent & Electricity">Office Rent & Utilities</option>
                  <option value="Travel & Logistics">Travel & Logistics</option>
                  <option value="Revenue - Client Retainer">Revenue - Consulting / Retainer</option>
                  <option value="Equipment & Hardware">Equipment & Hardware (Capital Asset)</option>
                </select>
              </div>

              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-slate-900">Tax Deductible Business Expense</div>
                    <div className="text-[11px] text-slate-500">Under Income Tax Act 2025 Section 37(1)</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={taxDeductible}
                    onChange={(e) => setTaxDeductible(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                  />
                </div>

                <div className="flex items-center justify-between border-t border-slate-200/80 pt-2.5">
                  <div>
                    <div className="text-xs font-bold text-slate-900">Eligible for GST Input Tax Credit (ITC)</div>
                    <div className="text-[11px] text-slate-500">Subject to invoice reflection in GSTR-2B</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={gstEligible}
                    onChange={(e) => setGstEligible(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                  />
                </div>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <div className="p-4 bg-emerald-50/80 border border-emerald-200 rounded-xl">
                <div className="text-xs font-bold text-emerald-900 uppercase tracking-wider mb-2">
                  Review & Ledger Impact
                </div>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-slate-500 block">Amount:</span>
                    <span className="font-extrabold text-slate-900 text-sm">₹{Number(amount).toLocaleString('en-IN')}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Type:</span>
                    <span className={`font-bold capitalize ${type === 'debit' ? 'text-rose-700' : 'text-emerald-700'}`}>
                      {type === 'debit' ? 'Debit (Expense)' : 'Credit (Revenue)'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Party / Vendor:</span>
                    <span className="font-bold text-slate-900">{vendor}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Category:</span>
                    <span className="font-bold text-slate-900">{category}</span>
                  </div>
                </div>
              </div>

              <div className="text-xs text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-200">
                <span className="font-bold text-slate-800">Automated Action: </span>
                This transaction will instantly update your monthly P&L, recalculate estimated Advance Tax under Income Tax Act 2025, and allocate GST ITC.
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/70 flex items-center justify-between">
          {step > 1 ? (
            <button
              type="button"
              onClick={() => {
                setStepErrors([]);
                setStep((s) => (s - 1) as any);
              }}
              className="px-3.5 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 flex items-center gap-1 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Back
            </button>
          ) : (
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 cursor-pointer"
            >
              Cancel
            </button>
          )}

          {step < 4 ? (
            <button
              type="button"
              onClick={handleContinue}
              className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl flex items-center gap-1.5 shadow-2xs cursor-pointer"
            >
              Continue <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleComplete}
              className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl flex items-center gap-1.5 shadow-2xs cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" /> Save to Ledger
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
