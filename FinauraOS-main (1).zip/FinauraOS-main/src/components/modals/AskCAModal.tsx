import React, { useState } from 'react';
import { X, CheckCircle2, ArrowRight, ArrowLeft, UserCheck, ShieldCheck, FileText, Send } from 'lucide-react';
import { CAProfessional } from '../../types';

interface AskCAModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (request: any) => void;
}

export const AskCAModal: React.FC<AskCAModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
}) => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [selectedCA, setSelectedCA] = useState<string>('CA Krishna Singhania (FCA, 14 Yrs Exp)');
  const [serviceType, setServiceType] = useState<string>('Income Tax Act 2025 Audit & Advance Tax');
  const [queryDescription, setQueryDescription] = useState<string>(
    'Please review our Section 43B(h) MSME vendor aging and advise on Advance Tax installment payment buffer for Q2.'
  );
  const [attachedDoc, setAttachedDoc] = useState<string>('August_2026_Ledger_TrialBalance.pdf');

  if (!isOpen) return null;

  const handleSubmit = () => {
    onSubmit({
      id: `ca-req-${Date.now()}`,
      serviceName: serviceType,
      caName: selectedCA,
      query: queryDescription,
      attachedDoc,
      requestedAt: 'Just now',
    });
    onClose();
    setStep(1);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              CA Advisory Request • Step {step} of 4
            </span>
            <h3 className="text-base font-bold text-slate-900 mt-1">Consult Chartered Accountant</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-100 h-1">
          <div
            className="bg-emerald-600 h-1 transition-all duration-300"
            style={{ width: `${(step / 4) * 100}%` }}
          />
        </div>

        {/* Content */}
        <div className="p-6">
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 block">Choose Professional / Partner</label>
                <select
                  value={selectedCA}
                  onChange={(e) => setSelectedCA(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="CA Krishna Singhania (FCA, 14 Yrs Exp)">CA Krishna Singhania (FCA, 14 Yrs Exp - Corporate & Tax)</option>
                  <option value="CA Ananya Deshmukh (Audit Specialist)">CA Ananya Deshmukh (Statutory & MSME Audit)</option>
                  <option value="CS Rohan Mehta (MCA / ROC Compliance)">CS Rohan Mehta (MCA / ROC & Secretarial Compliance)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 block">Statutory Advisory Domain</label>
                <select
                  value={serviceType}
                  onChange={(e) => setServiceType(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="Income Tax Act 2025 Audit & Advance Tax">Income Tax Act 2025 Audit & Advance Tax</option>
                  <option value="MSME Section 43B(h) Disallowance Review">MSME Section 43B(h) Disallowance Review</option>
                  <option value="GSTR-9 & 9C Annual Reconciliation">GSTR-9 & 9C Annual Reconciliation</option>
                  <option value="MCA Annual Filing & Director KYC">MCA Annual Filing & Director KYC</option>
                  <option value="TDS Certificate & 26AS/AIS Discrepancy">TDS Certificate & 26AS/AIS Discrepancy</option>
                </select>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 block">Describe Your Specific Request</label>
                <textarea
                  rows={4}
                  value={queryDescription}
                  onChange={(e) => setQueryDescription(e.target.value)}
                  placeholder="Outline the financial scenario, transaction dates, or statutory doubts..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>All communication is attorney/client privileged and protected by ICAI strict confidentiality standards.</span>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 block">Attach Supporting Record from Vault</label>
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-emerald-600" />
                    <span className="text-xs font-bold text-slate-800">{attachedDoc}</span>
                  </div>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">Encrypted</span>
                </div>
              </div>

              <div className="text-xs text-slate-500">
                Your CA will receive direct read-only access to this document along with your verified ledger summary.
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-900 text-white rounded-xl space-y-2">
                <div className="text-xs text-emerald-400 font-mono font-bold">DISPATCH BRIEF</div>
                <div className="text-sm font-bold">{selectedCA}</div>
                <div className="text-xs text-slate-400">{serviceType}</div>
                <p className="text-xs text-slate-300 italic pt-2 border-t border-slate-800">
                  "{queryDescription}"
                </p>
              </div>

              <div className="text-xs text-center text-slate-500">
                Average turnaround time: <strong>Within 4 Business Hours</strong>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/70 flex items-center justify-between">
          {step > 1 ? (
            <button
              type="button"
              onClick={() => setStep((s) => (s - 1) as any)}
              className="px-3.5 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Back
            </button>
          ) : (
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 text-xs font-bold text-slate-600 hover:text-slate-900"
            >
              Cancel
            </button>
          )}

          {step < 4 ? (
            <button
              type="button"
              onClick={() => setStep((s) => (s + 1) as any)}
              className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl flex items-center gap-1.5 shadow-2xs"
            >
              Continue <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSubmit}
              className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl flex items-center gap-1.5 shadow-2xs"
            >
              <Send className="w-4 h-4" /> Send Request
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
