import React from 'react';
import { X, Bell, CheckCircle2, AlertTriangle, Sparkles, Clock, ArrowRight, ShieldAlert } from 'lucide-react';
import { NavTab } from '../../types';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: NavTab) => void;
  onOpenAI: (prompt?: string) => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onOpenAI,
}) => {
  if (!isOpen) return null;

  const notifications = [
    {
      id: 'notif-1',
      title: 'Section 43B(h) MSME Disallowance Alert',
      message: '₹85,000 pending to Precision Printworks is in Day 39 of 45. Disallowance risk under Income Tax Act 2025.',
      time: '10 mins ago',
      type: 'urgent',
      tab: 'compliance' as NavTab,
      action: 'Review Compliance HQ',
    },
    {
      id: 'notif-2',
      title: 'GSTR-1 Outward Supply Cutoff Approaching',
      message: 'Filing window closes on 11th. 3 outward invoices ready for sync.',
      time: '2 hours ago',
      type: 'tax',
      tab: 'tax' as NavTab,
      action: 'Open Tax Center',
    },
    {
      id: 'notif-3',
      title: 'Unusual Software Spend Anomaly Detected',
      message: 'CloudHost transaction is 340% above 3-month rolling average.',
      time: 'Yesterday',
      type: 'finance',
      tab: 'finance' as NavTab,
      action: 'Check Spend Ledger',
    },
    {
      id: 'notif-4',
      title: 'CA Review Complete: TDS Challans Verified',
      message: 'CA Krishna Singhania completed the Section 194J quarterly reconciliation.',
      time: 'Yesterday',
      type: 'success',
      tab: 'professionals' as NavTab,
      action: 'View CA Workspace',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Statutory & Activity Notifications</h3>
              <span className="text-[10px] text-slate-500">4 unread compliance triggers</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 divide-y divide-slate-100 max-h-96 overflow-y-auto">
          {notifications.map((n) => (
            <div key={n.id} className="py-3 px-2 hover:bg-slate-50 rounded-xl transition-colors space-y-1">
              <div className="flex items-center justify-between">
                <span className={`text-xs font-bold ${n.type === 'urgent' ? 'text-rose-700' : n.type === 'tax' ? 'text-blue-700' : 'text-slate-900'}`}>
                  {n.title}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">{n.time}</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">{n.message}</p>
              <div className="pt-1 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => {
                    onNavigate(n.tab);
                    onClose();
                  }}
                  className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
                >
                  {n.action} <ArrowRight className="w-3 h-3" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onOpenAI(`Explain statutory implications of ${n.title} and recommended action.`);
                    onClose();
                  }}
                  className="text-[11px] font-semibold text-slate-500 hover:text-slate-900 flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3 text-emerald-600" /> Ask AI
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50/70 text-center">
          <button
            type="button"
            onClick={onClose}
            className="text-xs font-bold text-slate-600 hover:text-slate-900"
          >
            Dismiss All
          </button>
        </div>
      </div>
    </div>
  );
};
