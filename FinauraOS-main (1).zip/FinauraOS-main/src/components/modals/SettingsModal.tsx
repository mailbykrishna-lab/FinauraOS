import React, { useState, useEffect } from 'react';
import { X, Settings, Building2, Shield, Lock, CreditCard, Sparkles, CheckCircle2, User, Key, ArrowRight, QrCode } from 'lucide-react';
import QRCode from 'qrcode';
import { BusinessProfile, UserSubscription } from '../../types';
import { getPlan } from '../../lib/plans';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: BusinessProfile;
  onUpdateProfile: (profile: BusinessProfile) => void;
  subscription?: UserSubscription;
  onNavigateToBilling?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  profile,
  onUpdateProfile,
  subscription,
  onNavigateToBilling,
}) => {
  const [activeTab, setActiveTab] = useState<'entity' | 'tax' | 'bank' | 'security' | 'billing'>('entity');
  const [businessName, setBusinessName] = useState(profile.businessName);
  const [gstin, setGstin] = useState(profile.gstin || '');
  const [state, setState] = useState(profile.state);
  const [upiId, setUpiId] = useState(profile.bankDetails?.upiId || 'mailbykrishna@okhdfcbank');
  const [bankName, setBankName] = useState(profile.bankDetails?.bankName || '');
  const [accountNumber, setAccountNumber] = useState(profile.bankDetails?.accountNumber || '');
  const [ifscCode, setIfscCode] = useState(profile.bankDetails?.ifscCode || '');
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');

  useEffect(() => {
    if (activeTab === 'bank' && upiId) {
      const upiUrl = `upi://pay?pa=${encodeURIComponent(upiId.trim())}&pn=${encodeURIComponent(businessName)}&cu=INR&tn=${encodeURIComponent('Invoice Payment')}`;
      QRCode.toDataURL(upiUrl, {
        margin: 1,
        width: 180,
        color: { dark: '#0f172a', light: '#ffffff' },
      })
        .then((url) => setQrCodeDataUrl(url))
        .catch(() => {});
    }
  }, [activeTab, upiId, businessName]);

  if (!isOpen) return null;

  const handleSave = () => {
    onUpdateProfile({
      ...profile,
      businessName,
      gstin,
      state,
      bankDetails: {
        ...profile.bankDetails,
        bankName,
        accountHolderName: profile.bankDetails?.accountHolderName || `${businessName} Pvt Ltd`,
        accountNumber,
        ifscCode,
        accountType: profile.bankDetails?.accountType || 'Current',
        upiId: upiId.trim() || 'finaura@upi',
      },
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Workspace & Statutory Settings</h3>
              <span className="text-[10px] text-slate-500">{profile.businessName}</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Headers */}
        <div className="flex border-b border-slate-200 bg-slate-50/40 px-6 pt-2 gap-4 text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('entity')}
            className={`pb-2 border-b-2 transition-all ${
              activeTab === 'entity' ? 'border-emerald-600 text-emerald-700' : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Entity & Profile
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('tax')}
            className={`pb-2 border-b-2 transition-all ${
              activeTab === 'tax' ? 'border-emerald-600 text-emerald-700' : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Tax & GSTIN
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('bank')}
            className={`pb-2 border-b-2 transition-all ${
              activeTab === 'bank' ? 'border-emerald-600 text-emerald-700' : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Bank & UPI
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('security')}
            className={`pb-2 border-b-2 transition-all ${
              activeTab === 'security' ? 'border-emerald-600 text-emerald-700' : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Encryption & Compliance
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('billing')}
            className={`pb-2 border-b-2 transition-all ${
              activeTab === 'billing' ? 'border-emerald-600 text-emerald-700' : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Plan &amp; Billing
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 space-y-4 max-h-96 overflow-y-auto">
          {activeTab === 'entity' && (
            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 block">Registered Business Name</label>
                <input
                  type="text"
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 mb-1 block">Entity Persona</label>
                  <input
                    type="text"
                    disabled
                    value={profile.persona.toUpperCase()}
                    className="w-full px-3.5 py-2.5 bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-600"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 mb-1 block">Operating State</label>
                  <input
                    type="text"
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'tax' && (
            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 block">GSTIN (15-Digit Statutory Identifier)</label>
                <input
                  type="text"
                  value={gstin}
                  onChange={(e) => setGstin(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono uppercase focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900">
                <strong>Income Tax Act 2025 Calibrated: </strong>
                All calculations in this workspace automatically apply New Direct Tax slabs, standard deduction ₹75,000, Section 87A rebate up to ₹12L, and Section 44ADA/43B(h) statutory triggers.
              </div>
            </div>
          )}

          {activeTab === 'bank' && (
            <div className="space-y-4">
              {/* Dynamic UPI QR Section */}
              <div className="p-3.5 bg-emerald-50/60 border border-emerald-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                    <QrCode className="w-4 h-4 text-emerald-700" />
                    Dynamic UPI QR &amp; VPA (Primary)
                  </span>
                  <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded border border-emerald-300">
                    Instant Scan-to-Pay
                  </span>
                </div>
                <p className="text-[11px] text-emerald-900 leading-relaxed">
                  Enter your UPI ID (VPA) to auto-generate dynamic payment QR codes on client invoices with exact bill amounts. Bank account details are optional.
                </p>
                <div>
                  <label className="text-xs font-bold text-slate-800 mb-1 block">UPI ID / VPA</label>
                  <input
                    type="text"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value.toLowerCase().replace(/\s+/g, ''))}
                    placeholder="e.g. mailbykrishna@okhdfcbank or business@upi"
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono font-semibold focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* Handle presets */}
                <div className="flex flex-wrap gap-1.5 pt-0.5">
                  {['@okhdfcbank', '@okicici', '@oksbi', '@okaxis', '@paytm', '@ybl', '@upi'].map((handle) => {
                    const prefix = upiId.split('@')[0] || 'finaura';
                    return (
                      <button
                        key={handle}
                        type="button"
                        onClick={() => setUpiId(`${prefix}${handle}`)}
                        className="px-2 py-0.5 bg-white hover:bg-emerald-50 border border-slate-200 rounded text-[10px] font-mono text-slate-700 transition-colors cursor-pointer"
                      >
                        {handle}
                      </button>
                    );
                  })}
                </div>

                {qrCodeDataUrl && (
                  <div className="flex items-center gap-3 bg-white p-2.5 rounded-lg border border-slate-200">
                    <img
                      src={qrCodeDataUrl}
                      alt="UPI QR Code"
                      className="w-16 h-16 object-contain rounded border border-slate-100 p-0.5"
                    />
                    <div className="text-[11px] text-slate-600">
                      <strong className="text-slate-900 block font-sans">Live QR Calibrated</strong>
                      <span className="font-mono text-[10px] text-slate-500">{upiId}</span>
                      <div className="text-[10px] text-emerald-700 mt-0.5 font-medium">✓ Ready for dynamic amount encoding on PDF invoices</div>
                    </div>
                  </div>
                )}
              </div>

              {/* Bank Details (Optional) */}
              <div className="border-t border-slate-200 pt-3 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800">Bank Account Details</span>
                  <span className="text-[11px] text-slate-400 font-normal">Optional (for NEFT / RTGS transfers)</span>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 mb-1 block">Bank Name</label>
                  <input
                    type="text"
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    placeholder="Optional (e.g. HDFC Bank Ltd)"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-slate-400"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 mb-1 block">Account Number</label>
                    <input
                      type="text"
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value.replace(/\s+/g, ''))}
                      placeholder="Optional (e.g. 50200084920194)"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:outline-none focus:border-slate-400"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-700 mb-1 block">IFSC Code</label>
                    <input
                      type="text"
                      value={ifscCode}
                      onChange={(e) => setIfscCode(e.target.value.toUpperCase().replace(/\s+/g, ''))}
                      placeholder="Optional (e.g. HDFC0000184)"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono uppercase focus:outline-none focus:border-slate-400"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-3">
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                <div className="flex items-center gap-2 font-bold text-slate-900">
                  <Shield className="w-4 h-4 text-emerald-600" />
                  <span>Statutory Data Isolation & Privacy</span>
                </div>
                <p className="text-slate-600 leading-relaxed">
                  Financial records are isolated per entity with role-based access. Gemini 3.7 AI operates server-side with strict parameters.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'billing' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-900 text-white rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                    Current Active Tier
                  </span>
                  <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    {subscription?.status || 'Active'}
                  </span>
                </div>
                <div className="flex items-baseline justify-between">
                  <h4 className="text-xl font-black">
                    FINAURA {getPlan(subscription?.planId || 'growth').name.toUpperCase()}
                  </h4>
                  <span className="text-sm font-bold text-slate-300">
                    ₹{getPlan(subscription?.planId || 'growth').priceMonthly}/mo
                  </span>
                </div>
                <p className="text-xs text-slate-300">
                  {getPlan(subscription?.planId || 'growth').purpose}
                </p>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-slate-800 block">Need full invoice history &amp; usage meters?</span>
                  <span className="text-slate-500">Access the full Plan &amp; Billing workspace.</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    if (onNavigateToBilling) onNavigateToBilling();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1 cursor-pointer"
                >
                  <span>Open Billing HQ</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/70 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl flex items-center gap-1.5 shadow-2xs"
          >
            <CheckCircle2 className="w-4 h-4" /> Save Settings
          </button>
        </div>
      </div>
    </div>
  );
};
