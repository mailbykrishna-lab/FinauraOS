export interface GmailAttachmentMeta {
  id: string;
  filename: string;
  mimeType: string;
  size: number;
}

export interface GmailFinancialMessage {
  id: string;
  threadId: string;
  from: string;
  fromEmail: string;
  subject: string;
  date: string;
  snippet: string;
  hasAttachment: boolean;
  attachments: GmailAttachmentMeta[];
  detectedCategory: 'invoice' | 'receipt' | 'bank_statement' | 'tax' | 'vendor_bill';
  estimatedVendor?: string;
  estimatedAmount?: number;
}

function parseHeaders(headers: Array<{ name: string; value: string }>) {
  const result: Record<string, string> = {};
  for (const h of headers) {
    result[h.name.toLowerCase()] = h.value;
  }
  return result;
}

function extractEmail(fromHeader: string): string {
  const match = fromHeader.match(/<([^>]+)>/);
  return match ? match[1] : fromHeader;
}

function detectCategory(subject: string, snippet: string): 'invoice' | 'receipt' | 'bank_statement' | 'tax' | 'vendor_bill' {
  const text = `${subject} ${snippet}`.toLowerCase();
  if (text.includes('bank statement') || text.includes('account statement') || text.includes('statement of account')) {
    return 'bank_statement';
  }
  if (text.includes('tax') || text.includes('gst') || text.includes('challan') || text.includes('tds')) {
    return 'tax';
  }
  if (text.includes('receipt') || text.includes('payment received') || text.includes('bill received')) {
    return 'receipt';
  }
  if (text.includes('invoice') || text.includes('bill') || text.includes('tax invoice')) {
    return 'invoice';
  }
  return 'vendor_bill';
}

function extractVendor(fromHeader: string, subject: string): string {
  if (fromHeader) {
    const clean = fromHeader.replace(/<[^>]+>/, '').replace(/["']/g, '').trim();
    if (clean) return clean;
  }
  const cleanSubject = subject.split(/[-–—:|]/)[0]?.trim();
  return cleanSubject || 'Direct Supplier';
}

export async function fetchFinancialEmails(
  accessToken: string,
  maxResults = 10,
  searchQuery = 'has:attachment (invoice OR receipt OR bill OR "bank statement" OR statement OR "tax invoice" OR GST OR Razorpay)'
): Promise<GmailFinancialMessage[]> {
  const queryParams = new URLSearchParams({
    maxResults: String(maxResults),
    q: searchQuery,
  });

  const listRes = await fetch(
    `https://gmail.googleapis.com/gmail/v1/users/me/messages?${queryParams.toString()}`,
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    }
  );

  if (!listRes.ok) {
    const errData = await listRes.json().catch(() => ({}));
    throw new Error(errData?.error?.message || `Failed to fetch messages from Gmail: ${listRes.statusText}`);
  }

  const listData = await listRes.json();
  const messages = listData.messages || [];

  if (messages.length === 0) {
    return [];
  }

  const detailedMessages: GmailFinancialMessage[] = [];

  for (const msgItem of messages.slice(0, maxResults)) {
    try {
      const msgRes = await fetch(
        `https://gmail.googleapis.com/gmail/v1/users/me/messages/${msgItem.id}?format=full`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      if (!msgRes.ok) continue;

      const fullMsg = await msgRes.json();
      const headers = parseHeaders(fullMsg.payload?.headers || []);
      const fromHeader = headers['from'] || 'Unknown Sender';
      const subject = headers['subject'] || '(No Subject)';
      const dateHeader = headers['date'] || new Date().toISOString();

      const attachments: GmailAttachmentMeta[] = [];

      const walkParts = (part: any) => {
        if (!part) return;
        if (part.filename && part.body?.attachmentId) {
          attachments.push({
            id: part.body.attachmentId,
            filename: part.filename,
            mimeType: part.mimeType || 'application/octet-stream',
            size: part.body.size || 0,
          });
        }
        if (part.parts && Array.isArray(part.parts)) {
          part.parts.forEach(walkParts);
        }
      };

      walkParts(fullMsg.payload);

      const detectedCat = detectCategory(subject, fullMsg.snippet || '');
      const vendorName = extractVendor(fromHeader, subject);

      detailedMessages.push({
        id: fullMsg.id,
        threadId: fullMsg.threadId,
        from: fromHeader,
        fromEmail: extractEmail(fromHeader),
        subject,
        date: dateHeader,
        snippet: fullMsg.snippet || '',
        hasAttachment: attachments.length > 0,
        attachments,
        detectedCategory: detectedCat,
        estimatedVendor: vendorName,
      });
    } catch (e) {
      console.warn('Error fetching message details for message', msgItem.id, e);
    }
  }

  return detailedMessages;
}

export async function fetchAttachmentBlob(
  accessToken: string,
  messageId: string,
  attachmentId: string
): Promise<{ data: string; size: number }> {
  const res = await fetch(
    `https://gmail.googleapis.com/gmail/v1/users/me/messages/${messageId}/attachments/${attachmentId}`,
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    }
  );

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.error?.message || 'Failed to download attachment data from Gmail');
  }

  const json = await res.json();
  return {
    data: json.data, // base64url encoded string
    size: json.size,
  };
}

export interface SendGmailOptions {
  to: string;
  subject: string;
  bodyText: string;
  fromName?: string;
  fromEmail?: string;
  cc?: string;
  pdfBase64?: string;
  pdfFileName?: string;
}

/**
 * Sends an email using the Gmail REST API (RFC 2822).
 * NOTE: As required by Workspace guidelines, the calling UI MUST prompt
 * with an explicit confirmation dialog before invoking this function.
 */
export async function sendEmailViaGmail(
  accessToken: string,
  options: SendGmailOptions
): Promise<{ id: string; threadId: string }> {
  const boundary = `----=_Part_${Date.now()}_${Math.random().toString(36).substring(2)}`;

  let rawMessage = '';

  if (options.pdfBase64 && options.pdfFileName) {
    // Multipart MIME message with attachment
    const headers = [
      `To: ${options.to}`,
      options.cc ? `Cc: ${options.cc}` : null,
      `Subject: =?UTF-8?B?${btoa(unescape(encodeURIComponent(options.subject)))}?=`,
      'MIME-Version: 1.0',
      `Content-Type: multipart/mixed; boundary="${boundary}"`,
    ]
      .filter(Boolean)
      .join('\r\n');

    const cleanPdfBase64 = options.pdfBase64.replace(/^data:[^;]+;base64,/, '');

    const bodyPart = [
      `--${boundary}`,
      'Content-Type: text/plain; charset=UTF-8',
      'Content-Transfer-Encoding: 8bit',
      '',
      options.bodyText,
      '',
    ].join('\r\n');

    const attachmentPart = [
      `--${boundary}`,
      `Content-Type: application/pdf; name="${options.pdfFileName}"`,
      'Content-Transfer-Encoding: base64',
      `Content-Disposition: attachment; filename="${options.pdfFileName}"`,
      '',
      cleanPdfBase64,
      '',
      `--${boundary}--`,
    ].join('\r\n');

    rawMessage = `${headers}\r\n\r\n${bodyPart}\r\n${attachmentPart}`;
  } else {
    // Plain text email
    const headers = [
      `To: ${options.to}`,
      options.cc ? `Cc: ${options.cc}` : null,
      `Subject: =?UTF-8?B?${btoa(unescape(encodeURIComponent(options.subject)))}?=`,
      'Content-Type: text/plain; charset=UTF-8',
      'Content-Transfer-Encoding: 8bit',
    ]
      .filter(Boolean)
      .join('\r\n');

    rawMessage = `${headers}\r\n\r\n${options.bodyText}`;
  }

  // Base64URL encode the raw MIME message
  const utf8Bytes = new TextEncoder().encode(rawMessage);
  let binaryString = '';
  for (let i = 0; i < utf8Bytes.length; i++) {
    binaryString += String.fromCharCode(utf8Bytes[i]);
  }
  const base64 = btoa(binaryString);
  const base64Url = base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

  const response = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ raw: base64Url }),
  });

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData?.error?.message || `Failed to dispatch email via Gmail API: ${response.statusText}`);
  }

  return await response.json();
}
