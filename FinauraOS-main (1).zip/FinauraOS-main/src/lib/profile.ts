import { supabase } from './supabase';
import { BusinessProfile, UserAccount } from '../types';
import { User as SupabaseAuthUser } from '@supabase/supabase-js';

const STORAGE_KEY_PREFIX = 'finaura_profile_';

export const defaultEmptyBusinessProfile: BusinessProfile = {
  businessName: '',
  businessType: 'proprietorship',
  industry: 'Services & Consulting',
  state: 'Maharashtra',
  gstStatus: 'unregistered',
  gstin: undefined,
  persona: 'freelancer',
  turnoverRange: '< ₹20 Lakhs',
  incorporationYear: `${new Date().getFullYear()}`,
  contactName: '',
};

export interface ProfileCheckResult {
  exists: boolean;
  onboarding_completed: boolean;
  profile: BusinessProfile;
  isNewUser: boolean;
}

interface StoredProfileRecord {
  exists: boolean;
  onboarding_completed: boolean;
  profile: BusinessProfile;
  updatedAt: string;
}

function getLocalProfile(userId: string): StoredProfileRecord | null {
  try {
    const raw = localStorage.getItem(`${STORAGE_KEY_PREFIX}${userId}`);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.warn('Error reading cached FINAURA profile:', err);
  }
  return null;
}

function setLocalProfile(userId: string, record: StoredProfileRecord): void {
  try {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}${userId}`, JSON.stringify(record));
  } catch (err) {
    console.warn('Error saving local FINAURA profile:', err);
  }
}

/**
 * Check whether a FINAURA profile exists for the authenticated user.
 * Queries Supabase 'profiles' table first; falls back to user_metadata and local storage.
 * Does NOT create a duplicate profile if one already exists.
 */
export async function checkAndGetFinauraProfile(
  user: SupabaseAuthUser | UserAccount
): Promise<ProfileCheckResult> {
  const userId = user.id;
  const userEmail = user.email || '';
  const meta = ('user_metadata' in user ? user.user_metadata : {}) || {};
  const fullName =
    meta.full_name ||
    meta.name ||
    ('name' in user ? user.name : '') ||
    (userEmail ? userEmail.split('@')[0] : 'Founder');

  let dbProfile: any = null;
  let tableQueryAttempted = false;

  // 1. Check Supabase 'profiles' table
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    tableQueryAttempted = true;
    if (!error && data) {
      dbProfile = data;
    }
  } catch (err) {
    console.warn('Supabase profiles query error or table not configured:', err);
  }

  // 2. If record found in Supabase 'profiles' table
  if (dbProfile) {
    const businessProfile: BusinessProfile = {
      ...defaultEmptyBusinessProfile,
      businessName: dbProfile.business_name || `${fullName}'s Business`,
      businessType: dbProfile.business_type || 'proprietorship',
      industry: dbProfile.industry || 'Technology & Digital Services',
      state: dbProfile.state || 'Maharashtra',
      gstStatus: dbProfile.gst_status || 'unregistered',
      gstin: dbProfile.gstin || undefined,
      persona: dbProfile.persona || 'freelancer',
      contactName: dbProfile.full_name || fullName,
    };

    const onboardingCompleted = Boolean(dbProfile.onboarding_completed);

    setLocalProfile(userId, {
      exists: true,
      onboarding_completed: onboardingCompleted,
      profile: businessProfile,
      updatedAt: new Date().toISOString(),
    });

    return {
      exists: true,
      onboarding_completed: onboardingCompleted,
      profile: businessProfile,
      isNewUser: false,
    };
  }

  // 3. Fallback: Check user_metadata in Supabase Auth
  if (meta.finaura_profile_exists) {
    const local = getLocalProfile(userId);
    const onboardingCompleted = Boolean(meta.onboarding_completed ?? local?.onboarding_completed ?? false);
    const resolvedProfile: BusinessProfile = local?.profile || {
      ...defaultEmptyBusinessProfile,
      contactName: fullName,
      businessName: meta.profile?.businessName || `${fullName}'s Business`,
      persona: meta.profile?.persona || 'freelancer',
    };

    return {
      exists: true,
      onboarding_completed: onboardingCompleted,
      profile: resolvedProfile,
      isNewUser: false,
    };
  }

  // 4. Fallback: Check local storage
  const localRecord = getLocalProfile(userId);
  if (localRecord && localRecord.exists) {
    return {
      exists: true,
      onboarding_completed: Boolean(localRecord.onboarding_completed),
      profile: localRecord.profile,
      isNewUser: false,
    };
  }

  // 5. If profile does not exist: create it!
  return await createFinauraProfile(user, tableQueryAttempted);
}

/**
 * Creates a brand new FINAURA profile for a new authenticated user.
 * Sets onboarding_completed = false.
 * Persists in Supabase 'profiles' table, Supabase Auth user_metadata, and local storage.
 */
export async function createFinauraProfile(
  user: SupabaseAuthUser | UserAccount,
  tableAvailable: boolean = true
): Promise<ProfileCheckResult> {
  const userId = user.id;
  const userEmail = user.email || '';
  const meta = ('user_metadata' in user ? user.user_metadata : {}) || {};
  const fullName =
    meta.full_name ||
    meta.name ||
    ('name' in user ? user.name : '') ||
    (userEmail ? userEmail.split('@')[0] : 'Founder');
  const avatarUrl =
    meta.avatar_url ||
    meta.picture ||
    ('avatarUrl' in user ? user.avatarUrl : '') ||
    `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(fullName)}`;

  const newBusinessProfile: BusinessProfile = {
    ...defaultEmptyBusinessProfile,
    businessName: `${fullName}'s Business`,
    contactName: fullName,
    persona: 'freelancer',
    gstStatus: 'unregistered',
  };

  // Explicitly set onboarding_completed = false for new users
  const onboarding_completed = false;

  // 1. Attempt insert into Supabase 'profiles' table
  if (tableAvailable) {
    try {
      const { error: insertErr } = await supabase.from('profiles').upsert(
        {
          id: userId,
          email: userEmail,
          full_name: fullName,
          avatar_url: avatarUrl,
          business_name: newBusinessProfile.businessName,
          business_type: newBusinessProfile.businessType,
          industry: newBusinessProfile.industry,
          state: newBusinessProfile.state,
          gst_status: newBusinessProfile.gstStatus,
          gstin: newBusinessProfile.gstin || null,
          persona: newBusinessProfile.persona,
          onboarding_completed: false,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'id' }
      );
      if (insertErr) {
        console.warn('Could not insert into Supabase profiles table:', insertErr.message);
      }
    } catch (err) {
      console.warn('Exception during profiles table upsert:', err);
    }
  }

  // 2. Persist in Supabase Auth user_metadata
  try {
    await supabase.auth.updateUser({
      data: {
        finaura_profile_exists: true,
        onboarding_completed: false,
        profile: {
          businessName: newBusinessProfile.businessName,
          contactName: fullName,
          persona: newBusinessProfile.persona,
        },
      },
    });
  } catch (err) {
    console.warn('Failed updating user_metadata in Supabase auth:', err);
  }

  // 3. Persist in local storage
  setLocalProfile(userId, {
    exists: true,
    onboarding_completed: false,
    profile: newBusinessProfile,
    updatedAt: new Date().toISOString(),
  });

  return {
    exists: true,
    onboarding_completed: false,
    profile: newBusinessProfile,
    isNewUser: true,
  };
}

/**
 * Saves completed onboarding state and updates profile data.
 * Sets onboarding_completed = true.
 */
export async function saveCompletedOnboarding(
  userId: string,
  updatedProfile: BusinessProfile
): Promise<void> {
  // 1. Update Supabase table if available
  try {
    await supabase
      .from('profiles')
      .update({
        business_name: updatedProfile.businessName,
        business_type: updatedProfile.businessType,
        industry: updatedProfile.industry,
        state: updatedProfile.state,
        gst_status: updatedProfile.gstStatus,
        gstin: updatedProfile.gstin || null,
        persona: updatedProfile.persona,
        turnover_range: updatedProfile.turnoverRange,
        contact_name: updatedProfile.contactName,
        onboarding_completed: true,
        updated_at: new Date().toISOString(),
      })
      .eq('id', userId);
  } catch (err) {
    console.warn('Failed updating Supabase profiles table on onboarding complete:', err);
  }

  // 2. Update Supabase Auth user_metadata
  try {
    await supabase.auth.updateUser({
      data: {
        finaura_profile_exists: true,
        onboarding_completed: true,
        profile: {
          businessName: updatedProfile.businessName,
          contactName: updatedProfile.contactName,
          persona: updatedProfile.persona,
        },
      },
    });
  } catch (err) {
    console.warn('Failed updating Supabase user_metadata on onboarding complete:', err);
  }

  // 3. Update local storage
  setLocalProfile(userId, {
    exists: true,
    onboarding_completed: true,
    profile: updatedProfile,
    updatedAt: new Date().toISOString(),
  });
}
