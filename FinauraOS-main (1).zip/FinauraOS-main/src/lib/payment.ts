import {
  PlanTier,
  BillingCycle,
  UserSubscription,
  BillingInvoice,
} from '../types';
import { PLANS } from './plans';

export interface CheckoutOptions {
  planId: PlanTier;
  billingCycle: BillingCycle;
  paymentMethodType: 'upi' | 'card' | 'netbanking';
  upiVpa?: string;
  cardDetails?: {
    number: string;
    exp: string;
    cvv: string;
    name: string;
  };
  netbankingBank?: string;
}

export interface PaymentResult {
  success: boolean;
  transactionId?: string;
  invoiceNumber?: string;
  error?: string;
  updatedSubscription?: UserSubscription;
  newInvoice?: BillingInvoice;
}

// Payment Service Abstraction Layer
class PaymentService {
  private isDemoMode: boolean = true;

  constructor() {
    // Check if live Razorpay/Stripe keys exist in environment
    const hasLiveKeys = typeof process !== 'undefined' && Boolean(process.env.RAZORPAY_KEY_ID);
    this.isDemoMode = !hasLiveKeys;
  }

  public getIsDemoMode(): boolean {
    return this.isDemoMode;
  }

  // Simulate or execute checkout
  public async processCheckout(
    currentSub: UserSubscription,
    options: CheckoutOptions
  ): Promise<PaymentResult> {
    const targetPlan = PLANS[options.planId];
    if (!targetPlan) {
      return { success: false, error: 'Invalid plan selected' };
    }

    const amount =
      options.billingCycle === 'yearly'
        ? targetPlan.priceYearly
        : targetPlan.priceMonthly;

    // Simulated network processing latency
    await new Promise((resolve) => setTimeout(resolve, 800));

    // Demo Mode processing
    const now = new Date();
    const periodEnd = new Date(now);
    if (options.billingCycle === 'yearly') {
      periodEnd.setFullYear(periodEnd.getFullYear() + 1);
    } else {
      periodEnd.setMonth(periodEnd.getMonth() + 1);
    }

    const invoiceNumber = `INV-${now.getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const txId = `txn_${Date.now()}_${Math.random().toString(36).substring(7)}`;

    const updatedSubscription: UserSubscription = {
      ...currentSub,
      planId: options.planId,
      status: 'active',
      billingCycle: options.billingCycle,
      currentPeriodStart: now.toISOString(),
      currentPeriodEnd: periodEnd.toISOString(),
      cancelAtPeriodEnd: false,
      pendingDowngradePlanId: undefined,
      pendingDowngradeDate: undefined,
      paymentMethod: {
        type: options.paymentMethodType,
        vpa: options.paymentMethodType === 'upi' ? (options.upiVpa || 'user@okhdfcbank') : undefined,
        last4: options.paymentMethodType === 'card' ? (options.cardDetails?.number.slice(-4) || '4242') : undefined,
        brand: options.paymentMethodType === 'card' ? 'Visa' : undefined,
      },
      lastPaymentStatus: 'success',
      lastPaymentDate: now.toISOString(),
      lastPaymentAmount: amount,
      isDemoMode: this.isDemoMode,
    };

    const newInvoice: BillingInvoice = {
      id: `inv_${Date.now()}`,
      invoiceNumber,
      date: now.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
      planId: options.planId,
      planName: targetPlan.name,
      amount,
      status: 'paid',
      billingCycle: options.billingCycle,
      paymentMethod: options.paymentMethodType.toUpperCase(),
      receiptUrl: '#',
    };

    return {
      success: true,
      transactionId: txId,
      invoiceNumber,
      updatedSubscription,
      newInvoice,
    };
  }

  // Handle plan cancellation (active until current period end)
  public async cancelSubscription(
    currentSub: UserSubscription
  ): Promise<{ success: boolean; updatedSubscription: UserSubscription; error?: string }> {
    await new Promise((resolve) => setTimeout(resolve, 500));

    const updatedSubscription: UserSubscription = {
      ...currentSub,
      status: 'cancelled',
      cancelAtPeriodEnd: true,
    };

    return {
      success: true,
      updatedSubscription,
    };
  }

  // Resume a cancelled subscription before period end
  public async resumeSubscription(
    currentSub: UserSubscription
  ): Promise<{ success: boolean; updatedSubscription: UserSubscription; error?: string }> {
    await new Promise((resolve) => setTimeout(resolve, 500));

    const updatedSubscription: UserSubscription = {
      ...currentSub,
      status: 'active',
      cancelAtPeriodEnd: false,
    };

    return {
      success: true,
      updatedSubscription,
    };
  }

  // Schedule a downgrade at the end of billing period
  public async scheduleDowngrade(
    currentSub: UserSubscription,
    targetPlanId: PlanTier
  ): Promise<{ success: boolean; updatedSubscription: UserSubscription; error?: string }> {
    await new Promise((resolve) => setTimeout(resolve, 500));

    const updatedSubscription: UserSubscription = {
      ...currentSub,
      status: 'scheduled_downgrade',
      pendingDowngradePlanId: targetPlanId,
      pendingDowngradeDate: currentSub.currentPeriodEnd,
    };

    return {
      success: true,
      updatedSubscription,
    };
  }

  // Generate simulated invoice text download
  public downloadInvoice(inv: BillingInvoice, businessName: string) {
    const content = `
================================================================================
                            FINAURA INC. TAX INVOICE
                        Autonomous Financial OS for Bharat
================================================================================
Invoice No   : ${inv.invoiceNumber}
Invoice Date : ${inv.date}
GSTIN        : 27AABCF1234F1Z8 (Finaura Software Pvt Ltd)
SAC Code     : 998313 (Information Technology & Software as a Service)

BILLED TO:
Entity Name  : ${businessName}
GSTIN        : Customer GSTIN Registered
Address      : India

SUBSCRIPTION SUMMARY:
Plan Name    : FINAURA ${inv.planName.toUpperCase()} WORKSPACE
Billing Term : ${inv.billingCycle.toUpperCase()}
Status       : ${inv.status.toUpperCase()}
Payment Mode : ${inv.paymentMethod}

Item Description                         SAC        Taxable (₹)   GST Rate   Total (₹)
--------------------------------------------------------------------------------
Finaura Cloud Software Subscription      998313     ${(inv.amount / 1.18).toFixed(2)}    18.00%     ${inv.amount.toLocaleString('en-IN')}

Total Amount Paid (inclusive of 18% GST): ₹${inv.amount.toLocaleString('en-IN')}
Amount in Words: INR ${inv.amount} Only

Payment Method: ${inv.paymentMethod}
Digital Signature: Signed by Finaura Autonomous Billing Node
Note: This is a computer-generated tax invoice and requires no physical signature.
================================================================================
    `.trim();

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${inv.invoiceNumber}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}

export const paymentService = new PaymentService();
