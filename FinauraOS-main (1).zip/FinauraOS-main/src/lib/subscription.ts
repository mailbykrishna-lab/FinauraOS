import {
  UserSubscription,
  BillingInvoice,
  UsageMetrics,
  PlanTier,
  Invoice,
  UploadedDoc,
} from '../types';
import { PLANS } from './plans';

const STORAGE_KEY_SUB = 'finaura_subscription_state_v1';
const STORAGE_KEY_INVOICES = 'finaura_billing_invoices_v1';
const STORAGE_KEY_AI_USAGE = 'finaura_ai_questions_used_v1';

export const initialSubscription: UserSubscription = {
  planId: 'growth',
  status: 'active',
  billingCycle: 'monthly',
  currentPeriodStart: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
  currentPeriodEnd: new Date(Date.now() + 23 * 24 * 60 * 60 * 1000).toISOString(),
  cancelAtPeriodEnd: false,
  paymentMethod: {
    type: 'upi',
    vpa: 'director@okhdfcbank',
  },
  lastPaymentStatus: 'success',
  lastPaymentDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
  lastPaymentAmount: 499,
  isDemoMode: true,
};

export const sampleBillingInvoices: BillingInvoice[] = [
  {
    id: 'inv_b1',
    invoiceNumber: 'INV-2026-0012',
    date: '01 Sep 2026',
    planId: 'growth',
    planName: 'Growth',
    amount: 499,
    status: 'paid',
    billingCycle: 'monthly',
    paymentMethod: 'UPI',
    receiptUrl: '#',
  },
  {
    id: 'inv_b2',
    invoiceNumber: 'INV-2026-0008',
    date: '01 Aug 2026',
    planId: 'growth',
    planName: 'Growth',
    amount: 499,
    status: 'paid',
    billingCycle: 'monthly',
    paymentMethod: 'UPI',
    receiptUrl: '#',
  },
  {
    id: 'inv_b3',
    invoiceNumber: 'INV-2026-0003',
    date: '01 Jul 2026',
    planId: 'growth',
    planName: 'Growth',
    amount: 499,
    status: 'paid',
    billingCycle: 'monthly',
    paymentMethod: 'Netbanking (HDFC)',
    receiptUrl: '#',
  },
];

// Read stored subscription or fallback
export function getStoredSubscription(): UserSubscription {
  if (typeof window === 'undefined') return initialSubscription;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SUB);
    if (raw) return JSON.parse(raw);
  } catch (err) {
    console.warn('Could not read subscription from storage', err);
  }
  return initialSubscription;
}

// Save subscription
export function saveSubscription(sub: UserSubscription): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_SUB, JSON.stringify(sub));
  } catch (err) {
    console.warn('Could not save subscription to storage', err);
  }
}

// Read stored billing invoices
export function getStoredBillingInvoices(): BillingInvoice[] {
  if (typeof window === 'undefined') return sampleBillingInvoices;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_INVOICES);
    if (raw) return JSON.parse(raw);
  } catch (err) {
    console.warn('Could not read billing invoices from storage', err);
  }
  return sampleBillingInvoices;
}

// Save billing invoices
export function saveBillingInvoices(invoices: BillingInvoice[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_INVOICES, JSON.stringify(invoices));
  } catch (err) {
    console.warn('Could not save billing invoices to storage', err);
  }
}

// AI Questions tracker
export function getAIQuestionsUsed(): number {
  if (typeof window === 'undefined') return 18;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_AI_USAGE);
    if (raw) return parseInt(raw, 10);
  } catch {}
  return 18;
}

export function incrementAIQuestionsUsed(): number {
  const current = getAIQuestionsUsed() + 1;
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(STORAGE_KEY_AI_USAGE, current.toString());
    } catch {}
  }
  return current;
}

// Calculate real-time metrics based on live app data
export function calculateUsageMetrics(
  planId: PlanTier,
  invoices: Invoice[] = [],
  documents: UploadedDoc[] = [],
  customTeamMembers: number = 2,
  customBusinesses: number = 1
): UsageMetrics {
  const plan = PLANS[planId] || PLANS.growth;
  const aiUsed = getAIQuestionsUsed();

  // Calculate document storage in bytes (approx 2.4 GB base + uploaded docs)
  const baseStorageBytes = 2.4 * 1024 * 1024 * 1024;
  const docExtraBytes = documents.length * 15 * 1024 * 1024; // 15MB per doc average
  const totalStorageBytes = baseStorageBytes + docExtraBytes;

  return {
    aiQuestionsUsed: aiUsed,
    aiQuestionsLimit: plan.limits.aiQuestionsPerMonth,
    storageUsedBytes: totalStorageBytes,
    storageLimitBytes: plan.limits.storageGB * 1024 * 1024 * 1024,
    invoicesCount: invoices.length || 23,
    invoicesLimit: plan.limits.invoicesPerMonth,
    teamMembersCount: customTeamMembers,
    teamMembersLimit: plan.limits.teamMembers,
    businessesCount: customBusinesses,
    businessesLimit: plan.limits.businesses,
  };
}

export const subscriptionManager = {
  getSubscription: getStoredSubscription,
  saveSubscription: saveSubscription,
  getBillingInvoices: getStoredBillingInvoices,
  saveBillingInvoices: saveBillingInvoices,
  addBillingInvoice: (invoice: BillingInvoice): BillingInvoice[] => {
    const list = getStoredBillingInvoices();
    const updated = [invoice, ...list];
    saveBillingInvoices(updated);
    return updated;
  },
  getUsageMetrics: calculateUsageMetrics,
  getAIQuestionsUsed,
  incrementAIQuestionsUsed,
};

