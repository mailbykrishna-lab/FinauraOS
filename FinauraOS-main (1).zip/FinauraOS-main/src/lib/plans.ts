import {
  PlanTier,
  PlanDefinition,
  PlanFeature,
  FeatureKey,
  BusinessProfile,
} from '../types';

export const PLANS: Record<PlanTier, PlanDefinition> = {
  free: {
    id: 'free',
    name: 'Free',
    tagline: 'Get your finances organized.',
    purpose: 'Get your finances organized with essential accounting and statutory tracking.',
    priceMonthly: 0,
    priceYearly: 0,
    monthlyEquivalentYearly: 0,
    ctaText: 'Start Free',
    targetAudience: 'Solo freelancers & early-stage creators starting their financial journey.',
    features: [
      'Basic dashboard overview',
      'Basic income and expense tracking',
      'Limited invoices (up to 5/month)',
      'Basic customer management',
      'Basic document storage (1 GB)',
      'Basic compliance calendar',
      'Limited AI questions (15/month)',
    ],
    limits: {
      aiQuestionsPerMonth: 15,
      storageGB: 1,
      invoicesPerMonth: 5,
      teamMembers: 1,
      businesses: 1,
    },
    isCA: false,
  },
  growth: {
    id: 'growth',
    name: 'Growth',
    tagline: 'Understand your numbers and stay on top of compliance.',
    purpose: 'Understand your numbers, automate reconciliations, and stay on top of Indian compliance.',
    priceMonthly: 499,
    priceYearly: 4790, // ~₹399/mo (save 20%)
    monthlyEquivalentYearly: 399,
    badge: 'MOST POPULAR',
    isPopular: true,
    ctaText: 'Start Growth',
    targetAudience: 'Growing consultants, service businesses & active MSMEs needing notice-proof books.',
    features: [
      'Full accounting workspace & double-entry ledger',
      'Invoice and payment tracking',
      'Expense intelligence & categorization',
      'Receivables and payables management',
      'Government-referenced compliance updates',
      'Automated statutory compliance reminders',
      'GST workflow support (GSTR-1 & GSTR-3B matching)',
      'TDS workflow support (194C, 194J, 194I)',
      'ITR workflow support (Presumptive 44ADA/AD)',
      'AI financial insights & health scores',
      'AI document analysis & OCR bill parsing',
      'Business health insights',
      'Increased document storage (10 GB)',
    ],
    limits: {
      aiQuestionsPerMonth: 75,
      storageGB: 10,
      invoicesPerMonth: 100,
      teamMembers: 2,
      businesses: 1,
    },
    isCA: false,
  },
  business: {
    id: 'business',
    name: 'Business',
    tagline: 'Run your finance workflow as your business grows.',
    purpose: 'Run your multi-user finance workflow with forecasting, payroll, and inventory.',
    priceMonthly: 999,
    priceYearly: 9590, // ~₹799/mo (save 20%)
    monthlyEquivalentYearly: 799,
    badge: 'SCALING TEAMS',
    ctaText: 'Start Business',
    targetAudience: 'Agencies, trading firms, and multi-member teams with operational depth.',
    features: [
      'Everything in Growth plus:',
      'Multiple users (up to 5 team members)',
      'Advanced accounting & multi-ledger P&L',
      'Cash-flow analysis & runway metrics',
      'Financial forecasting & revenue projections',
      'Advanced AI insights & scenario modeling',
      'Comprehensive business reports & exports',
      'Inventory management & stock valuation',
      'Payroll processing & TDS Form 16 prep',
      'Vendor management (Section 43B(h) MSME tracking)',
      'Advanced compliance workflows',
      'CA collaboration workspace',
      'Priority email & chat support',
    ],
    limits: {
      aiQuestionsPerMonth: 250,
      storageGB: 30,
      invoicesPerMonth: 500,
      teamMembers: 5,
      businesses: 2,
    },
    isCA: false,
  },
  professional: {
    id: 'professional',
    name: 'Professional',
    tagline: 'Connect finance, intelligence and professional support.',
    purpose: 'Connect advanced intelligence, automation, multi-entity support, and audit-ready escrow.',
    priceMonthly: 1499,
    priceYearly: 14390, // ~₹1,199/mo (save 20%)
    monthlyEquivalentYearly: 1199,
    badge: 'MAXIMUM CAPABILITY',
    ctaText: 'Go Professional',
    targetAudience: 'High-velocity startups, complex multi-entity businesses & funded companies.',
    features: [
      'Everything in Business plus:',
      'Advanced financial intelligence & autonomous rules',
      'Automated reconciliation rules & bank sync',
      'Multi-business support (up to 5 legal entities)',
      'Advanced compliance monitoring & ROC filings',
      'Direct professional collaboration & workpaper export',
      'Audit preparation workspace & trial balances',
      'Advanced document workflows & tamper-proof vault',
      'Custom role-based permissions & audit trails',
      'Dedicated priority account support',
    ],
    limits: {
      aiQuestionsPerMonth: 750,
      storageGB: 100,
      invoicesPerMonth: 2500,
      teamMembers: 15,
      businesses: 5,
    },
    isCA: false,
  },
  ca_pro: {
    id: 'ca_pro',
    name: 'CA Pro',
    tagline: 'Built specifically for CAs, accounting firms & tax professionals.',
    purpose: 'Purpose-built practice management OS for Chartered Accountants and finance firms.',
    priceMonthly: 1999,
    priceYearly: 19190, // ~₹1,599/mo (save 20%)
    monthlyEquivalentYearly: 1599,
    badge: 'FOR PRACTITIONERS',
    ctaText: 'Explore CA Pro',
    targetAudience: 'Chartered Accountants, tax practitioners, accounting firms & compliance advisors.',
    features: [
      'Client management (up to 25 client workspaces)',
      'Multi-client dashboard with unified deadline radar',
      'Automated client document requests & secure portal',
      'Master statutory compliance calendar across clients',
      'Client task management & team work allocations',
      'Financial review & one-click books validation',
      'AI client summaries & executive briefing notes',
      'Client communication portal & notices tracking',
      'Workflow management & Tally/ITD XML export',
      'Statutory deadline monitoring & proactive penalty alerts',
    ],
    limits: {
      aiQuestionsPerMonth: 1000,
      storageGB: 150,
      invoicesPerMonth: 5000,
      teamMembers: 10,
      businesses: 25, // 25 client accounts
    },
    isCA: true,
  },
};

// Plan hierarchy ranking for upgrade/downgrade logic
export const PLAN_RANKS: Record<PlanTier, number> = {
  free: 1,
  growth: 2,
  business: 3,
  professional: 4,
  ca_pro: 5,
};

// Feature mapping for central entitlement checks
export const FEATURE_ENTITLEMENTS: Record<FeatureKey, PlanTier[]> = {
  basic_tracking: ['free', 'growth', 'business', 'professional', 'ca_pro'],
  invoicing: ['free', 'growth', 'business', 'professional', 'ca_pro'],
  unlimited_invoicing: ['business', 'professional', 'ca_pro'],
  expense_intelligence: ['growth', 'business', 'professional', 'ca_pro'],
  receivables_payables: ['growth', 'business', 'professional', 'ca_pro'],
  compliance_updates: ['free', 'growth', 'business', 'professional', 'ca_pro'],
  compliance_reminders: ['growth', 'business', 'professional', 'ca_pro'],
  gst_workflow: ['growth', 'business', 'professional', 'ca_pro'],
  tds_workflow: ['growth', 'business', 'professional', 'ca_pro'],
  itr_workflow: ['growth', 'business', 'professional', 'ca_pro'],
  ai_financial_insights: ['growth', 'business', 'professional', 'ca_pro'],
  ai_document_analysis: ['growth', 'business', 'professional', 'ca_pro'],
  business_health_insights: ['growth', 'business', 'professional', 'ca_pro'],
  multiple_users: ['business', 'professional', 'ca_pro'],
  advanced_accounting: ['business', 'professional', 'ca_pro'],
  cashflow_analysis: ['business', 'professional', 'ca_pro'],
  financial_forecasting: ['business', 'professional', 'ca_pro'],
  inventory_management: ['business', 'professional', 'ca_pro'],
  payroll_management: ['business', 'professional', 'ca_pro'],
  vendor_management_43b: ['business', 'professional', 'ca_pro'],
  advanced_compliance_workflow: ['business', 'professional', 'ca_pro'],
  ca_collaboration: ['business', 'professional', 'ca_pro'],
  priority_support: ['business', 'professional', 'ca_pro'],
  multi_business: ['professional', 'ca_pro'],
  audit_prep_workspace: ['professional', 'ca_pro'],
  custom_permissions: ['professional', 'ca_pro'],
  ca_client_management: ['ca_pro'],
  ca_client_document_requests: ['ca_pro'],
  ca_task_management: ['ca_pro'],
  ca_financial_review: ['ca_pro'],
  ca_ai_client_summaries: ['ca_pro'],
  ca_deadline_monitoring: ['ca_pro'],
};

// Check if a plan has access to a specific feature
export function hasFeature(currentPlan: PlanTier, feature: FeatureKey): boolean {
  const allowed = FEATURE_ENTITLEMENTS[feature];
  if (!allowed) return false;
  return allowed.includes(currentPlan);
}

// Check if a plan meets or exceeds required tier
export function isPlanAtLeast(currentPlan: PlanTier, requiredPlan: PlanTier): boolean {
  return PLAN_RANKS[currentPlan] >= PLAN_RANKS[requiredPlan];
}

// Get plan definition safely
export function getPlan(planId: PlanTier): PlanDefinition {
  return PLANS[planId] || PLANS.free;
}

// Calculate smart plan recommendation based on business profile
export interface PlanRecommendation {
  recommendedPlan: PlanTier;
  confidence: 'high' | 'medium';
  primaryReason: string;
  supportingReasons: string[];
}

export function getRecommendedPlan(
  profile?: Partial<BusinessProfile>,
  metrics?: { teamMembers?: number; hasPayroll?: boolean; hasInventory?: boolean }
): PlanRecommendation {
  if (!profile) {
    return {
      recommendedPlan: 'growth',
      confidence: 'medium',
      primaryReason: 'Growth is our balanced tier for active businesses managing GST & income tax.',
      supportingReasons: ['Includes automated GST & TDS workflows', 'AI financial health insights'],
    };
  }

  // 1. Check if CA or accounting firm
  const isCA = 
    profile.industry?.toLowerCase().includes('accounting') ||
    profile.industry?.toLowerCase().includes('audit') ||
    profile.businessName?.toLowerCase().includes('associates') ||
    profile.businessName?.toLowerCase().includes('ca ') ||
    profile.businessName?.toLowerCase().includes('& co');

  if (isCA) {
    return {
      recommendedPlan: 'ca_pro',
      confidence: 'high',
      primaryReason: 'CA Pro provides multi-client workspaces, audit validation, and client document management.',
      supportingReasons: [
        'Manage up to 25 client workspaces simultaneously',
        'Centralized statutory deadline tracking across clients',
        'Direct Tally & ITD workpaper export',
      ],
    };
  }

  // 2. Check for multi-user, multi-business or large turnover
  const turnover = profile.turnoverRange || '';
  const isHighTurnover = turnover.includes('1 Cr') || turnover.includes('5 Cr') || turnover.includes('10 Cr') || turnover.includes('50L - 1Cr');
  const hasTeam = (metrics?.teamMembers || 1) > 2;
  const needsInventoryOrPayroll = metrics?.hasPayroll || metrics?.hasInventory;
  const isPvtLtd = profile.businessType === 'pvt_ltd' || profile.businessType === 'llp';

  if (isHighTurnover && (isPvtLtd || hasTeam)) {
    return {
      recommendedPlan: 'business',
      confidence: 'high',
      primaryReason: 'Business plan supports multi-user collaboration, financial forecasting, and Section 43B(h) MSME compliance.',
      supportingReasons: [
        `Recommended for ${profile.businessName} based on ${profile.businessType?.toUpperCase()} structure`,
        'Advanced cash flow forecasting & multi-user permissions',
        'Vendor Section 43B(h) compliance tracking',
      ],
    };
  }

  // 3. Check for GST registered MSME or active agency
  if (profile.gstStatus === 'registered' || profile.persona === 'msme' || profile.persona === 'agency' || profile.persona === 'startup') {
    return {
      recommendedPlan: 'growth',
      confidence: 'high',
      primaryReason: 'Growth automates your monthly GST filings, vendor ITC reconciliation, and TDS compliance.',
      supportingReasons: [
        'Reconciles GSTR-2B automatically to prevent losing Input Tax Credit',
        'Tracks TDS 194C/J/I withholding without manual spreadsheets',
        'AI document scanner for auto-categorizing invoices & bills',
      ],
    };
  }

  // 4. Default for solo freelancer with lower turnover
  return {
    recommendedPlan: 'free',
    confidence: 'medium',
    primaryReason: 'Free plan covers clean invoicing, income & expense tracking, and basic compliance reminders.',
    supportingReasons: [
      'Simple GST & Section 44ADA compliance calendar',
      'Track up to 5 tax invoices per month at zero cost',
      'Upgrade anytime as your client volume scales',
    ],
  };
}

// Detailed comparison matrix categories
export interface ComparisonCategory {
  category: string;
  items: {
    name: string;
    description?: string;
    free: string | boolean;
    growth: string | boolean;
    business: string | boolean;
    professional: string | boolean;
  }[];
}

export const COMPARISON_MATRIX: ComparisonCategory[] = [
  {
    category: 'Core Accounting & Ledgers',
    items: [
      { name: 'Income & Expense Tracking', free: 'Basic', growth: 'Full Double-Entry', business: 'Advanced Multi-Ledger', professional: 'Autonomous Rules' },
      { name: 'Monthly Tax Invoices', free: '5 / month', growth: '100 / month', business: '500 / month', professional: '2,500 / month' },
      { name: 'Receivables & Payables', free: false, growth: true, business: true, professional: true },
      { name: 'Bank Statement Reconciliation', free: 'Manual', growth: 'Guided CSV', business: 'Automated 2-Way', professional: 'Real-time AA Feed' },
      { name: 'Cash Flow Forecasting', free: false, growth: false, business: '90-Day Runway', professional: 'Scenario Simulator' },
      { name: 'Inventory & Stock Valuation', free: false, growth: false, business: true, professional: true },
      { name: 'Payroll & Form 16 Generation', free: false, growth: false, business: 'Up to 25 staff', professional: 'Unlimited staff' },
    ],
  },
  {
    category: 'Indian Tax & Statutory Compliance',
    items: [
      { name: 'Statutory Compliance Calendar', free: 'Basic', growth: 'Smart Alerts', business: 'Proactive Priority', professional: 'Escalation Workflows' },
      { name: 'GSTR-1 & GSTR-3B Prep', free: false, growth: true, business: true, professional: true },
      { name: 'GSTR-2B vs Books ITC Matching', free: false, growth: true, business: true, professional: true },
      { name: 'TDS Withholding (194C, 194J, 194I)', free: false, growth: true, business: true, professional: true },
      { name: 'Presumptive Tax (44ADA & 44AD)', free: 'Estimator only', growth: 'Full Computation', business: 'Full Computation', professional: 'Audit Ready' },
      { name: 'MSME Section 43B(h) 45-Day Monitor', free: false, growth: false, business: true, professional: true },
      { name: 'Government Circulars (Simplified)', free: true, growth: true, business: true, professional: true },
    ],
  },
  {
    category: 'AI Financial Copilot & OCR',
    items: [
      { name: 'Monthly AI Questions', free: '15 queries', growth: '75 queries', business: '250 queries', professional: '750 queries' },
      { name: 'AI Bill & Invoice OCR Parsing', free: false, growth: true, business: true, professional: true },
      { name: 'Natural Language Finance Copilot', free: 'Standard', growth: 'Proactive Explanations', business: 'Deep Analysis', professional: 'Autonomous Advisor' },
      { name: 'Document Vault Storage', free: '1 GB', growth: '10 GB', business: '30 GB', professional: '100 GB' },
    ],
  },
  {
    category: 'Collaboration, Team & Audit',
    items: [
      { name: 'Team Member Seats', free: '1 user', growth: '2 users', business: '5 users', professional: '15 users' },
      { name: 'Separate Legal Entities / GSTINs', free: '1 entity', growth: '1 entity', business: '2 entities', professional: '5 entities' },
      { name: 'CA Collaboration Workspace', free: false, growth: false, business: true, professional: true },
      { name: 'Audit Workpaper & Tally XML Export', free: false, growth: false, business: true, professional: true },
      { name: 'Support SLA', free: 'Community', growth: 'Standard Email', business: 'Priority Chat & Email', professional: 'Dedicated Desk' },
    ],
  },
];

// FAQs for landing page pricing
export interface PricingFAQ {
  question: string;
  answer: string;
}

export const PRICING_FAQS: PricingFAQ[] = [
  {
    question: 'Can I start on the Free plan and upgrade later?',
    answer: 'Yes, absolutely. You can start on Free with zero commitment. As your invoice volume grows or you require automated GST matching and tax filing support, you can upgrade instantly with prorated billing.',
  },
  {
    question: 'Are professional CA consultation and audit fees included in the subscription?',
    answer: 'No. Finaura has two distinct layers: our SaaS software subscription covers your automated accounting, AI, and compliance tools. Certified Chartered Accountant services (such as formal audit sign-offs, statutory ITR filing representations, or 1-on-1 advisory) are separate professional services with transparent transparent fixed quotes.',
  },
  {
    question: 'How does the Yearly billing discount work?',
    answer: 'When you choose Yearly billing, you receive a flat 20% discount (equivalent to over 2 months free). You are billed once annually, and all plan limits remain active for the full 12-month period.',
  },
  {
    question: 'Is Finaura a government portal or official tax authority?',
    answer: 'No. Finaura is an autonomous private software OS. We provide government-referenced compliance updates, deterministic tax calculations based on the Income Tax Act and CGST rules, and direct exports formatted for official government portals (like GSTN and ITD).',
  },
  {
    question: 'What is the CA Pro plan and who is it for?',
    answer: 'CA Pro is specifically engineered for practicing Chartered Accountants, tax practitioners, and accounting firms. It provides multi-client workspaces, client document request portals, unified client compliance calendars, and Tally/ITD XML exports for managing up to 25 business clients.',
  },
  {
    question: 'What payment methods are supported in India?',
    answer: 'We support all major Indian payment methods via our secure checkout abstraction, including UPI (Google Pay, PhonePe, Paytm, BHIM), Netbanking (50+ Indian banks), Debit Cards, and Credit Cards.',
  },
  {
    question: 'What happens if I need to downgrade or cancel?',
    answer: 'You can cancel or downgrade at any time. When you cancel, your workspace remains fully active with your existing plan features until the end of your prepaid billing cycle. We never silently delete your invoices, ledger entries, or tax records.',
  },
];
