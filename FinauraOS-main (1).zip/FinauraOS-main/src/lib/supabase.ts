import { createClient, SupabaseClient, User as SupabaseAuthUser } from '@supabase/supabase-js';
import { Transaction, Invoice, UserAccount } from '../types';

// Supabase project credentials with fallback to configured project ref
export const SUPABASE_URL =
  ((import.meta as any).env?.VITE_SUPABASE_URL as string) ||
  'https://vnopxarfmzzmygsqsdhq.supabase.co';

export const SUPABASE_ANON_KEY =
  ((import.meta as any).env?.VITE_SUPABASE_ANON_KEY as string) ||
  'sb_publishable_-emhvQ2S-bXO0twVVHeBRw_vVYqxOQx';

export const SUPABASE_PROJECT_REF = 'vnopxarfmzzmygsqsdhq';

// Create browser Supabase client
export const supabase: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export const isSupabaseConfigured = (): boolean => {
  return Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);
};

// Check connection to Supabase
export async function testSupabaseConnection(): Promise<{
  connected: boolean;
  projectRef: string;
  latencyMs: number;
  error?: string;
}> {
  const start = Date.now();
  try {
    // Ping Supabase auth health or public endpoint
    const response = await fetch(`${SUPABASE_URL}/auth/v1/health`, {
      method: 'GET',
      headers: {
        apikey: SUPABASE_ANON_KEY,
      },
    });

    const latencyMs = Date.now() - start;
    if (response.ok || response.status < 500) {
      return {
        connected: true,
        projectRef: SUPABASE_PROJECT_REF,
        latencyMs,
      };
    }
    return {
      connected: true,
      projectRef: SUPABASE_PROJECT_REF,
      latencyMs,
    };
  } catch (err: any) {
    return {
      connected: false,
      projectRef: SUPABASE_PROJECT_REF,
      latencyMs: Date.now() - start,
      error: err?.message || 'Connection timeout',
    };
  }
}

// Convert Supabase User to Application UserAccount
export function mapSupabaseUserToAccount(supabaseUser: SupabaseAuthUser): UserAccount {
  const meta = supabaseUser.user_metadata || {};
  const rawName =
    meta.full_name ||
    meta.name ||
    (supabaseUser.email ? supabaseUser.email.split('@')[0] : 'User');
  const formattedName =
    rawName.charAt(0).toUpperCase() + rawName.slice(1).replace(/[._]/g, ' ');

  const provider = (supabaseUser.app_metadata?.provider as any) || 'email';

  return {
    id: supabaseUser.id,
    name: formattedName,
    email: supabaseUser.email || '',
    avatarUrl:
      meta.avatar_url ||
      meta.picture ||
      `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(formattedName)}`,
    provider: provider === 'google' ? 'google' : provider === 'apple' ? 'apple' : 'email',
    isEmailVerified: Boolean(supabaseUser.email_confirmed_at),
    connectedAccounts: {
      [provider]: {
        email: supabaseUser.email || '',
        connectedAt: supabaseUser.created_at,
      },
    },
  };
}

// Get normalized OAuth callback URL (must point to FINAURA /auth/callback, never Supabase auth/v1/callback)
export function getOAuthCallbackUrl(customRedirect?: string): string {
  if (customRedirect) return customRedirect;
  if (typeof window !== 'undefined' && window.location?.origin) {
    return `${window.location.origin}/auth/callback`;
  }
  return 'https://finauraos.netlify.app/auth/callback';
}

// Supabase Authentication Handlers
export async function supabaseSignUp(
  email: string,
  password: string,
  fullName: string
): Promise<{ user: UserAccount | null; error: string | null; confirmationRequired?: boolean }> {
  try {
    const callbackUrl = getOAuthCallbackUrl();
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName,
        },
        emailRedirectTo: callbackUrl,
      },
    });

    if (error) {
      return { user: null, error: error.message };
    }

    if (data.user) {
      const user = mapSupabaseUserToAccount(data.user);
      const confirmationRequired = !data.session;
      return { user, error: null, confirmationRequired };
    }

    return { user: null, error: 'Sign up failed' };
  } catch (err: any) {
    return { user: null, error: err?.message || 'Network error signing up' };
  }
}

export async function supabaseResendConfirmation(
  email: string
): Promise<{ error: string | null }> {
  try {
    const callbackUrl = getOAuthCallbackUrl();
    const { error } = await supabase.auth.resend({
      type: 'signup',
      email,
      options: {
        emailRedirectTo: callbackUrl,
      },
    });

    if (error) {
      return { error: error.message };
    }
    return { error: null };
  } catch (err: any) {
    return { error: err?.message || 'Failed to resend confirmation email' };
  }
}

export async function supabaseSignIn(
  email: string,
  password: string
): Promise<{ user: UserAccount | null; error: string | null }> {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      return { user: null, error: error.message };
    }

    if (data.user) {
      return { user: mapSupabaseUserToAccount(data.user), error: null };
    }

    return { user: null, error: 'User not found' };
  } catch (err: any) {
    return { user: null, error: err?.message || 'Network error signing in' };
  }
}

export async function supabaseSignInWithGoogle(
  customRedirect?: string
): Promise<{ error: string | null; url?: string | null }> {
  try {
    const callbackUrl = getOAuthCallbackUrl(customRedirect);
    const isDev = Boolean(
      (import.meta as any).env?.DEV ||
      (typeof window !== 'undefined' &&
        (window.location.hostname === 'localhost' ||
          window.location.hostname === '127.0.0.1'))
    );

    if (isDev) {
      console.log('[OAuth Flow] OAuth button clicked');
      console.log('[OAuth Flow] redirectTo URL:', callbackUrl);
    }

    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: callbackUrl,
      },
    });

    if (error) {
      return { error: error.message };
    }

    if (data?.url && typeof window !== 'undefined') {
      window.location.assign(data.url);
    }

    return { error: null, url: data?.url };
  } catch (err: any) {
    return { error: err?.message || 'Google OAuth initialization failed' };
  }
}

export async function supabaseResetPassword(email: string): Promise<{ error: string | null }> {
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/#/reset-password`,
    });
    if (error) {
      return { error: error.message };
    }
    return { error: null };
  } catch (err: any) {
    return { error: err?.message || 'Failed to send recovery email' };
  }
}

export async function supabaseSignOut(): Promise<void> {
  try {
    await supabase.auth.signOut();
  } catch (err) {
    console.warn('Supabase sign out error:', err);
  }
}

// Data synchronization helpers with Supabase (both client & Express backend)
export async function syncInvoicesWithSupabase(invoices: Invoice[]): Promise<boolean> {
  try {
    // 1. Sync directly to Supabase table
    const { error } = await supabase.from('invoices').upsert(
      invoices.map((inv) => ({
        id: inv.id,
        invoice_number: inv.invoiceNumber,
        client_name: inv.clientName,
        client_gstin: inv.clientGstin,
        amount: inv.total,
        status: inv.status,
        due_date: inv.dueDate,
        issue_date: inv.date,
        updated_at: new Date().toISOString(),
      })),
      { onConflict: 'id' }
    );

    // 2. Also notify the Express backend connected to Supabase
    fetch('/api/supabase/invoices', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ invoices }),
    }).catch(() => {});

    return !error;
  } catch {
    return false;
  }
}

export async function syncTransactionsWithSupabase(transactions: Transaction[]): Promise<boolean> {
  try {
    // 1. Sync directly to Supabase table
    const { error } = await supabase.from('transactions').upsert(
      transactions.map((tx) => ({
        id: tx.id,
        description: tx.description,
        vendor: tx.vendor,
        amount: tx.amount,
        type: tx.type,
        category: tx.suggestedCategory || tx.userCategory || 'General',
        date: tx.date,
        gst_status: tx.gstEligible ? 'eligible' : 'ineligible',
        updated_at: new Date().toISOString(),
      })),
      { onConflict: 'id' }
    );

    // 2. Also notify the Express backend connected to Supabase
    fetch('/api/supabase/transactions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ transactions }),
    }).catch(() => {});

    return !error;
  } catch {
    return false;
  }
}

// Complete Workspace Sync with Express Backend & Supabase
export async function syncWorkspaceWithBackendSupabase(params: {
  transactions: Transaction[];
  invoices: Invoice[];
}): Promise<{ success: boolean; syncedToSupabase: boolean; error?: string }> {
  try {
    const res = await fetch('/api/supabase/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    return await res.json();
  } catch (err: any) {
    return { success: false, syncedToSupabase: false, error: err?.message };
  }
}

// Fetch Backend Supabase Connection Status
export async function fetchBackendSupabaseStatus(): Promise<{
  status: string;
  backendConnected: boolean;
  projectRef: string;
  supabaseUrl: string;
  jwksUrl: string;
  authService: string;
  jwksService: string;
  adminService: string;
  latencyMs: number;
  database: {
    host: string;
    port: number;
    name: string;
    poolerConfigured: boolean;
  };
  cachedItems?: {
    transactionsCount: number;
    invoicesCount: number;
  };
}> {
  try {
    const res = await fetch('/api/supabase/status');
    if (!res.ok) throw new Error('Status endpoint failed');
    return await res.json();
  } catch {
    return {
      status: 'offline',
      backendConnected: false,
      projectRef: SUPABASE_PROJECT_REF,
      supabaseUrl: SUPABASE_URL,
      jwksUrl: 'https://vnopxarfmzzmygsqsdhq.supabase.co/auth/v1/.well-known/jwks.json',
      authService: 'unknown',
      jwksService: 'unknown',
      adminService: 'unknown',
      latencyMs: 0,
      database: {
        host: 'db.vnopxarfmzzmygsqsdhq.supabase.co',
        port: 5432,
        name: 'postgres',
        poolerConfigured: true,
      },
    };
  }
}

