import { Transaction } from '../types';

export interface ParsedTransactionRow {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'debit' | 'credit';
  vendor: string;
  category: string;
  confidence: number;
  status: 'pending_review' | 'approved';
  rawLine?: string;
  validationError?: string;
  bufferId?: string;
}

/**
 * Intelligent categorization dictionary for Indian SMB / startup transactions
 */
const CATEGORY_KEYWORDS: Record<string, { category: string; isTaxDeductible: boolean; isGstEligible: boolean }> = {
  // Software / Cloud
  aws: { category: 'Software & Cloud', isTaxDeductible: true, isGstEligible: true },
  amazon: { category: 'Office Supplies', isTaxDeductible: true, isGstEligible: true },
  google: { category: 'Software & Cloud', isTaxDeductible: true, isGstEligible: true },
  microsoft: { category: 'Software & Cloud', isTaxDeductible: true, isGstEligible: true },
  github: { category: 'Software & Cloud', isTaxDeductible: true, isGstEligible: true },
  adobe: { category: 'Software & Cloud', isTaxDeductible: true, isGstEligible: true },
  slack: { category: 'Software & Cloud', isTaxDeductible: true, isGstEligible: true },
  notion: { category: 'Software & Cloud', isTaxDeductible: true, isGstEligible: true },
  digitalocean: { category: 'Software & Cloud', isTaxDeductible: true, isGstEligible: true },
  zoho: { category: 'Software & Cloud', isTaxDeductible: true, isGstEligible: true },
  canva: { category: 'Software & Cloud', isTaxDeductible: true, isGstEligible: true },
  atlassian: { category: 'Software & Cloud', isTaxDeductible: true, isGstEligible: true },
  openai: { category: 'Software & Cloud', isTaxDeductible: true, isGstEligible: true },

  // Contractors & Consulting
  freelancer: { category: 'Contractors & Freelancers', isTaxDeductible: true, isGstEligible: false },
  consultant: { category: 'Contractors & Freelancers', isTaxDeductible: true, isGstEligible: true },
  upwork: { category: 'Contractors & Freelancers', isTaxDeductible: true, isGstEligible: false },
  fiverr: { category: 'Contractors & Freelancers', isTaxDeductible: true, isGstEligible: false },
  legal: { category: 'Legal & Professional', isTaxDeductible: true, isGstEligible: true },
  audit: { category: 'Legal & Professional', isTaxDeductible: true, isGstEligible: true },

  // Marketing & Ads
  meta: { category: 'Marketing & Ad Spend', isTaxDeductible: true, isGstEligible: true },
  facebook: { category: 'Marketing & Ad Spend', isTaxDeductible: true, isGstEligible: true },
  ads: { category: 'Marketing & Ad Spend', isTaxDeductible: true, isGstEligible: true },
  linkedin: { category: 'Marketing & Ad Spend', isTaxDeductible: true, isGstEligible: true },
  marketing: { category: 'Marketing & Ad Spend', isTaxDeductible: true, isGstEligible: true },

  // Office & Utilities
  rent: { category: 'Rent & Facilities', isTaxDeductible: true, isGstEligible: true },
  wework: { category: 'Rent & Facilities', isTaxDeductible: true, isGstEligible: true },
  airtel: { category: 'Utilities & Internet', isTaxDeductible: true, isGstEligible: true },
  jio: { category: 'Utilities & Internet', isTaxDeductible: true, isGstEligible: true },
  bescom: { category: 'Utilities & Internet', isTaxDeductible: true, isGstEligible: false },
  electricity: { category: 'Utilities & Internet', isTaxDeductible: true, isGstEligible: false },

  // Travel & Commute
  uber: { category: 'Travel & Meals', isTaxDeductible: true, isGstEligible: true },
  ola: { category: 'Travel & Meals', isTaxDeductible: true, isGstEligible: true },
  indigo: { category: 'Travel & Meals', isTaxDeductible: true, isGstEligible: true },
  makemytrip: { category: 'Travel & Meals', isTaxDeductible: true, isGstEligible: true },
  swiggy: { category: 'Travel & Meals', isTaxDeductible: false, isGstEligible: false },
  zomato: { category: 'Travel & Meals', isTaxDeductible: false, isGstEligible: false },

  // Banking & Statutory
  gst: { category: 'Taxes & Statutory', isTaxDeductible: false, isGstEligible: false },
  tds: { category: 'Taxes & Statutory', isTaxDeductible: false, isGstEligible: false },
  bank: { category: 'Bank Charges', isTaxDeductible: true, isGstEligible: true },
  interest: { category: 'Bank Charges', isTaxDeductible: true, isGstEligible: false },
};

/**
 * Predict category and vendor from transaction description
 */
export function classifyTransactionDescription(desc: string, type: 'debit' | 'credit'): {
  vendor: string;
  category: string;
  confidence: number;
} {
  const clean = desc.toLowerCase();

  if (type === 'credit') {
    return {
      vendor: desc.split(/[-–,/]/)[0]?.trim() || 'Client Payment',
      category: 'Client Retainer / Revenue',
      confidence: 0.94,
    };
  }

  for (const [kw, meta] of Object.entries(CATEGORY_KEYWORDS)) {
    if (clean.includes(kw)) {
      // derive nice vendor name
      const words = desc.split(/[\s,/_-]+/);
      const vendorMatch = words.find((w) => w.toLowerCase().includes(kw)) || kw;
      const formattedVendor = vendorMatch.charAt(0).toUpperCase() + vendorMatch.slice(1);

      return {
        vendor: formattedVendor,
        category: meta.category,
        confidence: 0.92,
      };
    }
  }

  return {
    vendor: desc.split(/[-–,/]/)[0]?.trim() || 'General Vendor',
    category: 'Office & Operations',
    confidence: 0.65,
  };
}

/**
 * Parses raw CSV text or bank statement text into previewable transactions
 */
export function parseTransactionsFromCsv(csvText: string): {
  success: boolean;
  rows: ParsedTransactionRow[];
  error?: string;
  summary: { totalRows: number; validRows: number; invalidRows: number; totalAmount: number };
} {
  if (!csvText || !csvText.trim()) {
    return {
      success: false,
      rows: [],
      error: 'CSV file is empty.',
      summary: { totalRows: 0, validRows: 0, invalidRows: 0, totalAmount: 0 },
    };
  }

  const lines = csvText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (lines.length < 2) {
    return {
      success: false,
      rows: [],
      error: 'CSV requires at least a header row and one data row.',
      summary: { totalRows: 0, validRows: 0, invalidRows: 0, totalAmount: 0 },
    };
  }

  // Search for the true header row within the first 30 lines
  let headerIndex = -1;
  let headerCols: string[] = [];

  for (let idx = 0; idx < Math.min(lines.length, 30); idx++) {
    const rawCols = splitCsvLine(lines[idx]);
    const lowerCols = rawCols.map((c) => c.toLowerCase().trim());
    const hasDateCol = lowerCols.some(
      (c) => c.includes('date') || c.includes('txn') || c.includes('time') || c === 'dt'
    );
    const hasAmountCol = lowerCols.some(
      (c) =>
        c.includes('amount') ||
        c.includes('debit') ||
        c.includes('credit') ||
        c.includes('withdrawal') ||
        c.includes('deposit') ||
        c.includes('amt') ||
        c === 'dr' ||
        c === 'cr'
    );

    if (hasDateCol && hasAmountCol) {
      headerIndex = idx;
      headerCols = lowerCols;
      break;
    }
  }

  // If no explicit header detected, default to row 0
  if (headerIndex === -1) {
    headerIndex = 0;
    headerCols = splitCsvLine(lines[0]).map((c) => c.toLowerCase().trim());
  }

  let dateIdx = headerCols.findIndex((c) => c.includes('date') || c.includes('txn') || c.includes('time') || c === 'dt');
  let descIdx = headerCols.findIndex((c) => c.includes('desc') || c.includes('narration') || c.includes('particulars') || c.includes('party') || c.includes('remark'));
  let amountIdx = headerCols.findIndex((c) => c === 'amount' || c.includes('total amt') || c.includes('net amt') || c === 'amt');
  let debitIdx = headerCols.findIndex((c) => c.includes('debit') || c.includes('withdrawal') || c === 'dr');
  let creditIdx = headerCols.findIndex((c) => c.includes('credit') || c.includes('deposit') || c === 'cr');
  let typeIdx = headerCols.findIndex((c) => c === 'type' || c.includes('dr/cr') || c.includes('cr/dr'));
  let categoryIdx = headerCols.findIndex((c) => c.includes('category'));
  let refIdx = headerCols.findIndex((c) => c.includes('chq') || c.includes('ref') || c.includes('cheque') || c.includes('utr'));

  // Default fallback if headers are not explicitly labeled
  if (dateIdx === -1) dateIdx = 0;
  if (descIdx === -1) descIdx = 1;

  const rows: ParsedTransactionRow[] = [];
  let totalAmount = 0;

  for (let i = headerIndex + 1; i < lines.length; i++) {
    const rawLine = lines[i];
    const cols = splitCsvLine(rawLine);

    if (cols.length < 2) continue;

    const rawDate = cols[dateIdx] || new Date().toISOString().split('T')[0];
    const rawDesc = cols[descIdx] || `Transaction #${i}`;

    // Skip summary / footer rows (e.g. "Total Debits", "Closing Balance", etc.)
    const lowerDesc = rawDesc.toLowerCase();
    if (
      lowerDesc.includes('closing balance') ||
      lowerDesc.includes('total amount') ||
      lowerDesc.includes('generated on') ||
      lowerDesc.includes('page ') ||
      lowerDesc.includes('*** end')
    ) {
      continue;
    }

    let amount = 0;
    let type: 'debit' | 'credit' = 'debit';

    // Check separate debit / credit columns first
    if (debitIdx >= 0 && cols[debitIdx] && cleanNumber(cols[debitIdx]) > 0) {
      amount = cleanNumber(cols[debitIdx]);
      type = 'debit';
    } else if (creditIdx >= 0 && cols[creditIdx] && cleanNumber(cols[creditIdx]) > 0) {
      amount = cleanNumber(cols[creditIdx]);
      type = 'credit';
    } else if (amountIdx >= 0 && cols[amountIdx]) {
      const rawAmt = cols[amountIdx];
      const parsedAmt = cleanNumber(rawAmt);
      amount = Math.abs(parsedAmt);
      if (typeIdx >= 0 && cols[typeIdx]) {
        type = cols[typeIdx].toLowerCase().includes('cr') || cols[typeIdx].toLowerCase().includes('in') ? 'credit' : 'debit';
      } else {
        type = rawAmt.includes('-') || rawAmt.toLowerCase().includes('dr') ? 'debit' : 'credit';
      }
    } else {
      // Try to find any numeric column
      for (const col of cols) {
        const n = cleanNumber(col);
        if (n > 0) {
          amount = n;
          break;
        }
      }
    }

    if (amount <= 0) {
      // skip or record as validation issue
      continue;
    }

    totalAmount += amount;

    // Classification
    const classification = classifyTransactionDescription(rawDesc, type);
    const assignedCategory = categoryIdx >= 0 && cols[categoryIdx] ? cols[categoryIdx].trim() : classification.category;

    rows.push({
      id: `parsed-${Date.now()}-${i}-${Math.random().toString(36).substring(2, 6)}`,
      date: formatDateString(rawDate),
      description: rawDesc,
      amount,
      type,
      vendor: classification.vendor,
      category: assignedCategory,
      confidence: classification.confidence,
      status: classification.confidence >= 0.85 ? 'approved' : 'pending_review',
      rawLine,
    });
  }

  return {
    success: rows.length > 0,
    rows,
    summary: {
      totalRows: lines.length - 1,
      validRows: rows.length,
      invalidRows: lines.length - 1 - rows.length,
      totalAmount,
    },
  };
}

function cleanNumber(str: string): number {
  if (!str) return 0;
  const cleaned = str.replace(/[₹$,\s]/g, '').trim();
  const val = parseFloat(cleaned);
  return isNaN(val) ? 0 : val;
}

function splitCsvLine(line: string): string[] {
  const result: string[] = [];
  let inQuotes = false;
  let cur = '';

  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      inQuotes = !inQuotes;
    } else if (ch === ',' && !inQuotes) {
      result.push(cur.trim());
      cur = '';
    } else {
      cur += ch;
    }
  }
  result.push(cur.trim());
  return result;
}

function formatDateString(str: string): string {
  if (!str) return new Date().toISOString().split('T')[0];
  const trimmed = str.trim();

  // Handle standard YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) return trimmed;

  const months: Record<string, string> = {
    jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06',
    jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12',
  };

  // Check for DD-Mon-YYYY e.g. 15-Aug-2026 or 15 Aug 2026
  const monMatch = trimmed.match(/^(\d{1,2})[-\s/]([a-zA-Z]{3})[-\s/](\d{2,4})$/);
  if (monMatch) {
    const day = monMatch[1].padStart(2, '0');
    const month = months[monMatch[2].toLowerCase()] || '01';
    let year = monMatch[3];
    if (year.length === 2) year = `20${year}`;
    return `${year}-${month}-${day}`;
  }

  // Handle DD/MM/YYYY or DD-MM-YYYY
  const parts = trimmed.split(/[/.-]/);
  if (parts.length === 3) {
    if (parts[0].length <= 2 && parts[2].length === 4) {
      // DD/MM/YYYY -> YYYY-MM-DD
      return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
    } else if (parts[0].length === 4 && parts[2].length <= 2) {
      // YYYY/MM/DD -> YYYY-MM-DD
      return `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
    }
  }
  return trimmed;
}
