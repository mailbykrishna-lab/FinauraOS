export type AnalyticsEventName =
  | 'pricing_page_view'
  | 'pricing_plan_view'
  | 'pricing_toggle_yearly'
  | 'pricing_cta_click'
  | 'signup_started'
  | 'subscription_started'
  | 'checkout_started'
  | 'payment_success'
  | 'payment_failed'
  | 'upgrade_started'
  | 'upgrade_completed'
  | 'downgrade_started'
  | 'downgrade_completed'
  | 'subscription_cancelled'
  | 'subscription_resumed'
  | 'feature_gate_viewed'
  | 'upgrade_prompt_clicked';

export interface AnalyticsPayload {
  planId?: string;
  billingCycle?: 'monthly' | 'yearly';
  featureKey?: string;
  source?: string;
  amount?: number;
  error?: string;
  [key: string]: any;
}

class AnalyticsManager {
  private listeners: ((event: AnalyticsEventName, payload?: AnalyticsPayload) => void)[] = [];

  public track(event: AnalyticsEventName, payload?: AnalyticsPayload) {
    if (typeof window !== 'undefined') {
      // In development or demo mode, log structured event to console
      console.log(`[Finaura Analytics] Tracked: ${event}`, payload || {});
    }

    this.listeners.forEach((listener) => {
      try {
        listener(event, payload);
      } catch (err) {
        console.warn('Analytics listener error', err);
      }
    });
  }

  public subscribe(listener: (event: AnalyticsEventName, payload?: AnalyticsPayload) => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }
}

export const analytics = new AnalyticsManager();
