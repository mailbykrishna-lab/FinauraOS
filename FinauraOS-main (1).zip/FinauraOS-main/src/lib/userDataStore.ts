import { Transaction, Invoice, UploadedDoc, BusinessProfile } from '../types';
import { supabase } from './supabase';

const PREFIX = 'finaura_userdata_';

export interface UserFinancialData {
  transactions: Transaction[];
  invoices: Invoice[];
  documents: UploadedDoc[];
  customers?: { id: string; name: string; email: string; gstin?: string; totalBilled: number }[];
  vendors?: { id: string; name: string; email?: string; gstin?: string; totalPaid: number; isMsme?: boolean }[];
  isDemoDataActive?: boolean;
}

/**
 * Returns empty baseline financial state for a newly authenticated user.
 * ZERO fake or invented numbers.
 */
export function getInitialEmptyUserData(): UserFinancialData {
  return {
    transactions: [],
    invoices: [],
    documents: [],
    customers: [],
    vendors: [],
    isDemoDataActive: false,
  };
}

/**
 * Load user's scoped financial data.
 * Checks localStorage first, and queries Supabase database tables if available.
 */
export async function loadUserFinancialData(userId: string): Promise<UserFinancialData> {
  if (!userId) {
    return getInitialEmptyUserData();
  }

  // 1. Check local storage cache for this user
  let localData: UserFinancialData | null = null;
  try {
    const raw = localStorage.getItem(`${PREFIX}${userId}`);
    if (raw) {
      localData = JSON.parse(raw);
    }
  } catch (err) {
    console.warn('Error reading user financial data from storage:', err);
  }

  // If local data exists, start with it
  const result: UserFinancialData = localData || getInitialEmptyUserData();

  // 2. Query Supabase tables asynchronously to merge fresh records
  try {
    const [txRes, invRes] = await Promise.all([
      supabase.from('transactions').select('*').limit(200),
      supabase.from('invoices').select('*').limit(100),
    ]);

    if (!txRes.error && Array.isArray(txRes.data) && txRes.data.length > 0) {
      // Map Supabase transactions
      const dbTransactions: Transaction[] = txRes.data.map((row: any) => ({
        id: String(row.id),
        amount: Number(row.amount || 0),
        type: (row.type === 'credit' ? 'credit' : 'debit') as 'credit' | 'debit',
        vendor: row.vendor || 'Unknown Party',
        description: row.description || '',
        date: row.date || new Date().toISOString().split('T')[0],
        suggestedCategory: row.category || 'General',
        userCategory: row.category || 'General',
        confidence: 0.95,
        status: (row.status === 'needs_review' || row.status === 'skipped' ? row.status : 'approved') as 'approved' | 'needs_review' | 'skipped',
        taxDeductible: true,
        gstEligible: row.gst_status === 'eligible',
      }));

      // Merge avoiding duplicates
      const txMap = new Map<string, Transaction>();
      dbTransactions.forEach((t) => txMap.set(t.id, t));
      result.transactions.forEach((t) => {
        if (!txMap.has(t.id)) txMap.set(t.id, t);
      });
      result.transactions = Array.from(txMap.values());
    }

    if (!invRes.error && Array.isArray(invRes.data) && invRes.data.length > 0) {
      const dbInvoices: Invoice[] = invRes.data.map((row: any) => ({
        id: String(row.id),
        invoiceNumber: row.invoice_number || `INV-${row.id}`,
        clientName: row.client_name || 'Customer',
        clientEmail: row.client_email || '',
        clientGstin: row.client_gstin || undefined,
        date: row.issue_date || new Date().toISOString().split('T')[0],
        dueDate: row.due_date || new Date().toISOString().split('T')[0],
        subtotal: Number(row.amount ? row.amount / 1.18 : 0),
        gstAmount: Number(row.amount ? (row.amount * 0.18) / 1.18 : 0),
        total: Number(row.amount || 0),
        status: (row.status === 'draft' || row.status === 'paid' || row.status === 'overdue' ? row.status : 'sent') as 'draft' | 'sent' | 'paid' | 'overdue',
        items: [],
      }));

      const invMap = new Map<string, Invoice>();
      dbInvoices.forEach((i) => invMap.set(i.id, i));
      result.invoices.forEach((i) => {
        if (!invMap.has(i.id)) invMap.set(i.id, i);
      });
      result.invoices = Array.from(invMap.values());
    }
  } catch (err) {
    console.warn('Could not query Supabase tables for user data:', err);
  }

  // Derive customers & vendors from real transactions & invoices if empty
  if ((!result.customers || result.customers.length === 0) && result.invoices.length > 0) {
    const custMap = new Map<string, { id: string; name: string; email: string; gstin?: string; totalBilled: number }>();
    result.invoices.forEach((inv) => {
      const key = inv.clientName.trim().toLowerCase();
      const existing = custMap.get(key);
      if (existing) {
        existing.totalBilled += inv.total;
      } else {
        custMap.set(key, {
          id: `cust-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          name: inv.clientName,
          email: inv.clientEmail || '',
          gstin: inv.clientGstin,
          totalBilled: inv.total,
        });
      }
    });
    result.customers = Array.from(custMap.values());
  }

  return result;
}

/**
 * Save user financial data to local storage and sync with backend.
 */
export function saveUserFinancialData(userId: string, data: Partial<UserFinancialData>): void {
  if (!userId) return;
  let updated: UserFinancialData;
  try {
    const raw = localStorage.getItem(`${PREFIX}${userId}`);
    const existing = raw ? JSON.parse(raw) : getInitialEmptyUserData();
    updated = { ...existing, ...data };
    localStorage.setItem(`${PREFIX}${userId}`, JSON.stringify(updated));
  } catch (err) {
    console.warn('Error saving user financial data:', err);
    return;
  }

  // Asynchronously sync with Supabase backend
  if (!updated.isDemoDataActive) {
    fetch('/api/supabase/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        transactions: updated.transactions,
        invoices: updated.invoices,
      }),
    }).catch(() => {});
  }
}

/**
 * Clear user data (resets to empty real-user state)
 */
export function clearUserFinancialData(userId: string): UserFinancialData {
  const empty = getInitialEmptyUserData();
  if (userId) {
    localStorage.removeItem(`${PREFIX}${userId}`);
  }
  return empty;
}
