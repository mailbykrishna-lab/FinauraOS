import { jsPDF } from 'jspdf';
import QRCode from 'qrcode';
import { Invoice, BankDetails } from '../types';

export interface SupplierDetails {
  businessName?: string;
  contactName?: string;
  email?: string;
  gstin?: string;
  state?: string;
  bankDetails?: BankDetails;
}

export async function generateInvoicePdf(
  invoice: Invoice,
  supplier?: SupplierDetails | string,
  supplierGstinParam?: string
): Promise<void> {
  const supplierInfo: SupplierDetails = typeof supplier === 'string' 
    ? { businessName: supplier, gstin: supplierGstinParam || '29AABCF1234F1Z9' }
    : supplier || {};

  const businessName = supplierInfo.businessName || 'Krishna Tech Enterprises';
  const supplierGstin = supplierInfo.gstin || '29AABCF1234F1Z9';
  const supplierEmail = supplierInfo.email || 'mailbykrishna@gmail.com';
  const supplierContact = supplierInfo.contactName || '';
  const supplierState = supplierInfo.state || 'Karnataka (Code: 29)';

  const bank: BankDetails = supplierInfo.bankDetails || {
    bankName: 'HDFC Bank Ltd',
    accountHolderName: businessName,
    accountNumber: '50200084920194',
    ifscCode: 'HDFC0000184',
    branchName: 'Indiranagar, Bengaluru',
    accountType: 'Current',
    upiId: 'mailbykrishna@okhdfcbank',
  };

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 16;

  // Primary Colors
  const darkSlate = [15, 23, 42]; // #0f172a
  const mutedGray = [100, 116, 139]; // #64748b
  const lightBg = [248, 250, 252]; // #f8fafc
  const borderColor = [226, 232, 240]; // #e2e8f0

  // 1. Header Bar
  doc.setFillColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.rect(14, y, pageWidth - 28, 22, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text('TAX INVOICE', 20, y + 10);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text('ORIGINAL FOR RECIPIENT | GST COMPLIANT', 20, y + 16);

  // Invoice Number & Date on right of header
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text(invoice.invoiceNumber || 'INV-2024-001', pageWidth - 20, y + 9, { align: 'right' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text(`Date: ${invoice.date || new Date().toISOString().split('T')[0]}`, pageWidth - 20, y + 16, { align: 'right' });

  y += 28;

  // 2. Supplier (From) & Buyer (To) Details
  const colWidth = (pageWidth - 32) / 2;

  // Box 1: Billed By (Supplier)
  doc.setFillColor(lightBg[0], lightBg[1], lightBg[2]);
  doc.setDrawColor(borderColor[0], borderColor[1], borderColor[2]);
  doc.roundedRect(14, y, colWidth, 40, 2, 2, 'FD');

  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('BILLED BY (SUPPLIER):', 18, y + 7);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text(businessName, 18, y + 14);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(mutedGray[0], mutedGray[1], mutedGray[2]);
  if (supplierContact) {
    doc.text(`Contact: ${supplierContact}`, 18, y + 20);
    doc.text(`GSTIN: ${supplierGstin}`, 18, y + 25);
    doc.text(`Email: ${supplierEmail}`, 18, y + 30);
    doc.text(`State: ${supplierState}`, 18, y + 35);
  } else {
    doc.text(`GSTIN: ${supplierGstin}`, 18, y + 20);
    doc.text(`Email: ${supplierEmail}`, 18, y + 26);
    doc.text(`State: ${supplierState}`, 18, y + 32);
  }

  // Box 2: Billed To (Buyer)
  doc.setFillColor(lightBg[0], lightBg[1], lightBg[2]);
  doc.setDrawColor(borderColor[0], borderColor[1], borderColor[2]);
  doc.roundedRect(14 + colWidth + 4, y, colWidth, 40, 2, 2, 'FD');

  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('BILLED TO (RECIPIENT):', 18 + colWidth + 4, y + 7);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text(invoice.clientName || 'Valued Client', 18 + colWidth + 4, y + 14);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(mutedGray[0], mutedGray[1], mutedGray[2]);
  doc.text(`GSTIN: ${invoice.clientGstin || 'Unregistered / Consumer'}`, 18 + colWidth + 4, y + 20);
  doc.text(`Email: ${invoice.clientEmail || 'N/A'}`, 18 + colWidth + 4, y + 26);
  doc.text(`Payment Due: ${invoice.dueDate || 'Upon Receipt'}`, 18 + colWidth + 4, y + 32);

  y += 46;

  // 3. Line Items Table Header
  const tableX = 14;
  const tableWidth = pageWidth - 28;

  doc.setFillColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.rect(tableX, y, tableWidth, 8, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);

  doc.text('#', tableX + 3, y + 5.5);
  doc.text('DESCRIPTION & SAC/HSN', tableX + 12, y + 5.5);
  doc.text('QTY', tableX + 96, y + 5.5, { align: 'right' });
  doc.text('RATE (INR)', tableX + 124, y + 5.5, { align: 'right' });
  doc.text('GST %', tableX + 146, y + 5.5, { align: 'right' });
  doc.text('AMOUNT (INR)', tableX + tableWidth - 4, y + 5.5, { align: 'right' });

  y += 8;

  // Line items
  const items = invoice.items && invoice.items.length > 0 ? invoice.items : [
    { description: 'Consulting & Engineering Support', quantity: 1, rate: invoice.subtotal || invoice.total, gstRate: 18, amount: invoice.subtotal || invoice.total },
  ];

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);

  items.forEach((item, index) => {
    const isEven = index % 2 === 0;
    const itemAmount = item.quantity * item.rate;

    if (isEven) {
      doc.setFillColor(252, 252, 253);
    } else {
      doc.setFillColor(245, 247, 250);
    }
    doc.rect(tableX, y, tableWidth, 9, 'F');

    // Row border
    doc.setDrawColor(borderColor[0], borderColor[1], borderColor[2]);
    doc.line(tableX, y + 9, tableX + tableWidth, y + 9);

    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    doc.text(`${index + 1}`, tableX + 3, y + 6);
    doc.text(item.description.length > 44 ? item.description.substring(0, 41) + '...' : item.description, tableX + 12, y + 6);
    doc.text(`${item.quantity}`, tableX + 96, y + 6, { align: 'right' });
    doc.text(`Rs. ${item.rate.toLocaleString('en-IN')}`, tableX + 124, y + 6, { align: 'right' });
    doc.text(`${item.gstRate}%`, tableX + 146, y + 6, { align: 'right' });
    doc.setFont('helvetica', 'bold');
    doc.text(`Rs. ${itemAmount.toLocaleString('en-IN')}`, tableX + tableWidth - 4, y + 6, { align: 'right' });
    doc.setFont('helvetica', 'normal');

    y += 9;
  });

  y += 6;

  // 4. Totals & Tax Breakdown Block
  const summaryWidth = 72;
  const summaryX = tableX + tableWidth - summaryWidth;

  const subtotal = invoice.subtotal || (items || []).reduce((acc, it) => acc + (it?.quantity || 0) * (it?.rate || 0), 0);
  const gstAmount = invoice.gstAmount || (invoice.total - subtotal);
  const total = invoice.total || (subtotal + gstAmount);
  const halfGst = gstAmount / 2;

  // Summary box
  doc.setDrawColor(borderColor[0], borderColor[1], borderColor[2]);
  doc.setFillColor(lightBg[0], lightBg[1], lightBg[2]);
  doc.roundedRect(summaryX, y, summaryWidth, 42, 2, 2, 'FD');

  doc.setFontSize(8.5);
  doc.setTextColor(mutedGray[0], mutedGray[1], mutedGray[2]);
  doc.text('Taxable Subtotal:', summaryX + 4, y + 7);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text(`Rs. ${subtotal.toLocaleString('en-IN')}`, summaryX + summaryWidth - 4, y + 7, { align: 'right' });

  doc.setTextColor(mutedGray[0], mutedGray[1], mutedGray[2]);
  doc.text('CGST (9%):', summaryX + 4, y + 14);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text(`Rs. ${Math.round(halfGst).toLocaleString('en-IN')}`, summaryX + summaryWidth - 4, y + 14, { align: 'right' });

  doc.setTextColor(mutedGray[0], mutedGray[1], mutedGray[2]);
  doc.text('SGST (9%):', summaryX + 4, y + 21);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text(`Rs. ${Math.round(halfGst).toLocaleString('en-IN')}`, summaryX + summaryWidth - 4, y + 21, { align: 'right' });

  // Total divider
  doc.setDrawColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.line(summaryX + 2, y + 27, summaryX + summaryWidth - 2, y + 27);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text('Total (INR):', summaryX + 4, y + 35);
  doc.text(`Rs. ${total.toLocaleString('en-IN')}`, summaryX + summaryWidth - 4, y + 35, { align: 'right' });

  // Left: Bank & Payment info box + UPI QR Code beside it
  const bankBoxWidth = summaryX - tableX - 4;
  doc.setFillColor(lightBg[0], lightBg[1], lightBg[2]);
  doc.setDrawColor(borderColor[0], borderColor[1], borderColor[2]);
  doc.roundedRect(tableX, y, bankBoxWidth, 42, 2, 2, 'FD');

  const upiIdClean = (bank.upiId || 'mailbykrishna@okhdfcbank').trim();
  const holderName = bank.accountHolderName || businessName;
  const hasBankAccount = Boolean(bank.accountNumber && bank.accountNumber.trim());

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);

  if (hasBankAccount) {
    doc.text('BANK & PAYMENT DETAILS', tableX + 4, y + 7);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(mutedGray[0], mutedGray[1], mutedGray[2]);

    const branchText = bank.branchName ? ` (${bank.branchName})` : '';
    const acctType = bank.accountType ? ` [${bank.accountType}]` : '';

    doc.text(`A/C Name: ${holderName}`, tableX + 4, y + 13);
    doc.text(`Bank: ${bank.bankName || 'Direct Transfer'}${branchText}`, tableX + 4, y + 18.5);
    doc.text(`Account No: ${bank.accountNumber}${acctType}`, tableX + 4, y + 24);
    doc.text(`IFSC Code: ${bank.ifscCode || 'N/A'}`, tableX + 4, y + 29.5);
    doc.text(`UPI ID / VPA: ${upiIdClean}`, tableX + 4, y + 35);
  } else {
    doc.text('DYNAMIC UPI QR PAYMENT', tableX + 4, y + 7);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(mutedGray[0], mutedGray[1], mutedGray[2]);

    doc.text(`UPI ID / VPA: ${upiIdClean}`, tableX + 4, y + 13);
    doc.text(`Payee Name: ${holderName}`, tableX + 4, y + 18.5);
    doc.text(`Amount: Rs. ${total.toLocaleString('en-IN')}`, tableX + 4, y + 24);
    doc.text(`Invoice Ref: ${invoice.invoiceNumber || 'Payment'}`, tableX + 4, y + 29.5);
    doc.text(`Accepted Apps: GPay • PhonePe • Paytm • BHIM`, tableX + 4, y + 35);
  }

  // Generate UPI QR Code image to place beside payment text
  const upiUrl = `upi://pay?pa=${encodeURIComponent(upiIdClean)}&pn=${encodeURIComponent(businessName)}&am=${total}&cu=INR&tn=${encodeURIComponent('Invoice ' + (invoice.invoiceNumber || 'Payment'))}`;

  try {
    const qrDataUrl = await QRCode.toDataURL(upiUrl, {
      margin: 1,
      width: 256,
      errorCorrectionLevel: 'M',
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
    });

    const qrSize = 25;
    const qrX = tableX + bankBoxWidth - qrSize - 4;
    const qrY = y + 5;

    // Draw white backdrop for QR code
    doc.setFillColor(255, 255, 255);
    doc.setDrawColor(borderColor[0], borderColor[1], borderColor[2]);
    doc.roundedRect(qrX - 1, qrY - 1, qrSize + 2, qrSize + 2, 1, 1, 'FD');
    
    // Embed QR code image
    doc.addImage(qrDataUrl, 'PNG', qrX, qrY, qrSize, qrSize);

    // Label below QR code
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.5);
    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    doc.text('Scan & Pay via UPI', qrX + qrSize / 2, qrY + qrSize + 4.5, { align: 'center' });

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(5.5);
    doc.setTextColor(mutedGray[0], mutedGray[1], mutedGray[2]);
    doc.text('GPay • PhonePe • Paytm', qrX + qrSize / 2, qrY + qrSize + 7.5, { align: 'center' });
  } catch (err) {
    console.error('Failed to render QR Code into PDF:', err);
  }

  y += 50;

  // 5. Terms and Signatory
  doc.setFontSize(7.5);
  doc.setTextColor(mutedGray[0], mutedGray[1], mutedGray[2]);
  doc.text('Terms & Conditions:', tableX, y);
  doc.text('1. Payment is due within the stipulated due date via NEFT/RTGS or UPI QR code scan.', tableX, y + 4.5);
  doc.text('2. This is a computer-generated tax invoice verified under Section 31 of CGST Act 2017.', tableX, y + 9);
  doc.text('3. Section 43B(h) compliance: MSME vendor payment cycle enforced within 45 days.', tableX, y + 13.5);

  // Authorised Signatory box on bottom right
  doc.setDrawColor(borderColor[0], borderColor[1], borderColor[2]);
  doc.line(pageWidth - 65, y + 10, pageWidth - 14, y + 10);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text('For ' + businessName, pageWidth - 14, y + 14, { align: 'right' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(mutedGray[0], mutedGray[1], mutedGray[2]);
  doc.text('Authorized Signatory', pageWidth - 14, y + 18, { align: 'right' });

  // Save the PDF
  const filename = `${invoice.invoiceNumber || 'INVOICE'}_${invoice.clientName ? invoice.clientName.replace(/\s+/g, '_') : 'client'}.pdf`;
  doc.save(filename);
}

export async function getInvoicePdfBase64(
  invoice: Invoice,
  supplier?: SupplierDetails | string,
  supplierGstinParam?: string
): Promise<{ base64: string; filename: string }> {
  const supplierInfo: SupplierDetails = typeof supplier === 'string' 
    ? { businessName: supplier, gstin: supplierGstinParam || '29AABCF1234F1Z9' }
    : supplier || {};

  const businessName = supplierInfo.businessName || 'Krishna Tech Enterprises';
  const supplierGstin = supplierInfo.gstin || '29AABCF1234F1Z9';
  const supplierEmail = supplierInfo.email || 'mailbykrishna@gmail.com';
  const supplierContact = supplierInfo.contactName || '';
  const supplierState = supplierInfo.state || 'Karnataka (Code: 29)';

  const bank: BankDetails = supplierInfo.bankDetails || {
    bankName: 'HDFC Bank Ltd',
    accountHolderName: businessName,
    accountNumber: '50200084920194',
    ifscCode: 'HDFC0000184',
    branchName: 'Indiranagar, Bengaluru',
    accountType: 'Current',
    upiId: 'mailbykrishna@okhdfcbank',
  };

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 16;

  const darkSlate = [15, 23, 42];
  const mutedGray = [100, 116, 139];
  const lightBg = [248, 250, 252];
  const borderColor = [226, 232, 240];

  doc.setFillColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.rect(14, y, pageWidth - 28, 22, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text('TAX INVOICE', 20, y + 14);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('ORIGINAL FOR RECIPIENT', pageWidth - 20, y + 14, { align: 'right' });
  y += 26;

  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text(businessName, 14, y);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(mutedGray[0], mutedGray[1], mutedGray[2]);
  doc.text(`GSTIN: ${supplierGstin}`, 14, y + 4.5);
  doc.text(`State: ${supplierState}`, 14, y + 9);
  doc.text(`Email: ${supplierEmail}`, 14, y + 13.5);

  const metaBoxX = pageWidth - 75;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text(`Invoice No: ${invoice.invoiceNumber || 'INV-001'}`, metaBoxX, y);
  doc.setFont('helvetica', 'normal');
  doc.text(`Invoice Date: ${invoice.date || new Date().toISOString().slice(0, 10)}`, metaBoxX, y + 4.5);
  doc.text(`Due Date: ${invoice.dueDate || 'Immediate'}`, metaBoxX, y + 9);
  y += 20;

  doc.setDrawColor(borderColor[0], borderColor[1], borderColor[2]);
  doc.line(14, y, pageWidth - 14, y);
  y += 6;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text('Billed To (Client):', 14, y);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text(invoice.clientName || 'Client Name', 14, y + 4.5);
  if (invoice.clientGstin) doc.text(`GSTIN: ${invoice.clientGstin}`, 14, y + 9);
  if (invoice.clientEmail) doc.text(`Email: ${invoice.clientEmail}`, 14, y + 13.5);
  y += 18;

  // Items table
  const tableX = 14;
  const tableW = pageWidth - 28;
  doc.setFillColor(lightBg[0], lightBg[1], lightBg[2]);
  doc.rect(tableX, y, tableW, 7, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text('#', tableX + 3, y + 5);
  doc.text('Description / Service Item', tableX + 12, y + 5);
  doc.text('Qty', tableX + 90, y + 5);
  doc.text('Rate (INR)', tableX + 105, y + 5);
  doc.text('GST %', tableX + 130, y + 5);
  doc.text('Amount (INR)', tableX + tableW - 3, y + 5, { align: 'right' });
  y += 9;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);

  const items = invoice.items && invoice.items.length > 0
    ? invoice.items
    : [{ description: 'Professional Financial Consulting & Engineering Services', quantity: 1, rate: invoice.subtotal || invoice.total, gstRate: 18 }];

  items.forEach((it, idx) => {
    const itAmt = (it.quantity || 1) * (it.rate || 0);
    doc.text(String(idx + 1), tableX + 3, y);
    doc.text(it.description || 'Deliverable', tableX + 12, y);
    doc.text(String(it.quantity || 1), tableX + 90, y);
    doc.text(Number(it.rate || 0).toLocaleString('en-IN'), tableX + 105, y);
    doc.text(`${it.gstRate || 18}%`, tableX + 130, y);
    doc.text(itAmt.toLocaleString('en-IN'), tableX + tableW - 3, y, { align: 'right' });
    y += 6;
  });

  y += 4;
  doc.setDrawColor(borderColor[0], borderColor[1], borderColor[2]);
  doc.line(tableX, y, tableX + tableW, y);
  y += 6;

  const totalX = tableX + tableW - 3;
  const labelX = totalX - 45;
  const subtotal = invoice.subtotal || invoice.total;
  const gstAmount = invoice.gstAmount || (invoice.total - subtotal);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(mutedGray[0], mutedGray[1], mutedGray[2]);
  doc.text('Subtotal:', labelX, y);
  doc.text(`Rs. ${Number(subtotal).toLocaleString('en-IN')}`, totalX, y, { align: 'right' });
  y += 5;
  doc.text('Total GST (18%):', labelX, y);
  doc.text(`Rs. ${Number(gstAmount).toLocaleString('en-IN')}`, totalX, y, { align: 'right' });
  y += 6;

  doc.setFillColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.rect(labelX - 4, y - 4, 52, 9, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('Total Due:', labelX, y + 2);
  doc.text(`Rs. ${Number(invoice.total).toLocaleString('en-IN')}`, totalX, y + 2, { align: 'right' });
  y += 12;

  // QR Code
  try {
    const upiId = bank.upiId || 'mailbykrishna@okhdfcbank';
    const upiUri = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(businessName)}&am=${invoice.total}&cu=INR&tn=${encodeURIComponent('Invoice ' + (invoice.invoiceNumber || 'INV'))}`;
    const qrDataUrl = await QRCode.toDataURL(upiUri, { width: 140, margin: 1 });
    doc.addImage(qrDataUrl, 'PNG', 14, y, 22, 22);
  } catch (e) {
    // Ignore QR errors
  }

  const filename = `${invoice.invoiceNumber || 'INVOICE'}_${invoice.clientName ? invoice.clientName.replace(/\s+/g, '_') : 'client'}.pdf`;
  const dataUri = doc.output('datauristring');
  const base64 = dataUri.split(',')[1] || '';

  return { base64, filename };
}

