// Statutory & Financial Reasoning Solver Engine
// Built for the Income Tax Act 2025, CGST/IGST Act 2017, and MSMED Act 2006

export interface SolvedProblem {
  title: string;
  category: string;
  markdown: string;
  source: string;
  actionTabs?: Array<'accounting' | 'tax' | 'compliance' | 'invoices' | 'ca_services'>;
}

// Helper to extract numbers from user prompt (e.g. ₹50L, 18 lakh, 45000, 35%)
function extractNumbers(text: string): number[] {
  const matches = text.match(/₹?\s*(\d+(?:\.\d+)?)\s*(?:lakhs?|lacs?|lac|l|cr|crores?|k)?/gi) || [];
  const numbers: number[] = [];
  
  for (const m of matches) {
    const clean = m.replace(/[₹,\s]/g, '').toLowerCase();
    if (clean.endsWith('cr') || clean.endsWith('crore') || clean.endsWith('crores')) {
      const val = parseFloat(clean.replace(/(?:cr|crores?)/, ''));
      if (!isNaN(val)) numbers.push(val * 10000000);
    } else if (clean.endsWith('l') || clean.endsWith('lakh') || clean.endsWith('lakhs') || clean.endsWith('lac') || clean.endsWith('lacs')) {
      const val = parseFloat(clean.replace(/(?:lakhs?|lacs?|lac|l)/, ''));
      if (!isNaN(val)) numbers.push(val * 100000);
    } else if (clean.endsWith('k')) {
      const val = parseFloat(clean.replace('k', ''));
      if (!isNaN(val)) numbers.push(val * 1000);
    } else {
      const val = parseFloat(clean);
      if (!isNaN(val) && val > 0) numbers.push(val);
    }
  }
  return numbers;
}

// Compute Income Tax 2025 New Tax Regime for any income
export function computeTax2025(grossIncome: number, isSalaried: boolean = false): {
  grossIncome: number;
  standardDeduction: number;
  netTaxableIncome: number;
  slabTax: number;
  rebate87A: number;
  taxAfterRebate: number;
  cess: number;
  totalTax: number;
  effectiveRate: number;
  slabsBreakdown: Array<{ slab: string; rate: string; taxableAmount: number; tax: number }>;
} {
  const standardDeduction = isSalaried ? 75000 : 0;
  const netTaxableIncome = Math.max(0, grossIncome - standardDeduction);

  const slabs = [
    { max: 400000, rate: 0, label: '₹0 - ₹4,00,000' },
    { max: 800000, rate: 0.05, label: '₹4,00,001 - ₹8,00,000' },
    { max: 1200000, rate: 0.10, label: '₹8,00,001 - ₹12,00,000' },
    { max: 1600000, rate: 0.15, label: '₹12,00,001 - ₹16,00,000' },
    { max: 2000000, rate: 0.20, label: '₹16,00,001 - ₹20,00,000' },
    { max: 2400000, rate: 0.25, label: '₹20,00,001 - ₹24,00,000' },
    { max: Infinity, rate: 0.30, label: 'Above ₹24,00,000' },
  ];

  let remaining = netTaxableIncome;
  let prevLimit = 0;
  let slabTax = 0;
  const slabsBreakdown: Array<{ slab: string; rate: string; taxableAmount: number; tax: number }> = [];

  for (const s of slabs) {
    if (remaining <= 0) break;
    const slabSpan = s.max === Infinity ? remaining : s.max - prevLimit;
    const taxableInThisSlab = Math.min(remaining, slabSpan);
    const taxInThisSlab = Math.round(taxableInThisSlab * s.rate);
    
    slabsBreakdown.push({
      slab: s.label,
      rate: `${(s.rate * 100).toFixed(0)}%`,
      taxableAmount: taxableInThisSlab,
      tax: taxInThisSlab,
    });

    slabTax += taxInThisSlab;
    remaining -= taxableInThisSlab;
    prevLimit = s.max;
  }

  // Section 87A rebate in Income Tax Act 2025 applies if taxable income <= ₹12,00,000
  let rebate87A = 0;
  if (netTaxableIncome <= 1200000) {
    rebate87A = slabTax;
  }

  const taxAfterRebate = Math.max(0, slabTax - rebate87A);
  const cess = Math.round(taxAfterRebate * 0.04);
  const totalTax = taxAfterRebate + cess;
  const effectiveRate = grossIncome > 0 ? (totalTax / grossIncome) * 100 : 0;

  return {
    grossIncome,
    standardDeduction,
    netTaxableIncome,
    slabTax,
    rebate87A,
    taxAfterRebate,
    cess,
    totalTax,
    effectiveRate,
    slabsBreakdown,
  };
}

export function formatINR(val: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(val);
}

// Master Statutory Problem Solver for any prompt under Income Tax Act 2025
export function solveQueryLocally(userQuery: string, businessContext?: any): SolvedProblem {
  const q = userQuery.toLowerCase().trim();
  const nums = extractNumbers(userQuery);
  
  // 1. Income Tax Calculation / Slabs / Salary / 2025 Tax Computation
  if (
    q.includes('tax on') ||
    q.includes('calculate tax') ||
    q.includes('salary') ||
    q.includes('tax slab') ||
    q.includes('income tax 2025') ||
    q.includes('tax liability') ||
    q.includes('new tax regime') ||
    q.includes('87a') ||
    (nums.length > 0 && (q.includes('tax') || q.includes('incom')))
  ) {
    const principalAmount = nums[0] || 1500000;
    const isSalaried = q.includes('salary') || q.includes('salaried') || q.includes('ctc') || q.includes('employee');
    const comp = computeTax2025(principalAmount, isSalaried);

    return {
      title: `Tax Computation for ${formatINR(principalAmount)}`,
      category: 'Income Tax Act 2025',
      source: 'Income Tax Act 2025 - Direct Tax Code Slabs',
      actionTabs: ['tax', 'accounting', 'ca_services'],
      markdown: `### 1. Statutory Framework: Income Tax Act 2025 (New Regime)
- **Applicable Statute**: The modernized **Income Tax Act 2025** (revised Direct Tax Code).
- **Assessed Gross Value**: **${formatINR(comp.grossIncome)}**
- **Standard Deduction**: **${formatINR(comp.standardDeduction)}** ${isSalaried ? '(Applicable for salaried assessee)' : '(For business/professional income, actual expenses apply)'}
- **Net Taxable Income**: **${formatINR(comp.netTaxableIncome)}**

---

### 2. Step-by-Step Slab Computation

| Income Slab | Tax Rate | Taxable Amount | Computed Tax |
| :--- | :--- | :--- | :--- |
${comp.slabsBreakdown.map(s => `| **${s.slab}** | ${s.rate} | ${formatINR(s.taxableAmount)} | ${formatINR(s.tax)} |`).join('\n')}
| **Aggregate Slab Tax** | - | - | **${formatINR(comp.slabTax)}** |
| **Section 87A Rebate** | (Threshold: ₹12L) | - | **- ${formatINR(comp.rebate87A)}** |
| **Health & Education Cess (4%)** | 4% on Net Tax | - | **${formatINR(comp.cess)}** |
| **FINAL TOTAL TAX PAYABLE** | - | - | **${formatINR(comp.totalTax)}** |

#### Effective Tax Rate: **${comp.effectiveRate.toFixed(2)}%**

---

### 3. Key Observations under Income Tax Act 2025
- **Zero Tax Threshold**: With the standard deduction of ₹75,000 and Section 87A full rebate for income up to ₹12,00,000, individuals earning up to **₹12,75,000 pay ₹0 tax**.
- **Advance Tax Schedule**: If total tax exceeds ₹10,000, pay quarterly installments: 15% (June 15), 45% (Sept 15), 75% (Dec 15), and 100% (March 15) to prevent Section 234C interest.

---

### 4. Immediate Executable Steps
1. Compute your business expense deductions in Smart Accounting: [ACTION:accounting]
2. Verify advance tax schedule and challan generation: [ACTION:tax]
3. Connect with a CA for annual tax planning: [ACTION:ca_services]`,
    };
  }

  // 2. Section 44ADA Presumptive Taxation vs Audit
  if (q.includes('44ada') || q.includes('presumptive') || q.includes('44ab') || q.includes('tax audit') || q.includes('44ad')) {
    const turnover = nums[0] || 6800000;
    const deemedProfit = turnover * 0.5;
    const taxUnder44ada = computeTax2025(deemedProfit, false);

    return {
      title: 'Section 44ADA Presumptive vs Regular Books Assessment',
      category: 'Income Tax Act 2025',
      source: 'Income Tax Act 2025 - Section 44ADA & Section 44AB',
      actionTabs: ['tax', 'accounting', 'ca_services'],
      markdown: `### 1. Statutory Limits under Income Tax Act 2025
- **Gross Professional Receipts**: **${formatINR(turnover)}**
- **Section 44ADA Limit**: **₹75,00,000** (provided digital collections >= 95%; otherwise ₹50 Lakhs).
- **Deemed Profit Mandate**: Minimum **50% of gross receipts** (i.e. **${formatINR(deemedProfit)}**).

---

### 2. Comparative Tax Matrix

| Feature | Section 44ADA (Presumptive) | Regular Books & Tax Audit |
| :--- | :--- | :--- |
| **Gross Receipts** | ${formatINR(turnover)} | ${formatINR(turnover)} |
| **Recognized Net Profit** | **50% (${formatINR(deemedProfit)})** | Actual Net Profit after legitimate expenses |
| **Tax under 2025 Act** | **${formatINR(taxUnder44ada.totalTax)}** | Calculated on actual net profit |
| **Compliance Overhead** | **Zero Books & No Audit** | Mandatory Form 3CB/3CD CA Audit |
| **Advance Tax Due** | 100% on **March 15** in 1 single payment | 4 Quarterly Installments (June/Sept/Dec/Mar) |

#### Decision Formula:
- If your verifiable actual expenses are **less than 50%**, Section 44ADA is strictly superior.
- If your verifiable business expenses **exceed 55%** (e.g. heavy subcontractor, server costs), maintaining formal books and getting an audit under Section 44AB will save substantial direct tax.

---

### 3. Immediate Action Plan
1. Reconcile operating expenses in the ledger: [ACTION:accounting]
2. Verify single advance tax installment on Tax Workflow: [ACTION:tax]
3. Consult certified CA for Form 3CB-3CD assessment: [ACTION:ca_services]`,
    };
  }

  // 3. Section 43B(h) MSME 45-Day Payment Rule
  if (q.includes('43b') || q.includes('msme') || q.includes('45 day') || q.includes('15 day') || q.includes('udyam') || q.includes('supplier')) {
    const overdueAmt = nums[0] || 480000;
    const taxDisallowance = Math.round(overdueAmt * 0.30);
    const msmeInterest = Math.round(overdueAmt * 0.195 * (45 / 365));

    return {
      title: 'Section 43B(h) MSME Disallowance & Penalties',
      category: 'MSME & Income Tax Act 2025',
      source: 'Income Tax Act 2025 - Section 43B(h) & MSMED Act 2006',
      actionTabs: ['invoices', 'accounting', 'compliance'],
      markdown: `### 1. Statutory Mandate: Section 43B(h) of Income Tax Act 2025
- **Statutory Rule**: Any expenditure incurred on purchases from **Micro and Small Enterprises** must be paid within:
  - **45 Days** (if there is a written agreement).
  - **15 Days** (if there is no written contract).
- **Target Overdue Invoices**: **${formatINR(overdueAmt)}**

---

### 2. Mathematical Impact of Default

| Financial Parameter | Amount | Statutory Consequence |
| :--- | :--- | :--- |
| **Overdue MSME Payables** | **${formatINR(overdueAmt)}** | Disallowed from current year P&L deductions |
| **Immediate Tax Cash Outflow** | **${formatINR(taxDisallowance)}** | Added back to taxable profit @ 30% tax rate |
| **Penal Interest (Sec 16 MSMED Act)** | **~${formatINR(msmeInterest)}** | Compound interest @ **3x RBI Bank Rate (~19.5% p.a.)** |
| **Deductibility of Interest** | **₹0 (Strictly Barred)** | Interest is **non-deductible** under Sec 23 MSMED Act |

---

### 3. Immediate Action Protocol
1. Filter vendor invoices by due date in Invoicing: [ACTION:invoices]
2. Request Udyam registration certificates for all active vendors: [ACTION:compliance]
3. Clear overdue payables before the financial year closing: [ACTION:accounting]`,
    };
  }

  // 4. GST ITC Mismatch / GSTR-2B / Section 16(2)(aa) / Section 50(1)
  if (q.includes('gst') || q.includes('gstr') || q.includes('itc') || q.includes('2b') || q.includes('input tax') || q.includes('reverse charge') || q.includes('lut')) {
    const invoiceVal = nums[0] || 124000;
    const gstVal = nums[1] || Math.round(invoiceVal * 0.18);
    const sec50Interest = Math.round(gstVal * 0.18 * (60 / 365));

    return {
      title: 'GST Input Tax Credit & GSTR-2B Compliance Analysis',
      category: 'GST Statutory Law',
      source: 'CGST Act 2017 - Section 16(2)(aa), Rule 36(4) & Section 50',
      actionTabs: ['tax', 'compliance', 'invoices'],
      markdown: `### 1. Statutory Eligibility under CGST Act Section 16(2)(aa)
- **Invoice Value**: **${formatINR(invoiceVal)}** | **GST Component (18%)**: **${formatINR(gstVal)}**
- **Strict Rule**: Under **Section 16(2)(aa) & Rule 36(4)**, no Input Tax Credit (ITC) can be claimed in GSTR-3B unless the invoice details are uploaded by the vendor in their **GSTR-1** and reflected in your auto-populated **GSTR-2B**.

---

### 2. Risk & Interest Matrix if Wrongly Claimed

| Scenario | Legal Position | Financial Liability |
| :--- | :--- | :--- |
| **Invoice in GSTR-2B** | 100% Eligible for ITC | **₹0 Interest** |
| **Invoice Missing from 2B** | Ineligible - Must be withheld | Must reverse in Table 4(B) |
| **Claimed & Utilized without 2B** | Penalty & Statutory Reversal | **${formatINR(gstVal)} + 18% p.a. interest** under Sec 50(1) |
| **Delay in GST Tax Deposit** | Late Fee + Section 50(1) | ₹50/day late fee + **18% p.a. interest** |

---

### 3. Immediate Action Protocol
1. Check GSTR-2B vs Purchase Register mismatch in Tax Workflow: [ACTION:tax]
2. Issue automated payment hold to vendors whose GST returns are pending: [ACTION:invoices]
3. Reconcile monthly GSTR-3B offsets in Compliance HQ: [ACTION:compliance]`,
    };
  }

  // 5. TDS (Withholding Tax: 194C, 194J, 194Q, 194R, 194M)
  if (q.includes('tds') || q.includes('194') || q.includes('withholding') || q.includes('contractor') || q.includes('freelance') || q.includes('26as') || q.includes('ais')) {
    const payment = nums[0] || 250000;
    const tds194c = Math.round(payment * 0.02);
    const tds194j_tech = Math.round(payment * 0.02);
    const tds194j_prof = Math.round(payment * 0.10);

    return {
      title: 'TDS Deduction & Classification Framework (Income Tax Act 2025)',
      category: 'TDS & Withholding',
      source: 'Income Tax Act 2025 - Chapter XVII-B',
      actionTabs: ['accounting', 'tax', 'compliance'],
      markdown: `### 1. Statutory TDS Classification on ${formatINR(payment)}
Under the **Income Tax Act 2025**, the rate of Tax Deducted at Source (TDS) depends on the nature of contractual engagement:

---

### 2. TDS Rate Comparison Matrix

| Section | Nature of Service | Rate | TDS Deductible | Threshold Limit |
| :--- | :--- | :--- | :--- | :--- |
| **Sec 194C** | Works Contract / Vendor Routine Work | **2% (Co/LLP) / 1% (Ind)** | **${formatINR(tds194c)}** | Single > ₹30k / Annual > ₹1 Lakh |
| **Sec 194J(1)(ba)** | Technical / IT / Software Development Services | **2%** | **${formatINR(tds194j_tech)}** | Annual > ₹30,000 |
| **Sec 194J(1)** | Professional Advisory (CA, Legal, Medical) | **10%** | **${formatINR(tds194j_prof)}** | Annual > ₹30,000 |
| **Sec 194R** | Business Perks, Dealer Incentives, Gifts | **10%** | **${formatINR(Math.round(payment * 0.10))}** | Annual > ₹20,000 |

---

### 3. Compliance Calendar & Deposit Deadlines
- **Monthly Deposit**: TDS deducted in any calendar month must be paid via Challan ITNS 281 by the **7th of the subsequent month** (30th April for March deductions).
- **Default Interest**: Delay in deduction attracts **1% per month**; delay in deposit attracts **1.5% per month** under Section 201(1A).

---

### 4. Executable Action Items
1. Apply correct TDS deduction in Smart Accounting ledger: [ACTION:accounting]
2. Verify quarterly Form 26Q TDS return filing status: [ACTION:compliance]
3. Consult CA for complex multi-vendor contract structuring: [ACTION:ca_services]`,
    };
  }

  // 6. Cash Flow Stress Testing / Runway / Burn Rate / Expense Cuts
  if (q.includes('cash') || q.includes('runway') || q.includes('stress') || q.includes('crunch') || q.includes('burn') || q.includes('revenue drop') || q.includes('drop')) {
    const revDropPct = nums.find(n => n <= 100) || 35;
    const currentRev = 864000;
    const fixedCosts = 385000;
    const stressedRev = Math.round(currentRev * (1 - revDropPct / 100));
    const stressedMargin = stressedRev - fixedCosts;
    const bankBalance = 1840000;
    const runwayMonths = (bankBalance / Math.max(1, fixedCosts - stressedRev)).toFixed(1);

    return {
      title: `${revDropPct}% Revenue Crunch Stress-Test & Runway Model`,
      category: 'Strategic Cash Flow',
      source: 'Working Capital & Treasury Simulation Engine',
      actionTabs: ['accounting', 'invoices', 'ca_services'],
      markdown: `### 1. Quantitative Stress-Test Baseline
- **Current Monthly Revenue**: **${formatINR(currentRev)}**
- **Simulated Revenue Drop**: **-${revDropPct}%** ➔ **${formatINR(stressedRev)} / month**
- **Non-Negotiable Fixed Costs** (Salaries, Cloud Servers, Rent): **${formatINR(fixedCosts)} / month**
- **Available Liquid Reserves**: **${formatINR(bankBalance)}**

---

### 2. Financial Sensitivity Matrix

| Metric | Normal Operations | Stressed Scenario (-${revDropPct}%) | Variance |
| :--- | :--- | :--- | :--- |
| **Monthly Inflows** | ${formatINR(currentRev)} | ${formatINR(stressedRev)} | -${formatINR(currentRev - stressedRev)} |
| **Monthly Fixed Overhead** | ${formatINR(fixedCosts)} | ${formatINR(fixedCosts)} | ₹0 |
| **Net Operating Cashflow** | **+${formatINR(currentRev - fixedCosts)}** | **${stressedMargin >= 0 ? '+' : ''}${formatINR(stressedMargin)}** | ${stressedMargin < 0 ? 'Deficit' : 'Surplus'} |
| **Runway Duration** | Infinite (Profitable) | **${stressedMargin < 0 ? `${runwayMonths} Months` : 'Self-Sustaining'}** | Critical buffer |

---

### 3. 3-Point Capital Preservation Strategy
1. **Accelerate Receivables Collection**: Send immediate 1-click reminders on overdue invoices to unlock tied-up working capital: [ACTION:invoices]
2. **Convert Fixed to Variable Overheads**: Renegotiate cloud infrastructure and annual SaaS contracts down by 15-20%.
3. **Set Up Automated Sweep-In Bank Buffers**: Maintain a dedicated 3-month operating buffer in a high-liquidity sweep account.

---

### 4. Immediate Steps
1. Audit ledger vendor subscriptions: [ACTION:accounting]
2. Trigger overdue client reminders: [ACTION:invoices]`,
    };
  }

  // 7. Company Structure: LLP vs Private Limited vs Sole Proprietorship
  if (q.includes('llp') || q.includes('pvt ltd') || q.includes('private limited') || q.includes('sole prop') || q.includes('partnership') || q.includes('entity')) {
    return {
      title: 'Entity Tax Structuring: LLP vs Private Limited (Income Tax Act 2025)',
      category: 'Corporate Tax Structuring',
      source: 'Income Tax Act 2025 - Section 115BAA & Companies Act 2013',
      actionTabs: ['tax', 'compliance', 'ca_services'],
      markdown: `### 1. Comparative Analysis: Private Limited vs. LLP (Tax Act 2025)

| Structural Parameter | Private Limited Company | Limited Liability Partnership (LLP) |
| :--- | :--- | :--- |
| **Base Corporate Tax Rate** | **22%** (Sec 115BAA) + 10% Surcharge + 4% Cess = **25.17%** | **30%** Flat + 12% Surcharge (if >₹1Cr) + 4% Cess = **34.94%** |
| **Profit Distribution Tax** | Dividend is taxed in shareholder hands at slab rates (up to 35.88%) | **100% Tax-Exempt** in partners' hands under **Section 10(2A)** |
| **Partner / Director Salary** | Deductible if reasonable (subject to Sec 40A(2)(b)) | Deductible up to **Section 40(b) statutory limits** |
| **MCA Compliance Overhead** | High: Mandatory Statutory Audit, AOC-4, MGT-7, CARO | Moderate: Audit only if turnover > ₹40L or capital > ₹25L |
| **Fundraising Suitability** | High: Venture Capital & ESOP friendly | Low: VCs rarely invest in LLPs |

---

### 2. Strategic Recommendation under Income Tax Act 2025
- **Choose Private Limited**: If you plan to raise institutional equity capital, hire employees with ESOPs, or retain substantial profits inside the company for reinvestment at 25.17% tax.
- **Choose LLP**: If you are a high-margin professional or service agency looking to withdraw profits every year without double dividend taxation.

---

### 3. Immediate Action Steps
1. Review active MCA compliance requirements: [ACTION:compliance]
2. Book an entity restructuring consultation with CA: [ACTION:ca_services]`,
    };
  }

  // 8. General Financial, Statutory, or Custom Calculation Query
  const estimatedTax = nums[0] ? computeTax2025(nums[0]) : null;

  return {
    title: `Statutory Analysis & Strategic Solution`,
    category: 'Income Tax Act 2025 & Commercial Law',
    source: 'Income Tax Act 2025 & Indian Regulatory Framework',
    actionTabs: ['accounting', 'tax', 'compliance', 'invoices', 'ca_services'],
    markdown: `### 1. Statutory Problem Deconstruction
- **Scenario Evaluated**: **"${userQuery}"**
- **Governing Legal Framework**: **Income Tax Act 2025**, Central Goods & Services Tax (CGST) Act 2017, and MSMED Act 2006.
${estimatedTax ? `- **Primary Evaluated Capital**: **${formatINR(estimatedTax.grossIncome)}** (Net tax under 2025 slabs: **${formatINR(estimatedTax.totalTax)}** @ effective ${estimatedTax.effectiveRate.toFixed(1)}%)` : ''}

---

### 2. Multi-Dimensional Regulatory & Financial Assessment

| Compliance Dimension | Statutory Clause | Required Standard |
| :--- | :--- | :--- |
| **Direct Taxation** | Income Tax Act 2025 (Chapter IV / XVII) | Ensure all operating expenses satisfy the commercial expediency test under Section 37(1). |
| **Indirect Tax (GST)** | CGST Act Sec 16 & Rule 36(4) | Input Tax Credit must 100% reconcile with vendor filings in **GSTR-2B**. |
| **MSME Protection** | MSMED Act Sec 15 & Income Tax Sec 43B(h) | Payment to registered micro/small vendors strictly within **45 days**. |
| **Advance Tax Buffer** | Sections 208-211 | Maintain 15% (Q1), 45% (Q2), 75% (Q3), 100% (Q4) to avoid Section 234C interest. |

---

### 3. Quantitative Risk & Optimization Strategy
- **Working Capital Health**: Keep liquid reserves equivalent to at least **3 months of fixed overhead** in an auto-sweep operational account.
- **Deduction Maximization**: Ensure all software licenses, cloud servers, travel, and contractor disbursements are supported with valid GST invoices.

---

### 4. Executable Action Items
1. Reconcile pending ledger line items: [ACTION:accounting]
2. Verify active advance tax computations: [ACTION:tax]
3. Audit invoice payment milestones: [ACTION:invoices]
4. Consult CA for specialized structuring: [ACTION:ca_services]`,
  };
}
