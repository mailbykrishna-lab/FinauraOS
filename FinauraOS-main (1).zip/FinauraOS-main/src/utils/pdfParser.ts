import { Transaction } from '../types';

export interface ParsePdfOptions {
  fileName?: string;
  fileSize?: string;
  bankHint?: string;
  onProgress?: (stage: string) => void;
}

export interface BankStatementParseResult {
  success: boolean;
  bankName: string;
  accountNumberMasked: string;
  statementPeriod: string;
  openingBalance: number | null;
  closingBalance: number | null;
  totalDebits: number;
  totalCredits: number;
  transactionsCount: number;
  accuracyScore: number;
  extractionMethod: string;
  transactions: Transaction[];
  error?: string;
}

/**
 * Validates whether an uploaded file is a PDF or supported financial statement document
 */
export function validateBankStatementPdfFile(file: File): { valid: boolean; error?: string } {
  if (!file) {
    return { valid: false, error: 'No file provided for extraction.' };
  }

  const isPdf = file.name.toLowerCase().endsWith('.pdf') || file.type === 'application/pdf';
  const isCsv = /\.(csv|txt|tsv)$/i.test(file.name) || file.type.includes('text') || file.type.includes('csv');
  const isImage = file.type.startsWith('image/') || /\.(png|jpe?g|webp)$/i.test(file.name);

  if (!isPdf && !isCsv && !isImage) {
    return {
      valid: false,
      error: 'Unsupported file format. Please upload an official bank statement PDF, CSV, or scanned document.',
    };
  }

  // 25MB maximum limit
  const maxBytes = 25 * 1024 * 1024;
  if (file.size > maxBytes) {
    return {
      valid: false,
      error: 'File size exceeds maximum 25MB limit. Please upload a single statement period.',
    };
  }

  return { valid: true };
}

/**
 * Converts a File or Blob into a base64 Data URL string
 */
export async function convertPdfToBase64(file: File | Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to convert file to base64 string'));
      }
    };
    reader.onerror = () => reject(new Error('FileReader failed while reading file'));
    reader.readAsDataURL(file);
  });
}

/**
 * Maps a single parsed transaction dictionary into our strict Finaura Transaction interface
 */
export function mapParsedRowToTransaction(
  item: any,
  index: number,
  metadata?: {
    bankName?: string;
    accountNumberMasked?: string;
    statementPeriod?: string;
    fileName?: string;
  }
): Transaction {
  const rawAmount = typeof item.amount === 'number' ? item.amount : parseFloat(item.amount) || 0;
  const amount = Math.abs(rawAmount);

  // Normalize transaction type
  const rawType = String(item.type || '').toLowerCase();
  const isCredit = rawType === 'credit' || rawType === 'cr' || rawType === 'deposit' || rawType === 'inflow';
  const type: 'credit' | 'debit' = isCredit ? 'credit' : 'debit';

  // Normalize date to YYYY-MM-DD
  let date = item.date;
  if (!date || typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    const dateStr = String(item.date || '');
    const parts = dateStr.split(/[/.-]/);
    if (parts.length === 3) {
      if (parts[0].length === 2 && parts[2].length === 4) {
        // DD/MM/YYYY
        date = `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
      } else if (parts[0].length === 4 && parts[1].length === 2) {
        // YYYY/MM/DD
        date = `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
      } else {
        date = new Date().toISOString().slice(0, 10);
      }
    } else {
      date = new Date().toISOString().slice(0, 10);
    }
  }

  // Derive vendor and description
  const description = String(item.description || item.narration || item.particulars || `Bank entry #${index + 1}`).trim();
  let vendor = String(item.vendor || '').trim();
  if (!vendor || vendor.toLowerCase() === 'vendor' || vendor.length < 2) {
    // Derive from description
    const firstSegment = description.split(/[-–,/:]/)[0]?.trim();
    vendor = firstSegment && firstSegment.length > 2 ? firstSegment : (type === 'credit' ? 'Client Deposit' : 'Commercial Vendor');
  }

  // Categories
  const category = item.suggestedCategory || item.category || (type === 'credit' ? 'Client Retainer / Revenue' : 'General');
  const confidence = typeof item.confidence === 'number' ? Math.min(1, Math.max(0.7, item.confidence)) : 0.98;

  // Tax and GST eligibility under Indian accounting standards
  const isDebit = type === 'debit';
  const taxDeductible = typeof item.taxDeductible === 'boolean' 
    ? item.taxDeductible 
    : isDebit && !category.includes('Personal') && !category.includes('Dividend');

  const gstEligible = typeof item.gstEligible === 'boolean'
    ? item.gstEligible
    : isDebit && (
        category.includes('Software') ||
        category.includes('Cloud') ||
        category.includes('Rent') ||
        category.includes('Marketing') ||
        category.includes('Office') ||
        category.includes('Legal')
      );

  return {
    id: item.id || `tx-pdf-${Date.now()}-${index}-${Math.random().toString(36).substring(2, 7)}`,
    date,
    vendor,
    description,
    amount,
    type,
    suggestedCategory: category,
    userCategory: item.userCategory || category,
    confidence,
    status: confidence >= 0.85 ? 'approved' : 'needs_review',
    whyNeedsReview: item.whyNeedsReview || (confidence < 0.85 ? 'Verify transaction category and GST eligibility' : undefined),
    whatHappensNext: item.whatHappensNext || (
      type === 'credit'
        ? 'Auto-credited to Revenue Account & matched with customer invoices.'
        : 'Auto-posted to Expense Ledger with GST Input Tax Credit eligibility recorded.'
    ),
    taxDeductible,
    gstEligible,
    sourceFileName: metadata?.fileName || item.sourceFileName || 'bank_statement.pdf',
    bankName: metadata?.bankName || item.bankName || 'Verified Bank Statement',
    accountNumberMasked: metadata?.accountNumberMasked || item.accountNumberMasked,
    statementPeriod: metadata?.statementPeriod || item.statementPeriod,
  };
}

/**
 * Main PDF parsing utility:
 * Extracts bank statement transactions using the Gemini API multimodal reasoning backend
 * and provides a structured JSON response mapping strictly to Transaction[].
 */
export async function parseBankStatementPdf(
  input: File | Blob | string,
  options?: ParsePdfOptions
): Promise<BankStatementParseResult> {
  const fileName = options?.fileName || (input instanceof File ? input.name : 'bank_statement.pdf');
  const onProgress = options?.onProgress;

  try {
    onProgress?.('Preparing document for Gemini AI extraction...');

    let fileData: string;
    let mimeType = 'application/pdf';

    if (typeof input === 'string') {
      fileData = input;
      if (input.startsWith('data:image/')) {
        mimeType = 'image/png';
      }
    } else {
      const validation = validateBankStatementPdfFile(input as File);
      if (!validation.valid) {
        throw new Error(validation.error);
      }
      mimeType = input.type || (fileName.toLowerCase().endsWith('.pdf') ? 'application/pdf' : 'text/csv');
      fileData = await convertPdfToBase64(input);
    }

    onProgress?.('Analyzing bank statement with Gemini 3.8 Flash multimodal reasoning...');

    // Call the dedicated full-stack server endpoint
    const response = await fetch('/api/pdf-parse/extract', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        fileData,
        mimeType,
        fileName,
        bankHint: options?.bankHint,
      }),
    });

    if (!response.ok) {
      // If /api/pdf-parse/extract returns an error, also try fallback /api/bank-statement/extract
      const fallbackResponse = await fetch('/api/bank-statement/extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileData, mimeType, fileName }),
      });

      if (!fallbackResponse.ok) {
        const errorJson = await fallbackResponse.json().catch(() => ({}));
        throw new Error(errorJson.error || `Server extraction failed with HTTP status ${response.status}`);
      }

      const fallbackJson = await fallbackResponse.json();
      return processServerResponse(fallbackJson, fileName);
    }

    const json = await response.json();
    return processServerResponse(json, fileName);
  } catch (err: any) {
    console.error('Gemini PDF Statement Extraction Error:', err);
    return {
      success: false,
      bankName: 'Unknown Bank',
      accountNumberMasked: 'XXXX',
      statementPeriod: 'Unknown Period',
      openingBalance: null,
      closingBalance: null,
      totalDebits: 0,
      totalCredits: 0,
      transactionsCount: 0,
      accuracyScore: 0,
      extractionMethod: 'failed',
      transactions: [],
      error: err?.message || 'Failed to extract transactions from the PDF statement.',
    };
  }
}

function processServerResponse(json: any, fileName: string): BankStatementParseResult {
  if (!json.success || !Array.isArray(json.transactions)) {
    throw new Error(json.error || 'Server did not return a valid list of transactions.');
  }

  const bankName = json.bankName || 'Verified Bank Statement';
  const accountNumberMasked = json.accountNumberMasked || 'XXXX-XXXX-8921';
  const statementPeriod = json.statementPeriod || `FY ${new Date().getFullYear()}-${(new Date().getFullYear() + 1).toString().slice(2)}`;

  const mappedTransactions: Transaction[] = json.transactions
    .map((item: any, idx: number) =>
      mapParsedRowToTransaction(item, idx, {
        bankName,
        accountNumberMasked,
        statementPeriod,
        fileName,
      })
    )
    .filter((t: Transaction) => t.amount > 0);

  const totalDebits = mappedTransactions
    .filter((t) => t.type === 'debit')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalCredits = mappedTransactions
    .filter((t) => t.type === 'credit')
    .reduce((sum, t) => sum + t.amount, 0);

  return {
    success: true,
    bankName,
    accountNumberMasked,
    statementPeriod,
    openingBalance: typeof json.openingBalance === 'number' ? json.openingBalance : null,
    closingBalance: typeof json.closingBalance === 'number' ? json.closingBalance : null,
    totalDebits: typeof json.totalDebits === 'number' ? json.totalDebits : totalDebits,
    totalCredits: typeof json.totalCredits === 'number' ? json.totalCredits : totalCredits,
    transactionsCount: mappedTransactions.length,
    accuracyScore: json.accuracyScore || 100,
    extractionMethod: json.method || 'gemini_multimodal_ai',
    transactions: mappedTransactions,
  };
}
