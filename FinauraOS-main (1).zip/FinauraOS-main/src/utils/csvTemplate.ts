export const FINAURA_CSV_TEMPLATE_CONTENT = `Date,Narration / Description,Chq_Ref_No,Withdrawal (Dr),Deposit (Cr),Balance
01/08/2026,NEFT-RAZORPAY-CLIENT-SUBSCRIPTION,UTR9482109,,185000.00,345200.00
03/08/2026,ACH/AMAZON WEB SERVICES CLOUD/INV921,ACH84019,18450.00,,326750.00
07/08/2026,UPI/GOOGLE WORKSPACE/948201,UPI94820,4200.00,,322550.00
10/08/2026,RTGS-TECHCORP-RETAINER-FEE,RTGS83910,,250000.00,572550.00
14/08/2026,CHQ-WEWORK INDIA LEASE AUGUST,CHQ000492,65000.00,,507550.00
20/08/2026,UPI/AIRTEL BROADBAND FIBER,UPI83912,1770.00,,505780.00
25/08/2026,NEFT-DEVELOPER-CONTRACTOR-PAYMENT,NEFT38910,45000.00,,460780.00
30/08/2026,BANK CONSOLIDATED MAINTENANCE CHARGES,REF00129,236.00,,460544.00`;

export const FINAURA_CSV_COLUMNS = [
  { name: 'Date', required: true, format: 'DD/MM/YYYY or YYYY-MM-DD', description: 'Transaction date' },
  { name: 'Narration / Description', required: true, format: 'Text', description: 'Vendor, customer, or transaction details' },
  { name: 'Chq_Ref_No', required: false, format: 'Text/Numeric', description: 'UTR, Cheque, or UPI reference number' },
  { name: 'Withdrawal (Dr)', required: false, format: 'Decimal (e.g. 18450.00)', description: 'Money spent / debited' },
  { name: 'Deposit (Cr)', required: false, format: 'Decimal (e.g. 185000.00)', description: 'Money received / credited' },
  { name: 'Balance', required: false, format: 'Decimal (e.g. 345200.00)', description: 'Running account balance after entry' },
];

export function downloadFinauraCsvTemplate(filename = 'finaura_transaction_template.csv'): void {
  const blob = new Blob([FINAURA_CSV_TEMPLATE_CONTENT], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
