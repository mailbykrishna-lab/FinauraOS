// Ambient type declarations for Next.js helpers used in Supabase server/middleware utilities
declare module 'next/headers' {
  export interface ReadonlyRequestCookies {
    get(name: string): { name: string; value: string } | undefined;
    getAll(): Array<{ name: string; value: string }>;
    set(name: string, value: string, options?: any): void;
    delete(name: string): void;
    has(name: string): boolean;
  }
  export function cookies(): Promise<ReadonlyRequestCookies>;
}

declare module 'next/server' {
  export class NextRequest {
    cookies: {
      get(name: string): { name: string; value: string } | undefined;
      getAll(): Array<{ name: string; value: string }>;
      set(name: string, value: string): void;
    };
    headers: Headers;
    url: string;
    constructor(input?: any, init?: any);
  }

  export class NextResponse extends Response {
    static next(init?: { request?: { headers?: Headers } }): NextResponse;
    cookies: {
      set(name: string, value: string, options?: any): void;
      get(name: string): { name: string; value: string } | undefined;
      delete(name: string): void;
    };
  }
}
