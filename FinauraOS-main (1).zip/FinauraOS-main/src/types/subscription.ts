export type PlanTier = 'free' | 'growth' | 'business' | 'professional' | 'ca_pro';

export type BillingCycle = 'monthly' | 'yearly';

export type SubscriptionStatus = 
  | 'trial'
  | 'active'
  | 'past_due'
  | 'cancelled'
  | 'expired'
  | 'scheduled_downgrade'
  | 'payment_failed'
  | 'demo';

export interface PlanLimit {
  aiQuestionsPerMonth: number;
  storageGB: number;
  invoicesPerMonth: number;
  teamMembers: number;
  businesses: number;
}

export interface PlanFeature {
  id: string;
  name: string;
  category: 'core' | 'accounting' | 'tax' | 'compliance' | 'ai' | 'collaboration' | 'ca_pro';
  description?: string;
  includedIn: PlanTier[];
  highlight?: boolean;
}

export interface PlanDefinition {
  id: PlanTier;
  name: string;
  tagline: string;
  purpose: string;
  priceMonthly: number;
  priceYearly: number; // billed annually
  monthlyEquivalentYearly: number;
  badge?: string;
  isPopular?: boolean;
  ctaText: string;
  targetAudience: string;
  features: string[];
  limits: PlanLimit;
  isCA?: boolean;
}

export interface UsageMetrics {
  aiQuestionsUsed: number;
  aiQuestionsLimit: number;
  storageUsedBytes: number;
  storageLimitBytes: number;
  invoicesCount: number;
  invoicesLimit: number;
  teamMembersCount: number;
  teamMembersLimit: number;
  businessesCount: number;
  businessesLimit: number;
}

export interface UserSubscription {
  planId: PlanTier;
  status: SubscriptionStatus;
  billingCycle: BillingCycle;
  currentPeriodStart: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
  pendingDowngradePlanId?: PlanTier;
  pendingDowngradeDate?: string;
  paymentMethod?: {
    type: 'upi' | 'card' | 'netbanking';
    last4?: string;
    brand?: string;
    vpa?: string;
    expiry?: string;
  };
  lastPaymentStatus?: 'success' | 'failed' | 'pending';
  lastPaymentDate?: string;
  lastPaymentAmount?: number;
  isDemoMode: boolean;
}

export interface BillingInvoice {
  id: string;
  invoiceNumber: string;
  date: string;
  planId: PlanTier;
  planName: string;
  amount: number;
  status: 'paid' | 'pending' | 'failed' | 'refunded';
  billingCycle: BillingCycle;
  paymentMethod: string;
  receiptUrl?: string;
}

export type FeatureKey =
  | 'basic_tracking'
  | 'invoicing'
  | 'unlimited_invoicing'
  | 'expense_intelligence'
  | 'receivables_payables'
  | 'compliance_updates'
  | 'compliance_reminders'
  | 'gst_workflow'
  | 'tds_workflow'
  | 'itr_workflow'
  | 'ai_financial_insights'
  | 'ai_document_analysis'
  | 'business_health_insights'
  | 'multiple_users'
  | 'advanced_accounting'
  | 'cashflow_analysis'
  | 'financial_forecasting'
  | 'inventory_management'
  | 'payroll_management'
  | 'vendor_management_43b'
  | 'advanced_compliance_workflow'
  | 'ca_collaboration'
  | 'priority_support'
  | 'multi_business'
  | 'audit_prep_workspace'
  | 'custom_permissions'
  | 'ca_client_management'
  | 'ca_client_document_requests'
  | 'ca_task_management'
  | 'ca_financial_review'
  | 'ca_ai_client_summaries'
  | 'ca_deadline_monitoring';
